<?php
namespace Chetu\Blog\Model;

class Blog extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Chetu\Blog\Model\ResourceModel\Blog');
    }
}
?>