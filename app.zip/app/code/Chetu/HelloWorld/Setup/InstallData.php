<?php
 
namespace Chetu\Helloworld\Setup;
 
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
 
class InstallData implements InstallDataInterface
{
    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $setup->startSetup();
 
        // Get blog_post_news table
        $tableName = $setup->getTable('blog_post_news');
        // Check if the table already exists
        if ($setup->getConnection()->isTableExists($tableName) == true) {
            // Declare data
            $data = [
                [
                    'title' => 'How to create a simple module install data',
                    'content' => 'The content',
                    'creation_time' => date('Y-m-d H:i:s'),
                    'is_active' => 1
                ],
                [
                    'title' => 'How to create a simple module',
                    'content' => 'The content',
                    'creation_time' => date('Y-m-d H:i:s'),
                    'is_active' => 1
                ]
            ];
 
            // Insert data to table
            foreach ($data as $item) {
                $setup->getConnection()->insert($tableName, $item);
            }
        }
 
        $setup->endSetup();
    }
}