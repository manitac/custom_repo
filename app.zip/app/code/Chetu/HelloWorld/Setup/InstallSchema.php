<?php
 
namespace Chetu\Helloworld\Setup;
 
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
 
class InstallSchema implements InstallSchemaInterface {
 
    public function install( SchemaSetupInterface $setup, ModuleContextInterface $context ) {
        $installer = $setup;
 
        $installer->startSetup();
 
        /**
         * Create table 'blog_post_news'
         */
        $table = $installer->getConnection()->newTable(
            $installer->getTable( 'blog_post_news' )
        )->addColumn(
            'post_id',
            Table::TYPE_SMALLINT,
            null,
            [ 'identity' => true, 'nullable' => false, 'primary' => true ],
            'Post ID'
        )->addColumn(
            'title',
            Table::TYPE_TEXT,
            255,
            [ 'nullable' => false ],
            'Post Title'
        
        )->addColumn(
            'content',
            Table::TYPE_TEXT,
            '2M',
            [ ],
            'Post Content'
        )->addColumn(
            'creation_time',
            Table::TYPE_TIMESTAMP,
            null,
            [ 'nullable' => false, 'default' => Table::TIMESTAMP_INIT ],
            'Post Creation Time'
        )->addColumn(
            'update_time',
            Table::TYPE_TIMESTAMP,
            null,
            [ 'nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE ],
            'Post Update Time'
        )->addColumn(
            'is_active',
            Table::TYPE_SMALLINT,
            null,
            [ 'nullable' => false, 'default' => '1' ],
            'Is Post Active'
        )->addIndex(
            $setup->getIdxName(
                $installer->getTable( 'blog_post_news' ),
                [ 'title','content' ],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            [ 'title', 'content' ],
            [ 'type' => AdapterInterface::INDEX_TYPE_FULLTEXT ]
        )->setComment(
            'Blog Post News Table'
        );
 
        $installer->getConnection()->createTable( $table );
 
        $installer->endSetup();
    }
}