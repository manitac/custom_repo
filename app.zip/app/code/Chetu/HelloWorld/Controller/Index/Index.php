<?php
 
namespace Chetu\Helloworld\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{

    protected $_cacheTypeList;


    protected $_cacheState;

    protected $_cacheFrontendPool;


    protected $resultPageFactory;


    public function __construct(
       \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Framework\App\Cache\StateInterface $cacheState,
        \Magento\Framework\App\Cache\Frontend\Pool $cacheFrontendPool,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->_cacheTypeList = $cacheTypeList;
        $this->_cacheState = $cacheState;
        $this->_cacheFrontendPool = $cacheFrontendPool;
        $this->resultPageFactory = $resultPageFactory;
    }


    public function execute()
    {
        $this->resultPage = $this->resultPageFactory->create();  
        return $this->resultPage;

    }
}