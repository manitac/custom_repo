<?php
namespace SilkSoftware\CatalogCustom\Observer;

class Test implements \Magento\Framework\Event\ObserverInterface
{
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
     /* $product = $observer->getEvent()->getData('product');
      
            $params = array(
                'product' => $product->getEntityId(),
                'qty' => 10
            );
            $_product = $this->_productRepository->getById($product->getEntityId());
            $this->_cart->addProduct($_product,$params);
            $this->_cart->save();*/
            return $this;
  }
}