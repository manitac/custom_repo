<?php
namespace Chetu\Blog\Observer;

class Customlogin implements \Magento\Framework\Event\ObserverInterface
{
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
     echo "this is the event observer called in Blog module in Chetu package";
     die;
  }
}