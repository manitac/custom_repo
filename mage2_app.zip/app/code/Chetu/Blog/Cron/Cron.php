<?php

namespace Chetu\Blog\Cron;
 
class Cron
{
	protected $logger;
 
	public function __construct(
		\Psr\Log\LoggerInterface $loggerInterface
	) {
		$this->logger = $loggerInterface;
	}
 
	public function execute() {

		//test command line
        //php bin/magento cron:run --group="chetu_blog_cron_group"
		//$this->logger->debug('Chetu\Blog\Cron\Cron');

	}
}