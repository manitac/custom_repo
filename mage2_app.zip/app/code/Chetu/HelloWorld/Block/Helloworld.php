<?php
namespace Chetu\Helloworld\Block;
 
class Helloworld extends \Magento\Framework\View\Element\Template
{

public function __construct(\Magento\Backend\Block\Template\Context $context,
    \Chetu\Helloworld\Model\NewsFactory $modelFactory,
    array $data = []
){
      $this->modelFactory = $modelFactory;
      parent::__construct($context, $data);
}

    public function getHelloWorldTxt()
    {
        echo 'Hello world!';

    }
    public function getNewsCollection() {
            $postModel = $this->modelFactory->create();

	        // Load the item with ID is 1
	        $item = $postModel->load(1);
	      //  var_dump($item->getData());

	        // Get news collection
	        $postCollection = $postModel->getCollection();
	return $postCollection;
      }


}