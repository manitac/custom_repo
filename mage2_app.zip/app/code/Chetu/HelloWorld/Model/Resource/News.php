<?php
 
namespace Chetu\Helloworld\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
 
class News extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('blog_posts_test', 'post_id');
    }
}