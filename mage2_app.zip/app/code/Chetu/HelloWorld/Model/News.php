<?php
 
namespace Chetu\Helloworld\Model;
 
use Magento\Framework\Model\AbstractModel;
 
class News extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Chetu\Helloworld\Model\Resource\News');
    }
}