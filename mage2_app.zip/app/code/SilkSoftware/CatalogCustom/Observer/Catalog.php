<?php
namespace SilkSoftware\CatalogCustom\Observer;

class Catalog implements \Magento\Framework\Event\ObserverInterface
{
  public function execute(\Magento\Framework\Event\Observer $observer)
  {
      echo "added for compare";
      die;
  }
}