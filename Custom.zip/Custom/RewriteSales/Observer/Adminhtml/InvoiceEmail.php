<?php  
namespace DocResearch\RewriteSales\Observer\Adminhtml;

class InvoiceEmail implements \Magento\Framework\Event\ObserverInterface
{ 


    public function execute(\Magento\Framework\Event\Observer $observer)
    { 
    	 $order= $observer;
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/tested'.time().'.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
      $logger->info("test");
         $logger->info(print_r($order, true));


     //$order->doSomething();

     return $this;

    }
}
?>