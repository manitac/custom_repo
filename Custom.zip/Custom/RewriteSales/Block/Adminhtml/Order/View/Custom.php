<?php

namespace DocResearch\RewriteSales\Block\Adminhtml\Order\View;

class Custom extends \Magento\Backend\Block\Template {
    
}
