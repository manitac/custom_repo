<?php

namespace DocResearch\RewriteSales\Block\Adminhtml\Order\View;

class Info extends \Magento\Sales\Block\Adminhtml\Order\View\Info {
    
}
