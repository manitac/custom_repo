<?php

namespace DocResearch\RewriteSales\Block\Adminhtml\Order\Create\Form;

use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Pricing\PriceCurrencyInterface;

class Account extends \Magento\Sales\Block\Adminhtml\Order\Create\Form\Account {

    protected $_metadataFormFactory;

    /**
     * Customer repository
     *
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepository;

    /**
     * @var \Magento\Framework\Api\ExtensibleDataObjectConverter
     */
    protected $_extensibleDataObjectConverter;
    protected $_formFactory;
    protected $_sessionQuote;
    protected $_customerSession;
    protected $_authSession;

    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Backend\Model\Session\Quote $sessionQuote, \Magento\Sales\Model\AdminOrder\Create $orderCreate, PriceCurrencyInterface $priceCurrency, \Magento\Framework\Data\FormFactory $formFactory, \Magento\Framework\Reflection\DataObjectProcessor $dataObjectProcessor, \Magento\Customer\Model\Metadata\FormFactory $metadataFormFactory, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository, \Magento\Framework\Api\ExtensibleDataObjectConverter $extensibleDataObjectConverter, array $data = []
    ) {
        $this->_formFactory = $formFactory;
        $this->_metadataFormFactory = $metadataFormFactory;
        $this->customerRepository = $customerRepository;
        $this->_extensibleDataObjectConverter = $extensibleDataObjectConverter;
        $this->_sessionQuote = $sessionQuote;
        parent::__construct(
                $context, $sessionQuote, $orderCreate, $priceCurrency, $formFactory, $dataObjectProcessor, $metadataFormFactory, $customerRepository, $extensibleDataObjectConverter, $data
        );
    }

    /**
     * Find collection for all the stores assigned to a customer
     * @return $this
     */
    public function getCustomerStoreCollection() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($this->_sessionQuote->getCustomerId());
        $restaurantId = $customerObj->getData('restaurant');

        $restaurantCollection = $objectManager->create('DocResearch\Restaurant\Model\ResourceModel\Template\Collection');

        /** Apply filters here */
        $restaurant_data = $restaurantCollection->addFieldToFilter('id', array('in' => $restaurantId));
        return $restaurant_data;
    }

    /**
     * Find current selected store from session
     * @return string
     */
    public function getSessionStore() {
        $sess_store = $this->_sessionQuote->getCurrentStore();
        return $sess_store;
    }

}

?>