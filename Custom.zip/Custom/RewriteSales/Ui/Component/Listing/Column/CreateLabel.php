<?php

namespace DocResearch\RewriteSales\Ui\Component\Listing\Column;

use \Magento\Sales\Api\OrderRepositoryInterface;
use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Magento\Framework\View\Element\UiComponentFactory;
use \Magento\Ui\Component\Listing\Columns\Column;
use \Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\UrlInterface;

class CreateLabel extends Column {

    protected $_orderRepository;
    protected $_searchCriteria;
    protected $_orderFactory;
    protected $urlBuilder;

    public function __construct(
    ContextInterface $context, UiComponentFactory $uiComponentFactory, OrderRepositoryInterface $orderRepository, \Magento\Sales\Model\OrderFactory $OrderFactory, UrlInterface $urlBuilder, SearchCriteriaBuilder $criteria, array $components = [], array $data = []) {
        $this->_orderRepository = $orderRepository;
        $this->_orderFactory = $OrderFactory;
        $this->urlBuilder = $urlBuilder;
        $this->_searchCriteria = $criteria;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Data source for create label link in order grid
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource) {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as & $item) {

                $order = $this->_orderFactory->create()->load($item["entity_id"]);
                $shipmentCollection = $order->getShipmentsCollection();
                $shipId = "";
                $shipmentID = $shipmentCollection->getData();
                if (!empty($shipmentID)) {
                    $shipId = $shipmentCollection->getData()[0]['entity_id'];
                }

                if (isset($item['entity_id'])) {
                    $viewUrlPath = $this->getData('config/viewUrlPath') ? : '#';
                    $urlEntityParamName = $this->getData('config/urlEntityParamName') ? : 'entity_id';
                    $item[$this->getData('name')] = [
                        'view' => [
                            'href' => $this->urlBuilder->getUrl(
                                    $viewUrlPath, [
                                $urlEntityParamName => $shipId
                                    ]
                            ),
                            'label' => __('Create Label')
                        ]
                    ];
                }
            }
        }

        return $dataSource;
    }

}
