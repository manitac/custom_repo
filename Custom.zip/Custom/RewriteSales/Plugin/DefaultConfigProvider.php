<?php

namespace DocResearch\RewriteSales\Plugin;
use \Magento\Checkout\Model\Session as CheckoutSession;
class DefaultConfigProvider
{
    protected $checkoutSession;

    public function __construct(
        CheckoutSession $checkoutSession
    ) {
        $this->checkoutSession = $checkoutSession;
    }
   
    public function afterGetConfig(\Magento\Checkout\Model\DefaultConfigProvider $subject, array $result)
    {
        
        $result['defaultBillingData'] = $this->getBillingData();
        return $result;
    }
    
    public function getBillingData(){
       
           
        /**
         * Get Restaurant Settings
         * As per Admin
         */
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSessionFac = $objectManager->get('Magento\Customer\Model\SessionFactory')->create();
        $c_id = $customerSessionFac->getCustomer()->getId();
        $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($c_id);

        #Define var Blank
        $store_restaurant_id = "";
        $shipping_method = "";
        $quoteBillingData = array();

        #Get Restaurant Id
        $store_restaurant_id = $customerObj->getRestaurant();

        /* Get Restaurant Collection */
        $restaurantCollection = $objectManager->create('DocResearch\Restaurant\Model\ResourceModel\Template\Collection');
        
        /** Apply filters here */
        $restaurant_data = $restaurantCollection->addFieldToFilter('id', array('eq' => $store_restaurant_id));
        /**
         * 1 Corporate Address
         * 2 Third Party Address
         */
        $firstname = "";
        $lastname = "";

        $corporate_billing = $restaurant_data->getData()[0]['corporate_billing'];

        $region_id = $restaurant_data->getData()[0]['state'];
        $region    = $objectManager->create('Magento\Directory\Model\ResourceModel\Region\Collection')
                        ->addFieldToFilter('main_table.region_id', ['eq' => $region_id])
                        ->getFirstItem();


        if($corporate_billing == 1){
            if(!empty($restaurant_data->getData()[0]['contact_name'])){
                $contact_name = explode(" ", $restaurant_data->getData()[0]['contact_name']);
                $firstname = $contact_name[0];
                $lastname = $contact_name[1];
            }

            $quoteBillingData = [
                //"email"      => $restaurant_data->getData()[0]['email'],
                "email"      => '',
                "firstname"  => $firstname,
                "lastname"   => $lastname,
                "company"    => $restaurant_data->getData()[0]['brand_name'],
                "street"     => array($restaurant_data->getData()[0]['address']),
                "city"       => $restaurant_data->getData()[0]['city'],
                "postcode"   => $restaurant_data->getData()[0]['zip'],
                "telephone"  => $restaurant_data->getData()[0]['phone_number'],
                "countryId"  => $restaurant_data->getData()[0]['country'],
                "save_in_address_book"  =>  "0",
                "customer_address_id"   =>  Null,
                "regionId"   =>  $region_id,
                "region"  => $region->getName(),   // id from directory_country_region table                
            ];

        } elseif($corporate_billing == 2) {
                
            /* Third Party Address Collection */
            $thridPartyCollection = $objectManager->create('DocResearch\Restaurant\Model\ResourceModel\Address\Collection');
        
            /** Apply filters here */
            $thirdParty_data = $thridPartyCollection->addFieldToFilter('restaurant_id', array('eq' => $store_restaurant_id));
            $region_id = $thirdParty_data->getData()[0]['state'];
            $region = $objectManager->create('Magento\Directory\Model\ResourceModel\Region\Collection')
                        ->addFieldToFilter('main_table.region_id', ['eq' => $region_id])
                        ->getFirstItem();

            $quoteBillingData = [
                //"email"      => $thirdParty_data->getData()[0]['email'],
                "email"      => '',
                "firstname"  => '',
                "lastname"   => '',
                "company"    => $thirdParty_data->getData()[0]['company_name'],
                "street"     => array($thirdParty_data->getData()[0]['address'], $thirdParty_data->getData()[0]['address2']),
                "city"       => $thirdParty_data->getData()[0]['city'],
                "postcode"   => $thirdParty_data->getData()[0]['zip'],
                "telephone"  => '',
                "countryId"  => $thirdParty_data->getData()[0]['country'],
                "save_in_address_book"  =>  "0",
                "customer_address_id"   =>  Null,
                "regionId"   =>  $region_id,
                "region"  => $region->getName(), // id from directory_country_region table
            ];
        } else {

            $quoteBillingData = [
                "email"      => $this->checkoutSession->getQuote()->getData('email'),
                "firstname"  => $this->checkoutSession->getQuote()->getData('firstname'),
                "lastname"   => $this->checkoutSession->getQuote()->getData('lastname'),
                "company"    => $this->checkoutSession->getQuote()->getData('company'),
                "street"     => array($this->checkoutSession->getQuote()->getData('street')),
                "city"       => $this->checkoutSession->getQuote()->getData('city'),
                "postcode"   => $this->checkoutSession->getQuote()->getData('postcode'),
                "telephone"  => $this->checkoutSession->getQuote()->getData('telephone'),
                "countryId"  => $this->checkoutSession->getQuote()->getData('country'),
                "save_in_address_book"  =>  "0",
                "customer_address_id"   =>  Null,
                "regionId"   =>  $this->checkoutSession->getQuote()->getData('region_id'),
                "region"  => $this->checkoutSession->getQuote()->getData('region'), // id from directory_country_region table
            ];
        }

        return $quoteBillingData;

    }

}

