<?php

/**
 * SalesPersonReport setup to create module table
 */

namespace DocResearch\SalesPersonReport\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema to create module table
 */
class InstallSchema implements InstallSchemaInterface {

    /**
     * install Action
     * @retrun bool
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;
        $installer->startSetup();
        $salesPersonTable = $installer->getConnection()->newTable(
                        $installer->getTable('salespersonreport_template'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'orderid', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'orderid'
                )
                ->addColumn(
                        'products', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'products name'
                )
                ->addColumn(
                        'sals_prsn_name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Person name'
                )
                ->addColumn(
                        'percentage', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'percentage'
                )
                ->addColumn(
                        'commission', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'commission amount'
                )
                ->addColumn(
                        'order_price', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'base price'
                )
                ->addColumn(
                        'qty', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'quantity'
                )
                ->addColumn(
                        'customer_store', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'customer store'
                )
                ->addColumn(
                        'customer_store_id', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'customer store id'
                )
                ->addColumn(
                        'restaurant_id', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 0, ['nullable' => false], 'Restaurant ID'
                )
                ->addColumn(
                        'store_id', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 0, ['nullable' => false], 'Store ID'
                )
                ->addColumn(
                        'restaurent_name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 0, ['nullable' => false], 'restaurent name'
                )
                ->addColumn(
                        'order_date', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 0, ['nullable' => false], 'order date'
                )
                ->addColumn(
                'sales_person_id', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, 0, ['nullable' => false], 'sales person id'
        );
        $installer->getConnection()->createTable($salesPersonTable);
        $installer->getConnection()->addIndex($installer->getTable('salespersonreport_template'), $setup->getIdxName($installer->getTable('salespersonreport_template'), ['sals_prsn_name', 'products', 'restaurent_name', 'customer_store'], \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
                ), ['sals_prsn_name', 'products', 'restaurent_name', 'customer_store'], \Magento\Framework\DB\Adapter\AdapterInterface::INDEX_TYPE_FULLTEXT
        );

        $installer->endSetup();
    }

}
