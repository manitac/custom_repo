<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * SalesPersonReport Edit Form Block
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 */

namespace DocResearch\SalesPersonReport\Block\Adminhtml\Template\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic {

    /**
     * @var \DocResearch\SalesPersonReport\Helper\Option
     */
    protected $_statusOption;
    protected $_countryFactory;
    protected $_templateFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig
     * @param array $data
     */
    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Registry $registry, \Magento\Framework\Data\FormFactory $formFactory, \DocResearch\SalesPersonReport\Helper\Option $optionData, \Magento\Directory\Model\Config\Source\Country $countryFactory, \DocResearch\Restaurant\Model\TemplateFactory $templateFactory, \DocResearch\Store\Model\TemplateFactory $storeFactory, array $data = []
    ) {
        $this->_templateFactory = $templateFactory;
        $this->_storeFactory = $storeFactory;
        $this->_statusOption = $optionData;
        $this->_countryFactory = $countryFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Retrieve template object
     *
     * @return \Magento\SalesPersonReport\Model\Template
     */
    public function getModel() {
        return $this->_coreRegistry->registry('_salesperson_template');
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm() {
        $model = $this->getModel();


        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
                ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('SalesPersonReport Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id', 'value' => $model->getId()]);
        }

        $fieldset->addField(
                'restaurant_id', 'select', [
            'name' => 'restaurant_id',
            'label' => __('Restaurant/Brand'),
            'required' => true,
            'value' => $model->getRestaurantId(),
            'values' => $this->getApprovedBrand(),
                ]
        );

        $fieldset->addField(
                'store_id', 'select', [
            'name' => 'store_id',
            'label' => __('Store Name'),
            'required' => true,
            'value' => $model->getStoreId(),
            'values' => $this->getSelectedStore($model->getStoreId()),
                ]
        );

        $fieldset->addField(
                'sales_person', 'text', [
            'name' => 'sales_person',
            'label' => __('Sales Person Name'),
            'title' => __('Sales Person Name'),
            'required' => true,
            'value' => $model->getSalesPerson()
                ]
        );

        $fieldset->addField(
                'sales_commission', 'text', [
            'name' => 'sales_commission',
            'label' => __('Sales Commission'),
            'title' => __('Sales Commission'),
            'required' => true,
            'value' => $model->getSalesCommission()
                ]
        );

        $fieldset->addField(
                'email', 'text', [
            'name' => 'email',
            'label' => __('Email'),
            'title' => __('Email'),
            'required' => true,
            'value' => $model->getEmail()
                ]
        );

        $fieldset->addField(
                'phone_number', 'text', [
            'name' => 'phone_number',
            'label' => __('Phone Number'),
            'title' => __('Phone Number'),
            'required' => true,
            'value' => $model->getPhoneNumber()
                ]
        );

        $fieldset->addField(
                'address', 'text', [
            'name' => 'address',
            'label' => __('Address'),
            'title' => __('Address'),
            'required' => true,
            'value' => $model->getAddress()
                ]
        );

        $fieldset->addField(
                'city', 'text', [
            'name' => 'city',
            'label' => __('City'),
            'title' => __('City'),
            'required' => true,
            'value' => $model->getCity()
                ]
        );


        $fieldset->addField(
                'zip', 'text', [
            'name' => 'zip',
            'label' => __('Zip Code'),
            'title' => __('Zip Code'),
            'required' => true,
            'value' => $model->getZip()
                ]
        );


        $fieldset->addField(
                'status', 'select', [
            'label' => __('Status'),
            'required' => true,
            'name' => 'status',
            'value' => $model->getStatus(),
            'values' => $this->_statusOption->getStatusesOptionArray()
                ]
        );

        $optionsc = $this->_countryFactory->toOptionArray();
        $country = $fieldset->addField(
                'country', 'select', [
            'name' => 'country',
            'label' => __('Country'),
            'title' => __('Country'),
            'value' => $model->getCountry(),
            'values' => $optionsc,
                ]
        );

        $fieldset->addField(
                'state', 'text', [
            'name' => 'state',
            'label' => __('State'),
            'title' => __('State'),
            'required' => false,
            'value' => $model->getState(),
                ]
        );


        /*
         * Add Ajax to the Country select box html output
         */
        $country->setAfterElementHtml("   
            <script type=\"text/javascript\">
                    require([
                    'jquery',
                ],
              function($) {
                   $('#salesperson_template_edit_form').on('change', '#country', function(event){
					   var country_code = $('#country').val();
					   if(country_code == 'US') {
                        $.ajax({
                               url : '" . $this->getUrl('restaurant/*/regionlist') . "country/' +  $('#country').val(),
                                type: 'get',
                                dataType: 'json',
                               showLoader:true,
                               success: function(data){
                                    $('#state').parent().html(data.htmlconent);
                               }
                            });
					   }	
                    });
                   $('#salesperson_template_edit_form').on('change', '#restaurant_id', function(event){  
                        $.ajax({
                               url : '" . $this->getUrl('salespersonreport/*/storelist') . "restaurant_id/' +  $('#restaurant_id').val(),
                                type: 'get',
                                dataType: 'json',
                               showLoader:true,
                               success: function(data){
                                    $('#store_id').parent().html(data.htmlconent);
                               }
                            });
                    })
				   }

            );
            </script>"
        );

        $form->setAction($this->getUrl('*/*/save'));
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Retrieve Approved store
     *
     * @return array
     */
    public function getApprovedBrand() {
        $brandCollection = $this->_templateFactory->create()->getCollection()
                ->addFieldToFilter('status', 1);
        $brands = $brandCollection->getData();
        $brandData[] = [
            'value' => '',
            'label' => 'Please Select Restaurant',
        ];
        foreach ($brands as $brand) {
            $brandData[] = [
                'value' => $brand['id'],
                'label' => $brand['name'],
            ];
        }

        return $brandData;
    }

    /**
     * Retrieve Approved store
     *
     * @return array
     */
    public function getSelectedStore($sales_store_id) {
        $brandCollection = $this->_storeFactory->create()->getCollection()
                ->addFieldToFilter('id', $sales_store_id);
        $brands = $brandCollection->getData();
        if (empty($brands)) {
            $brandData[] = [
                'value' => '',
                'label' => 'Please select store',
            ];
        } else {
            foreach ($brands as $brand) {
                $brandData[] = [
                    'value' => $brand['id'],
                    'label' => $brand['name'],
                ];
            }
        }
        return $brandData;
    }

}
