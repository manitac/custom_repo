<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * Sales Person content block
 *
 */

namespace DocResearch\SalesPersonReport\Block\Adminhtml;

class Template extends \Magento\Backend\Block\Template {

    /**
     * @var string
     */
    protected $_template = 'template/list.phtml';

    /**
     * @return $this
     */
    protected function _prepareLayout() {
        return parent::_prepareLayout();
    }

    /**
     * Get the url for create
     *
     * @return string
     */
    public function getCreateUrl() {
        return $this->getUrl('*/*/new');
    }

    /**
     * Get header text
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText() {
        return __(' Sales Report');
    }

}
