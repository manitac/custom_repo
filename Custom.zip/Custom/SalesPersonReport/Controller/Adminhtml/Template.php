<?php

/**
 * SalesPersonReport controller  
 *
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml;

/**
 * Template abstract Class for authrization
 */
abstract class Template extends \Magento\Backend\App\Action {

    /**
     * @return bool
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('DocResearch_SalesPersonReport::salespersonreport_template');
    }

}
