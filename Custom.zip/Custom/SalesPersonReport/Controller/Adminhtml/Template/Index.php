<?php

/**
 * SalesPersonReport Index Controller  
 *
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action {

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
    Context $context, PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        $OrdertableName = $resource->getTableName('sales_order');
        $report_table_name = $resource->getTableName('salespersonreport_template');
        $get_order_data = "SELECT  entity_id, sales_person_name, sales_person_id, sales_person_percentage, status, products_name, created_at, total_item_count, base_subtotal, customer_store_id, customer_store_name, restaurant_name, total_qty_ordered   FROM " . $OrdertableName . " WHERE status = 'complete'";

        $orders = $connection->fetchAll($get_order_data);


        foreach ($orders as $order) {

            $report_data = "SELECT * FROM " . $report_table_name . " WHERE orderid = '" . $order['entity_id'] . "'";
            $reports = $connection->fetchAll($report_data);

            if (count($reports) > 0) {
                continue;
            } else {
                $priceHelper = $objectManager->create('Magento\Framework\Pricing\Helper\Data'); // Instance of Pricing Helper
                $commission = 0;
                $commission = ($order['base_subtotal'] * $order['sales_person_percentage']) / 100;
                $commission = $priceHelper->currency($commission, true, false);

                $qty = intval($order['total_qty_ordered']);


                $formattedPrice = $priceHelper->currency($order['base_subtotal'], true, false);

                $sql_report_update = "INSERT INTO " . $report_table_name . " (orderid, products, sals_prsn_name, percentage, order_price, qty, customer_store, customer_store_id, restaurent_name, sales_person_id, order_date, commission) VALUES ('" . $order['entity_id'] . "','" . addslashes($order['products_name']) . "','" . addslashes($order['sales_person_name']) . "','" . $order['sales_person_percentage'] . "','" . $formattedPrice . "','" . $qty . "','" . addslashes($order['customer_store_name']) . "','" . $order['customer_store_id'] . "','" . addslashes($order['restaurant_name']) . "','" . $order['sales_person_id'] . "','" . $order['created_at'] . "','" . $commission . "')";

                $connection->query($sql_report_update);
            }
        }

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('DocResearch_SalesPersonReport::salespersonreport_template_ui');
        $resultPage->addBreadcrumb(__('SalesPersonReport'), __('SalesPersonReport'));
        $resultPage->addBreadcrumb(__('SalesPersonReport'), __('SalesPersonReport'));
        $resultPage->getConfig()->getTitle()->prepend(__('Sales Report'));

        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('DocResearch_SalesPersonReport::salespersonreport_template');
    }

}
