<?php

/**
 * SalesPersonReport Edit Controller
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

class Edit extends \DocResearch\SalesPersonReport\Controller\Adminhtml\Template {

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry) {
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context);
    }

    /**
     * Edit SalesPersonReport Template
     *
     * @return void
     */
    public function execute() {
        $model = $this->_objectManager->create('DocResearch\SalesPersonReport\Model\Template');
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            $model->load($id);
        }

        $this->_coreRegistry->register('_salesperson_template', $model);

        $this->_view->loadLayout();
        $this->_setActiveMenu('DocResearch_SalesPersonReport::salespersonreport_template');

        if ($model->getId()) {
            $breadcrumbTitle = __('Edit SalesPersonReport');
            $breadcrumbLabel = $breadcrumbTitle;
        } else {
            $breadcrumbTitle = __('New SalesPersonReport');
            $breadcrumbLabel = __('Create SalesPersonReport');
        }
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('SalesPersonReports'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
                $model->getId() ? $model->getTemplateId() : __('New SalesPersonReport')
        );

        $this->_addBreadcrumb($breadcrumbLabel, $breadcrumbTitle);

        // restore data
        $values = $this->_getSession()->getData('salespersonreport_template_form_data', true);
        if ($values) {
            $model->addData($values);
        }

        $this->_view->renderLayout();
    }

}
