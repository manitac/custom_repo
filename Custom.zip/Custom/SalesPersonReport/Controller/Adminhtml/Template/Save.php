<?php

/**
 * SalesPersonReport Save Controller
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;

class Save extends \DocResearch\SalesPersonReport\Controller\Adminhtml\Template {

    /**
     * Save SalesPersonReport Details
     *
     * @return void
     */
    public function execute() {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/template'));
        }
        $template = $this->_objectManager->create('DocResearch\SalesPersonReport\Model\Template');
        $id = (int) $request->getParam('id');

        if ($id) {
            $template->load($id);
        }
        try {

            $template->setData('sales_person', $request->getParam('sales_person')
            )->setData('phone_number', $request->getParam('phone_number')
            )->setData('email', $request->getParam('email')
            )->setData('sales_commission', $request->getParam('sales_commission')
            )->setData('address', $request->getParam('address')
            )->setData('city', $request->getParam('city')
            )->setData('state', $request->getParam('state')
            )->setData('country', $request->getParam('country')
            )->setData('zip', $request->getParam('zip')
            )->setData('restaurant_id', $request->getParam('restaurant_id')
            )->setData('store_id', $request->getParam('store_id')
            )->setData('status', $request->getParam('status')
            );
            $template->save();
            $this->messageManager->addSuccess(__('The SalesPersonReport has been saved.'));
            $this->_getSession()->setFormData(false);
        } catch (LocalizedException $e) {

            $this->messageManager->addError(nl2br($e->getMessage()));
            $this->_getSession()->setData('salesperson_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        } catch (\Exception $e) {

            $this->messageManager->addException($e, __('Something went wrong while saving this SalesPersonReport.'));
            $this->_getSession()->setData('salesperson_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        }

        return $resultRedirect->setPath('*/*/');
    }

}
