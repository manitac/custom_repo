<?php

/**
 * SalesPersonReport Save Controller
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Controller\ResultFactory;

class StoreList extends \DocResearch\SalesPersonReport\Controller\Adminhtml\Template {

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \DocResearch\Store\Model\TemplateFactory
     */
    protected $_templateFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \DocResearch\Store\Model\TemplateFactory $templateFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_templateFactory = $templateFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return void
     */
    public function execute() {
        $restaurant_id = $this->getRequest()->getParam('restaurant_id');
        $storeCollection = $this->_templateFactory->create()->getCollection()
                        ->addFieldToFilter('restaurant_id', $restaurant_id)->toOptionArray();
        if (!empty($storeCollection)) {
            $store = '<select id="store_id" name="store_id" title="Region" class=" select admin__control-select" data-ui-id="template-edit-form-fieldset-element-select-store_id">';
            $store .= "<option value=''>--Please Select--</option>";
            foreach ($storeCollection as $storelist) {
                if ($storelist['value']) {
                    $store .= "<option value='" . $storelist['value'] . "'>" . $storelist['label'] . "</option>";
                }
            }
            $store .= "</select>";
        }
        $result['htmlconent'] = $store;
        $this->getResponse()->representJson(
                $this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result)
        );
    }

}
