<?php
/**
 * SalesPersonReport NewAction Controller
 */
namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

class NewAction extends \DocResearch\SalesPersonReport\Controller\Adminhtml\Template
{
    /**
     * Create new SalesPersonReport
     *
     * @return void
     */
    public function execute()
    {
        $this->_forward('edit');
    }
}
