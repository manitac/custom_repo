<?php

/**
 * SalesPersonReport Grid Controller
 */

namespace DocResearch\SalesPersonReport\Controller\Adminhtml\Template;

/**
 * Grid Class for creating grid
 */
class Grid extends \DocResearch\SalesPersonReport\Controller\Adminhtml\Template {

    /**
     * Managing SalesPersonReport grid
     *
     * @return void
     */
    public function execute() {
        $this->_view->loadLayout(false);
        $this->_view->renderLayout();
    }

}
