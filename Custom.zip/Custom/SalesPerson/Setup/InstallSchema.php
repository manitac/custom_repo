<?php

/**
 * SalesPerson setup to create module table
 */

namespace DocResearch\SalesPerson\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema to create module table
 */
class InstallSchema implements InstallSchemaInterface {

    /**
     * install Action
     * @retrun bool
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;
        $installer->startSetup();
        $salesPersonTable = $installer->getConnection()->newTable(
                        $installer->getTable('salesperson_template'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'email', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Email'
                )
                ->addColumn(
                        'sales_person', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Person'
                )
                ->addColumn(
                        'sales_commission', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Commission'
                )
                ->addColumn(
                        'total_earning', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Total Earning'
                )
                ->addColumn(
                        'phone_number', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Phone Number'
                )
                ->addColumn(
                        'address', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Address'
                )
                ->addColumn(
                        'city', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'City'
                )
                ->addColumn(
                        'state', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'State'
                )
                ->addColumn(
                        'country', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Country'
                )
                ->addColumn(
                        'zip', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['nullable' => false], 'Zip'
                )
                ->addColumn(
                        'restaurant_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Restaurant ID'
                )
                ->addColumn(
                        'store_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Store ID'
                )
                ->addColumn(
                'status', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Status'
        );
        $installer->getConnection()->createTable($salesPersonTable);

        $salesPersonCommisionTable = $installer->getConnection()->newTable(
                        $installer->getTable('salesperson_commision'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'salesperson_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Sales Person ID'
                )
                ->addColumn(
                        'paid_date', \Magento\Framework\DB\Ddl\Table::TYPE_DATETIME, 0, ['nullable' => false], 'Paid Date'
                )
                ->addColumn(
                        'paid_amount', \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, '12,4', ['nullable' => false], 'Paid Amount'
                )
                ->addColumn(
                'remaining_amount', \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, '12,4', ['nullable' => false], 'Remaining Amount'
        );

        $installer->getConnection()->createTable($salesPersonCommisionTable);


        $installer->endSetup();
    }

}
