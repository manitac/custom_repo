<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * SalesPerson Edit Form Block
 *
 * @author     Magento Core Team <core@magentocommerce.com>
 */

namespace DocResearch\SalesPerson\Block\Adminhtml\Template\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic {

    /**
     * @var \DocResearch\SalesPerson\Helper\Option
     */
    protected $_statusOption;
    protected $_countryFactory;
    protected $_templateFactory;
    protected $_regionColFactory;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig
     * @param array $data
     */
    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Framework\Registry $registry, \Magento\Framework\Data\FormFactory $formFactory, \DocResearch\SalesPerson\Helper\Option $optionData, \Magento\Directory\Model\Config\Source\Country $countryFactory, \DocResearch\Restaurant\Model\TemplateFactory $templateFactory, \Magento\Directory\Model\RegionFactory $regionColFactory, \DocResearch\Store\Model\TemplateFactory $storeFactory, array $data = []
    ) {
        $this->_templateFactory = $templateFactory;
        $this->_regionColFactory = $regionColFactory;
        $this->_storeFactory = $storeFactory;
        $this->_statusOption = $optionData;
        $this->_countryFactory = $countryFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Retrieve template object
     *
     * @return \Magento\SalesPerson\Model\Template
     */
    public function getModel() {
        return $this->_coreRegistry->registry('_salesperson_template');
    }

    /**
     * Prepare form before rendering HTML
     *
     * @return $this
     * @SuppressWarnings(PHPMD.NPathComplexity)
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    protected function _prepareForm() {
        $model = $this->getModel();

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
                ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('SalesPerson Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id', 'value' => $model->getId()]);
        }

        $fieldset->addField(
            'sales_person', 'text', [
            'name' => 'sales_person',
            'label' => __('Sales Person Name'),
            'title' => __('Sales Person Name'),
            'required' => true,
            'value' => $model->getSalesPerson()
            ]
        );

        $fieldset->addField(
            'total_earning', 'text', [
            'name' => 'total_earning',
            'label' => __('Total Earning'),
            'title' => __('Total Earning'),
            'disabled' => true,
            'required' => true,
            'value' => $model->getTotalEarning()
            ]
        );

        $fieldset->addField(
            'email', 'text', [
            'name' => 'email',
            'label' => __('Email'),
            'title' => __('Email'),
            'class' => 'validate-email',
            'required' => true,
            'value' => $model->getEmail()
            ]
        );

        $fieldset->addField(
            'phone_number', 'text', [
            'name' => 'phone_number',
            'label' => __('Phone Number'),
            'title' => __('Phone Number'),
            //'class' => 'validate-digits validate-length minimum-length-10 maximum-length-10',
            'class' => 'validate-phoneStrict',
            'required' => true,
            'value' => $model->getPhoneNumber()
            ]
        );

        $fieldset->addField(
                'address', 'text', [
            'name' => 'address',
            'label' => __('Address Line 1'),
            'title' => __('Address Line 1'),
            'required' => true,
            'value' => $model->getAddress()
                ]
        );
        
        $fieldset->addField(
                'address2', 'text', [
            'name' => 'address2',
            'label' => __('Address Line 2'),
            'title' => __('Address Line 2'),
            'value' => $model->getAddressLine()
                ]
        );

        $fieldset->addField(
            'city', 'text', [
            'name' => 'city',
            'label' => __('City'),
            'title' => __('City'),
            'required' => true,
            'value' => $model->getCity()
            ]
        );

		$fieldset->addField(
            'state', 'select', [
            'name' => 'state',
            'label' => __('State'),
            'title' => __('State'),
            'required' => false,
            'value' => $model->getState(),
            'values' => $this->stateListDropDown()
            ]
        );

        $fieldset->addField(
            'zip', 'text', [
            'name' => 'zip',
            'label' => __('Zip Code3'),
            'title' => __('Zip Code'),
            'class' => 'validate-digits validate-length minimum-length-4 maximum-length-6',
            'required' => true,
            'value' => $model->getZip()
            ]
        );

		 $optionsc = array('US' => 'United States');
        $country = $fieldset->addField(
            'country', 'select', [
            'name' => 'country',
            'label' => __('Country'),
            'title' => __('Country'),
            'value' => $model->getCountry(),
            'values' => $optionsc,
            ]
        );
		
        $fieldset->addField(
            'status', 'select', [
            'label' => __('Status'),
            'required' => true,
            'name' => 'status',
            'value' => $model->getStatus(),
            'values' => $this->_statusOption->getStatusesOptionArray()
            ]
        );

       

        

        if ($model->getTotalEarning() > 0) {

            $fieldset->addField(
                'pay_today', 'checkbox', [
                'name' => 'pay_today',
                'label' => __('Pay Today'),
                'title' => __('Pay Today'),
                'required' => false,
                'onclick' => 'this.value = this.checked ? 1 : 0;'
                ]
            );

            $fieldset->addField(
                'amount', 'text', [
                'name' => 'amount',
                'label' => __('Paid Amount'),
                'title' => __('Paid Amount'),
                'required' => false
                ]
            );
        }

         /*
          * Add Ajax to the Country select box html output
          */
        $country->setAfterElementHtml("   
            <script type=\"text/javascript\">
                    require([
                    'jquery',
                ],
                function($) {
                     $('#phone_number').on('input', function() {
                            $('#phone_number').attr('maxlength', '14');
                            var number = $(this).val().replace(/[^\d]/g, '')
                            if (number.length == 7) {
                                    number = number.replace(/(\d{3})(\d{4})/, '$1-$2');
                            } else if (number.length == 10) {
                                    number = number.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
                            }
                            $(this).val(number)
                    });
                }
            );
            </script>"
        );

        $form->setAction($this->getUrl('*/*/save'));
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Retrieve Approved store
     *
     * @return array
     */
    public function getApprovedBrand() {
        $brandCollection = $this->_templateFactory->create()->getCollection()
                ->addFieldToFilter('status', 1);
        $brands = $brandCollection->getData();
        foreach ($brands as $brand) {
            $brandData[] = [
                'value' => $brand['id'],
                'label' => $brand['name'],
            ];
        }

        return $brandData;
    }

    /**
     * Retrieve State list of US country
     *
     * @return array
     */
    public function stateListDropDown() {
        $state_list = $this->_regionColFactory->create()->getCollection()->addFieldToFilter('country_id', 'US');
        $final_state_list = $state_list->toOptionArray();
        return $final_state_list;
    }

}
