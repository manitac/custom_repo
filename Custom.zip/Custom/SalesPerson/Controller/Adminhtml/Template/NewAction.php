<?php

/**
 * SalesPerson NewAction Controller
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml\Template;

class NewAction extends \DocResearch\SalesPerson\Controller\Adminhtml\Template {

    /**
     * Create new SalesPerson
     *
     * @return void
     */
    public function execute() {
        $this->_forward('edit');
    }

}
