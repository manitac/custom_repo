<?php

/**
 * SalesPerson Grid Controller
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml\Template;

/**
 * Grid Class for creating grid
 */
class Grid extends \DocResearch\SalesPerson\Controller\Adminhtml\Template {

    /**
     * Managing SalesPerson grid
     *
     * @return void
     */
    public function execute() {
        $this->_view->loadLayout(false);
        $this->_view->renderLayout();
    }

}
