<?php

/**
 * SalesPerson Index Controller  
 *
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml\Template;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use DocResearch\SalesPerson\Model\TemplateFactory;
use DocResearch\SalesPerson\Model\CommisionFactory;

class Index extends \Magento\Backend\App\Action {

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;
    protected $_templateFactory;
    protected $_commisionFactory;
    protected $_orderCollectionFactory;
    protected $_objectManager;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
    Context $context, PageFactory $resultPageFactory, TemplateFactory $templateFactory, CommisionFactory $commisionFactory, \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
    ) {
        $this->_templateFactory = $templateFactory;
        $this->_commisionFactory = $commisionFactory;
        $this->resultPageFactory = $resultPageFactory;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        parent::__construct($context);
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute() {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $order_data = $this->getOrders();
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('DocResearch_SalesPerson::salesperson_template_ui');
        $resultPage->addBreadcrumb(__('SalesPerson'), __('SalesPerson'));
        $resultPage->addBreadcrumb(__('SalesPerson'), __('SalesPerson'));
        $resultPage->getConfig()->getTitle()->prepend(__('SalesPerson'));
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('DocResearch_SalesPerson::salesperson_template');
    }

    /**
     * Take all the orders of a sales person
     * @param nothing
     * @return nothing, Update total earning of SalesPerson
     */
    public function getOrders() {
        $paid_amount = 0;
        $model = $this->_templateFactory->create();
        $restaurantCollection = $this->_objectManager->create('\DocResearch\Restaurant\Model\Template')->getCollection();
        $restaurantCollection->addFieldToSelect('*');
        $restaurantCommInfo = $restaurantCollection->getData();

        if (!empty($restaurantCommInfo)) {
            foreach ($restaurantCommInfo as $restaurant) {
                $paid_amount = $this->getTotalEarning($restaurant['sales_person_id']);
                $commision = $this->getOrderCommision($restaurant['sales_person_id'], $restaurant['sales_commission']);
                $total_pay = 0;
                if (!empty($paid_amount)) {
                    $total_pay = $paid_amount;
                }

                $total_earn = $commision - $total_pay;
                $model->load($restaurant['sales_person_id']);
                $model->setTotalEarning($total_earn);
                $model->save();
            }
        }
    }

    /**
     * Sales Person commission
     * @param $sales_person_id, $sales_commission
     * @return double
     */
    public function getOrderCommision($sales_person_id, $sales_commission) {
        $orderCollection = $this->_objectManager->create('\Magento\Sales\Model\Order')->getCollection();
        $orderCollection->addAttributeToSelect('*')->addFieldToFilter('status', 'complete');
        $commision = 0;

        if (!empty($orderCollection)) {
            foreach ($orderCollection as $order) {
                if ($sales_person_id == $order['sales_person_id']) {
                    $commision += $order['sales_commission'];
                }
            }
        }

        return $commision;
    }

    /**
     * Total earning of a sales person
     * @param $sales_person_id
     * @return double
     */
    public function getTotalEarning($sales_person_id) {
        $salespersonCommision = $this->_objectManager->create('\DocResearch\SalesPerson\Model\Commision')->getCollection();
        $salespersonCommision->addFieldToSelect('*')->addFieldToFilter('salesperson_id', $sales_person_id);
        $salesinfo = $salespersonCommision->getData();
        $total_pay = 0;

        if (!empty($salesinfo)) {
            foreach ($salesinfo as $info) {
                if ($sales_person_id == $info['salesperson_id']) {
                    $total_pay += $info['paid_amount'];
                }
            }
        }
        return $total_pay;
    }

}
