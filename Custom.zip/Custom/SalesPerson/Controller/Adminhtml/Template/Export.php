<?php

/**
 * SalesPerson Export Controller
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml\Template;

use DocResearch\SalesPerson\Model\CommisionFactory;

class Export extends \DocResearch\SalesPerson\Controller\Adminhtml\Template {

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;
    protected $_commisionFactory;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
    CommisionFactory $commisionFactory, \Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry) {
        $this->_coreRegistry = $coreRegistry;
        $this->_commisionFactory = $commisionFactory;
        parent::__construct($context);
    }

    /**
     * Export SalesPerson Template
     *
     * @return void
     */
    public function execute() {
        $model = $this->_objectManager->create('DocResearch\SalesPerson\Model\Template');
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            $model->load($id);
        }
        $this->_coreRegistry->register('_salesperson_template', $model);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $salespersonCommision = $objectManager->create('\DocResearch\SalesPerson\Model\Commision')->getCollection();

        $joinConditions = 'main_table.salesperson_id = salesperson_template.id';
        $salespersonCommision->getSelect()->joinleft(
                ['salesperson_template'], $joinConditions, []
        );
        $salespersonCommision->getSelect()->columns("salesperson_template.email")
                ->columns('salesperson_template.sales_person')
                ->columns('salesperson_template.sales_commission')
                ->columns('salesperson_template.id')
                ->where("salesperson_template.id = '" . $id . "'");
        $salesperson_data = $salespersonCommision->getData();
        $heading = [
            __('Sales Person Id'),
            __('Sales Person Name'),
            __('Email'),
            __('Commission Rate'),
            __('Amoutnt Paid'),
            __('Remaining Amount'),
            __('Paid Date')
        ];
        $outputFile = "SalesPerson_commission" . date('Ymd_His') . ".csv";
        $handle = fopen($outputFile, 'w');
        fputcsv($handle, $heading);
        foreach ($salesperson_data as $data) {
            $row = [
                $data['id'],
                $data['sales_person'],
                $data['email'],
                $data['sales_commission'],
                $data['paid_amount'],
                $data['remaining_amount'],
                date('Y-m-d', strtotime($data['paid_date']))
            ];
            fputcsv($handle, $row);
        }
        $this->downloadCsv($outputFile);
    }

    public function downloadCsv($file) {
        if (file_exists($file)) {
            //set appropriate headers
            header('Content-Description: File Transfer');
            header('Content-Type: application/csv');
            header('Content-Disposition: attachment; filename=' . basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();
            flush();
            readfile($file);
        }
    }

}
