<?php

/**
 * SalesPerson Save Controller
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml\Template;

use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;

class Save extends \DocResearch\SalesPerson\Controller\Adminhtml\Template {

    /**
     * Save SalesPerson Details
     *
     * @return void
     */
    public function execute() {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/template'));
        }

        $template = $this->_objectManager->create('DocResearch\SalesPerson\Model\Template');
        $id = (int) $request->getParam('id');

        if ($id) {
            $template->load($id);
        }
        try {

            $template->setData('sales_person', $request->getParam('sales_person')
            )->setData('phone_number', $request->getParam('phone_number')
            )->setData('email', $request->getParam('email')
            )->setData('sales_commission', $request->getParam('sales_commission')
            )->setData('address', $request->getParam('address')
			)->setData('address_line', $request->getParam('address2')
            )->setData('city', $request->getParam('city')
            )->setData('state', $request->getParam('state')
            )->setData('country', $request->getParam('country')
            )->setData('zip', $request->getParam('zip')
            )->setData('restaurant_id', $request->getParam('restaurant_id')
            )->setData('store_id', $request->getParam('store_id')
            )->setData('status', $request->getParam('status')
            );
            
            $template->save();

            $pay_today = $request->getParam('pay_today');

            if (isset($pay_today) && $pay_today == 1) {
                $amount_paid = $request->getParam('amount');
                if ($amount_paid > 0) {
                    $remaining_amount = $request->getParam('total_earning') - $amount_paid;
                    $today_date = date('Y-m-d');
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                    $connection = $resource->getConnection();
                    $insert_sql = "INSERT INTO salesperson_commision (salesperson_id, paid_amount, paid_date, remaining_amount) VALUES ('" . $id . "', '" . $amount_paid . "', '" . $today_date . "', '" . $remaining_amount . "')";
                    $connection->query($insert_sql);
                }

                /*
                  Update sales person total earning into sales person template table
                 */
                $salespersonCollection = $objectManager->create('\DocResearch\SalesPerson\Model\Template')->getCollection();
                $salespersonCollection->addFieldToSelect('*')->addFieldToFilter('id', $id);
                $total_earningdata = $salespersonCollection->getData();
                $update_totalearning = $total_earningdata[0]['total_earning'] - $amount_paid;
                $update_sql = "update salesperson_template SET total_earning = '" . $update_totalearning . "' WHERE id = '" . $id . "'";
                $connection->query($update_sql);
            }
            $this->messageManager->addSuccess(__('The SalesPerson has been saved.'));
            $this->_getSession()->setFormData(false);
        } catch (LocalizedException $e) {

            $this->messageManager->addError(nl2br($e->getMessage()));
            $this->_getSession()->setData('salesperson_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        } catch (\Exception $e) {

            $this->messageManager->addException($e, __('Something went wrong while saving this SalesPerson.'));
            $this->_getSession()->setData('salesperson_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        }

        return $resultRedirect->setPath('*/*/');
    }

}
