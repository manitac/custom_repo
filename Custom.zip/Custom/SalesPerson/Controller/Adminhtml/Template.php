<?php

/**
 * SalesPerson controller  
 *
 */

namespace DocResearch\SalesPerson\Controller\Adminhtml;

/**
 * Template abstract Class for authrization
 */
abstract class Template extends \Magento\Backend\App\Action {

    /**
     * @return bool
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('DocResearch_SalesPerson::salesperson_template');
    }

}
