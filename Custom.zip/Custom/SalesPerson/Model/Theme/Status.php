<?php

/**
 * SalesPerson Status model
 *
 */

namespace DocResearch\SalesPerson\Model\Theme;

class Status implements \Magento\Framework\Data\OptionSourceInterface {

    protected $_template;

    /**
     * Constructor
     *
     * @param \DocResearch\SalesPerson\Model\Template $template
     */
    public function __construct(\DocResearch\SalesPerson\Model\Template $template) {
        $this->_template = $template;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray() {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_template->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

}
