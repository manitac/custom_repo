<?php

/**
 * Sales Person Commision Collection
 */

namespace DocResearch\SalesPerson\Model\ResourceModel\Commision;

/**
 * Class Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\SalesPerson\Model\Commision', 'DocResearch\SalesPerson\Model\ResourceModel\Commision');
    }

}
