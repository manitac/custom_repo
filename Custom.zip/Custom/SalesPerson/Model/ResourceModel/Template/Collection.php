<?php

/**
 * Directory SalesPerson Resource Collection
 */

namespace DocResearch\SalesPerson\Model\ResourceModel\Template;

/**
 * Class Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\SalesPerson\Model\Template', 'DocResearch\SalesPerson\Model\ResourceModel\Template');
    }

}
