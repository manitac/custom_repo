<?php

namespace DocResearch\MultiSelect\Model;

use Magento\Framework\Model\AbstractModel;

class Restaurant extends AbstractModel {

    /**
     * Define resource model
     */
    protected function _construct() {
        $this->_init('DocResearch\MultiSelect\Model\Resource\Restaurant');
    }

}
