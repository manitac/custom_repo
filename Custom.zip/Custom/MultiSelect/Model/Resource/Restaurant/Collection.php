<?php

namespace DocResearch\MultiSelect\Model\Resource\Restaurant;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Define model & resource model
     */
    protected function _construct() {
        $this->_init(
                'DocResearch\MultiSelect\Model\Restaurant', 'DocResearch\MultiSelect\Model\Resource\Restaurant'
        );
    }

}
