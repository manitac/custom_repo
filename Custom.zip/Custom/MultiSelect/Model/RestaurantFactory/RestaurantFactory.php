<?php

namespace DocResearch\MultiSelect\Model\Resource\Restaurant;

class RestaurantFactory {

    protected $_restaurantFactory;

    public function __construct(DocResearch\MultiSelect\Model\RestaurantFactory $db) {
        $this->_restaurantFactory = $db;
    }

    public function getRestaurantDetail() {
//set value
        $this->_restaurantFactory->create()->setData(array('restaurant_id' => '', 'restaurants' => ''))->save();

//get value
        $data = $this->_restaurantFactory->create()->getCollection();
        foreach ($data as $d) {
            echo $d->getRestaurantId();   //table field event_imgurl
            echo $d->getRestaurants();    //table field event_name
        }
    }

}
