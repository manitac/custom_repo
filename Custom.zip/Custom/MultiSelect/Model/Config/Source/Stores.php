<?php

namespace DocResearch\MultiSelect\Model\Config\Source;

use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Framework\DB\Ddl\Table;

/**
 * Custom Attribute Renderer
 *
 * @author Chetu India Team
 */
class Stores extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource {

    /**
     * @var OptionFactory
     */
    protected $optionFactory;

    /**
     * Get all options
     * For Stores Drop Down
     * @return array
     */
    public function getAllOptions() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $this->_options = array();

        $request = $objectManager->get('\Magento\Framework\App\Request\Http');
        $customerID = $request->getParam('id');
        if (isset($customerID) && !empty($customerID)) {

            $customer_entity_text_tab = $resource->getTableName('customer_entity_text');
            $sql_cus_rest = "SELECT value from " . $customer_entity_text_tab . " WHERE `attribute_id` = '136' and entity_id = '" . $customerID . "'";
            $result_cus_rest = $connection->fetchAll($sql_cus_rest);
            if ($result_cus_rest) {
                $cus_restaurent = $result_cus_rest[0]['value'];
            } else {
                $cus_restaurent = "";
            }

            $tableName = $resource->getTableName('store_template');
            $sql = "Select * FROM " . $tableName . " where restaurant_id = '" . $cus_restaurent . "'";
            $result = $connection->fetchAll($sql);

            foreach ($result as $key => $value) {

                $this->_options[] = array(
                    "label" => $value['name'],
                    "value" => $value['id']
                );
            }

            return $this->_options;
        } else {

            return $this->_options;
        }
    }

    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string
     */
    public function getOptionText($value) {
        $options = $this->getAllOptions();
        foreach ($options as $option) {
            if ($option["value"] == $value) {
                return $option["label"];
            }
        }
        return false;
    }

    /**
     * Retrieve Column(s) for Flat
     *
     * @return array
     */
    public function getFlatColums() {
        $columns = array();
        $columns[$this->getAttribute()->getAttributeCode()] = array(
            "type" => "text",
            "unsigned" => false,
            "is_null" => true,
            "default" => null,
            "extra" => null
        );

        return $columns;
    }

    /**
     * Retrieve Indexes(s) for Flat
     *
     * @return array
     */
    public function getFlatIndexes() {
        $indexes = array();

        $index = "IDX_" . strtoupper($this->getAttribute()->getAttributeCode());
        $indexes[$index] = array(
            "type" => "index",
            "fields" => array($this->getAttribute()->getAttributeCode())
        );

        return $indexes;
    }

    /**
     * Retrieve Select For Flat Attribute update
     *
     * @param int $store
     * @return Varien_Db_Select|null
     */
    public function getFlatUpdateSelect($store) {
        return Mage::getResourceModel("eav/entity_attribute")
                        ->getFlatUpdateSelect($this->getAttribute(), $store);
    }

}
