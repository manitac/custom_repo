<?php

/**
 * MultiSelect index controller
 */

namespace DocResearch\MultiSelect\Controller\Adminhtml\Stores;

use Magento\Catalog\Model\Category;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class Index extends Action {

    protected $_storeCollection;
    protected $_resultJsonFactory;

    public function __construct(Context $context, \DocResearch\Store\Model\ResourceModel\StoreFactory $storeCollection, JsonFactory $jsonFactory
    ) {
        $this->_storeCollection = $storeCollection;
        $this->_resultJsonFactory = $jsonFactory;

        parent::__construct($context);
    }

    /*
     * Index action.
     * 
     * @return \Magento\Backend\Model\View\Result\Page
     */

    public function execute() {
        // get parent category
        $restaurant_id = $this->getRequest()->getParam('restaurant_id');
        /** @var Category $category */
        $stores = $this->_storeCollection->create()->getCollection()
                ->addFieldToFilter('restaurant_id', $restaurant_id);

        $storesData = [];

        foreach ($stores as $store) {
            $storesData[] = [
                'name' => $store->getName(),
                'id' => $store->getId()
            ];
        }

        return $this->resultJsonFactory->create()->setData($childrenData);
    }

}
