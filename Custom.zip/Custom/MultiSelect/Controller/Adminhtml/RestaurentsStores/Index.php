<?php

/**
 * MultiSelect index controller
 */

namespace DocResearch\MultiSelect\Controller\Adminhtml\RestaurentsStores;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;

class Index extends Action {

    protected $_storeCollection;
    protected $_resultJsonFactory;
    protected $_storeManager;
    protected $_sessionQuote;
    protected $request;

    public function __construct(Context $context, \Magento\Backend\Model\Session\Quote $sessionQuote, \Magento\Framework\App\Request\Http $request, \DocResearch\Store\Model\ResourceModel\StoreFactory $storeCollection, JsonFactory $jsonFactory, \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {

        $this->_sessionQuote = $sessionQuote;
        $this->request = $request;
        $this->_storeCollection = $storeCollection;
        $this->_resultJsonFactory = $jsonFactory;
        $this->_storeManager = $storeManager;


        parent::__construct($context);
    }

    /*
     * Index action.
     *
     *  Function to restun the Stores according to the 
     *  Restaurent selected in the Ajax Call
     *  
     * @return HTML options values
     */

    public function execute() {
        #Initialize db connections
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        #get request parameter
        $restaurant_id = $this->getRequest()->getParam('restaurant_id');

        $tableName1 = $resource->getTableName('store_template');

        $sql = "SELECT " . $tableName1 . ".id as store_id, " . $tableName1 . ".name as store_name FROM " . $tableName1 . " WHERE " . $tableName1 . ".restaurant_id = '" . $restaurant_id . "'";
        $result = $connection->fetchAll($sql);

        $storesData = [];
        $optionsVal = "";
        $selVal = "";

        foreach ($result as $store) {

            $optionsVal .= "<option data-title='" . $store['store_name'] . "' value='" . $store['store_id'] . "'>" . $store['store_name'] . "</option>";
        }
        echo $optionsVal;
    }

}
