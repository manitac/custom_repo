<?php

namespace DocResearch\MultiSelect\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Eav\Model\Config;

class InstallData implements InstallDataInterface {

    private $eavSetupFactory;

    public function __construct(EavSetupFactory $eavSetupFactory, Config $eavConfig) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->eavConfig = $eavConfig;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
        $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY, 'restaurant', [
            'type' => 'text',
            'class' => 'my-custom-class',
            'label' => 'Restaurant',
            'input' => 'select',
            'source' => 'DocResearch\MultiSelect\Model\Config\Source\Options',
            'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
            'required' => true,
            'default' => '0',
            'sort_order' => 1,
            'system' => false,
            'position' => 1
                ]
        );
        $restaurantAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'restaurant');
        $usedInForms = array(
            'customer_account_create',
            'customer_account_edit',
            'checkout_register',
        );
        if (!empty($data['adminhtml_only'])) {
            $usedInForms = array('adminhtml_customer');
        } else {
            $usedInForms[] = 'adminhtml_customer';
        }
        $restaurantAttribute->setData('used_in_forms', $usedInForms);

        $restaurantAttribute->save();

        $eavSetup->addAttribute(
                \Magento\Customer\Model\Customer::ENTITY, 'stores', [
            'type' => 'text',
            'label' => 'Stores',
            'input' => 'multiselect',
            'source' => 'DocResearch\MultiSelect\Model\Config\Source\Stores',
            'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
            'required' => true,
            'default' => '0',
            'sort_order' => 2,
            'system' => false,
            'position' => 2
                ]
        );
        $storeAttribute = $this->eavConfig->getAttribute(\Magento\Customer\Model\Customer::ENTITY, 'stores');
        $usedInForms = array(
            'customer_account_create',
            'customer_account_edit',
            'checkout_register',
        );
        if (!empty($data['adminhtml_only'])) {
            $usedInForms = array('adminhtml_customer');
        } else {
            $usedInForms[] = 'adminhtml_customer';
        }
        $storeAttribute->setData('used_in_forms', $usedInForms);

        $storeAttribute->save();
    }

}
