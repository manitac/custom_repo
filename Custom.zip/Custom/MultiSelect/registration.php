<?php

/**
 * Module configuration
 */
\Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE, 'DocResearch_MultiSelect', __DIR__
);
