<?php

/**
 * Copyright © 2016 DocResearch. All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace DocResearch\PaymentRestriction\Plugin\Payment\Method\CashOnDelivery;

use Magento\Customer\Model\Session as CustomerSession;
use Magento\Backend\Model\Auth\Session as BackendSession;
use Magento\OfflinePayments\Model\Cashondelivery;

class Available {

    /**
     * @var CustomerSession
     */
    protected $customerSession;

    /**
     * @var BackendSession
     */
    protected $backendSession;
    protected $_result;

    /**
     * @param CustomerSession $customerSession
     * @param BackendSession $backendSession
     */
    public function __construct(
    CustomerSession $customerSession, BackendSession $backendSession
    ) {
        $this->customerSession = $customerSession;
        $this->backendSession = $backendSession;
    }

    /**
     *
     * @param Cashondelivery $subject
     * @param $result
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function afterIsAvailable(Cashondelivery $subject, $result) {
        $this->_result = $result;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');


        $c_store_id = $customerSession->getCustomer()->getData('restaurant');

        $store = $objectManager->get('DocResearch\Restaurant\Model\Template');
        $check = ($store->load($c_store_id)->getPayLater());

        if ($check == '1') {
            return $this->_result;
        } else {
            return false;
        }
    }

}
