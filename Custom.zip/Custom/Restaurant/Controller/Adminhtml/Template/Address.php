<?php

/**
 * Restaurant Grid Controller
 */

namespace DocResearch\Restaurant\Controller\Adminhtml\Template;

/**
 * Grid Class for creating grid
 */
class Address extends \DocResearch\Restaurant\Controller\Adminhtml\Template {

    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;

    public function __construct(
    \Magento\Backend\App\Action\Context $context, \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultLayoutFactory = $resultLayoutFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute() {
        $resultLayout = $this->resultLayoutFactory->create();
        $layout = $resultLayout->getLayout();
        $block = $layout->createBlock('DocResearch\Restaurant\Block\Adminhtml\Template\Edit\Tab\Address');
        $this->getResponse()->appendBody($block->toHtml());
    }
}
