<?php

/**
 * Restaurant Save Controller
 */

namespace DocResearch\Restaurant\Controller\Adminhtml\Template;

use Magento\Framework\App\TemplateTypesInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Controller\ResultFactory;

class Save extends \DocResearch\Restaurant\Controller\Adminhtml\Template {

    /**
     * Save Restaurant Details
     *
     * @return void
     */
    public function execute() {
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $request = $this->getRequest();
        if (!$request->isPost()) {
            $this->getResponse()->setRedirect($this->getUrl('*/template'));
        }

        /*echo "<pre>";
        print_r($request->getParams());
        echo "</pre>";
        die('testing only');*/

        $template = $this->_objectManager->create('DocResearch\Restaurant\Model\Template');
        $price = $this->_objectManager->create('DocResearch\Restaurant\Model\Price');
        $restaurant_price = $this->_objectManager->create('DocResearch\Restaurant\Model\Store');
        $id = (int) $request->getParam('id');

        if ($id) {
            $template->load($id);
            $price->load($id, 'restaurant_id');
            $restaurant_price->load($id, 'restaurant_id');
        }
        try {

            /*echo "<pre>";
            print_r($request->getParams());
            echo "</pre>";
            die('testing only');*/
            $send_corporate = isset($_REQUEST['send_corporate']) ? $_REQUEST['send_corporate'] : '0';
            $pay_later = isset($_REQUEST['pay_later']) ? $_REQUEST['pay_later'] : '0';
            $purchase_order = isset($_REQUEST['purchase_order']) ? $_REQUEST['purchase_order'] : '0';
            $corporate_billing = isset($_REQUEST['corporate_billing']) ? $_REQUEST['corporate_billing'] : '0';
            //$use_third_party_address = isset($_REQUEST['use_third_party_address']) ? $_REQUEST['use_third_party_address'] : '0';

            $email_1 = $request->getParam('email_1');
            $address_1 = $request->getParam('address_1');
            $address_2 = $request->getParam('address_2');
            $city_1 = $request->getParam('city_1');
            $state_1 = $request->getParam('state_1');
            $country_1 = $request->getParam('country_1');
            $zip_1 = $request->getParam('zip_1');
            
            $template->setData('name', $request->getParam('rname')
            )->setData('brand_name', $request->getParam('brand')
            )->setData('sales_person_id', $request->getParam('sales_person_id')
            )->setData('phone_number', $request->getParam('phone_number')
            )->setData('email', $request->getParam('email')
            )->setData('contact_name', $request->getParam('contactname')
            )->setData('sales_commission', $request->getParam('sales_commission')
            )->setData('address', $request->getParam('address')
			)->setData('address_line', $request->getParam('address2')
            )->setData('city', $request->getParam('city')
            )->setData('state', $request->getParam('state')
            )->setData('country', $request->getParam('country')
            )->setData('zip', $request->getParam('zip')
            )->setData('is_multi', $request->getParam('is_multi')
            )->setData('message', $request->getParam('message')
            )->setData('corporate_billing', $corporate_billing
            )->setData('pay_later', $pay_later
            )->setData('purchase_order', $purchase_order
            )->setData('send_corporate', $send_corporate
            //)->setData('use_third_party_address', $use_third_party_address
            )->setData('status', $request->getParam('status')
            )->setData('freeshipping_method', $request->getParam('freeshipping_method')
            )->setData('flat_rate', $request->getParam('flat_rate')
            );


            $template->save();
            $restaurant_insert_id = $template->getId();
            $shipping_price = $request->getParam('ups');
            if (!empty($shipping_price)) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
                if (!empty($price->getData('restaurant_id'))) {
                    $availableShipping = $this->getAvailableShipping($price->getData('restaurant_id'));

                    foreach ($shipping_price as $shipping_code => $ship_price) {
                        if (in_array($shipping_code, $availableShipping)) {
                            $update_sql = "Update restaurant_shipping SET shipping_price = '" . $ship_price . "' where restaurant_id = '" . $price->getData('restaurant_id') . "' AND shipping_code = '" . $shipping_code . "'";
                            $connection->query($update_sql);
                        } else {
                            $insert_sql = "Insert Into restaurant_shipping(restaurant_id, shipping_code, shipping_price) Values ('" . $restaurant_insert_id . "', '" . $shipping_code . "','" . $ship_price . "')";
                            $connection->query($insert_sql);
                        }
                    }
                } else {
                    foreach ($shipping_price as $shipping_code => $ship_price) {
                        $insert_sql = "Insert Into restaurant_shipping(restaurant_id, shipping_code, shipping_price) Values ('" . $restaurant_insert_id . "', '" . $shipping_code . "','" . $ship_price . "')";
                        $connection->query($insert_sql);
                    }
                }
            }
            /*
             * Start To add product price at restaurant level
             */

            $product_price = $request->getParam('product_price');
            if (!empty($product_price)) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
                $connection = $resource->getConnection();
                $sql = "SELECT product_id,product_price FROM store_price WHERE restaurant_id = " . $restaurant_insert_id;
                $already_id = $connection->fetchAll($sql);
                $added_ids = array();
                foreach ($already_id as $a_id) {
                    $added_ids[$a_id['product_id']] = $a_id['product_price'];
                }
                foreach ($product_price as $id => $price) {
                    if (!empty($price)) {
                        $new_ids[$id] = $price;
                    }
                }
                $product_to_add = array_diff_key($new_ids, $added_ids);
                $product_to_delete = array_keys(array_diff_key($added_ids, $new_ids));
                $product_to_update = array_intersect_key($new_ids, $added_ids);
                if (!empty($restaurant_price->getData('restaurant_id'))) {
                    if (!empty($product_to_delete)) {
                        $delete_query = "Delete FROM store_price Where product_id IN (" . implode(',', $product_to_delete) . ") AND restaurant_id = " . $restaurant_price->getData('restaurant_id');
                        $connection->query($delete_query);
                    }
                    if (!empty($product_to_update)) {
                        foreach ($product_to_update as $id => $update_price) {
                            $update_sql = "UPDATE store_price SET product_price = '" . $update_price . "' WHERE product_id = '" . $id . "' AND restaurant_id =" . $restaurant_price->getData('restaurant_id');
                            $connection->query($update_sql);
                        }
                    }
                }
                foreach ($product_to_add as $id => $price) {
                    $insert_sql = "Insert Into store_price (restaurant_id, product_id, product_price) Values ('" . $restaurant_insert_id . "', '" . $id . "','" . $price . "')";
                    $connection->query($insert_sql);
                }
            }

            /**
             * Save third party address details
             */

            if(isset($email_1) && !empty($email_1) && isset($address_1) && !empty($address_1)){
                $sql3rdPartySel = "SELECT * FROM third_party_address WHERE restaurant_id = " . $restaurant_insert_id;
                $addr_already_exists = $connection->fetchAll($sql3rdPartySel);
                if(empty($addr_already_exists)){
                    $insert_3rdPartyAddr = "Insert Into third_party_address (restaurant_id, email, address, address2, city, state, zip, country) Values ('" . $restaurant_insert_id . "', '".$email_1."', " . $address_1 . "','" . $address_2 . "', '".$city_1."', '".$state_1."', '".$zip_1."', '".$country_1."')";
                    $connection->query($insert_3rdPartyAddr);
                } else {
                    $up_3rdPartyAddr = "UPDATE third_party_address SET email = '".$email_1."', address = '".$address_1."', address2 = '".$address_2."', city = '".$city_1."', state = '".$state_1."', zip = '".$zip_1."', country = '".$country_1."' WHERE restaurant_id = '".$restaurant_insert_id."'";
                    $connection->query($up_3rdPartyAddr);
                }                
            }


            /*
             * End To add product price at restaurant level 
             */
            $this->messageManager->addSuccess(__('The restaurant has been saved.'));
            $this->_getSession()->setFormData(false);
        } catch (LocalizedException $e) {

            $this->messageManager->addError(nl2br($e->getMessage()));
            $this->_getSession()->setData('restaurant_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        } catch (\Exception $e) {

            $this->messageManager->addException($e, __('Something went wrong while saving this restaurant.'));
            $this->_getSession()->setData('restaurant_template_form_data', $this->getRequest()->getParams());
            return $resultRedirect->setPath('*/*/edit', ['id' => $template->getId(), '_current' => true]);
        }

        return $resultRedirect->setPath('*/*/');
    }

    /**
     * Get available shipping methods for a Restaurant
     * @param type $res_id
     * @return Array
     */
    public function getAvailableShipping($res_id) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $sql = "SELECT shipping_code FROM restaurant_shipping WHERE restaurant_id = " . $res_id;
        $shipping_code = $connection->fetchAll($sql);

        $code_ship = array();
        foreach ($shipping_code as $key => $value) {
            $code_ship[] = $value['shipping_code'];
        }
        return $code_ship;
    }

}
