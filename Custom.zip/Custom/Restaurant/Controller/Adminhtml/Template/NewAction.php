<?php

/**
 * Restaurant NewAction Controller
 */

namespace DocResearch\Restaurant\Controller\Adminhtml\Template;

class NewAction extends \DocResearch\Restaurant\Controller\Adminhtml\Template {

    /**
     * Create new Restaurant
     *
     * @return void
     */
    public function execute() {
        $this->_forward('edit');
    }

}
