<?php

/**
 *
 * Copyright � 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
// @codingStandardsIgnoreFile

namespace DocResearch\Restaurant\Controller\Adminhtml\Template;

/**
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Regionlist extends \Magento\Framework\App\Action\Action {

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var \Magento\Directory\Model\CountryFactory
     */
    protected $_countryFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory resultPageFactory
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Directory\Model\CountryFactory $countryFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_countryFactory = $countryFactory;
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Default customer account page
     *
     * @return void
     */
    public function execute() {

        $countrycode = 'US';
        if ($countrycode != '') {
            $statearray = $this->_countryFactory->create()->setId($countrycode)->getLoadedRegionCollection()->toOptionArray();

            if (!empty($statearray)) {
                $state = '<select id="state" name="state" title="Region" class=" select admin__control-select" data-ui-id="template-edit-form-fieldset-element-select-state">';
                $state .= "<option value=''>--Please Select--</option>";
                foreach ($statearray as $_state) {
                    if ($_state['value']) {
                        $state .= "<option value='" . $_state['value'] . "'>" . $_state['label'] . "</option>";
                    }
                }
                $state .= "</select>";
            }
            $result['htmlconent'] = $state;
            $this->getResponse()->representJson($this->_objectManager->get('Magento\Framework\Json\Helper\Data')->jsonEncode($result));
        }
    }

}
