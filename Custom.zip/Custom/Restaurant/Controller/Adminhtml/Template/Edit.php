<?php
/**
 * Restaurant Edit Controller
 */
namespace DocResearch\Restaurant\Controller\Adminhtml\Template;

class Edit extends \DocResearch\Restaurant\Controller\Adminhtml\Template
{
	
    /**
     * Core store config
     *
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_shippingConfig;

    /**
     * @var \Magento\Shipping\Model\CarrierFactory
     */
    protected $_carrierFactory;
	
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Shipping\Model\Config $shippingConfig,
        \Magento\Shipping\Model\CarrierFactory $carrierFactory)
    {
        $this->_coreRegistry = $coreRegistry;
        $this->_shippingConfig = $shippingConfig;
        $this->_carrierFactory = $carrierFactory;
        parent::__construct($context);
    }

    /**
     * Edit Restaurant Template
     *
     * @return void
     */
    public function execute()
    {		
        $model = $this->_objectManager->create('DocResearch\Restaurant\Model\Template');
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            $model->load($id);
        }

        $addrCollection = $this->_objectManager->create('DocResearch\Restaurant\Model\ResourceModel\Address\Collection');
        
        /** Apply filters here */
        $thirdPartyAddrData = $addrCollection->addFieldToFilter('restaurant_id', array('eq' => $id));

        $this->_coreRegistry->register('_third_party_address', $thirdPartyAddrData);
        
        $this->_coreRegistry->register('_restaurant_template', $model);

        $this->_view->loadLayout();
        $this->_setActiveMenu('DocResearch_Restaurant::restaurant_template');

        if ($model->getId()) {
            $breadcrumbTitle = __('Edit Restaurant');
            $breadcrumbLabel = $breadcrumbTitle;
        } else {
            $breadcrumbTitle = __('New Restaurant');
            $breadcrumbLabel = __('Create Restaurant');
        }
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Restaurants'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
            $model->getId() ? $model->getTemplateId() : __('New Restaurant')
        );

        $this->_addBreadcrumb($breadcrumbLabel, $breadcrumbTitle);

        // restore data
        $values = $this->_getSession()->getData('restaurant_template_form_data', true);
        if ($values) {
            $model->addData($values);
        }

        $this->_view->renderLayout();
    }
}
