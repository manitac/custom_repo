<?php

/**
 * Restaurant setup to create module table
 */

namespace DocResearch\Restaurant\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Class InstallSchema to create module table
 */
class InstallSchema implements InstallSchemaInterface {

    /**
     * install Action
     * @retrun bool
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;
        $installer->startSetup();
        $restaurantTable = $installer->getConnection()->newTable(
                        $installer->getTable('restaurant_template'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Name'
                )
                ->addColumn(
                        'brand_name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Brand Name'
                )
                ->addColumn(
                        'email', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Email'
                )
                ->addColumn(
                        'sales_person', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Person'
                )
                ->addColumn(
                        'contact_name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Contact Name'
                )
                ->addColumn(
                        'sales_commission', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Commission'
                )
                ->addColumn(
                        'phone_number', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Phone Number'
                )
                ->addColumn(
                        'address', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Address'
                )
                ->addColumn(
                        'city', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'City'
                )
                ->addColumn(
                        'state', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'State'
                )
                ->addColumn(
                        'country', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Country'
                )
                ->addColumn(
                        'message', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Message'
                )
                ->addColumn(
                        'zip', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['nullable' => false], 'Zip'
                )
                ->addColumn(
                        'is_multi', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Is Multi Store'
                )
                ->addColumn(
                        'sales_person_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'SalesPerson Id'
                )
                ->addColumn(
                        'has_pay_later', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Has Pay Later'
                )
                ->addColumn(
                'status', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Status'
        );
        $installer->getConnection()->createTable($restaurantTable);
        $installer->endSetup();
    }

}
