<?php

/**
 * Store Product Collection
 */

namespace DocResearch\Restaurant\Model\ResourceModel\Store;

/**
 * Class Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\Restaurant\Model\Store', 'DocResearch\Restaurant\Model\ResourceModel\Store');
    }

}
