<?php

/**
 * Directory Restaurant Resource Collection
 */

namespace DocResearch\Restaurant\Model\ResourceModel\Address;

/**
 * Class Collection
 */
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * @var string
     */
    protected $_idFieldName = 'id';

    /**
     * Define main table
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\Restaurant\Model\Address', 'DocResearch\Restaurant\Model\ResourceModel\Address');
    }

}
