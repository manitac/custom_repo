<?php

/**
 * Restaurant Status model
 *
 */

namespace DocResearch\Restaurant\Model\Theme;

class Status implements \Magento\Framework\Data\OptionSourceInterface {

    protected $_template;

    /**
     * Constructor
     *
     * @param \DocResearch\Restaurant\Model\Template $template
     */
    public function __construct(\DocResearch\Restaurant\Model\Template $template) {
        $this->_template = $template;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray() {
        $options[] = ['label' => '', 'value' => ''];
        $availableOptions = $this->_template->getAvailableStatuses();
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }
        return $options;
    }

}
