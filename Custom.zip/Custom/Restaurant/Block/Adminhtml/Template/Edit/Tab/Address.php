<?php
/**
 * Restaurant Information Edit Form Block
 *
 */
namespace DocResearch\Restaurant\Block\Adminhtml\Template\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Eav\Block\Adminhtml\Attribute\PropertyLocker;
 

class Address extends Generic implements TabInterface
{
    /**
     * @var \DocResearch\Restaurant\Helper\Option
     */
    protected $_statusOption;
    protected $_countryFactory;
    protected $_shippingConfig;
    protected $_priceFactory;
    protected $_regionColFactory;
    protected $_addrCollection;
   
   /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param FormFactory $templateFactory
     * @param FormFactory $optionData
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        \DocResearch\Restaurant\Helper\Option $optionData,
        \DocResearch\SalesPerson\Model\TemplateFactory $salesPersonFactory,
        \DocResearch\Restaurant\Model\PriceFactory $priceFactory,
        \Magento\Directory\Model\RegionFactory $regionColFactory,
        \Magento\Shipping\Model\Config $shippingConfig,
        \Magento\Directory\Model\Config\Source\Country $countryFactory,
        \DocResearch\Restaurant\Model\ResourceModel\Address\Collection $addrCollection,
        array $data = []
       
    ) {
        $this->_countryFactory = $countryFactory;
        $this->_statusOption = $optionData;
        $this->_salesPersonFactory = $salesPersonFactory;
        $this->_shippingConfig = $shippingConfig;
        $this->_priceFactory = $priceFactory;
        $this->_regionColFactory = $regionColFactory;
        $this->_addrCollection = $addrCollection;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
 
   /**
     * Retrieve template object
     *
     * @return \DocResearch\Store\Model\Template
     */
    public function getModel()
    {
        return $this->_coreRegistry->registry('_restaurant_template');
    }
 
 
    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
    	$model = $this->_coreRegistry->registry('_restaurant_template');
        $model = $this->getModel();
        $request = $this->getRequest();

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'third_party_address_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Third Party Address Information'), 'class' => 'fieldset-wide']
        );
        
        $thirdPartyAddrData = $this->_addrCollection->addFieldToFilter('restaurant_id', array('eq' => $request->getParam('id')));

        $fieldset->addField(
            'company_name',
            'text',
            [
                'name' => 'company_name_1',
                'label' => __('Company name'),
                'title' => __('Company Name'),
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['company_name']
            ]
        );

        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email_1',
                'label' => __('Email Address'),
                'title' => __('Email Address'),
                'class' => 'validate-email',
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['email']
            ]
        );


        $fieldset->addField(
            'address',
            'text',
            [
                'name' => 'address_1',
                'label' => __('Address Line 1'),
                'title' => __('Address  Line 1'),
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['address']
            ]
        );
        
        $fieldset->addField(
            'address2',
            'text',
            [
                'name' => 'address_2',
                'label' => __('Address Line 2'),
                'title' => __('Address  Line 2'),
                'value' => $thirdPartyAddrData->getData()[0]['address2']
            ]
        );
        
        $fieldset->addField(
            'city',
            'text',
            [
                'name' => 'city_1',
                'label' => __('City'),
                'title' => __('City'),
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['city']
            ]
        );
        
        $fieldset->addField(
            'state',
            'select',
            [
                'name' => 'state_1',
                'label' => __('State'),
                'title' => __('State'),
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['state'],
                'values' => $this->stateListDropDown()
            ]
        );
                
        $fieldset->addField(
            'zip',
            'text',
            [
                'name' => 'zip_1',
                'label' => __('Zip Code1'),
                'title' => __('Zip Code'),
                'class' => 'validate-digits validate-length minimum-length-5 maximum-length-6',
                'required' => false,
                'value' => $thirdPartyAddrData->getData()[0]['zip']
            ]
        );
        
        //die('THis is here 7');
        //$optionsc=$this->_countryFactory->toOptionArray();
        $optionsc = array('US' => 'United States');
        $country = $fieldset->addField(
             'country',
             'select',
             [
                'name' => 'country_1',
                'label' => __('Country'),
                'title' => __('Country'),
                'value'  => $thirdPartyAddrData->getData()[0]['country'],
                'value'  => 'US',
                'values' => $optionsc
             ]
         );

        //die('This is just to test 5');
        
        $form->setAction($this->getUrl('*/*/save'));
        $this->setForm($form);

        return parent::_prepareForm();
    }
    
    /**
     * Retrieve Approved Sales Person
     *
     * @return array
     */
    
    public function getSalesPerson(){
        $salesPersonData = array();
    $salesPersonCollection =  $this->_salesPersonFactory->create()->getCollection();
    $salesPerson =  $salesPersonCollection->getData();
    foreach($salesPerson as $sale){
            $salesPersonData[] = [
                'value' => $sale['id'],
                'label' => $sale['sales_person'],
            ];
    }
        
        return $salesPersonData;
    }
    
    /**
     * Retrieve Particular UPS Method Price
     *
     * @return array
     */
    public function getUpsPrice($id){
    $salesPersonCollection =  $this->_priceFactory->create()->getCollection()->addFieldToFilter('restaurant_id', array(
        'eq'=> $id ));
        $salesPerson =  $salesPersonCollection->getData(); 
        if(count($salesPerson) > 0) {
            foreach($salesPerson as $sale){
                $salesPersonData[] = [
                  'code' => $sale['shipping_code'],
                  'price' => $sale['shipping_price'],
                ];
            }
            $ups_price = array();
            foreach($salesPersonData as $data) {
              $ups_price[$data['code']] = $data['price'];
            }
            return $ups_price;
        }
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Restaurant Info');
    }
 
    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Restaurant Info');
    }
 
    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Create list of all US states
     * @return array
     */
    public function stateListDropDown()
    {
        $state_list = $this->_regionColFactory->create()->getCollection()->addFieldToFilter('country_id', 'US');
        $final_state_list = $state_list->toOptionArray();
        return $final_state_list;
    }
}