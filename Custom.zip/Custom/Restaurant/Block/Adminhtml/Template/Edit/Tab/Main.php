<?php
/**
 * Restaurant Information Edit Form Block
 *
 */
namespace DocResearch\Restaurant\Block\Adminhtml\Template\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Eav\Block\Adminhtml\Attribute\PropertyLocker;
 
class Main extends Generic implements TabInterface
{
    /**
     * @var \DocResearch\Restaurant\Helper\Option
     */
    protected $_statusOption;	
    protected $_countryFactory;
    protected $_shippingConfig;	
    protected $_priceFactory;
    protected $_regionColFactory;
   
   /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param FormFactory $templateFactory
     * @param FormFactory $optionData
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        \DocResearch\Restaurant\Helper\Option $optionData,
        \DocResearch\SalesPerson\Model\TemplateFactory $salesPersonFactory,
        \DocResearch\Restaurant\Model\PriceFactory $priceFactory,
        \Magento\Directory\Model\RegionFactory $regionColFactory,
        \Magento\Shipping\Model\Config $shippingConfig,
        \Magento\Directory\Model\Config\Source\Country $countryFactory,
        array $data = []
       
    ) {
        $this->_countryFactory = $countryFactory;
        $this->_statusOption = $optionData;
        $this->_salesPersonFactory = $salesPersonFactory;
        $this->_shippingConfig = $shippingConfig;
        $this->_priceFactory = $priceFactory;
        $this->_regionColFactory = $regionColFactory;
        parent::__construct($context, $registry, $formFactory, $data);
    }
 
 
   /**
     * Retrieve template object
     *
     * @return \DocResearch\Store\Model\Template
     */
    public function getModel()
    {
        return $this->_coreRegistry->registry('_restaurant_template');
    }
 
 
    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm()
    {
        $model = $this->_coreRegistry->registry('_restaurant_template');
        $model = $this->getModel();
        $request = $this->getRequest();
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('Restaurant Information'), 'class' => 'fieldset-wide']
        );
        
        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id', 'value' => $model->getId()]);
        }
		
         $fieldset->addField(
            'brand',
            'text',
            [
                'name' => 'brand',
                'label' => __('Brand Name'),
                'title' => __('Brand Name'),
                'required' => false,
                'value' => $model->getBrandName()
            ]
        );
	
         
         $fieldset->addField(
            'name',
            'text',
            [
                'name' => 'rname',
                'label' => __('Restaurant Name'),
                'title' => __('Restaurant Name'),
                'required' => true,
                'value' => $model->getName()
            ]
        );

         $fieldset->addField(
            'contactname',
            'text',
            [
                'name' => 'contactname',
                'label' => __('Contact Name'),
                'title' => __('Contact Name'),
                'required' => true,
                'value' => $model->getContactName()
            ]
        );
		
        $fieldset->addField(
            'sales_person_id',
            'select',
            [
                'name' => 'sales_person_id',
                'label' => __('Sales Person Name'),
                'required' => false,
		        'value'  => $model->getSalesPersonId(),
                'values' => $this->getSalesPerson()
            ]
        );

        $fieldset->addField(
            'sales_commission',
            'text',
            [
                'name' => 'sales_commission',
                'label' => __('Sales Commission'),
                'title' => __('Sales Commission'),
                'required' => true,
                'class'    => 'validate-digits',
                //'step'      => '0.01',
                'value' => $model->getSalesCommission()
            ]
        );
		
        $fieldset->addField(
            'email',
            'text',
            [
                'name' => 'email',
                'label' => __('Email'),
                'title' => __('Email'),
                'class' => 'validate-email',
                'required' => true,
                'value' => $model->getEmail()
            ]
        );
		
        $fieldset->addField(
            'phone_number',
            'text',
            [
                'name' => 'phone_number',
                'label' => __('Phone Number'),
                'title' => __('Phone Number'),
                //'class' => 'validate-digits validate-length minimum-length-10 maximum-length-11',
                'class' => 'validate-phoneStrict',
                'required' => true,
                'value' => $model->getPhoneNumber()
            ]
        );
		
        $fieldset->addField(
            'address',
            'text',
            [
                'name' => 'address',
                'label' => __('Address Line 1'),
                'title' => __('Address  Line 1'),
                'required' => true,
                'value' => $model->getAddress()
            ]
        );
        
        $fieldset->addField(
            'address2',
            'text',
            [
                'name' => 'address2',
                'label' => __('Address Line 2'),
                'title' => __('Address  Line 2'),
                'value' => $model->getAddressLine()
            ]
        );
		
        $fieldset->addField(
            'city',
            'text',
            [
                'name' => 'city',
                'label' => __('City'),
                'title' => __('City'),
                'required' => true,
                'value' => $model->getCity()
            ]
        );
		
		$fieldset->addField(
            'state',
            'select',
            [
                'name' => 'state',
                'label' => __('State'),
                'title' => __('State'),
                'required' => false,
                'value' => $model->getState(),
                'values' => $this->stateListDropDown()
            ]
        );
		        
        $fieldset->addField(
            'zip',
            'text',
            [
                'name' => 'zip',
                'label' => __('Zip Code'),
                'title' => __('Zip Code'),
                'class' => 'validate-digits validate-length minimum-length-5 maximum-length-6',
                'required' => true,
                'value' => $model->getZip()
            ]
        );
		
		//$optionsc=$this->_countryFactory->toOptionArray();
        $optionsc = array('US' => 'United States');
        $country = $fieldset->addField(
             'country',
             'select',
             [
                 'name' => 'country',
                 'label' => __('Country'),
                 'title' => __('Country'),
                 //'value'  => $model->getCountry(),
                  'value'  => 'US',
                 'values' => $optionsc
             ]
         );
		 
		 $fieldset->addField(
            'status',
            'select',
            [
                'label' => __('Status'),
                'required' => true,
                'name' => 'status',
                'value'  => $model->getStatus(),
                'values' => $this->_statusOption->getStatusesOptionArray()
            ]
        );
		
        $fieldset->addField(
            'message',
            'textarea',
            [
                'name' => 'message',
                'label' => __('Message'),
                'title' => __('Message'),
                'required' => false,
                'value' => $model->getMessage()
            ]
        );
		
        $fieldset->addField(
            'corporate_billing',
            'radios',
            [
                'label' => __('Default Billing Address'),
                'title' => __('Default Billing Address'),
                'name' => 'corporate_billing',
                'required' => false,
                'values' => array(
                            array('value'=>'1','label'=>'Corporate Address'),
                            array('value'=>'2','label'=>'Third Party Address'),
                            array('value'=>'3','label'=>'Store Address'),
                            array('value'=>'0','label'=>'None'),
                       ),
               'value' => $model->getCorporateBilling()
            ]
        );

		/*$fieldset->addField(
            'corporate_billing',
            'checkbox',
            array(
                'name' => 'corporate_billing',
                'label' => __('Use this address as Billing Address'),
                'required' => false,
                'value'  => $model->getCorporateBilling(),
                'onclick' => 'this.value = this.checked ? 1 : 0;',
            ))->setIsChecked($model->getCorporateBilling()
        );
        
        $fieldset->addField(
            'use_third_party_address',
            'checkbox',
            array(
                'name' => 'use_third_party_address',
                'label' => __('Use Third Party address as Billing Address'),
                'required' => false,
                'value'  => $model->getUseThirdPartyAddress(),
                'onclick' => 'this.value = this.checked ? 1 : 0;',
            ))->setIsChecked($model->getUseThirdPartyAddress()
        );   */
        

        $fieldset->addField(
            'freeshipping_method',
            'radios',
            [
                'label' => __('Default Shipping'),
                'title' => __('freeshipping_method'),
                'name' => 'freeshipping_method',
                'required' => false,
                'values' => array(
                            array('value'=>'freeshipping_freeshipping','label'=>'Ground Free'),
                            array('value'=>'flatrate_flatrate','label'=>'Ground Flat Rate'),
                            array('value'=>'upscharges','label'=>'Full UPS Charges'),
                       ),
               'value' => $model->getFreeshippingMethod()
            ]
        );

        $fieldset->addField(
            'flat_rate',
            'text',
            [
                'name' => 'flat_rate',
                'label' => __('Ground Flat Rate Price'),
                'title' => __('Ground Flat Rate Price'),
                'required' => false,
                'value' => $model->getFlatRate()
            ]
        );

        if($model->getId()){
            $ups_chagre = $this->getUpsPrice($model->getId());
        }
        
        $carriers = $this->_shippingConfig->getActiveCarriers($store = null);
        foreach($carriers as $code => $carrier){
            if($code == 'ups')
            {
                $carrierMethods = $carrier->getAllowedMethods();
                $c_code = $carrier->getCarrierCode();
                foreach($carrierMethods as $key => $value){
                    if($key == '03'){
                        continue;
                    }
                    $fieldset->addField(
                            'ups_'.$key,
                            'text',
                            [
                                'name' => 'ups['.$key.']',
                                'label' => __($value),
                                'title' => __($value),
                                'required' => false,
                                'class' => 'validate-digits',
                                'value' => isset($ups_chagre[$key]) ? $ups_chagre[$key] : ''
                            ]
                        );
                }
            }
        }        
        

        $fieldset->addField(
            'invoice_method',
            'checkboxes',
            [
                'label' => __('Send Invoice Through'),
                'title' => __('Send Invoice Through'),
                'name'  =>  __('invoice_method[]'),
                'required' => false,
                'values' => array(
                            array('value'=>'1','label'=>'Email'),
                            array('value'=>'2','label'=>'Mail')
                       ),
               'checked' => explode(",", $model->getInvoiceMethod())
            ]
        );

        $fieldset->addField(
            'send_corporate',
            'radios',
            [
                'label' => __('Send Invoice To'),
                'title' => __('Send Invoice To'),
                'name' => 'send_corporate',
                'required' => false,
                'values' => array(
                            array('value'=>'1','label'=>'Corporate Address'),
                            array('value'=>'2','label'=>'Store Address'),
                            array('value'=>'3','label'=>'Third Party Address'),
                            array('value'=>'0','label'=>'None'),
                       ),
               'value' => $model->getSendCorporate()
            ]
        );


        $fieldset->addField(
            'pay_later',
            'checkbox',
            array(
                'name' => 'pay_later',
                'label' => __('Bill without Purchase Order'),
                'required' => false,
                'value'  => $model->getPayLater(),
                'onclick' => 'this.value = this.checked ? 1 : 0;',
            ))->setIsChecked($model->getPayLater()
        );


        $fieldset->addField(
            'purchase_order',
            'checkbox',
            array(
                'name' => 'purchase_order',
                'label' => __('Bill with Purchase Order)'),
                'required' => false,
                'value'  => $model->getPurchaseOrder(),
                'onclick' => 'this.value = this.checked ? 1 : 0;',
            ))->setIsChecked($model->getPurchaseOrder()
        );

         /*
          * Add Ajax to the Country select box html output
          */
        $country->setAfterElementHtml("   
            <script type=\"text/javascript\">
                    require([
                    'jquery',
                ],
                function($) {
                     $('#phone_number').on('input', function() {
                            $('#phone_number').attr('maxlength', '14');
                            var number = $(this).val().replace(/[^\d]/g, '')
                            if (number.length == 7) {
                                    number = number.replace(/(\d{3})(\d{4})/, '$1-$2');
                            } else if (number.length == 10) {
                                    number = number.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
                            }
                            $(this).val(number)
                    });
                     $('#zip').on('input', function() {
                            $('#zip').attr('maxlength', '');
                            
                            $(this).val(number)
                    });
                }
            );
            </script>"
        );
		
        $form->setAction($this->getUrl('*/*/save'));
        $this->setForm($form);

        return parent::_prepareForm();
    }
    
    /**
     * Retrieve Approved Sales Person
     *
     * @return array
     */
	
    public function getSalesPerson(){
        $salesPersonData = array();
	$salesPersonCollection =  $this->_salesPersonFactory->create()->getCollection();
	$salesPerson =  $salesPersonCollection->getData();
	foreach($salesPerson as $sale){
            $salesPersonData[] = [
                'value' => $sale['id'],
                'label' => $sale['sales_person'],
            ];
	}
		
        return $salesPersonData;
    }
	
    /**
     * Retrieve Particular UPS Method Price
     *
     * @return array
     */
    public function getUpsPrice($id){
	$salesPersonCollection =  $this->_priceFactory->create()->getCollection()->addFieldToFilter('restaurant_id', array(
        'eq'=> $id ));
        $salesPerson =  $salesPersonCollection->getData(); 
        if(count($salesPerson) > 0) {
            foreach($salesPerson as $sale){
                $salesPersonData[] = [
                  'code' => $sale['shipping_code'],
                  'price' => $sale['shipping_price'],
                ];
            }
            $ups_price = array();
            foreach($salesPersonData as $data) {
              $ups_price[$data['code']] = $data['price'];
            }
            return $ups_price;
        }
    }

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel()
    {
        return __('Restaurant Info');
    }
 
    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle()
    {
        return __('Restaurant Info');
    }
 
    /**
     * {@inheritdoc}
     */
    public function canShowTab()
    {
        return true;
    }
 
    /**
     * {@inheritdoc}
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * Create list of all US states
     * @return array
     */
    public function stateListDropDown()
    {
        $state_list = $this->_regionColFactory->create()->getCollection()->addFieldToFilter('country_id', 'US');
        $final_state_list = $state_list->toOptionArray();
        return $final_state_list;
    }
}