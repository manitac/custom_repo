<?php

/**
 * Store Edit Form Block
 *
 */

namespace DocResearch\Restaurant\Block\Adminhtml\Template\Edit;

use Magento\Framework\Data\Form as DataForm;

class Form extends \Magento\Backend\Block\Widget\Form\Generic {

    /**
     * @return $this
     */
    protected function _prepareForm() {
        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
                [
                    'data' => [
                        'id' => 'edit_form',
                        'action' => $this->getData('action'),
                        'method' => 'post'
                    ]
                ]
        );
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }

}
