<?php

/**
 * Store  Tab Block
 *
 */

namespace DocResearch\Restaurant\Block\Adminhtml\Template\Edit;

/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs {

    /**
     * @return void
     */
    protected function _construct() {
        parent::_construct();
        $this->setId('restaurant_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Restaurant Information'));
    }

    /**
     * @return html for tab rendering
     */
    protected function _beforeToHtml() { 
        $this->addTab(
                'restaurant_info', [
            'label' => __('Restaurant Information'),
            'title' => __('Restaurant Information'),
            'content' => $this->getChildHtml('main'),
            'active' => true
                ]
        );

        $this->addTab(
            'third_party_address', [
            'label' => __('Third Party Address'),
            'url' => $this->getUrl('restaurant/*/address', ['_current' => true]),
            'class' => 'ajax'
                ]
        );

        $this->addTab(
            'restaurant_template', [
            'label' => __('Assign Product'),
            'url' => $this->getUrl('restaurant/*/grid', ['_current' => true]),
            'class' => 'ajax'
                ]
        );

        return parent::_beforeToHtml();
    }

}
