<?php

namespace DocResearch\Restaurant\Block;

use Magento\Framework\View\Element\Template;

/**
 * Restaurant Class Extending Magento\Framework\View\Element\Template
 */
class Restaurant extends Template {
    
    /**
     * Call Parent layout function
     * @return layout object
     */
    public function _prepareLayout() {
        return parent::_prepareLayout();
    }

    /**
     * Provide action to save form data
     * @return string
     */
    public function getFormAction() {
        return '/restaurant/request';
    }

}

?>