<?php

/**
 * Store Template Controller  
 *
 */

namespace DocResearch\Store\Controller\Adminhtml;

/**
 * Template abstract class
 *
 */
abstract class Template extends \Magento\Backend\App\Action {

    /**
     * @return bool
     */
    protected function _isAllowed() {
        return $this->_authorization->isAllowed('DocResearch_Store::store_template');
    }

}
