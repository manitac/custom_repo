<?php

/**
 * Store Grid Controller.
 */

namespace DocResearch\Store\Controller\Adminhtml\Template;

class Grid extends \DocResearch\Store\Controller\Adminhtml\Template {

    /**
     * @var \Magento\Framework\View\Result\LayoutFactory
     */
    protected $resultLayoutFactory;

    public function __construct(
    \Magento\Backend\App\Action\Context $context, \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultLayoutFactory = $resultLayoutFactory;
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * @return \Magento\Framework\View\Result\Layout
     */
    public function execute() {
        $resultLayout = $this->resultLayoutFactory->create();
        $layout = $resultLayout->getLayout();
        $block = $layout->createBlock('DocResearch\Store\Block\Adminhtml\Template\Edit\Tab\Grid');
        $this->getResponse()->appendBody($block->toHtml());
    }

}
