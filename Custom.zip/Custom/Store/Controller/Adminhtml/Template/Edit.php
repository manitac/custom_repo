<?php

/**
 * Store Edit Controller.
 */

namespace DocResearch\Store\Controller\Adminhtml\Template;

class Edit extends \DocResearch\Store\Controller\Adminhtml\Template {

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     */
    public function __construct(\Magento\Backend\App\Action\Context $context, \Magento\Framework\Registry $coreRegistry, \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_storeCollection = $storeCollection;
        parent::__construct($context);
    }

    /**
     * Edit Store
     *
     * @return void
     */
    public function execute() {
        $model = $this->_objectManager->create('DocResearch\Store\Model\Template');
        $id = $this->getRequest()->getParam('id');
        if ($id) {
            $model->load($id);
        }

        $this->_coreRegistry->register('_store_template', $model);

        $this->_view->loadLayout();
        $this->_setActiveMenu('DocResearch_Store::store_template');

        if ($model->getId()) {
            $breadcrumbTitle = __('Edit Store');
            $breadcrumbLabel = $breadcrumbTitle;
        } else {
            $breadcrumbTitle = __('New Store');
            $breadcrumbLabel = __('Create Store');
        }
        $this->_view->getPage()->getConfig()->getTitle()->prepend(__('Stores'));
        $this->_view->getPage()->getConfig()->getTitle()->prepend(
                $model->getId() ? $model->getTemplateId() : __('New Store')
        );

        $this->_addBreadcrumb($breadcrumbLabel, $breadcrumbTitle);

        // restore data
        $values = $this->_getSession()->getData('store_template_form_data', true);
        if ($values) {
            $model->addData($values);
        }

        $this->_view->renderLayout();
    }

}
