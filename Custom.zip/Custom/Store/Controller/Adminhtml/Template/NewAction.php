<?php

/**
 * Store New Action Controller.
 */

namespace DocResearch\Store\Controller\Adminhtml\Template;

class NewAction extends \DocResearch\Store\Controller\Adminhtml\Template {

    /**
     * Create new Store
     *
     * @return void
     */
    public function execute() {
        $this->_forward('edit');
    }

}
