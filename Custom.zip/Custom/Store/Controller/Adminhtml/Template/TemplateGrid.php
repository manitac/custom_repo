<?php

/**
 * Store Template Grid Controller.
 */

namespace DocResearch\Store\Controller\Adminhtml\Template;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class TemplateGrid extends \Magento\Backend\App\Action {

    public function __construct(
    Context $context, PageFactory $resultPageFactory, \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->resultLayoutFactory = $resultLayoutFactory;
    }

    public function execute() {
        $resultLayout = $this->resultLayoutFactory->create();
        $layout = $resultLayout->getLayout();
        $block = $layout->createBlock('DocResearch\Store\Block\Adminhtml\Template\Edit\Tab\Grid');
        $this->getResponse()->appendBody($block->toHtml());
    }

}
