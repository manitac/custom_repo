<?php

/**
 * Store Listing block
 *
 */

namespace DocResearch\Store\Block\Adminhtml;

class Template extends \Magento\Backend\Block\Template {

    /**
     * @var string
     */
    protected $_template = 'template/list.phtml';

    /**
     * @return $this
     */
    protected function _prepareLayout() {
        $this->getToolbar()->addChild(
                'add_button', 'Magento\Backend\Block\Widget\Button', [
            'label' => __('Add New Store'),
            'onclick' => "window.location='" . $this->getCreateUrl() . "'",
            'class' => 'add primary add-template'
                ]
        );

        return parent::_prepareLayout();
    }

    /**
     * Get the url for create
     *
     * @return string
     */
    public function getCreateUrl() {
        return $this->getUrl('*/*/new');
    }

    /**
     * Get header text
     *
     * @return \Magento\Framework\Phrase
     */
    public function getHeaderText() {
        return __(' Stores');
    }

}
