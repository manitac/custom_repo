<?php

/**
 * Store  Tab Block
 *
 */

namespace DocResearch\Store\Block\Adminhtml\Template\Edit;

/**
 * Admin page left menu
 */
class Tabs extends \Magento\Backend\Block\Widget\Tabs {

    /**
     * @return void
     */
    protected function _construct() {
        parent::_construct();
        $this->setId('store_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('Store Information'));
    }

    /**
     * @return html for tab rendering
     */
    protected function _beforeToHtml() {
        $this->addTab(
                'store_info', [
            'label' => __('Store Information'),
            'title' => __('Store Information'),
            'content' => $this->getChildHtml('main'),
            'active' => true
                ]
        );

        return parent::_beforeToHtml();
    }

}
