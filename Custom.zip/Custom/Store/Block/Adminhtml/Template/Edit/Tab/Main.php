<?php

/**
 * Store Information Edit Form Block
 *
 */

namespace DocResearch\Store\Block\Adminhtml\Template\Edit\Tab;

use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Backend\Block\Template\Context;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Eav\Block\Adminhtml\Attribute\PropertyLocker;

class Main extends Generic implements TabInterface {

    /**
     * @var \DocResearch\Restaurant\Helper\Option
     */
    protected $_statusOption;
    protected $_countryFactory;
    protected $_templateFactory;
    protected $_salesPersonFactory;
    protected $_regionColFactory;

    /**
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param FormFactory $templateFactory
     * @param FormFactory $optionData
     * @param array $data
     */
    public function __construct(
    Context $context, Registry $registry, FormFactory $formFactory, \DocResearch\Store\Helper\Option $optionData, \DocResearch\Restaurant\Model\TemplateFactory $templateFactory, \Magento\Directory\Model\RegionFactory $regionColFactory, \Magento\Directory\Model\Config\Source\Country $countryFactory, array $data = []
    ) {
        $this->_countryFactory = $countryFactory;
        $this->_templateFactory = $templateFactory;
        $this->_regionColFactory = $regionColFactory;
        $this->_statusOption = $optionData;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Retrieve template object
     *
     * @return \DocResearch\Store\Model\Template
     */
    public function getModel() {
        return $this->_coreRegistry->registry('_store_template');
    }

    /**
     * Prepare form fields
     *
     * @return \Magento\Backend\Block\Widget\Form
     */
    protected function _prepareForm() {
        $model = $this->_coreRegistry->registry('_store_template');
        $model = $this->getModel();
        $request = $this->getRequest();

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
                ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $fieldset = $form->addFieldset(
                'base_fieldset', ['legend' => __('Store Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id', 'value' => $model->getId()]);
        }

        $fieldset->addField(
                'restaurant_id', 'select', [
            'name' => 'restaurant_id',
            'label' => __('Restaurant/Brand'),
            'required' => false,
            'value' => $model->getRestaurantId(),
            'values' => $this->getApprovedBrand(),
                ]
        );


        $fieldset->addField(
            'store_name', 'text', [
            'name' => 'store_name',
            'label' => __('Store Name'),
            'title' => __('Store Name'),
            'required' => true,
            'value' => $model->getName()
                ]
        );

        $fieldset->addField(
                'email', 'text', [
            'name' => 'email',
            'label' => __('Email'),
            'title' => __('Email'),
            'class' => 'validate-email',
            'required' => true,
            'value' => $model->getEmail()
                ]
        );

        $fieldset->addField(
                'phone_number', 'text', [
            'name' => 'phone_number',
            'label' => __('Phone Number'),
            'title' => __('Phone Number'),
            //'class' => 'validate-digits validate-length minimum-length-10 maximum-length-11',
            'class' => 'validate-phoneStrict',
            'required' => true,
            'value' => $model->getPhoneNumber()
                ]
        );

        $fieldset->addField(
                'address', 'text', [
            'name' => 'address',
            'label' => __('Address Line 1'),
            'title' => __('Address Line 1'),
            'required' => true,
            'value' => $model->getAddress()
                ]
        );
        
         $fieldset->addField(
                'address2', 'text', [
            'name' => 'address2',
            'label' => __('Address Line 2'),
            'title' => __('Address Line 2'),
            'value' => $model->getAddressLine()
                ]
        );

		$fieldset->addField(
                'city', 'text', [
            'name' => 'city',
            'label' => __('City'),
            'title' => __('City'),
            'required' => true,
            'value' => $model->getCity()
                ]
        );
		
		$fieldset->addField(
                'state', 'select', [
            'name' => 'state',
            'label' => __('State'),
            'title' => __('State'),
            'required' => false,
            'value' => $model->getState(),
            'values' => $this->stateListDropDown()
                ]
        );
		
        $fieldset->addField(
                'zip', 'text', [
            'name' => 'zip',
            'label' => __('Zip Code5'),
            'title' => __('Zip Code'),
            'class' => 'validate-digits validate-length minimum-length-5 maximum-length-6',
            'required' => true,
            'value' => $model->getZip()
                ]
        );

        

        $optionsc = array('US' => 'United States');
        $country = $fieldset->addField(
                'country', 'select', [
            'name' => 'country',
            'label' => __('Country'),
            'title' => __('Country'),
            'value' => $model->getCountry(),
            'values' => $optionsc,
                ]
        );


        

         /*
          * Add Ajax to the Country select box html output
          */
        $country->setAfterElementHtml("   
            <script type=\"text/javascript\">
                    require([
                    'jquery',
                ],
                function($) {
                     $('#phone_number').on('input', function() {
                            $('#phone_number').attr('maxlength', '14');
                            var number = $(this).val().replace(/[^\d]/g, '')
                            if (number.length == 7) {
                                    number = number.replace(/(\d{3})(\d{4})/, '$1-$2');
                            } else if (number.length == 10) {
                                    number = number.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
                            }
                            $(this).val(number)
                    });
                }
            );
            </script>"
        );

        $form->setAction($this->getUrl('*/*/save'));
        $this->setForm($form);

        return parent::_prepareForm();
    }

    /**
     * Retrieve Approved store
     *
     * @return array
     */
    public function getApprovedBrand() {
        $brandData = array();
        $brandCollection = $this->_templateFactory->create()->getCollection()
                ->addFieldToFilter('status', 1);
        $brands = $brandCollection->getData();
        foreach ($brands as $brand) {
            $brandData[] = [
                'value' => $brand['id'],
                'label' => $brand['name'],
            ];
        }

        return $brandData;
    }

    /**
     * Retrieve Approved store
     *
     * @return array
     */

    /**
     * Prepare label for tab
     *
     * @return string
     */
    public function getTabLabel() {
        return __('Store Info');
    }

    /**
     * Prepare title for tab
     *
     * @return string
     */
    public function getTabTitle() {
        return __('Store Info');
    }

    /**
     * {@inheritdoc}
     */
    public function canShowTab() {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function isHidden() {
        return false;
    }

    public function stateListDropDown() {
        $state_list = $this->_regionColFactory->create()->getCollection()->addFieldToFilter('country_id', 'US');
        $final_state_list = $state_list->toOptionArray();
        return $final_state_list;
    }

}
