<?php

/**
 * Store Grid Block
 *
 */

namespace DocResearch\Store\Block\Adminhtml\Template\Edit\Tab;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended {

    protected $_productFactory;

    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Backend\Helper\Data $backendHelper, \Magento\Catalog\Model\ProductFactory $productFactory, \Magento\Framework\Registry $coreRegistry, array $data = []
    ) {
        $this->_productFactory = $productFactory;
        $this->_coreRegistry = $coreRegistry;
        parent::__construct($context, $backendHelper, $data);
    }

    protected function _prepareGrid() {
        $this->setId('store_grid' . $this->getWebsiteId());
        parent::_prepareGrid();
    }

    /**
     * {@inheritdoc}
     */
    protected function _preparePage() {
        $this->getCollection()->setPageSize(20)->setCurPage(1);
    }

    /**
     * @return void
     */
    protected function _construct() {

        parent::_construct();
        $this->setId('store_tab_grid');
        $this->setDefaultSort('entity_id');
        $this->setUseAjax(true);
    }

    /**
     * @return Store
     */
    protected function _getStore() {
        $storeId = (int) $this->getRequest()->getParam('store', 0);
        return $this->_storeManager->getStore($storeId);
    }

    /**
     * @return Grid
     */
    protected function _prepareCollection() {
        $store = $this->_getStore();
        $collection = $this->_productFactory->create()->getCollection()->addAttributeToSelect("*")
                        ->addAttributeToSelect('qty_per_box')
                        ->addAttributeToSelect(
                                'attribute_set_id'
                        )->addAttributeToSelect(
                        'type_id'
                )->setStore(
                $store
        );

        $this->setCollection($collection);
        $this->getCollection()->addWebsiteNamesToResult();
        return parent::_prepareCollection();
    }

    /**
     * @return Extended
     */
    protected function _prepareColumns() {
        $this->addColumn(
                'entity_id', [
            'header' => __('Product Id'),
            'sortable' => true,
            'index' => 'entity_id',
            'header_css_class' => 'col-id',
            'column_css_class' => 'col-id'
                ]
        );
        $this->addColumn(
                'name', [
            'header' => __('Product Name'),
            'index' => 'name'
                ]
        );
        $this->addColumn(
                'sku', [
            'header' => __('Sku'),
            'index' => 'sku'
                ]
        );

        $this->addColumn(
                'qty_per_box', [
            'header' => __('Qty Per Box'),
            'index' => 'qty_per_box',
            'renderer' => '\DocResearch\Store\Block\Adminhtml\Template\Renderer\QtyPerBox'
                ]
        );


        $this->addColumn(
                'price', [
            'header' => __('Price'),
            'index' => 'price'
                ]
        );

        $this->addColumn(
                'store_price', [
            'header' => __('Store Price'),
            'index' => 'entity_id',
            'renderer' => '\DocResearch\Store\Block\Adminhtml\Template\Renderer\StorePrice',
                ]
        );

        return parent::_prepareColumns();
    }

    /**
     * @return string
     */
    public function getGridUrl() {
        return $this->getUrl('store/*/templateGrid', ['_current' => true]);
    }

}
