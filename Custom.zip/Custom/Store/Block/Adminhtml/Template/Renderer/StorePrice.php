<?php

namespace DocResearch\Store\Block\Adminhtml\Template\Renderer;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\DataObject;
use Magento\Store\Model\StoreManagerInterface;
use DocResearch\Store\Model\StoreFactory;

class StorePrice extends AbstractRenderer {

    private $_storeManager;
    protected $_modelStoreFactory;

    /**
     * @param \Magento\Backend\Block\Context $context
     * @param array $data
     */
    public function __construct(\Magento\Backend\Block\Context $context, StoreManagerInterface $storemanager, StoreFactory $modelStoreFactory, array $data = []) {

        $this->_modelStoreFactory = $modelStoreFactory;
        $this->_storeManager = $storemanager;
        parent::__construct($context, $data);
        $this->_authorization = $context->getAuthorization();
    }

    /**
     * Renders grid column
     *
     * @param Object $row
     * @return  string
     */
    public function render(DataObject $row) {

        $id = $this->getRequest()->getParam('id');
        $value = parent::render($row);
        $modelStoreFactory = $this->_modelStoreFactory->create();
        $storeCollection = $modelStoreFactory->getCollection()->addFieldToFilter('product_id', $value)->addFieldToFilter('store_id', $id);
        $storeData = $storeCollection->getData();
        if (count($storeData) > 0 && !empty($id)) {
            $product_id = $storeData[0]['product_id'];
            $product_price = $storeData[0]['product_price'];
            return "<input type='text' maxlength='10' name='product_price[$product_id]' value='" . $product_price . "'>";
        } else {
            return "<input type='text' maxlength='10' name='product_price[$value]'>";
        }
    }

}
