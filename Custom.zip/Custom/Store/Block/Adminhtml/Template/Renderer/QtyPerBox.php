<?php

namespace DocResearch\Store\Block\Adminhtml\Template\Renderer;

use Magento\Backend\Block\Widget\Grid\Column\Renderer\AbstractRenderer;
use Magento\Framework\DataObject;
use Magento\Store\Model\StoreManagerInterface;

class QtyPerBox extends AbstractRenderer {

    protected $_productRepository;
    protected $eavAttributeRepository;

    public function __construct(
    \Magento\Backend\Block\Context $context, \Magento\Catalog\Model\ProductRepository $productRepository, \Magento\Eav\Api\AttributeRepositoryInterface $eavAttributeRepository, array $data = []
    ) {
        $this->_productRepository = $productRepository;
        $this->eavAttributeRepository = $eavAttributeRepository;
        parent::__construct($context, $data);
    }

    /**
     * Renders grid column
     *
     * @param Object $row
     * @return  string
     */
    public function render(DataObject $row) {

        $valuea = parent::render($row);
        $attributes = $this->eavAttributeRepository->get(\Magento\Catalog\Api\Data\ProductAttributeInterface::ENTITY_TYPE_CODE, 'qty_per_box');
        $optionList = $attributes->getSource()->getAllOptions(false);
        foreach ($optionList as $key => $value) {
            if ($valuea == $value['value']) {
                return $value['label'];
            }
        }
    }

}
