<?php
/**
 * Restaurant setup to create module table
 */
 
namespace DocResearch\Store\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
/**
 * Class InstallSchema to create module table
 */

    class UpgradeSchema implements UpgradeSchemaInterface{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    const CUSTOM_ATTRIBUTE_ID = 'address_line';
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '3.0.0') < 0) {
            $setup->getConnection()->addColumn(
                $setup->getTable('store_template'),
                self::CUSTOM_ATTRIBUTE_ID,
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => false,
                    'comment' => 'Address'
                ]
            );
        }
        $setup->endSetup();
    }
}
    

