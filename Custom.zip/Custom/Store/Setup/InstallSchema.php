<?php

namespace DocResearch\Store\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;
        $installer->startSetup();

        $storeTable = $installer->getConnection()->newTable(
                        $installer->getTable('store_template'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'name', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Name'
                )
                ->addColumn(
                        'email', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Email'
                )
                ->addColumn(
                        'sales_person', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Sales Person'
                )
                ->addColumn(
                        'phone_number', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Phone Number'
                )
                ->addColumn(
                        'address', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Address'
                )
                ->addColumn(
                        'city', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'City'
                )
                ->addColumn(
                        'state', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'State'
                )
                ->addColumn(
                        'country', \Magento\Framework\DB\Ddl\Table::TYPE_TEXT, null, ['nullable' => false], 'Country'
                )
                ->addColumn(
                        'zip', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['nullable' => false], 'Zip'
                )
                ->addColumn(
                        'has_pay_later', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Has Pay Later'
                )
                ->addColumn(
                        'restaurant_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Restaurant ID'
                )
                ->addColumn(
                        'sales_person_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Sales Person ID'
                )
                ->addColumn(
                'status', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Status'
        );
        $installer->getConnection()->createTable($storeTable);

        $storeTable2 = $installer->getConnection()->newTable(
                        $installer->getTable('store_price'))
                ->addColumn(
                        'id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, null, ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'store_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Store ID'
                )
                ->addColumn(
                        'product_id', \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER, 0, ['nullable' => false], 'Product ID'
                )
                ->addColumn(
                        'product_price', \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL, '12,4', ['nullable' => false], 'Product Price'
                )
                ->addColumn(
                'status', \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT, 0, ['nullable' => false], 'Status'
        );
        $installer->getConnection()->createTable($storeTable2);

        $installer->endSetup();
    }

}
