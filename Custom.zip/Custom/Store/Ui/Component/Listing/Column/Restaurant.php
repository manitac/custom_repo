<?php

namespace DocResearch\Store\Ui\Component\Listing\Column;

use \Magento\Sales\Api\OrderRepositoryInterface;
use \Magento\Framework\View\Element\UiComponent\ContextInterface;
use \Magento\Framework\View\Element\UiComponentFactory;
use \Magento\Ui\Component\Listing\Columns\Column;
use \Magento\Framework\Api\SearchCriteriaBuilder;
use DocResearch\Restaurant\Model\TemplateFactory; // model for restautrant

class Restaurant extends Column {

    protected $_orderRepository;
    protected $_searchCriteria;
    protected $_templateFactory;

    public function __construct(ContextInterface $context, UiComponentFactory $uiComponentFactory, OrderRepositoryInterface $orderRepository, SearchCriteriaBuilder $criteria, TemplateFactory $templateFactory, array $components = [], array $data = []) {
        $this->_orderRepository = $orderRepository;
        $this->_searchCriteria = $criteria;
        $this->_templateFactory = $templateFactory;

        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource) {
        $restaurantdata = $this->_templateFactory->create();


        if (isset($dataSource['data']['items'])) {

            foreach ($dataSource['data']['items'] as & $item) {
                $restaurantcoll = $restaurantdata->load($item["restaurant_id"]); //load data from restaurant model
                $item[$this->getData('name')] = $restaurantcoll->getName();  //restaurant name
            }
        }

        return $dataSource;
    }

}
