<?php

/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace DocResearch\Shipping\Controller\Adminhtml\Order\Shipment;

use Magento\Backend\App\Action;

class CreateLabel extends \Magento\Shipping\Controller\Adminhtml\Order\Shipment\CreateLabel {

    /**
     * Authorization level of a basic admin session
     *
     * @see _isAllowed()
     */
    

    /**
     * Create shipping label action for specific shipment
     *
     * @return void
     */
    public function execute() {
        $response = new \Magento\Framework\DataObject();
        try {

            $this->shipmentLoader->setOrderId($this->getRequest()->getParam('order_id'));
                    $this->shipmentLoader->setShipmentId($this->getRequest()->getParam('shipment_id'));
                    $this->shipmentLoader->setShipment($this->getRequest()->getParam('shipment'));
                    $this->shipmentLoader->setTracking($this->getRequest()->getParam('tracking'));

                    $shipment = $this->shipmentLoader->load();
                    $this->labelGenerator->create($shipment, $this->_request);
                    $shipment->save();


                    $order_id = $shipment->getData('order_id');

                    /**
                     * Change order status to a custom status
                     * To check if the shipping label has created
                     */
                    $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
                    $connection = $this->_resources->getConnection();

                    $connection->update('sales_order', ['state' => 'processing', 'status' => 'shipping_label_created'], ["entity_id = ?" => $order_id]);
                    $connection->update('sales_order_grid', ['status' => 'shipping_label_created'], ["entity_id = ?" => $order_id]);
                    $connection->update('sales_order_status_history', ['status' => 'shipping_label_created', 'comment' => 'Order status changed successfully'], ["parent_id = ?" => $order_id]);

                    /**
                     * Notify User that shipment is created
                     * Using Object Manager
                     */
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $objectManager->create('Magento\Shipping\Model\ShipmentNotifier')->notify($shipment);

                    $this->messageManager->addSuccess(__('You created the shipping label.'));
                    $response->setOk(true);
            
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $response->setError(true);
            $response->setMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->_objectManager->get('Psr\Log\LoggerInterface')->critical($e);
            $response->setError(true);
            $response->setMessage(__('An error occurred while creating shipping label.'));
        }

        $this->getResponse()->representJson($response->toJson());
    }

}
