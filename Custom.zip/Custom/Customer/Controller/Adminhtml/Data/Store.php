<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Controller\Adminhtml\Data;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action;

class Store extends \Magento\Framework\App\Action\Action {

    /**
     * Show customer tickets
     *
     * @return \Magento\Framework\View\Result\Page
     * @throws NotFoundException
     */
    protected $_customerSession;
    protected $_sessionQuote;
    protected $_response;
    protected $cart;

    public function __construct(
    Context $context, \Magento\Backend\Model\Session\Quote $sessionQuote, \Magento\Framework\App\Response\Http $response, \Magento\Checkout\Model\Cart $cart
    ) {
        $this->cart = $cart;
        $this->_sessionQuote = $sessionQuote;
        $this->_response = $response;
        parent::__construct($context);
    }

    public function execute() {
        #get store ID from post Request
        $customer_store_id = $this->getRequest()->getParam('store_id');

        #Delete the added products
        $this->deleteQuoteItems();

        #set current store in session
        $this->_sessionQuote->setCurrentStore($customer_store_id);
    }

    public function deleteQuoteItems() {
        $checkoutSession = $this->getCheckoutSession();
        $quote_Id = $checkoutSession->getQuote()->getId();
        $allItems = $checkoutSession->getQuote()->getAllVisibleItems(); //returns all the items in session

        foreach ($allItems as $item) {
            $itemId = $item->getItemId(); //item id of particular item
            $checkoutSession->getQuote()->removeItem($itemId)->save(); //Remove item from the Quote
        }
    }

    public function getCheckoutSession() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of object manager 
        $checkoutSession = $objectManager->get('Magento\Backend\Model\Session\Quote'); //checkout session
        return $checkoutSession;
    }

    public function getItemModel() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of object manager
        $itemModel = $objectManager->create('Magento\Quote\Model\Quote\Item'); //Quote item model to load quote item
        return $itemModel;
    }

}
