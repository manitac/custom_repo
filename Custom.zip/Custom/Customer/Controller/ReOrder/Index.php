<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Controller\ReOrder;

use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action {

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     *
     * @var \DocResearch\Customer\Model\Customer\Reorder
     */
    protected $_reorder;

    /**
     * Get customer Model for last order
     *
     * @return \Magento\Framework\View\Result\Page
     * @throws NotFoundException
     */
    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory, \DocResearch\Customer\Model\Reorder\ReOrder $reorder
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_reorder = $reorder;
        parent::__construct($context);
    }

    public function execute() {
        $data = $this->_reorder->createOrder();
        if ($data == false) {
            $message = __('Error While reordering.');
            $this->messageManager->addError($message);
        } else {
            $message = __('Your order has been placed. Order Id is ' . $data);
            $this->messageManager->addSuccess($message);
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;
    }

}
