<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Controller\Data;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action;

//use Magento\Checkout\Model\Cart as CustomerCart;

class Store extends \Magento\Framework\App\Action\Action {

    /**
     * Show customer tickets
     *
     * @return \Magento\Framework\View\Result\Page
     * @throws NotFoundException
     */
    protected $_customerSession;
    protected $_response;
    protected $cart;

    public function __construct(
    Context $context, \Magento\Customer\Model\Session $customerSession, \Magento\Framework\App\Response\Http $response, \Magento\Checkout\Model\Cart $cart
    ) {
        $this->cart = $cart;
        $this->_customerSession = $customerSession;
        $this->_response = $response;
        parent::__construct($context);
    }

    public function execute() {
        $cusStorArr = array();
        $customer_store_id = $this->getRequest()->getParam('store_id');

        if ($this->_customerSession->getCustomerStores()) {
            if (!in_array($customer_store_id, $this->_customerSession->getCustomerStores())) {
                $arr = $this->_customerSession->getCustomerStores();
                $arr[] = $customer_store_id;
                $sess = $this->_customerSession->setCustomerStores($arr);
            }
        } else {
            $cusStorArr[] = $customer_store_id;
            $this->_customerSession->setCustomerStores($cusStorArr);
        }
        $this->_customerSession->setCurrentStore($customer_store_id);
    }

    public function deleteQuoteItems() {
        $checkoutSession = $this->getCheckoutSession();
        $quote_Id = $this->cart->getQuote()->getId();
        $allItems = $checkoutSession->getQuote()->getAllVisibleItems(); //returns all teh items in session
        foreach ($allItems as $item) {
            $itemId = $item->getItemId(); //item id of particular item
            $quoteItem = $this->getItemModel()->load($itemId); //load particular item which you want to delete by his item id
            $quoteItem->delete();
        }
        if (!empty($quote_Id)) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('quote');
            $sql = "DELETE  FROM " . $tableName . " WHERE entity_id = " . $quote_Id;
            $connection->query($sql);
        }
    }

    public function getCheckoutSession() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of object manager 
        $checkoutSession = $objectManager->get('Magento\Checkout\Model\Session'); //checkout session
        return $checkoutSession;
    }

    public function getItemModel() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); //instance of object manager
        $itemModel = $objectManager->create('Magento\Quote\Model\Quote\Item'); //Quote item model to load quote item
        return $itemModel;
    }

}
