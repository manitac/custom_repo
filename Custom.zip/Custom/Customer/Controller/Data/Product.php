<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor. 3048001500007228 PUNB0304800
 */

namespace DocResearch\Customer\Controller\Data;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action;
use Magento\Framework\Exception\NotFoundException;
use Magento\Framework\Controller\ResultFactory;
use Magento\Sales\Controller\OrderInterface;
use Magento\Framework\View\Result\PageFactory;

class Product extends \Magento\Framework\App\Action\Action {

    /**
     * Show customer tickets
     *
     * @return \Magento\Framework\View\Result\Page
     * @throws NotFoundException
     */
    protected $_session;
    protected $response;

    public function __construct(
    Context $context, PageFactory $resultPageFactory, \Magento\Customer\Model\Session $session, \Magento\Framework\App\Response\Http $response
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_session = $session;
        $this->response = $response;
        parent::__construct($context);
    }

    public function execute() {
        if (!$this->_session->isLoggedIn()) {
            $result = $this->resultPageFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultPage = $this->response->setRedirect('/customer/account/login/');

            return $resultPage;
        } else {
            /** @var \Magento\Framework\View\Result\Page resultPage */
            $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
            $resultPage->getConfig()->getTitle()->prepend(__('Product(s)'));

            return $resultPage;
        }
    }

}
