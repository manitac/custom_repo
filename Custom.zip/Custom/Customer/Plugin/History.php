<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace DocResearch\Customer\Plugin;

use \Magento\Sales\Model\ResourceModel\Order\CollectionFactoryInterface;

/**
 * Sales order history block
 */
class History extends \Magento\Sales\Block\Order\History {

    /**
     * @var string
     */
    //protected $_template = 'order/history.phtml';

    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $_orderCollectionFactory;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Sales\Model\Order\Config
     */
    protected $_orderConfig;

    /** @var \Magento\Sales\Model\ResourceModel\Order\Collection */
    protected $orders;

    /**
     * @var CollectionFactoryInterface
     */
    private $orderCollectionFactory;

    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory, \Magento\Customer\Model\Session $customerSession, \Magento\Sales\Model\Order\Config $orderConfig, array $data = []
    ) {
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->_customerSession = $customerSession;
        $this->_orderConfig = $orderConfig;
        parent::__construct($context, $data);
        //die('This is just to test 8');
    }

    /**
     * @return CollectionFactoryInterface
     *
     * @deprecated
     */
    /*private function getOrderCollectionFactory() {
        if ($this->orderCollectionFactory === null) {
            $this->orderCollectionFactory = \Magento\Framework\App\ObjectManager::getInstance()->get(CollectionFactoryInterface::class);
        }
        return $this->orderCollectionFactory;
    }*/

    /**
     * @return bool|\Magento\Sales\Model\ResourceModel\Order\Collection
     */
    /*public function afterGetOrders(\Magento\Sales\Block\Order\History $subject, $result) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        $current_store = $customerSession->getCurrentStore();
        if (!empty($current_store)) {
            $c_store_id = $current_store;
        } else {
            $c_store_id = $customerSession->getCustomer()->getData('restaurant');
        }
        if (!($customerId = $customerSession->getCustomerId())) {
            return false;
        }
        if (!$this->orders) {
            $this->orders = $this->getOrderCollectionFactory()->create($customerId)->addFieldToSelect( '*'
                    )->addFieldToFilter('status', ['in' => $this->_orderConfig->getVisibleOnFrontStatuses()]
                    )->setOrder('created_at', 'desc');
        }
        return $this->orders;
    }*/

}
