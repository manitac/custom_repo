<?php

namespace DocResearch\Customer\Model\ReOrder;

class ReOrder extends \Magento\Framework\Model\AbstractModel {

    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Catalog\Model\ProductFactory $product, \Magento\Quote\Model\QuoteFactory $quote, \Magento\Quote\Model\QuoteManagement $quoteManagement, \Magento\Customer\Model\CustomerFactory $customerFactory, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository, \Magento\Sales\Model\Service\OrderService $orderService, \Magento\Quote\Api\CartRepositoryInterface $cartRepositoryInterface, \Magento\Quote\Api\CartManagementInterface $cartManagementInterface, \DocResearch\Customer\Block\Customer\LastOrder $lastorder
    ) {
        $this->_storeManager = $storeManager;
        $this->_product = $product;
        $this->quote = $quote;
        $this->quoteManagement = $quoteManagement;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->orderService = $orderService;
        $this->cartRepositoryInterface = $cartRepositoryInterface;
        $this->cartManagementInterface = $cartManagementInterface;
        $this->lastorder = $lastorder;
    }

    /**
     * Create Order On Your Store
     * @param array $orderData
     * @return int $orderId
     *
     */
    public function createOrder($orderData = null) {
        $_orderDetails = $this->lastorder->getOrders();
        $orderData = array();
        foreach ($_orderDetails as $_order) {
            $lid = $_order->getId();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $order = $objectManager->create('Magento\Sales\Model\Order')->load($lid);
            $items = $order->getAllItems();
            $shippingAddress = $_order->getShippingAddress();
            $orderData['shipping_address']['firstname'] = $shippingAddress->getFirstname();
            $orderData['shipping_address']['lastname'] = $shippingAddress->getLastname();
            $orderData['shipping_address']['street'] = $shippingAddress->getStreet();
            $orderData['shipping_address']['city'] = $shippingAddress->getCity();
            $orderData['shipping_address']['region'] = $shippingAddress->getRegion();
            $orderData['shipping_address']['region_id'] = $shippingAddress->getRegion_id();
            $orderData['shipping_address']['postcode'] = $shippingAddress->getPostcode();
            $orderData['shipping_address']['telephone'] = $shippingAddress->getTelephone();
            $orderData['shipping_address']['fax'] = $shippingAddress->getFax();
            $orderData['shipping_address']['country_id'] = $shippingAddress->getCountry_id();
            $orderData['shipping_address']['save_in_address_book'] = $shippingAddress->getCity();
            $orderData['email'] = $shippingAddress->getEmail();
            $orderData['shipping_method'] = $_order->getShippingMethod();
            $orderData['payment_method'] = $_order->getPayment()->getMethod();
        }

        //init the store id and website id @todo pass from array
        $store = $this->_storeManager->getStore();
        $websiteId = $this->_storeManager->getStore()->getWebsiteId();
        $mediaUrl = $store->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        //init the customer
        $customer = $this->customerFactory->create();
        $customer->setWebsiteId($websiteId);
        $customer->loadByEmail($orderData['email']); // load customet by email address
        //check the customer
        if (!$customer->getEntityId()) {
            //If not avilable then create this customer
            $customer->setWebsiteId($websiteId)
                    ->setStore($store)
                    ->setFirstname($orderData['shipping_address']['firstname'])
                    ->setLastname($orderData['shipping_address']['lastname'])
                    ->setEmail($orderData['email'])
                    ->setPassword($orderData['email']);
            $customer->save();
        }
        //init the quote
        $quote = $this->quote->create();
        $quote->setStore($store);
        // if you have already buyer id then you can load customer directly
        $customer = $this->customerRepository->getById($customer->getEntityId());
        $quote->setCurrency();
        $quote->assignCustomer($customer); //Assign quote to customer
        //add items in quote

        foreach ($items as $key => $value) {
            $product = $this->_product->create()->load($value->getProductId());
            $product_price = $this->getCustomerStorePrice($value->getProductId());
            $product->setPrice($product_price);
            $quote->addProduct(
                    $product, intval($value->getQtyOrdered())
            );
        }
        //Set Address to quote
        $quote->getBillingAddress()->addData($orderData['shipping_address']);
        $quote->getShippingAddress()->addData($orderData['shipping_address']);
        // Collect Rates and Set Shipping & Payment Method
        $shippingAddress = $quote->getShippingAddress();
        $shippingAddress->setCollectShippingRates(true)
                ->collectShippingRates()
                ->setShippingMethod($orderData['shipping_method']); //shipping method
        $quote->setPaymentMethod($orderData['payment_method']); //payment method
        $quote->setInventoryProcessed(false); //not effetc inventory
        $quote->save(); //Now Save quote and your quote is ready
        // Set Sales Order Payment
        $quote->getPayment()->importData(['method' => $orderData['payment_method']]);
        // Collect Totals & Save Quote
        $quote->collectTotals()->save();
        // Create Order From Quote
        $quote = $this->cartRepositoryInterface->get($quote->getId());
        $order = $this->cartManagementInterface->submit($quote);
        $order->setEmailSent(0);
        $increment_id = $order->getRealOrderId();
        if ($order->getEntityId()) {
            return $order->getRealOrderId();
        }
        return false;
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function getCustomerStorePrice($product_id) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            $c_id = $customerSession->getCustomer()->getId();
            $c_store_id = $customerSession->getCustomer()->getData('stores');
            /** @var \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection */
            $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
            /** Apply filters here */
            $store_data = $storeCollection->addFieldToFilter('store_id', array('in' => array($c_store_id)))
                    ->addFieldToFilter('product_id', $product_id);
            $product_price = $store_data->getData();
            return $product_price[0]['product_price'];
        }
        return false;
    }

}
