<?php

/**
 * DocResearch Customer CustomPrice Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use DocResearch\Store\Model\ResoureModel\Store;

class CustomPrice implements ObserverInterface {
    /**
     * @var \DocResearch\Store\Model\StoreFactory;
     */
    //protected $_storeFactory;

    /**
     * @param Context $context
     * @param StoreFactory $storeFactory
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $product_id = $observer->getProduct()->getId();
        $product_price = $this->getCustomerStore($product_id);
        $item = $observer->getEvent()->getData('quote_item');
        $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
        $item->setCustomPrice($product_price);
        $item->setOriginalCustomPrice($product_price);
        $item->getProduct()->setIsSuperMode(true);
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function getCustomerStore($product_id) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        if ($customerSession->isLoggedIn()) {
            $c_id = $customerSession->getCustomer()->getId();
            $c_restaurant_id = $customerSession->getCustomer()->getData('restaurant');
            /** @var \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection */
            $current_store = $customerSession->getCurrentStore();
            if (!empty($current_store)) {
                $c_store_id = $current_store;
            } else {
                $c_store_id = $customerSession->getCustomer()->getData('restaurant');
            }
            /* Get Price from store_price table */
            $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
            /** Apply filters here */
            $store_data = $storeCollection->addFieldToFilter('restaurant_id', array('eq' => $c_restaurant_id))
                    ->addFieldToFilter('product_id', $product_id);
            $product_price = $store_data->getData();
            return $product_price[0]['product_price'];
        }
        return false;
    }

}
