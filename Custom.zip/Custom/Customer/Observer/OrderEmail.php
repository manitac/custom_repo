<?php

namespace DocResearch\Customer\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class OrderEmail implements \Magento\Framework\Event\ObserverInterface {

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        $c_id = $customerSession->getCustomer()->getId();
        $c_store_id = $customerSession->getCurrentStore();
        $store = $objectManager->get('DocResearch\Store\Model\Template');
        //$store_name = ($store->load($c_store_id)->getName());
        $store_restaurant_id = $c_store_id;
        $restaurant = $objectManager->get('DocResearch\Restaurant\Model\Template');
        $restaurant_name = ($restaurant->load($store_restaurant_id)->getName());
        $transport = $observer->getTransport();
        //$transport['customerStoreName'] = $store_name;
        $transport['customerRestauerantName'] = $restaurant_name;
    }

}
