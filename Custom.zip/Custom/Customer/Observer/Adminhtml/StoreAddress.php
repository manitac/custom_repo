<?php

/**
 * DocResearch Customer StoreAddress Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer\Adminhtml;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class StoreAddress implements ObserverInterface {

    protected $_order;
    protected $_resources;
    protected $request;
    protected $_sessionQuote;
    protected $_countryFactory;

    public function __construct(
    \Magento\Backend\Model\Session\Quote $sessionQuote, \Magento\Framework\App\Request\Http $request, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Store\Model\StoreManagerInterface $storeManager, \Magento\Directory\Model\CountryFactory $countryFactory, array $data = []
    ) {
        $this->_sessionQuote = $sessionQuote;
        $this->request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_countryFactory = $countryFactory;
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $stores = '';
        $regionId = "";
        $region = "";
        $customer_data = array();
        $customer_info = $this->request->getPost('customer');
        $statearray =$this->_countryFactory->create()->setId('US')->getLoadedRegionCollection()->toOptionArray();
        if (isset($_POST) && isset($customer_info['stores'])) {
            $stores = implode(",", $customer_info['stores']);
            $customerInfo = $this->request->getPost('customer');
            if (isset($customerInfo['entity_id'])) {
                $customer_id = $customerInfo['entity_id'];
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Template\Collection');
                $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($customer_id);
                $customer_data['firstname'] = $customerObj->getData('firstname');
                $customer_data['lastname'] = $customerObj->getData('lastname');
                $customer_data['phone'] = preg_replace('/[^0-9]/u', '', $customerObj->getData('phone_number'));
                $store_data = $storeCollection->addFieldToFilter('id', array('in' => explode(',', $stores)));
                $this->getCustomerInfo($store_data, $customer_data, $statearray, $customer_id);
            }
        }
    }

    /**
     * get customer Information 
     * @param array $customer_data
     * @param array $store_data
     * @param int $customer_id
     * @return bool.
     */
    public function getCustomerInfo($store_data = array(), $customer_data = array(), $statearray = array(), $customer_id) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $this->_resources = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $this->_resources->getConnection();
        $customerAddrTable = $this->_resources->getTableName('customer_address_entity');
        foreach ($store_data->getData() as $storeData) {
            $selectCusAddrInfo = $connection->select()->from(['cae' => $customerAddrTable])->where('cae.parent_id=?', $customer_id)
                    ->where('cae.customer_store_id=?', $storeData['id']);
            $data = $connection->fetchAll($selectCusAddrInfo);
            if ($storeData['country'] === 'US') {
                $region = $storeData['state'];
                foreach ($statearray as $stateKey => $stateVal) {
                    if ($stateVal['title'] == $storeData['state']) {
                        $regionId = $stateVal['value'];
                    }
                }
            }
            if (empty($regionId)) {
                $regionId = $region;
            }
            if (count($data) < 1) {
                $queryCust = "INSERT INTO `$customerAddrTable` (`parent_id`, `customer_store_id`, `city`, `company`,`country_id`, `firstname`, `lastname`, `postcode`, `region`, `region_id`, `street`, `telephone`)  
                            VALUES ('" . $customer_id . "', '" . $storeData['id'] . "', '" . $storeData['city'] . "','" . $storeData['name'] . "', '" . $storeData['country'] . "', '" . $customer_data['firstname'] . "', '" . $customer_data['lastname'] . "', '" . $storeData['zip'] . "', '" . $region . "', '" . $regionId . "', '" . $storeData['address'] . "', '" . $customer_data['phone'] . "')";
                $connection->query($queryCust);
            }
        }
    }

}
