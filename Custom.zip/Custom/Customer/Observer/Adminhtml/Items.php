<?php

/**
 * DocResearch Customer CustomPrice Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer\Adminhtml;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

/**
 * Adminhtml sales order create items block
 *
 * @author Magento Core Team <core@magentocommerce.com>
 */
class Items implements ObserverInterface {

    protected $_sessionQuote;

    public function __construct(
    \Magento\Backend\Block\Template\Context $context, \Magento\Backend\Model\Session\Quote $sessionQuote, array $data = []
    ) {
        $this->_sessionQuote = $sessionQuote;
    }
    /**
     * observer function to save custom price for item
     * @param $observer
     * @return bool
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $customerCurrentStore = $this->_sessionQuote->getCurrentStore();
        $product_id = $observer->getQuoteItem()->getProductId();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($this->_sessionQuote->getCustomerId());
        $storeId = $customerObj->getData('restaurant');
        $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
        $store_data = $storeCollection->addFieldToFilter('restaurant_id', array('in' => array($customerCurrentStore)))
                ->addFieldToFilter('product_id', $product_id);
        $product_price = $store_data->getData();
        $original_price = $product_price[0]['product_price'];
        $item = $observer->getEvent()->getData('quote_item');
        $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
        $item->setCustomPrice($original_price);
        $item->setOriginalCustomPrice($original_price);
        $item->getProduct()->setIsSuperMode(true);
        $item->save();
    }

}

?>