<?php

namespace DocResearch\Customer\Observer\Adminhtml;

class SalesOrderSaveInfo implements \Magento\Framework\Event\ObserverInterface {

    protected $_order;

    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Sales\Api\Data\OrderInterface $order, \Magento\Store\Model\StoreManagerInterface $storeManager, array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_order = $order;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        $order_id = $order->getID();
        $custom_details = array();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($order['customer_id']);
        $custom_details['store_restaurant_id'] = $customerObj->getRestaurant();
        $restaurant = $objectManager->get('DocResearch\Restaurant\Model\Template');
        $custom_details['restaurant_name'] = $restaurant->load($custom_details['store_restaurant_id'])->getName();
        $custom_details['sales_person_id'] = ($restaurant->load($custom_details['store_restaurant_id'])->getSalesPersonId());
        $custom_details['sales_person_commission'] = ($restaurant->load($custom_details['store_restaurant_id'])->getSalesCommission());
        $sales_person = $objectManager->get('DocResearch\SalesPerson\Model\Template');
        $custom_details['sales_person_name'] = ($sales_person->load($custom_details['sales_person_id'], 'id')->getSalesPerson());
        $orderCollection = $objectManager->get('\Magento\Sales\Model\Order')->load($order_id);
        $orderSubTotal = $orderCollection->getData('base_subtotal');
        $custom_details['commision'] = (($orderSubTotal * $custom_details['sales_person_commission']) / 100);
        $prod_items = $order->getAllVisibleItems();
        $this->createShipment($order_id);        
        $this->saveCustomData($prod_items, $custom_details, $order_id);
    }
    
    /**
     * Save custom data in sales order grid
     * @param array $orderid
     * @param array $custom_details
     * @param int $order_id
     * @param float $commision
     * @return bool
     */
    public function saveCustomData($prod_items = array(), $custom_details = array(), $order_id) {
        $qty = 0;
        $productNms = array();
        foreach ($prod_items as $prod_item) {
            $productNms[] = addslashes($prod_item->getName());
            $qty += $prod_item->getQtyOrdered();
        }
        $products = implode(", ", $productNms);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('sales_order');
        $tableNameGrid = $resource->getTableName('sales_order_grid');
        $sql = "Update " . $tableName . " Set restaurant_id = '" . $custom_details['store_restaurant_id'] . "', restaurant_name = '" . addslashes($custom_details['restaurant_name']) . "', sales_person_id ='" . $custom_details['sales_person_id'] . "',sales_person_name ='" . addslashes($custom_details['sales_person_name']) . "',sales_person_percentage ='" . $custom_details['sales_person_commission'] . "',products_name ='" . $products . "', sales_commission = '" . $custom_details['commision'] . "' where entity_id = " . $order_id;
        $sql_grid = "Update " . $tableNameGrid . " Set restaurant_name = '" . addslashes($custom_details['restaurant_name']) . "',sales_person_name ='" . addslashes($custom_details['sales_person_name']) . "',sales_person_percentage ='" . $custom_details['sales_person_commission'] . "',products_name ='" . $products . "',total_qty ='" . $qty . "', track_order_status='N/A' where entity_id = " . $order_id;
        $connection->query($sql);
        $connection->query($sql_grid);
    }

    /**
     * Create Shipment for a partiular Order
     * @param order Id to create shipment
     * @return boolean
     */
    public function createShipment($order_id) {
        $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
        $connection = $this->_resources->getConnection();
        $orderId = $order_id;
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $orders = $objectManager->create('Magento\Sales\Model\Order')->load($orderId);
        if (preg_match('/ups/', $orders->getShippingMethod()) < 1) {
            $salesOrder = $this->_resources->getTableName('sales_order');
            $shipping_method = "ups_03";
            $connection->query("UPDATE `$salesOrder` set shipping_method = '" . $shipping_method . "' where entity_id = '" . $orderId . "'");
        }
        if (!$orders->canShip()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('You can\'t create the shipment.'));
        }
        $convertOrder = $objectManager->create('Magento\Sales\Model\Convert\Order');
        $shipment = $convertOrder->toShipment($orders);
        foreach ($orders->getAllItems() AS $orderItem) {
            if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                continue;
            }
            $qtyShipped = $orderItem->getQtyToShip();
            $shipmentItem = $convertOrder->itemToShipmentItem($orderItem)->setQty($qtyShipped);
            $shipment->addItem($shipmentItem);
        }
        $shipment->register();
        $shipment->getOrder()->setIsInProcess(true);
        try {
            $shipment->save();
            $shipment->getOrder()->save();
            
            $objectManager->create('Magento\Shipping\Model\ShipmentNotifier')->notify($shipment);
            $shipment->save();
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
        }
    }

    /**
     * Genere a Random string of given length
     * Used for the tracking number
     * @return string
     */
    public function randomStr($randStrLength = 6) {
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $randStr = substr(str_shuffle($str), 0, $randStrLength);
        return $randStr;
    }

}
