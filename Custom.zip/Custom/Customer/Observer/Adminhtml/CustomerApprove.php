<?php

/**
 * DocResearch Customer CustomerApprove Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer\Adminhtml;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class CustomerApprove implements \Magento\Framework\Event\ObserverInterface {

    protected $storeManager;
    private $scopeConfig;
    protected $inlineTranslation;
    protected $_transportBuilder;
    protected $_customerRepositoryInterface;
    protected $_request;

    public function __construct(
             \Magento\Framework\App\RequestInterface $request,
    \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
            \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
            \Magento\Store\Model\StoreManagerInterface $storeManager,
            \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation, 
            \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
            array $data = []
    ) {
        $this->_request = $request;
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->inlineTranslation = $inlineTranslation;
        $this->_transportBuilder = $transportBuilder;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
    }

    public function execute(\Magento\Framework\Event\Observer $observer) {
        
        $reqeustParams = $this->_request->getParams();
        $status = $reqeustParams['customer']['approval'];
        $sendemailfrom = $this->scopeConfig->getValue('trans_email/ident_general/email', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $stickyposname = $this->scopeConfig->getValue('trans_email/ident_general/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        //$customer_id = $observer->getCustomerDataObject()->getId();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$customerdata = $observer->getEvent()->getCustomer();
        $customer_id = $customerdata->getId();
        $customer = $objectManager->create('Magento\Customer\Model\Customer')->load($customer_id);
        $is_approved = $customer->getData('is_mail_send');
        $firstname = $customer->getData('firstname');
        $lastname = $customer->getData('lastname');
        $cusomer_name = $firstname. ' '.$lastname;
        $customer_email = $customer->getData('email');
        
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $tableName = $resource->getTableName('customer_entity');
            
        if ($is_approved != 1 && $status == 1) {
            $templateOptions = array('area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => $this->storeManager->getStore()->getId());
            $templateVars = array(
                'store' => $this->storeManager->getStore(),
                'firstname' => $cusomer_name,
                'email' => $customer_email,
                'message' => 'Hello'
            );
            $from = array('email' => $sendemailfrom, 'name' => $stickyposname);
            $this->inlineTranslation->suspend();
            $to = array($customer_email);
            $transport = $this->_transportBuilder->setTemplateIdentifier('mymodule_email_template')
                    ->setTemplateOptions($templateOptions)
                    ->setTemplateVars($templateVars)
                    ->setFrom($from)
                    ->addTo($to)
                    ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
            
            
            $sql = "Update " . $tableName . " Set is_mail_send = 1 where entity_id = " . $customer_id;
            $connection->query($sql);
        }elseif($status == 0){
            $sql = "Update " . $tableName . " Set is_mail_send = 0 where entity_id = " . $customer_id;
            $connection->query($sql);
        }
    }

}
