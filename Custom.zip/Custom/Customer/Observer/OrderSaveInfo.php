<?php

/**
 * DocResearch Customer Ordersave Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer;

class OrderSaveInfo implements \Magento\Framework\Event\ObserverInterface {

    protected $_order;

    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Sales\Api\Data\OrderInterface $order, \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_order = $order;
    }
    
    /**
     * Get store name, restaurant name and salesperson name 
     * @return bool
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\Session');
        $current_store = $customerSession->getCurrentStore();
        $custom_details = array();
        if (!empty($current_store)) {
            $c_store_id = $current_store;
        } else {
            $c_store_id = $customerSession->getCustomer()->getData('restaurant');
            $customerSession->setCurrentStore($c_store_id);
        }
        $store_restaurant_id = $c_store_id;
        $custom_details['c_store_id'] = $c_store_id;
        $restaurant = $objectManager->get('DocResearch\Restaurant\Model\Template');
        $custom_details['restaurant_name'] = ($restaurant->load($c_store_id)->getName());
        $custom_details['sales_person_id'] = ($restaurant->load($store_restaurant_id)->getSalesPersonId());
        $custom_details['sales_person_commission'] = ($restaurant->load($store_restaurant_id)->getSalesCommission());
        $sales_person = $objectManager->get('DocResearch\SalesPerson\Model\Template');
        $custom_details['sales_person_name'] = ($sales_person->load($custom_details['sales_person_id'], 'id')->getSalesPerson());
        $orderids = $observer->getOrderIds();
        $this->saveCustomData($orderids, $custom_details);
    }

     /**
     * Save custom data in sales order grid
     * @param array $orderid
     * @param array $custom_details
     * @return bool
     */
    public function saveCustomData($orderids = array(), $custom_details = array()) {
       $orderId = "";
        foreach ($orderids as $orderid) {
            $order = $this->_order->load($orderid);
            $orderId = $orderid;
        }
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $orderCollection = $objectManager->get('\Magento\Sales\Model\Order')->load($orderId);
        $orderSubTotal = $orderCollection->getData('base_subtotal');
        $commision = (($orderSubTotal * $custom_details['sales_person_commission']) / 100);
        $prod_items = $order->getAllVisibleItems();
        $qty = 0;
        $productNms = array();
        foreach ($prod_items as $prod_item) {
            $productNms[] = addslashes($prod_item->getName());
            $qty += $prod_item->getQtyOrdered();
        }
        $products = implode(", ", $productNms);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableName = $resource->getTableName('sales_order');
        $tableNameGrid = $resource->getTableName('sales_order_grid');
        $sql = "Update " . $tableName . " Set restaurant_id = '" . $custom_details['c_store_id'] . "', restaurant_name = '" . addslashes($custom_details['restaurant_name']) . "', sales_person_id ='" . $custom_details['sales_person_id'] . "',sales_person_name ='" . addslashes($custom_details['sales_person_name']) . "',sales_person_percentage ='" . $custom_details['sales_person_commission'] . "',products_name ='" . $products . "', sales_commission = '" . $commision . "' where entity_id = " . $orderId;
        
        $sql_grid = "Update " . $tableNameGrid . " Set restaurant_name = '" . addslashes($custom_details['restaurant_name']) . "',sales_person_name ='" . addslashes($custom_details['sales_person_name']) . "',sales_person_percentage ='" . $custom_details['sales_person_commission'] . "',products_name ='" . $products . "',total_qty ='" . $qty . "', track_order_status='N/A' where entity_id = " . $orderId;
        $connection->query($sql);
        $connection->query($sql_grid);

        $orders = $objectManager->create('Magento\Sales\Model\Order')->load($orderId);
        if (!preg_match('/ups/', $orders->getShippingMethod())) {

            $salesOrder = $resource->getTableName('sales_order');
            $shipping_method = "ups_03";
            $sql = "UPDATE ". $salesOrder. " set shipping_method = '" . $shipping_method . "' where entity_id = '" . $orderId . "'";
            $connection->query($sql);
        }
    }

}

?>