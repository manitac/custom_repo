<?php

/**
 * DocResearch Customer CustomPrice Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */

namespace DocResearch\Customer\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Sales\Model\Order;

class MultiShipping implements ObserverInterface {

    protected $_order;
    protected $_resources;
    protected $randStrLength;

    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Sales\Api\Data\OrderInterface $order, \Magento\Store\Model\StoreManagerInterface $storeManager, array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_order = $order;
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $orderids = $observer->getEvent()->getOrderIds();
		
        $id = array();
        foreach ($orderids as $orderid) {
            $_orderid = $this->_order->load($orderid);
            $ids[] = $_orderid->getEntityId();
        }
        foreach ($ids as $id) {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $orders = $objectManager->create('Magento\Sales\Model\Order')->load($id);
			
            if (!$orders->canShip()) {
                throw new \Magento\Framework\Exception\LocalizedException(__('You can\'t create the shipment.'));
            }
            $convertOrder = $objectManager->create('Magento\Sales\Model\Convert\Order');
            $shipment = $convertOrder->toShipment($orders);
            foreach ($orders->getAllItems() AS $orderItem) {
                if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                    continue;
                }
                $qtyShipped = $orderItem->getQtyToShip();
                $shipmentItem = $convertOrder->itemToShipmentItem($orderItem)->setQty($qtyShipped);
                $shipment->addItem($shipmentItem);
            }
            $shipment->register();
            $shipment->getOrder()->setIsInProcess(true);
            try {
                $shipment->save();
                $shipment->getOrder()->save();
                // $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
                // $connection = $this->_resources->getConnection();
                // $shipmentTrackTable = $this->_resources->getTableName('sales_shipment_track');
                // $connection->query("INSERT INTO `$shipmentTrackTable` (`parent_id`, `order_id`, `track_number`, `title`, `carrier_code`) 
	         	// VALUES (:parent_id, :order_id, :track_number, :title, :carrier_code)", array(
                    // 'parent_id' => $shipment->getId(),
                    // 'order_id' => $id,
                    // 'track_number' => $this->randomStr(),
                    // 'title' => 'United Parcel Service',
                    // 'carrier_code' => 'ups'
                // ));
                // $objectManager->create('Magento\Shipping\Model\ShipmentNotifier')->notify($shipment);
                $shipment->save();
            } catch (\Exception $e) {
                throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
            }
        }
    }

    /**
     * Genere a Random string of given length
     * Used for the tracking number
     * @return string
     */
    public function randomStr($randStrLength = 6) {
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $randStr = substr(str_shuffle($str), 0, $randStrLength);
        return $randStr;
    }

}
