<?php

/**
 * DocResearch Customer Shipment Observer
 *
 * @category    DocResearch
 * @package     DocResearch_Customer
 *
 */
namespace DocResearch\Customer\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Sales\Model\Order;

class Shipment implements ObserverInterface {

    protected $_order;
    protected $_resources;
    protected $randStrLength;
    
    public function __construct(
    \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig, \Magento\Sales\Api\Data\OrderInterface $order, \Magento\Store\Model\StoreManagerInterface $storeManager, array $data = []
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->storeManager = $storeManager;
        $this->_order = $order;
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $orderids = $observer->getEvent()->getOrderIds();
        $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\App\ResourceConnection');
        $connection = $this->_resources->getConnection();
        foreach ($orderids as $orderid) {
            $_orderid = $this->_order->load($orderid);
        }
        $orderId = $_orderid->getEntityId();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $orders = $objectManager->create('Magento\Sales\Model\Order')->load($orderId);
        /*if (preg_match('/ups/', $orders->getShippingMethod()) < 1) {
            $salesOrder = $this->_resources->getTableName('sales_order');
            $shipping_method = "ups_03";
            $connection->query("UPDATE `$salesOrder` set shipping_method = '" . $shipping_method . "' where entity_id = '" . $orderId . "'");
        }*/
        if (!$orders->canShip()) {
            throw new \Magento\Framework\Exception\LocalizedException(__('You can\'t create the shipment.'));
        }
        $convertOrder = $objectManager->create('Magento\Sales\Model\Convert\Order');
        $shipment = $convertOrder->toShipment($orders);
        foreach ($orders->getAllItems() AS $orderItem) {
            if (!$orderItem->getQtyToShip() || $orderItem->getIsVirtual()) {
                continue;
            }
            $qtyShipped = $orderItem->getQtyToShip();
            $shipmentItem = $convertOrder->itemToShipmentItem($orderItem)->setQty($qtyShipped);
            $shipment->addItem($shipmentItem);
        }
        $shipment->register();
        $shipment->getOrder()->setIsInProcess(true);
        try {
            $shipment->save();
            $shipment->getOrder()->save();

            //$objectManager->create('Magento\Shipping\Model\ShipmentNotifier')->notify($shipment);
            $shipment->save();
        } catch (\Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(__($e->getMessage()));
        }
    }

    /**
     * Genere a Random string of given length
     * Used for the tracking number
     * @return string
     */
    public function randomStr($randStrLength = 6) {
        $str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $randStr = substr(str_shuffle($str), 0, $randStrLength);
        return $randStr;
    }

}
