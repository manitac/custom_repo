<?php
/**
 * Restaurant setup to create module table
 */
 
namespace DocResearch\Customer\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;
/**
 * Class InstallSchema to create module table
 */

    class UpgradeSchema implements UpgradeSchemaInterface
{
    const CUSTOM_ATTRIBUTE_ID = 'is_mail_send';
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        if (version_compare($context->getVersion(), '3.0.1') < 0) {
            $setup->getConnection()->addColumn(
                $setup->getTable('customer_entity'),
                self::CUSTOM_ATTRIBUTE_ID,
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                    'nullable' => false,
                    'default' => 0,
                    'comment' => 'Mail Send Status'
                ]
            );
        }

        $setup->endSetup();


    }
}
    

