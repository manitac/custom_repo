<?php

namespace DocResearch\Customer\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface {

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {

        $connection = $setup->getConnection();

        $columns = [
            'customer_store_id' => [
                'type' => Table::TYPE_SMALLINT,
                'length' => 6,
                'nullable' => true,
                'comment' => 'customer store id',
            ],
            'customer_store_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'customer store name',
            ],
            'restaurant_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'restaurant name',
            ],
            'sales_person_id' => [
                'type' => Table::TYPE_TEXT,
                'length' => 100,
                'nullable' => true,
                'comment' => 'sales person id',
            ],
            'sales_person_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'sales person name',
            ],
            'sales_person_percentage' => [
                'type' => Table::TYPE_TEXT,
                'length' => 100,
                'nullable' => true,
                'comment' => 'sales person percentage',
            ],
            'products_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'Products Name',
            ]
        ];

        $columns_grid = [

            'customer_store_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'customer store name',
            ],
            'restaurant_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'restaurant name',
            ],
            'sales_person_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'sales person name',
            ],
            'sales_person_percentage' => [
                'type' => Table::TYPE_TEXT,
                'length' => 100,
                'nullable' => true,
                'comment' => 'sales person percentage',
            ],
            'total_qty' => [
                'type' => Table::TYPE_TEXT,
                'length' => 100,
                'nullable' => true,
                'comment' => 'Total Qty',
            ],
            'products_name' => [
                'type' => Table::TYPE_TEXT,
                'length' => 255,
                'nullable' => true,
                'comment' => 'Products Name',
            ]
        ];



        foreach ($columns as $name => $definition) {
            $connection->addColumn($setup->getTable('sales_order'), $name, $definition);
        }

        foreach ($columns_grid as $name => $definition) {
            $connection->addColumn($setup->getTable('sales_order_grid'), $name, $definition);
        }
    }

}
