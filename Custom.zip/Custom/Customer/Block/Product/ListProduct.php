<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Block\Product;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\View\Element\Template\Context;

class ListProduct extends \Magento\Catalog\Block\Product\ListProduct
{

    /**
     * 
     * @param \Magento\Catalog\Model\Product $product
     * @return string
     */
    public function getProductDetailsHtml(\Magento\Catalog\Model\Product $product)
    {
        $html = $this->getLayout()->createBlock('Magento\Framework\View\Element\Template')->setProduct($product)->setTemplate('DocResearch_Customer::productlist.phtml')->toHtml();
        $renderer = $this->getDetailsRenderer($product->getTypeId());
        if ($renderer) {
            $renderer->setProduct($product);
            return $html.$renderer->toHtml();
        }
        return '';
    }
    
    /**
     * 
     * @return Collection
     */
      protected function _getProductCollection()
    {
	 
        if ($this->_productCollection === null) {
            $layer = $this->getLayer();
            /* @var $layer \Magento\Catalog\Model\Layer */
            if ($this->getShowRootCategory()) {
                $this->setCategoryId($this->_storeManager->getStore()->getRootCategoryId());
            }

            // if this is a product view page
            if ($this->_coreRegistry->registry('product')) {
                // get collection of categories this product is associated with
                $categories = $this->_coreRegistry->registry('product')
                    ->getCategoryCollection()->setPage(1, 1)
                    ->load();
                // if the product is associated with any category
                if ($categories->count()) {
                    // show products from this category
                    $this->setCategoryId(current($categories->getIterator()));
                }
            }

            $origCategory = null;
            if ($this->getCategoryId()) {
                try {
                    $category = $this->categoryRepository->get($this->getCategoryId());
                } catch (NoSuchEntityException $e) {
                    $category = null;
                }

                if ($category) {
                    $origCategory = $layer->getCurrentCategory();
                    $layer->setCurrentCategory($category);
                }
            }
            $this->_productCollection = $layer->getProductCollection();

            $this->prepareSortableFieldsByCategory($layer->getCurrentCategory());

            if ($origCategory) {
                $layer->setCurrentCategory($origCategory);
            }
        }
        
		/*$joinConditions = 'e.entity_id=store_price.product_id';
		 $this->_productCollection->getSelect()->join(
                ['store_price'],
                    $joinConditions,
                []
        );*/

        $joinConditions = 'e.entity_id=store_price.product_id';
        $this->_productCollection->getSelect()->join(['store_price'], $joinConditions, []);
        $this->_productCollection->getSelect()->columns("store_price.product_price"); 
        $this->_productCollection->getSelect()->where('store_price.restaurant_id = '.$this->cusotmerRestaurant());
        $this->_productCollection->getSelect()->group('store_price.product_id');
        //return $this->_productCollection;
        //$this->_productCollection->printLogQuery(true);die('This is just to test');
		
		return $this->_productCollection;
    }
	
	 /**
     * Retrieve loaded category collection
     *
     * @return AbstractCollection
     */
    public function getLoadedProductCollection()
    {
        return $this->_getProductCollection();
    }
	
	
	/** Get Loggedin Customer Stores
	* @var $product_id
	* return string
	*/ 
	
	public function cusotmerStore(){

    	$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\SessionFactory')->create();

        if($customerSession->isLoggedIn()) {

            $c_id = $customerSession->getCustomer()->getId();            
            $customer_curr_store = $customerSession->getCurrentStore();
            
            if(!empty($customer_curr_store)){
                return $customer_curr_store;
            } else {
                return false;
            }
	   }
	}

    public function cusotmerRestaurant(){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        if(isset($_SESSION['customer_base']['customer_id'])) {
        $c_id = $_SESSION['customer_base']['customer_id'];
        $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($c_id);
        $current_restaurant = $customerObj->getData('restaurant');
        return $current_restaurant;
        }
        return false;
    }
}