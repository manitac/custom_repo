<?php
/**
 * Copyright � 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

/**
 * Catalog product price block
 */
namespace DocResearch\Customer\Block\Product\View;

class Price extends \Magento\Catalog\Block\Product\View\Price
{


    /**
     * @return  array|float
     */
    public function getPrice()
    {	$product_id = 25;
       $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$customerSession = $objectManager->get('Magento\Customer\Model\Session');
			//if($customerSession->isLoggedIn()) {
			$c_id = $customerSession->getCustomer()->getId();
			$c_store_id = $customerSession->getCustomer()->getData('stores');
			/** @var \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection */
			$storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
			/** Apply filters here */
			$store_data = $storeCollection->addFieldToFilter('store_id', array('in' => array($c_store_id)))
						->addFieldToFilter('product_id', $product_id);
			$product_price = $store_data->getData();
			
			return number_format($product_price[0]['product_price'],2);
			//}
			//return false;
        
    }
}
