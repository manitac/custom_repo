<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Block\Customer;

use Magento\Catalog\Model\ProductFactory;

class Product extends \Magento\Framework\View\Element\Template {

    /**
     *
     * @var \Magento\Framework\View\Element\Template\Context 
     */
    protected $context;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    protected $_productFactory;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Sales\Model\Order\Config $orderConfig
     * @param array $data
     */
    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Customer\Model\SessionFactory $customerSession, \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory, array $data = []
    ) {

        $this->_customerSession = $customerSession;
        $this->_productCollectionFactory = $productCollectionFactory;
        parent::__construct($context, $data);
    }

    /**
     * 
     * @return layoutblock
     */
    public function getCustomerName() {
        $customer = $this->_customerSession->create();
        return $customer->getCustomer()->getName();
    }

    public function getProductCollection() {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        return $collection;
    }

    protected function _prepareLayout() {
        parent::_prepareLayout();
    }

}
