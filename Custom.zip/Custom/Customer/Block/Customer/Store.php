<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Customer\Block\Customer;

class Store extends \Magento\Framework\View\Element\Template {

    /**
     *
     * @var \Magento\Framework\View\Element\Template\Context 
     */
    protected $context;
    /**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Customer\Model\Session $customerSession
     * @param array $data
     */
    protected $_template = 'DocResearch_Customer::store.phtml';

    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, \Magento\Customer\Model\Session $customerSession, array $data = []
    ) {
        $this->_customerSession = $customerSession;
        parent::__construct($context, $data);
    }

    public function getStores() {
        $customerId = $this->_customerSession->getCustomer()->getId();
        $c_store_id = $this->_customerSession->getCustomer()->getData('stores');
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        if (!($customerId)) {
            return false;
        }
        $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Template\Collection');
        /** Apply filters here */
        $store_data = $storeCollection->addFieldToFilter('id', array('in' => explode(',', $c_store_id)));
        return $store_data;
    }

    protected function _prepareLayout() {
        parent::_prepareLayout();
    }

    public function getCustomerSession() {
        return $this->_customerSession;
    }

}
