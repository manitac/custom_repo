<?php

namespace DocResearch\Customer\Helper;

use Magento\Customer\Model\Session;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\UrlInterface;

class Customer extends AbstractHelper {

    /**
     * @var Session
     */
    private $customerSession;

    /**
     * @var UrlInterface
     */
    private $urlInterface;

    public function __construct(
    Context $context, Session $customerSession, array $data = []
    ) {
        parent::__construct($context, $data);
        $this->customerSession = $customerSession;
        $this->urlInterface = $context->getUrlBuilder();
    }

    public function redirectIfNotLoggedIn() {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\Session');
        if (!$customerSession->isLoggedIn()) {
            $customerSession->setAfterAuthUrl('customer/account/login/');
            $customerSession->authenticate();
        }
    }

    /**
     * Check customer and get customer store 
     * @var $product_id (int)
     * @return array.
     */
    public function getCustomerStorePrice($product_id) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->get('Magento\Customer\Model\SessionFactory');
        $customer = $customerSession->create();

        if ($customer->getCustomer()->getId()) {

            $c_id = $customer->getCustomer()->getId();
            $c_store_id = $customer->getCustomer()->getData('restaurant');
            /** @var \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection */
            $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
            /** Apply filters here */
            $current_store = $customer->getCurrentStore();
            if (!empty($current_store)) {
                $c_store_id = $current_store;
            } else {
                $c_store_id = $customer->getCustomer()->getData('restaurant');
                $customer->setCurrentStore($c_store_id);
            }
            
            $store_data = $storeCollection->addFieldToFilter('restaurant_id', array('in' => array($c_store_id)))
                    ->addFieldToFilter('product_id', $product_id);
            $product_price = $store_data->getData();
            return $product_price[0]['product_price'];
        }
        return false;
    }

}
