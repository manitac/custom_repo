<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace DocResearch\SalesOrderCreate\Block\Adminhtml\Order\Create\Search\Grid\Renderer;

/**
 * Adminhtml sales create order product search grid price column renderer
 *
 * @author Magento Core Team <core@magentocommerce.com>
 */
class Price extends \Magento\Backend\Block\Widget\Grid\Column\Renderer\Price {

    /**
     * Render minimal price for downloadable products
     *
     * @param \Magento\Framework\DataObject $row
     * @return string
     */
    public function render(\Magento\Framework\DataObject $row) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerObj = $objectManager->create('\Magento\Backend\Model\Session\Quote');
        $customerCurrentStore = $customerObj->getCurrentStore();

        $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');

        /** Apply filters here */
        $store_data = $storeCollection->addFieldToFilter('restaurant_id', array('in' => array($customerCurrentStore)))
                ->addFieldToFilter('product_id', $row->getId());
        $product_price = $store_data->getData();
        return number_format($product_price[0]['product_price'], 2);
    }

}
