<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
// @codingStandardsIgnoreFile

/**
 * Shipping data helper
 */

namespace DocResearch\Ups\Helper;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Shipping\Model\Source\Allshippingmethods;

class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    protected $urlInterface;
    protected $scopeConfig;
    protected $_storeManager;
    protected $_srModel;
    protected $_asm;
    protected $resourceConnection;

    public function __construct(
    \Magento\Framework\App\Helper\Context $context, \Magento\Framework\UrlInterface $urlInterface, StoreManagerInterface $storeManager, \Test\Shipping\Model\ShippingFactory $ShippingFactory, \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfigObject, Allshippingmethods $Allshippingmethods, \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        parent::__construct($context);
        $this->scopeConfig = $scopeConfigObject;
        $this->urlInterface = $urlInterface;
        $this->_storeManager = $storeManager;
        $this->_srModel = $ShippingFactory;
        $this->_asm = $Allshippingmethods;
        $this->resourceConnection = $resourceConnection;
    }

    public function getGroupData() {

        $methods = $this->_asm->toOptionArray();

        foreach ($methods as $j => $inner) {
            if (!empty($inner['value'])) {
                foreach ($inner['value'] as $key => $value) {
                    if (in_array($value['value'], $split)) {
                        unset($methods[$j]['value'][$key]);
                    }
                }
            }
        }

        return $methods;
    }

    public function getAllMethods() {
        $methods = $this->_asm->toOptionArray();

        return $methods;
    }

}
