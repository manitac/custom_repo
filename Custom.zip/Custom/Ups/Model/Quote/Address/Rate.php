<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace DocResearch\Ups\Model\Quote\Address;

use Magento\Framework\Model\AbstractModel;
use DocResearch\Ups\Helper\Data;

/**
 * @author      Magento Core Team <core@magentocommerce.com>
 */
class Rate extends \Magento\Quote\Model\Quote\Address\Rate {

    /**
     * @var \Magento\Quote\Model\Quote\Address
     */
    protected $_address;
    protected $_shippingConfig;

    /**
     * @return void
     */
    protected function _construct() {
        $this->_init('Magento\Quote\Model\ResourceModel\Quote\Address\Rate');
    }

    /**
     * @return $this
     */
    public function beforeSave() {
        parent::beforeSave();
        if ($this->getAddress()) {
            $this->setAddressId($this->getAddress()->getId());
        }
        return $this;
    }

    /**
     * @param \Magento\Quote\Model\Quote\Address $address
     * @return $this
     */
    public function setAddress(\Magento\Quote\Model\Quote\Address $address) {
        $this->_address = $address;
        return $this;
    }

    /**
     * @return \Magento\Quote\Model\Quote\Address
     */
    public function getAddress() {
        return $this->_address;
    }

    /**
     * @param \Magento\Quote\Model\Quote\Address\RateResult\AbstractResult $rate
     * @return $this
     */
    public function importShippingRate(\Magento\Quote\Model\Quote\Address\RateResult\AbstractResult $rate) {
        $ship_code = $rate->getCarrier();
        $ship_method = $rate->getMethod();
        $extraprice = 0;
        if ($ship_code == 'ups') {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $customerSession = $objectManager->get('Magento\Customer\Model\SessionFactory')->create();
            $c_id = $customerSession->getCustomer()->getId();
            $current_store = $customerSession->getCurrentStore();
            if (!empty($current_store)) {
                $c_store_id = $current_store;
            } else {
                $c_store_id = $customerSession->getCustomer()->getData('restaurant');
                $customerSession->setCurrentStore($c_store_id);
            }
            $store_restaurant_id = $c_store_id;
            $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
            $connection = $resource->getConnection();
            $sql = "SELECT shipping_price FROM restaurant_shipping WHERE restaurant_id = '" . $store_restaurant_id . "' and shipping_code = '" . $ship_method . "'";
            $already_id = $connection->fetchAll($sql);
            if (!empty($already_id[0]['shipping_price']))
                $extraprice = $already_id[0]['shipping_price'];
        }
        if ($rate instanceof \Magento\Quote\Model\Quote\Address\RateResult\Error) {
            $this->setCode(
                    $rate->getCarrier() . '_error'
            )->setCarrier(
                    $rate->getCarrier()
            )->setCarrierTitle(
                    $rate->getCarrierTitle()
            )->setErrorMessage(
                    $rate->getErrorMessage()
            );
        } elseif ($rate instanceof \Magento\Quote\Model\Quote\Address\RateResult\Method) {
            $this->setCode(
                    $rate->getCarrier() . '_' . $rate->getMethod()
            )->setCarrier(
                    $rate->getCarrier()
            )->setCarrierTitle(
                    $rate->getCarrierTitle()
            )->setMethod(
                    $rate->getMethod()
            )->setMethodTitle(
                    $rate->getMethodTitle()
            )->setMethodDescription(
                    $rate->getMethodDescription()
            )->setPrice(
                    $rate->getPrice() + ( $extraprice ? $extraprice : 0 )
            );
        }
        return $this;
    }

}
