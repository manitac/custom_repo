<?php

namespace DocResearch\Product\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface {

    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context) {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
                ->newTable($installer->getTable('product_restaurants'))
                ->addColumn(
                        'id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true], 'ID'
                )
                ->addColumn(
                        'product_id', Table::TYPE_INTEGER, null, ['nullable' => false, 'default' => 0], 'Product Id'
                )
                ->addColumn(
                        'restaurant_id', Table::TYPE_INTEGER, null, ['nullable' => false, 'default' => 0], 'Restaurant Id'
                )
                ->addColumn(
                        'location_id', Table::TYPE_INTEGER, null, ['nullable' => false, 'default' => 0], 'Location Id'
                )
                ->addColumn(
                        'product_price', Table::TYPE_DECIMAL, '12,4', [], 'Product Price'
                )
                ->setComment('Products in Restaurants');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }

}
