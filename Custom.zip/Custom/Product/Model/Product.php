<?php

namespace DocResearch\Product\Model;

/**
 * Ecommerce Model
 *
 * @method \Jute\Ecommerce\Model\Resource\Page _getResource()
 * @method \Jute\Ecommerce\Model\Resource\Page getResource()
 */
class Product extends \Magento\Framework\Model\AbstractModel {

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\Product\Model\ResourceModel\Product');
    }

}
