<?php

/**
 * Product Resource Collection
 */

namespace DocResearch\Product\Model\ResourceModel\Product;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection {

    /**
     * Resource initialization
     *
     * @return void
     */
    protected function _construct() {
        $this->_init('DocResearch\Product\Model\Product', 'DocResearch\Product\Model\ResourceModel\Product');
    }

}
