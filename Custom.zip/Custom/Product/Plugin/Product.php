<?php

namespace DocResearch\Product\Plugin;

class Product {
    
    /**
     * Override product prices to use Restaurant prices
     * @param \Magento\Catalog\Model\Product $subject
     * @param type $result
     * @return type
     */
    public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customerSession = $objectManager->create('Magento\Customer\Model\SessionFactory')->create();

        if ($customerSession->isLoggedIn()) {
            $c_id = $customerSession->getCustomer()->getId();
            /** @var \DocResearch\Store\Model\ResourceModel\Store\Collection $storeCollection */
            $customerObj = $objectManager->create('Magento\Customer\Model\Customer')->load($c_id);
            $c_restaurant_id = $customerObj->getData('restaurant');

            $current_store = $customerSession->getCurrentStore();
            if (!empty($current_store)) {
                $c_store_id = $current_store;
            } else {
                $c_store_id = $customerSession->getCustomer()->getData('restaurant');
            }

            $storeCollection = $objectManager->create('DocResearch\Store\Model\ResourceModel\Store\Collection');
            /** Apply filters here */
            $store_data = $storeCollection->addFieldToFilter('restaurant_id', array('eq' => $c_restaurant_id))
                    ->addFieldToFilter('product_id', $subject->getId());
            $product_price = $store_data->getData();
            if (!empty($product_price)) {
                return $product_price[0]['product_price'];
            }
        }
    }

}
