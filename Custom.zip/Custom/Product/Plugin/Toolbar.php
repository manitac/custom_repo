<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace DocResearch\Product\Plugin;

/**
 * Product list toolbar
 *
 * @author  Chetu India Team
 * Class to override the total number of 
 * Records in the pagination for the product view page
 */
class Toolbar {

    /**
     * Count total number of products for a user
     * According to the store assigned to the 
     * Logged in User
     *
     * @return int
     */
    public function afterGetTotalNum(\Magento\Catalog\Block\Product\ProductList\Toolbar $subject, $result) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productColls = $objectManager->get('DocResearch\Customer\Block\Product\ListProduct');
        $totalProds = $productColls->getLoadedProductCollection()->count();

        return $totalProds;
    }

}
