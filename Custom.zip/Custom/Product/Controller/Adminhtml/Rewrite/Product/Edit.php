<?php

namespace DocResearch\Product\Controller\Adminhtml\Rewrite\Product;

use Magento\Catalog\Controller\Adminhtml\Product;
use DocResearch\Product\Model\ProductFactory;
use Magento\Framework\App\Action\Context;

class Edit extends \Magento\Catalog\Controller\Adminhtml\Product\Edit {

    protected $_productFactory;

    public function __construct(
    \Magento\Framework\App\Action\Context $context, \Magento\Catalog\Controller\Adminhtml\Product\Builder $productBuilder, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {  
        //parent::__construct($context,$productBuilder);
        // $this->_productFactory = $productFactory;
    }

    public function execute() {

        die('');
        $productModel = $this->_productFactory->create();

        // Load the item with ID is 1
        $item = $productModel->load(1);
        var_dump($item->getData());

        // Get news collection
        $productCollection = $productModel->getCollection();
        // Load all data of collection
        var_dump($productCollection->getData());
        exit;
    }

}
