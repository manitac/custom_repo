<?php

namespace DocResearch\Product\Observer;

use Magento\Framework\Event\ObserverInterface;

class Productsaveafter implements ObserverInterface {

    public function __construct(\DocResearch\Product\Model\ProductFactory $product) {
        $this_product = $product;
    }
    
    /**
     * Update restaurant price after product save
     * @param \Magento\Framework\Event\Observer $observer
     * @return \DocResearch\Product\Observer\Productsaveafter
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        $_product_id = $observer->getProduct()->getId();  // Will get product object
        $_product_res = $observer->getProduct()->getData('restaurant_id');
        $_product_price = $observer->getProduct()->getData('product_price');

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();
        $tableModulename = $resource->getTableName('product_restaurants');
        $checkId = "Select count('product_id') AS count From " . $tableModulename . " Where id = '" . $_product_id . "'";
        $data = $connection->query($checkId);
        
        $sqlInsert = "Insert Into " . $tableModulename . " (product_id,restaurant_id,product_price) Values ( '" . $_product_id . "', '" . $_product_res . "','" . $_product_price . "')";
        $connection->query($sqlInsert);
        return $this;
    }

}
