<?php

/**
 * LoginPost Controller to override login for cusotmer approval  
 *
 */

namespace DocResearch\CustomerOverride\Controller\Account;

use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Framework\Exception\EmailNotConfirmedException;
use Magento\Framework\Exception\AuthenticationException;
use Magento\Framework\Data\Form\FormKey\Validator;

/**
 * LoginPost Class 
 */
class LoginPost extends \Magento\Customer\Controller\Account\LoginPost {

    public function execute() {
        if ($this->session->isLoggedIn() || !$this->formKeyValidator->validate($this->getRequest())) {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('home');
            return $resultRedirect;
        }

        if ($this->getRequest()->isPost()) {
            $login = $this->getRequest()->getPost('login');
            if (!empty($login['username']) && !empty($login['password'])) {
                try {
                    $customer = $this->customerAccountManagement->authenticate($login['username'], $login['password']);
                    $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                    $url = \Magento\Framework\App\ObjectManager::getInstance();
                    $storeManager = $url->get('\Magento\Store\Model\StoreManagerInterface');
                    $websiteId = $storeManager->getWebsite()->getWebsiteId();
                    // Get Store ID
                    $store = $storeManager->getStore();
                    $storeId = $store->getStoreId();
                    $customerFactory = $objectManager->get('\Magento\Customer\Model\CustomerFactory');
                    $customer_check = $customerFactory->create();
                    $customer_check->setWebsiteId($websiteId);
                    $customer_check->loadByEmail($login['username']); // load customer by email address
                    $customer_approval = $customer_check->getData('approval');
                    $customerStores = $customer_check->getData('restaurant');
                    if ($customer_approval != 1) {
                        $message = __('Your account is not approved yet. Please contact to Manager.');
                        $this->messageManager->addError($message);
                        $resultRedirect = $this->resultRedirectFactory->create();
                        $resultRedirect->setPath($this->_redirect->getRefererUrl());
                        return $resultRedirect;
                        exit;
                    } elseif (empty($customerStores)) {
                        $message = __('Your dont have any assigned restaurant yet. Please contact to your Manager.');
                        $this->messageManager->addError($message);
                        $resultRedirect = $this->resultRedirectFactory->create();
                        $resultRedirect->setPath($this->_redirect->getRefererUrl());
                        return $resultRedirect;
                        exit;
                    } else {
                        $this->session->setCustomerDataAsLoggedIn($customer);
                        $this->session->regenerateId();
                    }
                } catch (EmailNotConfirmedException $e) {
                    $value = $this->customerUrl->getEmailConfirmationUrl($login['username']);
                    $message = __(
                            'This account is not confirmed.' .
                            ' <a href="%1">Click here</a> to resend confirmation email.', $value
                    );
                    $this->messageManager->addError($message);
                    $this->session->setUsername($login['username']);
                } catch (AuthenticationException $e) {
                    $message = __('Invalid login or password.');
                    $this->messageManager->addError($message);
                    $this->session->setUsername($login['username']);
                } catch (\Exception $e) {
                    $this->messageManager->addError(__('Invalid login or password.'));
                }
            } else {
                $this->messageManager->addError(__('A login and a password are required.'));
            }
            $resultRedirect = $this->resultRedirectFactory->create();

            $resultRedirect->setPath('home'); // set this path to what you want your customer to go
            return $resultRedirect;
        }
    }

}
