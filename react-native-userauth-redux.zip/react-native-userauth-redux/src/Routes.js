import React, { Component } from 'react';
import { Router, Stack, Scene } from 'react-native-router-flux';
import { createDrawerNavigator, createStackNavigator } from 'react-navigation';
import {
    StyleSheet,
    AsyncStorage,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

import Login from './pages/Login';
import Signup from './pages/Signup';
import Search from './pages/Search';
import Profile from './pages/Profile';
import Updateprofile from './pages/Updateprofile';
import Updateprofileimg from './pages/Updateprofileimg';
import Splash from './pages/Splash';
import Logout from './pages/Logout';
import HomeScreen from './pages/HomeScreen';
import Dashboard from './pages/Dashboard';


const ProfileStack = createStackNavigator({
    AppTabNavigator: {
        screen: Profile,
        navigationOptions: ({ navigation }) => ({
            title: 'Profile',
            headerLeft: (
                <Icon
              name='bars'
              type='font-awesome'
              color='#0A092F'
              iconStyle={styles.icon}
              onPress={() => navigation.toggleDrawer()}
              />
            )
        })
    },
    Updateprofile: {
        screen: Updateprofile,
        navigationOptions: () => ({
            title: "Update Profile",
        })
    },
    Updateprofileimg: {
        screen: Updateprofileimg,
        navigationOptions: () => ({
            title: "Update Profile Picture",
        })
    },
});

const SearchStack = createStackNavigator({
    AppTabNavigator: {
        screen: Search,
        navigationOptions: ({ navigation }) => ({
            title: 'Search User',
            headerLeft: (
                <Icon
              name='bars'
              type='font-awesome'
              color='#0A092F'
              iconStyle={styles.icon}
              onPress={() => navigation.toggleDrawer()}
              />
            )

        })
    },
    Dashboard: {
        screen: Dashboard,
        navigationOptions: () => ({
            title: "User Detail",
        })
    },
});


const LogoutStack = createStackNavigator({
    AppTabNavigator: {
        screen: Logout,
        navigationOptions: ({ navigation }) => ({
            title: 'Logout',

        })
    }
});
const HomeScreenStack = createStackNavigator({
    AppTabNavigator: {
        screen: HomeScreen,
        navigationOptions: ({ navigation }) => ({
            title: 'Home',
            headerLeft: (
                <Icon
              name='bars'
              type='font-awesome'
              color='#0A092F'
              iconStyle={styles.icon}
              onPress={() => navigation.toggleDrawer()}
              />
            )
        })
    }
});

const loggedin = createDrawerNavigator({
    Home: HomeScreenStack,
    Profile: ProfileStack,
    Search: SearchStack,
    Logout: LogoutStack,

}, {
    initialRouteName: 'Profile',
});

const loggedout = createDrawerNavigator({
    Login: {
        screen: Login,
        navigationOptions: () => ({
            title: "Sign In",
            headerLeft: (
                <Icon
              name='bars'
              type='font-awesome'
              color='#0A092F'
              iconStyle={styles.icon}
              onPress={() => navigation.toggleDrawer()}
              />
            )
        })
    },
    Signup: {
        screen: Signup,
        navigationOptions: () => ({
            title: "Sign Up",
            headerLeft: (
                <Icon
              name='bars'
              type='font-awesome'
              color='#0A092F'
              iconStyle={styles.icon}
              onPress={() => navigation.toggleDrawer()}
              />
            )
        })
    },
}, {
    initialRouteName: 'Login'
});

export const Root = createStackNavigator({
    loggedout: loggedout,
    loggedin: loggedin,
    AuthLoading: Splash,
}, {

    initialRouteName: 'AuthLoading',
    mode: 'modal',
    headerMode: 'none',
});

const styles = StyleSheet.create({
    homeicon: {
        width: 30,
        height: 30,
        margin: 5
    },
    icon: {
        backgroundColor: '#0A092F',
        color: '#000',
    },
})