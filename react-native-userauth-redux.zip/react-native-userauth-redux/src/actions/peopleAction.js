
export function peopleListing() {
  return (dispatch) => {
    dispatch(getPeople())
    fetch('https://swapi.co/api/people/')
    .then(data => data.json())
    .then(json => {
      dispatch(getPeopleSuccess(json.results))
    })
    .catch(err => dispatch(getPeopleFailure(err)))
  }
}

export function getPeople() {
  return {
    type: 'FETCHING_PEOPLE'
  }
}

export function getPeopleSuccess(data) {
  return {
    type: 'FETCHING_PEOPLE_SUCCESS',
    data,
  }
}

export function getPeopleFailure() {
  return {
    type: 'FETCHING_PEOPLE_FAILURE'
  }
}

export function deletePeople() {
  return {
    type: 'DELETE_PEOPLE'
  }
}