import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    TextInput,
    Image,
    AsyncStorage,
    TouchableHighlight
} from 'react-native';
import { Navigation } from 'react-native-navigation';

export default class Updateprofile extends Component {
    
    constructor(props) {
        super(props);

        this.state = {
            _id: '',
            first_name: '',
            last_name: '',
            email: '',
            avatar: '',
            token: '',
        }
    }
    async componentDidMount() {
        const self = this;
        var user = await AsyncStorage.getItem('user');
        user = JSON.parse(user);

        self.setState({ token: user.token });

        fetch('http://192.168.6.218:3001/user/' + user.id, {
                method: 'GET',
                headers: {
                    'Authorization': 'JWT ' + user.token
                },
            })
            .then((response) => response.json())
            .then((result) => {
                self.setState({
                    _id: result.data.user._id,
                    first_name: result.data.user.first_name,
                    last_name: result.data.user.last_name,
                    email: result.data.user.email,
                    avatar: result.data.user.avatar,

                });
            }).catch((error) => {
                alert('There was an error in profie.');
            }).done()
    }
    onChangeText = (key, val) => {
        this.setState({
            [key]: val
        })
    }

    updateProfile = async () => {

        const self = this;
        var apiBaseUrl = "http://192.168.6.218:3001";
        var data = {
            "first_name": this.state.first_name,
            "last_name": this.state.last_name,
        };

        const json = JSON.stringify(data);
        fetch('http://192.168.6.218:3001/user/' + self.state._id, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'JWT ' + self.state.token
                },
                body: json
            }).then((response) => response.json())
            .then((result) => {
                //success
                self.props.navigation.navigate('Profile');
            }).catch((error) => {
                alert('There was an error updating your account.');
            }).done()

    }

    render() {

        return (
            <View style={styles.container}>
                 <TextInput
                 style={styles.inputBox} 
                    placeholder='first name'
                    autoCapitalize="none"
                    value={this.state.first_name}
                    placeholderTextColor='white'
                    onChangeText={val => this.onChangeText('first_name', val)}
                  />
                  <TextInput
                    style={styles.inputBox} 
                    value={this.state.last_name}
                    placeholder='last name'
                    autoCapitalize="none"
                    placeholderTextColor='white'
                    onChangeText={val => this.onChangeText('last_name', val)}
                  />
                  <TouchableOpacity style={styles.button} onPress={this.updateProfile}>
                       <Text style={styles.buttonText}>Update </Text>
                  </TouchableOpacity>  
                   <TouchableOpacity style={styles.button} onPress={() => {this.props.navigation.navigate('Updateprofileimg');}}><Text style={styles.buttonText}>Change pic</Text></TouchableOpacity>
            </View>
        )
    }

}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#0A092F',
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    },
    inputBox: {
        width: 300,
        backgroundColor: 'rgba(255, 255,255,0.2)',
        borderRadius: 25,
        paddingHorizontal: 16,
        fontSize: 16,
        color: '#ffffff',
        marginVertical: 10
    },
    image: {
        height: 100,
        width: 100
    },
    title: {
        marginBottom: 20,
        marginTop: 30,
        fontSize: 25,
        textAlign: 'center',
        color: '#FFF',
    },
    searchInput: {
        height: 50,
        width: 200,
        padding: 4,
        marginRight: 5,
        fontSize: 23,
        borderWidth: 1,
        borderColor: 'white',
        borderRadius: 8,
        color: 'white'
    },
    buttonText: {
        fontSize: 14,
        color: '#111',
        alignSelf: 'center'
    },
    button: {
        height: 45,
        flexDirection: 'row',
        backgroundColor: 'white',
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 10,
        marginTop: 10,
        //alignSelf: 'stretch',
        justifyContent: 'center',
        width: 200,
    }
});