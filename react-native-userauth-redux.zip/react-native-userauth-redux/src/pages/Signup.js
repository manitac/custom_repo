import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Button,
  StatusBar ,
  TextInput,
  TouchableOpacity,
  ScrollView
} from 'react-native';

//import {Actions} from 'react-native-router-flux';
import Logo from '../components/Logo';
import Form from '../components/Form';


export default class Signup extends Component {

  constructor(props){
      super(props);
      this.state = {
          first_name: '', last_name: '', email: '', password: ''
        }
    }
  
  onChangeText = (key, val) => {
    this.setState({ [key]: val })
  }
  signUp = async () => {
    const self = this;
    const { first_name, last_name, password, email } = this.state

     const data = {
        first_name: first_name,
        last_name: last_name,
        email: email,
        password: password
      }
      // Serialize and post the data
      const json = JSON.stringify(data);
      fetch('http://192.168.6.218:3001/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json'
        },
        body: json
      })
      .then((response) => response.json())
      .then((result) => {
       alert("user id:- "+result.data.userId);
        alert('Success! You may now log in.');
        self.props.navigation.navigate('Login');
        // Redirect to home screen
      }).catch((error) => {
        alert('There was an error creating your account.');
      }).done()
   
  }


	render() {
		return(
       <ScrollView style={{backgroundColor: '#0A092F'}}>
			<View style={styles.container}>
				<Logo/>
			 <TextInput
          style={styles.inputBox} 
          placeholder='first name'
          autoCapitalize="none"
          placeholderTextColor='white'
          onChangeText={val => this.onChangeText('first_name', val)}
        />
        <TextInput
          style={styles.inputBox}
          placeholder='last name'
          autoCapitalize="none"
          placeholderTextColor='white'
          onChangeText={val => this.onChangeText('last_name', val)}
        />
        <TextInput
          style={styles.inputBox}
          placeholder='Email'
          autoCapitalize="none"
          placeholderTextColor='white'
          onChangeText={val => this.onChangeText('email', val)}
        />
        <TextInput
          style={styles.inputBox}
          placeholder='Password'
          secureTextEntry={true}
          autoCapitalize="none"
          placeholderTextColor='white'
          onChangeText={val => this.onChangeText('password', val)}
        />
        
        <TouchableOpacity style={styles.button} onPress={this.signUp}>
             <Text style={styles.buttonText}>signup</Text>
        </TouchableOpacity>  
				
			</View>	
    </ScrollView>
			)
	}
}

const styles = StyleSheet.create({
  container : {
    marginTop:100,
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  },
  inputBox: {
    width:300,
    backgroundColor:'rgba(255, 255,255,0.2)',
    borderRadius: 25,
    paddingHorizontal:16,
    fontSize:16,
    color:'#ffffff',
    marginVertical: 10
  },
  button: {
    width:300,
    backgroundColor:'#1c313a',
     borderRadius: 25,
      marginVertical: 10,
      paddingVertical: 13
  },
  buttonText: {
    fontSize:16,
    fontWeight:'500',
    color:'#ffffff',
    textAlign:'center'
  }
});
