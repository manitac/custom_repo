import React, { Component } from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  StatusBar ,
  AsyncStorage ,
  TouchableOpacity,
  ScrollView
} from 'react-native';
 // Version can be specified in package.json

import {Actions} from 'react-native-router-flux';
import Logo from '../components/Logo';
import Form from '../components/Form';
import Search from './Search';

export default class Login extends Component<{}> {
 constructor(props){
      super(props);
      this.state = {
           email: '', password: ''
        }
  }
  
  onChangeText = (key, val) => {
    this.setState({ [key]: val });
  }

  onClick(){
      this.props.navigation.navigate('Signup');
  }

  signIn = async () => {
    const self = this;
    const { password, email } = this.state

     const data = {
        email: email,
        password: password
      }
      fetch('http://192.168.6.218:3001/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
          },
          body: JSON.stringify({
              email: email,
              password: password
            })
      }).then((response) => response.json())
      .then((result) => {
              alert('Success! You are logged in.');
              var user = JSON.stringify({
                  id: result.data._id,
                  token: result.data.token
              })
              AsyncStorage.setItem('user', user);
             
              self.props.navigation.navigate('Profile');
      }).catch((error) => {
          alert('There was an error in login.');
      }).done()
   
  }

	render() {
		return(
      <ScrollView style={{backgroundColor: '#0A092F'}}>
  			<View style={styles.container}>
  				<Logo/>
    				<TextInput
              style={styles.inputBox}
              placeholder='Email'
              autoCapitalize="none"
              placeholderTextColor='white'
              onChangeText={val => this.onChangeText('email', val)}
            />
            <TextInput
              style={styles.inputBox}
              placeholder='Password'
              secureTextEntry={true}
              autoCapitalize="none"
              placeholderTextColor='white'
              onChangeText={val => this.onChangeText('password', val)}
            />
            
            <TouchableOpacity style={styles.button} onPress={this.signIn}>
                 <Text style={styles.buttonText}>sign in</Text>
            </TouchableOpacity>
        </View>	
        </ScrollView>
			)
	}
}

const styles = StyleSheet.create({
  container : {
    marginTop:200,
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  },
  inputBox: {
    width:300,
    backgroundColor:'rgba(255, 255,255,0.2)',
    borderRadius: 25,
    paddingHorizontal:16,
    fontSize:16,
    color:'#ffffff',
    marginVertical: 10
  },
  button: {
    width:300,
    backgroundColor:'#1c313a',
     borderRadius: 25,
      marginVertical: 10,
      paddingVertical: 13
  },
  buttonText: {
    fontSize:16,
    fontWeight:'500',
    color:'#ffffff',
    textAlign:'center'
  },
   title: {
    marginBottom: 20,
    marginTop: 30,
    fontSize: 25,
    textAlign: 'center',
    color: '#FFF',
  },
});
