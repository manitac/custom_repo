// SearchComponent.js

import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
  AsyncStorage ,
  TouchableHighlight
} from 'react-native';

import {Navigation} from 'react-native-navigation';

export default class Profile extends Component {

    constructor(props) {
      super(props);
      
      this.state={
        _id:'',
        first_name:'',
        last_name:'',
        email:'',
        avatar:'',
        token:''
      }
    }
 

   async  componentDidMount  (){

          const self = this;
          var user = await AsyncStorage.getItem('user');
          user = JSON.parse(user);
          fetch('http://192.168.6.218:3001/user/'+user.id, {
                  method: 'GET',
                  headers: {
                    'Authorization': 'JWT '+user.token
                  },
            })
            .then((response) => response.json())
            .then((result) => {
              self.setState({
                      _id : result.data.user._id,
                      first_name : result.data.user.first_name,
                      last_name : result.data.user.last_name,
                      email : result.data.user.email,
                      avatar : result.data.user.avatar,

                });
            }).catch((error) => {
                alert('There was an error in profie.');
            }).done()

    }

    onUpdate = () => {
      this.props.navigation.navigate('Updateprofile');
    }


  render() {
     
    return (
      <View style={styles.container}>
          <Text style={styles.title}> Profile Information</Text>
          <Text style={styles.title}> Name : {this.state.first_name} {this.state.last_name}</Text>
          <Text style={styles.title}> email : {this.state.email}</Text>
          <Image source={{uri: this.state.avatar}} style={styles.image} />
            <TouchableOpacity onPress={this.onUpdate.bind(this)}><Text style={styles.title}>Update profile</Text></TouchableOpacity>
                
      
      </View>

    )
  }

}

const styles = StyleSheet.create({
    container : {
    backgroundColor:'#0A092F',
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  },
  image: {
    height: 100,
    width:100
  },
  title: {
    marginBottom: 20,
    marginTop: 30,
    fontSize: 25,
    textAlign: 'center',
    color: '#FFF',
  },
  searchInput: {
    height: 50,
    width:200,
    padding: 4,
    marginRight: 5,
    fontSize: 23,
    borderWidth: 1,
    borderColor: 'white',
    borderRadius: 8,
    color: 'white'
  },
  buttonText: {
    fontSize: 14,
    color: '#111',
    alignSelf: 'center'
  },
  button: {
    height: 45,
    flexDirection: 'row',
    backgroundColor:'white',
    borderColor: 'white',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 10,
    marginTop: 10,
    //alignSelf: 'stretch',
    justifyContent: 'center',
     width:200,
  }
});