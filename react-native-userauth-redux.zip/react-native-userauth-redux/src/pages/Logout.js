import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
   AsyncStorage ,
  Image,
  TouchableHighlight
} from 'react-native';

import {Navigation} from 'react-native-navigation';

export default class Logout extends Component {

  constructor(props) {
      super(props);
      AsyncStorage.clear();
  }
  componentDidMount  (){
     //alert("you are logged out");
      this.props.navigation.navigate('Login');
  }
  render() {
    
    return (
      <View style={styles.container}>
        <Text>You are now logged out</Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({
    container : {
    backgroundColor:'#0A092F',
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  }
});