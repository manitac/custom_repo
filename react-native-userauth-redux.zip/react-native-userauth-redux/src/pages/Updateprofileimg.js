// SearchComponent.js

import React, { Component } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    StyleSheet,
    TextInput,
    Image,
    AsyncStorage,
    ScrollView,
    TouchableHighlight
} from 'react-native';

import ImagePicker from 'react-native-image-picker';

import { connect } from 'react-redux';

const options = {
    title: 'Select a Photo',
    takePhotoButtonTitle: 'Take Photo',
    chooseFromLibraryButtonTitle: 'Select from Library',
    mediaType: 'photo',
    quality: 1
};

class Updateprofileimg extends Component {



    constructor(props) {
        super(props);
        this.state = {
            ImageSource: ''
        }
    }

    uploadPhoto() {
        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);
            if (response.didCancel) {
                console.log('User cancelled image picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else {
                const source = { uri: response.uri };
                this.setState({
                    ImageSource: source,
                });
            }
        });

    }
    render() {

        const { people, isFetching } = this.props.people;

        return (
            <ScrollView style={styles.container}>
                <View style={styles.innerContainer}>
                  <TouchableHighlight onPress={this.uploadPhoto.bind(this)}>
                      <Image style={styles.image} source={this.state.imageSource != null ? this.state.imageSource : require('../images/logo.png')} />
                </TouchableHighlight>
                <TouchableOpacity style={styles.button} onPress={this.uploadPhoto.bind(this)}>
                     <Text style={styles.buttonText}>select image </Text>
                </TouchableOpacity>  

                 <View style={styles.innerContainer}>
                        {  people.length ? <View><Text style={styles.title}> Total {people.length} Results</Text><Text style={styles.title}>--------------------------------</Text></View> : null }
                      
                      {  people.length ? ( people.map((person, i) => {
                                              return <View key={i} >
                                                      <Text style={styles.title}>Name: {person.name} </Text>
                                                      <Text style={styles.title}> Birth Year: {person.birth_year}</Text>
                                                  </View>
                                            })
                                        ) : null
                      }
                  </View>
                </View>
            </ScrollView>
        )
    }

}
function mapStateToProps(state) {
    return {
        people: state.people
    }
}
export default connect(mapStateToProps)(Updateprofileimg)

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#0A092F',
        flex: 1,
    },
    innerContainer: {
        alignItems: 'center',
        justifyContent: 'center'
    },
    inputBox: {
        width: 300,
        backgroundColor: 'rgba(255, 255,255,0.2)',
        borderRadius: 25,
        paddingHorizontal: 16,
        fontSize: 16,
        color: '#ffffff',
        marginVertical: 10
    },
    image: {
        height: 100,
        width: 100
    },
    title: {
        marginBottom: 20,
        marginTop: 30,
        fontSize: 25,
        textAlign: 'center',
        color: '#FFF',
    },
    searchInput: {
        height: 50,
        width: 200,
        padding: 4,
        marginRight: 5,
        fontSize: 23,
        borderWidth: 1,
        borderColor: 'white',
        borderRadius: 8,
        color: 'white'
    },
    buttonText: {
        fontSize: 14,
        color: '#111',
        alignSelf: 'center'
    },
    button: {
        height: 45,
        flexDirection: 'row',
        backgroundColor: 'white',
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 10,
        marginTop: 10,
        //alignSelf: 'stretch',
        justifyContent: 'center',
        width: 200,
    }
});