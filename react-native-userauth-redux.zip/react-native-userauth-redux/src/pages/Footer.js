// DashboardComponent.js

import React, { Component } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  AsyncStorage ,
  Image
} from 'react-native';
import { Actions } from 'react-native-router-flux';

export default class Footer extends Component {

  constructor(props){
      super(props);
      this.state = {
          text: ''
        }
    }

    componentDidMount() {
      this._loadInitialState().done();
        
    }
    
    _loadInitialState = async () => {

      var  user =  await AsyncStorage.getItem('userid');
     // alert(user);
        if(user !==null){
            this.setState({ text: 'Logout'});
        }else{
          alert("user not logged in");
          this.setState({ text: 'Login'});
         
        }

    }

    signup() {
      Actions.signup()
    }

   
    search = () => {
      Actions.search()
    }

    login = () => {
      Actions.login()
    }
    logout =  async () => {

     AsyncStorage.clear();
     alert("logged out");
      
    }
  render() {
    var menu ='';
    if(this.state.text == 'Logout')
    {
      menu =<TouchableOpacity onPress={this.logout}><Text style={styles.signupButton}> {this.state.text}</Text></TouchableOpacity>
    }else{
      menu =<TouchableOpacity onPress={this.login}><Text style={styles.signupButton}> {this.state.text}</Text></TouchableOpacity>
    }

    return (
     <View style={styles.signupTextCont}>
          <TouchableOpacity onPress={this.signup}><Text style={styles.signupButton}> Signup |</Text></TouchableOpacity>
          <TouchableOpacity onPress={this.search}><Text style={styles.signupButton}> Search|</Text></TouchableOpacity>
          {menu}
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container : {
    backgroundColor:'#0A092F',
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  }, 
  signupTextCont : {
  	flexGrow: 1,
    alignItems:'flex-end',
    justifyContent :'center',
    paddingVertical:16,
    flexDirection:'row'
  },
  signupText: {
  	color:'rgba(255,255,255,0.6)',
  	fontSize:16
  },
  signupButton: {
  	color:'#ffffff',
  	fontSize:16,
  	fontWeight:'500'
  }
});
