import React, { Component } from 'react';
import {
    Text,
    View,
    StyleSheet,
    Image,
    TouchableHighlight,
    ScrollView,
    Button,
    TouchableOpacity
} from 'react-native';

import { connect } from 'react-redux';
import { peopleListing, deletePeople } from '../actions';

class Dashboard extends Component {

    constructor(props) {
        super(props);
    }
    render() {

        const { params } = this.props.navigation.state;
        const name = params ? params.name : null;
        const avatar_url = params ? params.avatar_url : null;
        const { people, isFetching } = this.props.people;

        return (

            <ScrollView style={styles.container}>
               <View style={styles.innerContainer}>
                  <Text style={styles.title}>Name: {JSON.stringify(name)}</Text><Image source={{uri: avatar_url}} style={styles.image} />
                  <Text style={styles.title}>--------------------------------</Text>
                  <View style={styles.innerContainer}>
                      <Text style={styles.title}>Redux for loading data</Text>
                      <TouchableHighlight style = {styles.button} underlayColor= "white" onPress={() => this.props.deletePeople()}>
                        <Text style={styles.buttonText}>Click to unload</Text>
                      </TouchableHighlight>
                      <TouchableHighlight style = {styles.button} underlayColor= "white" onPress={() => this.props.getPeople()}>
                        <Text style={styles.buttonText}>Click to Load</Text>
                      </TouchableHighlight>
                      { isFetching && <Text style={styles.title}>Loading...</Text> }
                  </View>
                  <View style={styles.innerContainer}>
  {  people.length ? <View><Text style={styles.title}> Total {people.length} Results</Text><Text style={styles.title}>--------------------------------</Text></View> : null }
                      
                      {  people.length ? ( people.map((person, i) => {
                                              return <View key={i} >
                                                      <Text style={styles.title}>Name: {person.name} </Text>
                                                      <Text style={styles.title}> Birth Year: {person.birth_year}</Text>
                                                  </View>
                                            })
                                        ) : null
                      }
                  </View>
               </View>
            </ScrollView>
        )
    }
}

function mapStateToProps(state) {
    return {
        people: state.people
    }
}

function mapDispatchToProps(dispatch) {
    return {
        getPeople: () => dispatch(peopleListing()),
        deletePeople : () => dispatch(deletePeople()),
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Dashboard)





const styles = StyleSheet.create({
    container: {
        backgroundColor: '#0A092F',
        flex: 1,
    },
    innerContainer: {
        marginLeft: 10,
        marginTop: 20,
    },
    image: {
        height: 100,
        width: 100
    },
    title: {
        marginBottom: 10,
        marginTop: 10,
        fontSize: 25,
        color: '#FFF',
    },

    buttonText: {
        fontSize: 14,
        color: '#111',
        alignSelf: 'center'
    },
    button: {
        height: 45,
        flexDirection: 'row',
        backgroundColor: 'white',
        borderColor: 'white',
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 10,
        marginTop: 10,
        //alignSelf: 'stretch',
        justifyContent: 'center',
        width: 200,
    }
});