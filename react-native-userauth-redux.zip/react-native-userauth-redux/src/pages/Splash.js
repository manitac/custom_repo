import React, { Component } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
  TouchableHighlight,
   AsyncStorage
} from 'react-native';
import {Navigation} from 'react-native-navigation';

export default class Splash extends Component {
  
    constructor(props) {
        super(props);
    }
    async componentDidMount  (){
       
      var user = await AsyncStorage.getItem('user');

      if(user){
            this.props.navigation.navigate('loggedin');
      }else{
        this.props.navigation.navigate('loggedout');
      }
    }
    render() {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Loading....</Text>
        </View>
      )
    }
}

const styles = StyleSheet.create({
  container : {
    backgroundColor:'#0A092F',
    flex: 1,
    alignItems:'center',
    justifyContent :'center'
  },
  title: {
    marginBottom: 20,
    marginTop: 30,
    fontSize: 25,
    textAlign: 'center',
    color: '#FFF',
  }
});