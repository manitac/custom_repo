import React, {Component} from 'react';
import {StyleSheet,
        View, 
        Text, 
        Image, 
        Dimensions,
        ScrollView,
        Linking,
        TouchableOpacity
    } from 'react-native';

import { SocialIcon } from 'react-native-elements';
import Icon from 'react-native-vector-icons/FontAwesome';



var { height } = Dimensions.get('window');
var box_count = 3;
var box_height = height / box_count;

export default class HomeScreen extends Component {
    
    render() {
        return (

          <ScrollView scrollEventThrottle={16}>
          <View style={styles.container}>
                <View style={styles.box}>
                    <ScrollView horizontal={true}>
                      <View style={styles.bIcon}> 
                          <Icon name="rocket" size={30} color="#900"  />
                          <Text style={styles.bIconText}>Flight</Text>
                      </View>

                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                            size={30} 
                            name='hotel'
                            type='g-translate'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                          <Text style={styles.bIconText}>Hotel</Text>
                      </View> 
                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                            size={30} 
                            name='car'
                            type='font-awesome'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                          <Text style={styles.bIconText}>Car</Text>
                      </View>

                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                             size={30} 
                            name='train'
                            type='font-awesome'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                         <Text style={styles.bIconText}> Rail</Text>
                      </View> 
                      <View style={styles.bIcon}> 
                          <Icon name="rocket" size={30} color="#900"  />
                          <Text style={styles.bIconText}>Flight</Text>
                      </View>

                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                            size={30} 
                            name='hotel'
                            type='g-translate'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                          <Text style={styles.bIconText}>Hotel</Text>
                      </View> 
                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                            size={30} 
                            name='car'
                            type='font-awesome'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                          <Text style={styles.bIconText}>Car</Text>
                      </View>

                      <View style={styles.bIcon}>
                          <Icon
                            reverse
                             size={30} 
                            name='train'
                            type='font-awesome'
                            color='#900'
                            onPress={() => this.props.navigation.navigate('Profile')} />
                         <Text style={styles.bIconText}> Rail</Text>
                      </View> 
                    </ScrollView>
                </View>     
                 <View style={{flex:1, paddingTop:20}}>
                        <Text style={{fontSize:20, fontWeight:'700', color: '#D9A352',}}>
                            Rooms Available
                        </Text>
                        <View style={{height:130, marginTop:20}}>
                            <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                                     <Image style={styles.image} source={require('../images/logo.png')} />
                            </ScrollView>
                        </View>
                    </View>
                    <View style={{flex:1, marginTop:20}}>
                        <View style={{paddingTop:0}}>
                            <View style={{flexDirection:'row'}}>
                                <Text style={{fontSize:20, fontWeight:'700', color:'#D9A352', paddingBottom:20}}>
                                    About
                                </Text>
                                <Text style={{ fontSize:13, fontWeight:'bold', color:'#D9A352', position:'absolute', right:0}} onPress={()=>this.props.navigation.navigate('Profile')}>
                                        see all >
                                </Text>
                            </View>
                           
                            
                            <View>
                                <Text style={{color:'#fff'}} >
                                This is just dummy text.  This is just dummy text.  This is just dummy text.  This is just dummy text.  This is just dummy text.  This is just dummy text.  This is just dummy text.  This is just dummy text.   
                                </Text>

                            </View>

                        </View>
                    </View>   
                    <View style={styles.box2}>
                       
                        <Text style={{fontSize:20, fontWeight:'700', color:'#D9A352', padding:20}}>
                                    Social
                        </Text>
                         <ScrollView horizontal={true}>
                            <View style={styles.box2Inner}>
                            
                                <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.facebook.com/igotwo.igotwo.3/')}>
                                  <SocialIcon type='facebook' iconTag='facebook-square' />
                                    <Text>Facebook</Text>
                                </TouchableOpacity> 
            
                                <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.twitter.com/')}>
                                <SocialIcon type='twitter'
                                        name='facebook-square' />
                                    <Text>Twitter</Text>
                                </TouchableOpacity>

                                <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.instagram.com/igo2bt/')}>
                                    <SocialIcon type='instagram'
                                        name='facebook-square'

                             />
                                    <Text>Instagram</Text>
                                </TouchableOpacity>
                                
                                <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.youtube.com/channel/UC--pv_ZlF2v0C4XKyk_YZNA?view_as=subscriber')}>
                                  <SocialIcon type='youtube' name='facebook-square' />
                                    <Text>YouTube</Text>
                                </TouchableOpacity>
                              
                            </View>
                         </ScrollView>
                    </View>
                     </View>
            </ScrollView>
        );
      }
}

const styles = StyleSheet.create({
    container: {
      backgroundColor: '#0A092F',
      paddingHorizontal:6,
    },
    image: {
    height: 100,
    width:100
  },
    box: {
      height: box_height,
      flexDirection: 'row',
      height: 100,
      backgroundColor: '#FBFBFB',
      marginTop: 30,
      justifyContent:'space-between',
      borderRadius: 5,
      shadowColor: '#04000C',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.8,
      shadowRadius: 5,
      elevation:3
    },
    box2: {
        backgroundColor: '#FBFBFB',
        marginTop: 50,
        marginBottom: 20,
        borderRadius: 5,
        shadowColor: '#04000C',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 5,
        elevation:3,
      },
      box2Inner:{
        justifyContent:'space-between',
        flexDirection: 'row',

      },
    bIcon:{
        padding: 20,
        alignItems: 'center'
    },
    bIconText:{
      fontSize:20,
      fontWeight:'bold'
    },
    
    socialIcon:{
        padding: 10,
        alignItems: 'center'
    },
    socialTitleText: {
        fontSize: 20,
        fontWeight: 'bold',
        padding:8
      }
  });
