module.exports = {
  user: require ('./user'),
  post: require ('./post'),
  postimg: require ('./postimg')
}