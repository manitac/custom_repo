let mongoose = require ('mongoose'),
  passwordHash = require('password-hash'),
  Schema = mongoose.Schema,
  config = require ('../../config/db'),
  userSchema = new Schema ({
    first_name: {
      required:[true, '{PATH} is required'],
      maxlength:[50, '{PATH} must be upto 50 characters long.'],
      trim:true,
      type:String,
    },
    last_name: {
      required:[true, '{PATH} is required'],
      maxlength:[50, '{PATH} must be upto 50 characters long.'],
      trim:true,
      type:String,
    },
    email: {
      required:[true, '{PATH} is required'],
      maxlength:[255, '{PATH} must be upto 255 characters long.'],
      unique: [true, '{PATH} already in use.'],
      trim:true,
      type:String,
      match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid {PATH} address']
    },
    password: {
      required: [true, '{PATH} is required'],
      type:String,
      trim: true,
       set: (password) => {
         return passwordHash.generate(password);
       }
    },
    gender: {
      required: [true, '{PATH} is required'],
      type: String,
      trim:true,
      enum: ['male', 'female'],
      default: 'male'
    },
    image: {
      type:String,
      trim: true,
      default: null
    },
    createdAt: {
      type: Date, 
      default: Date.now
    },
    updatedAt: {
      type: Date, 
      default: Date.now
    }
  })

  // method to verify password
  userSchema.methods.comparePassword = function (password) {
    return passwordHash.verify(password, this.password);
  }

  userSchema.methods.detail = function () {
    return {
      _id: this._id,
      first_name: this.first_name,
      last_name: this.last_name,
      email: this.email,
      gender:this.gender,
      avatar:config.host+ '/image/avatar/'+this._id
    };
  }

  module.exports = mongoose.model('users', userSchema);