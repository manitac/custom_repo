module.exports = {
  account: require ('./account'),
  auth: require ('./auth'),
  users: require ('./users'),
  posts: require ('./posts')
}