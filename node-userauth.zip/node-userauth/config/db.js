module.exports = {
  url : 'mongodb://manita:manita123@ds149404.mlab.com:49404/todo_app',
   //tokenExpireSeconds :8000,
   secret : "secret-userauth",
   host: 'http://192.168.6.218:3001'
};