
// server.js
const express        = require('express');
const mongoose    = require ('mongoose');
const bodyParser     = require('body-parser');
const cors           = require('cors');
const db             = require('./config/db');
const multer = require('multer');
const app            = express();
const port = 3001;
const passport = require('passport');
passport.initialize();

// parse application/json
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));

app.use(cors());

require('./passport');

require('./app/routes')(app, passport);

app.listen(port, () => {
    console.info(`We are live on ${port}`);
}); 

mongoose.connect(db.url,{ useNewUrlParser: true, useCreateIndex : true }, (err, database) => {
  if (err) 
  	return console.log(err);
  console.info (`DB successfully connected,... hurrey`)
});
