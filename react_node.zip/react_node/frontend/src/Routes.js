import React, {Component} from 'react';
import { BrowserRouter, Switch, Route, Link } from 'react-router-dom';
import App from './App';
import Login from './components/Login';
import Logout from './components/Logout';
import Register from './components/Register';
import Profile from './components/Profile';
import Navbar from './components/Navbar';
import Uploadimg from './components/Uploadimg';
import Update from './components/Update';
const Routes = ()=>(
	<BrowserRouter>
		<Switch>
			<Route exact path='/' component={App}/>
			<Route exact path='/login' component={Login}/>
			<Route exact path='/logout' component={Logout}/>
			<Route  exact path='/register' component={Register}/>
			<Route  exact path='/profile' component={Profile}/>
			<Route  exact path='/update_profile' component={Update}/>
			<Route  exact path='/uploadimg' component={Uploadimg}/>
		</Switch>
	</BrowserRouter>
)
export default Routes;