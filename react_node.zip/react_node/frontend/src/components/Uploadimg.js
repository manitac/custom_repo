import React, { Component } from 'react';
import Navbar from './Navbar';
import axios from 'axios';
import { Link , withRouter } from 'react-router-dom'; 

const BASE_URL = 'http://192.168.6.218:3001/';

class Uploadimg extends Component {

	constructor(props) {
		super(props);
		this.state = {
			images: [],
			imageUrls: [],
			message: '',
			img_path:''
		}
	}
	selectImages = (event) => {
			let images = []
			for (var i = 0; i < event.target.files.length; i++) {
				images[i] = event.target.files.item(i);
			}
			images = images.filter(image => image.name.match(/\.(jpg|jpeg|png|gif)$/))
			let message = `${images.length} valid image(s) selected`
			this.setState({ images, message })
	}
	uploadImages = () => {
		const uploaders = this.state.images.map(image => {
			const data = new FormData();

			data.append("image", image, image.name);
			// Make an AJAX upload request using Axios

			return axios.post(BASE_URL + 'image', data)
				.then(response => {
					this.setState({
						img_path: response.data.data.path
					});
				}).catch(function (error) {
					//alert(error);
				     alert("upload failed"); 
				 });
		});
		// Once all the files are uploaded 
		axios.all(uploaders).then(() => {
				const self = this;
			var data = {
		   	 	"image": this.state.img_path
		    }
			const token = localStorage.getItem('token');
			const id = localStorage.getItem('_id');
			axios.put(BASE_URL + 'user/'+id, data)
				.then(response => {
					alert('profile image updated successfully');
					self.props.history.push('/profile')
					
				});
		});
	}
	render() {
		return (
			<div>
				<Navbar/>
				<div className="Uploadimg">
					<h2>Update Profile image</h2><hr/>
					<div className="image">
						<input className="form-control " type="file" required
						onChange={this.selectImages} />
					</div>
					<p className="text-info">{this.state.message}</p>
					<br/>
					<div className="col-sm-4">
						<button className="btn btn-primary" value="Submit" 
						onClick={this.uploadImages}>Upload</button>
					</div>
				</div>
			</div>
		);
	}
}
export default withRouter(Uploadimg);