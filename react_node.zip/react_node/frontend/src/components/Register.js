import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import axios from 'axios';
import Navbar from './Navbar';
import Login from './Login';
import { 
  TextField,
  AppBar,
  RaisedButton,
  Dialog,
  Checkbox 
  } from 'material-ui';

import { Link , withRouter } from 'react-router-dom';

class Register extends Component {
	
  	constructor(props){
	    super(props);
	    this.state={
	      first_name:'',
	      last_name:'',
	      email:'',
	      password:''
	    }
  	}
  componentDidMount() {
    if(localStorage.getItem('token')){
      this.props.history.push('/')
    }
  }
  handleClick(event){
    const self = this;
  	event.preventDefault();
   	var apiBaseUrl = "http://192.168.6.218:3001";
    var data={
      "first_name": this.state.first_name,
      "last_name":this.state.last_name,
      "email":this.state.email,
      "password":this.state.password
    }
    axios.post(apiBaseUrl+'/signup', data)
   .then(function (response) {
     if(response.data.status == true){
        alert("register success");
        self.props.history.push('/login');
     }else{
     	  alert("can't register "+response.data.code);
     }
   })
   .catch(function (error) {
     alert("registration failed"); 
   });
  }

  render() {
    return (
      <div>
      <Navbar/>
      <div className="register">
        <MuiThemeProvider>
          <div>
          <AppBar
             title="Register"
           />
           <TextField
             hintText="Enter your First Name"
             floatingLabelText="First Name"
             onChange = {(event,newValue) => this.setState({first_name:newValue})}
             />
           <br/>
           <TextField
             hintText="Enter your Last Name"
             floatingLabelText="Last Name"
             onChange = {(event,newValue) => this.setState({last_name:newValue})}
             />
           <br/>
           <TextField
             hintText="Enter your Email"
             type="email"
             floatingLabelText="Email"
             onChange = {(event,newValue) => this.setState({email:newValue})}
             />
           <br/>
           <TextField
             type = "password"
             hintText="Enter your Password"
             floatingLabelText="Password"
             onChange = {(event,newValue) => this.setState({password:newValue})}
             />
           <br/>
           <RaisedButton label="Submit" primary={true} style={style} onClick={(event) => this.handleClick(event)}/>
           <Link to="/login" className="login-link">Login here</Link>
          </div>
         </MuiThemeProvider>
      </div>
      </div>
    );
  }
}
const style = {
  margin: 15,
};
export default withRouter(Register);