import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import axios from 'axios';
import '../App.css';
import { 
  TextField,
  AppBar,
  RaisedButton,
  } from 'material-ui';
import { ValidatorForm} from 'react-material-ui-form-validator';
import { Link , withRouter } from 'react-router-dom';
import Navbar from './Navbar';

class Login extends Component {
	constructor(props){
		  super(props);
		  this.state={
			  username:'',
			  password:'',
			  rememberMe: false,
			  fireRedirect: false,
			  remember:''
		  }
	 	  this.toggleRememberMe =  this.toggleRememberMe.bind(this);

	 }

	 componentDidMount() {
	 	this.setState({
	          username: localStorage.getItem('username'),
	          password: localStorage.getItem('password'),
	          remember: localStorage.getItem('remember')
	    });
	 }

	 
	handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

	toggleRememberMe(event) {
		 if(event.target.checked == true){
		 	this.setState({
	          rememberMe: true
	      });
		}
      
  	}
	handleClick(event){
		const self = this;
		event.preventDefault();

		if(this.state.rememberMe == true){
			localStorage.setItem('username',this.state.username);
			localStorage.setItem('password',this.state.password);
			localStorage.setItem('remember','checked');
		}else{
			localStorage.removeItem('username');
			localStorage.removeItem('password');
			localStorage.removeItem('remember');
		}
		
		var apiBaseUrl = "http://192.168.6.218:3001/login";
		
		var data ={
		 "email":this.state.username,
		 "password":this.state.password,
		 }
		 axios.post(apiBaseUrl, data)
		 .then(function (response) {
			 if(response.data.status == true){
			 	console.log("Login successful");
			 	alert(JSON.stringify(response.data.data));
			 	localStorage.setItem('token',response.data.data.token);
			 	localStorage.setItem('_id',response.data.data._id);
			 	self.props.history.push('/profile');
			 }else{
			 	alert("Username does not exist "+response.data.code);
			 }
		 }).catch(function (error) {
		 	alert("Login failed");

		 });
	
		
 		
	}
	

render() {

    return (
    	<div>
    	<Navbar/>
	    <div className="login">
	        <MuiThemeProvider>
	          	<div><AppBar title="Login" />
		           <ValidatorForm
		            ref="form"
		            onSubmit={(event) => this.handleClick(event)}>
		           	
		           	<TextField
		           	 name='username'
					 value={this.state.username}
					 hintText="Enter your Username"
		             floatingLabelText="Username"
                      onChange={e => this.handleChange(e)}/>
		             <br/>
		            <TextField
		               type="password"
		               name='password'
		               value={this.state.password}
						hintText="Enter your Password"
		               floatingLabelText="Password"
		                onChange={e => this.handleChange(e)}
		               />
		             <br/>
<input type="checkbox"  className="form-control" id="rememberMe" defaultChecked = {localStorage.getItem('remember')}  ref="rememberMe" placeholder="Remember Me" onChange={this.toggleRememberMe} />
			     <label htmlFor="rememberMe" className="remember-label">Remember me</label> <br />
		            <RaisedButton label="Submit" primary={true} style={style} onClick={(event) => this.handleClick(event)}/>
		            <Link to="/register" className="register-link">Register here</Link>
		        	</ValidatorForm>
	        	</div>
			</MuiThemeProvider>
	    </div>
	    </div>
    );
  }
}
const style = {
 	margin: 15,
};
export default withRouter(Login)