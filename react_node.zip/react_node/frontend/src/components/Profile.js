import React, { Component } from 'react';

import { Link, withRouter } from 'react-router-dom';
import axios from 'axios';
import Navbar from './Navbar';

class Profile extends Component {
	constructor(props){
	    super(props);
	    this.state={
	      _id:'',
	      first_name:'',
	      last_name:'',
	      email:'',
	      avatar:'',
	    }
  	}
	componentDidMount() {
		if(!localStorage.getItem('token')){
			this.props.history.push('/')
		}
		const self = this;
		const token = localStorage.getItem('token');
		 axios.get('http://192.168.6.218:3001/user/'+localStorage.getItem('_id') )
		 .then(function (response) {
				self.setState({
			          _id : response.data.data.user._id,
			          first_name : response.data.data.user.first_name,
			          last_name : response.data.data.user.last_name,
			          email : response.data.data.user.email,
			          avatar : response.data.data.user.avatar,

		    	});
		    	 localStorage.setItem('_id',response.data.data.user._id);
		}).catch(function (error) {
		 	console.log("user details not found");
		 });
	 }
	
	render() {
		    return (
		    	<div>
				<Navbar/>
		    	<div className="profile">

		    	 	<header className="App-header">
		    			<div className="user-details">
		    				<h2>User Details</h2>
		    				<div className="uid">User ID : {this.state._id}</div>
		    				<div className="ufname">First name : {this.state.first_name}</div>
		    				<div className="ulname">Last name : {this.state.last_name}</div>
		    				<div className="uemail">Email ID : {this.state.email}</div>
		    				<div className="uavatar"> Pic : 
		    				<img src={this.state.avatar} className="uavatarimg" />
		    				<Link to="/uploadimg" className="login-link">Change image</Link>
		    				</div>
		    			</div>
		    		</header>
		    	</div>
		    	</div>
		    );
		}

}
export default withRouter(Profile)