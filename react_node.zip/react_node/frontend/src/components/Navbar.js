import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';
export default class Navbar extends Component {

	render() {

		 	const isLoggedIn = localStorage.getItem('token');
		 	
	    	let button;

	    	if (isLoggedIn) {
	        	button = <Link to ="/logout">Logout</Link>;
		    } else {
		        button = <Link to ="/login">Login</Link>;
		    }
		    return (

		    	<div className="Navbar">

		    			{button}
		    			<Link to='/profile'>Profile</Link>
		    			<Link to='/register'>Register</Link>
		    	</div>
		    );
		}
}