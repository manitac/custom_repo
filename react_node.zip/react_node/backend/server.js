
// server.js
const express        = require('express');
const mongoose    = require ('mongoose');
const bodyParser     = require('body-parser');
const cors           = require('cors');
const db             = require('./config/db');
const multer = require('multer');
const app            = express();
const port = 3001;

// parse application/json
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({ extended: true }));

app.use(cors());

mongoose.connect(db.url,{ useNewUrlParser: true, useCreateIndex : true }, (err, database) => {
  if (err) 
  	return console.log(err)

  require('./app/routes')(app, database);

  app.listen(port, () => {
    console.log('We are live on ' + port);
  }); 

})