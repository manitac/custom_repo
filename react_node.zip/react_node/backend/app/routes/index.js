const controllers = require ('../controllers');

module.exports = function(app, db) {
	
  	app.get ('/', (req, res) => {
		return res.status(200).send({status: true, message: 'application successfully working'})
	});

  	
  	/**
   * Routes
   */
 	  app.post ('/signup', controllers.account.signup);
  	  app.post ('/login', controllers.auth.login);
	  app.get('/user/:_id', controllers.users.get);
 	  app.put ('/user/:_id', controllers.users.update);
	  app.post ('/image', controllers.users.uploadimage);
	  app.get ('/image/:type/:_id', controllers.users.getimage);
	
};