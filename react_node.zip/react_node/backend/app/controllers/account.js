
const models = require ('../models'),
  config = require ('../../config/db'),
  jwt = require('jsonwebtoken');
 /* Mail = require ('../helpers/mail');*/
  
let signup = (req, res) => {
  let user = new models.user(req.body);

  // save user data
  user.save ((err, data) => {
      if (err) 
        return res.status(422).send({status: false, message: 'unable to register user test', errors: err.message});

    return res.status(200).send ({status: true, message: 'user successfully registered test', data: {userId: data._id}});
  
  })
}

module.exports = {
  signup:signup
}