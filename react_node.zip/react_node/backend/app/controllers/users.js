const models = require ('../models'),
 multer  =   require('multer');

var storage =   multer.diskStorage({
          destination: function (req, file, callback) {
             //   console.log(file.fieldname);
            callback(null, './uploads');
          },
          filename: function (req, file, callback) {
            callback(null, file.fieldname + '-' + Date.now());
          }
  });

 var  uploadFile = multer({ storage : storage}).single('image');
 const fs = require ('fs');

/**
 * Method to get user detail by login token
 */
let detail = (req, res) => {
    // get user detail from token
    return res.status(200).send({status:true, message: 'user detail successfully found', data: {user: (req.user).detail()}});
}

/**
 * Method getUserById
 */
let getUserById = (req, res) => {
    (models.user).findById(req.params._id, (err, user) => {
        if (err) return res.status(500).send({status:false, message: 'unable to find user', error: err});

        return res.status(200).send({status:true, message: 'user detail successfully found', data: {user: user.detail()}});
    })
}

/**
 * Method uploadImg
 */
let uploadImg = (req, res) => {
    uploadFile(req,res,function(err) {
        if(err) 
            return res.status(500).send({status: false, message: 'Error uploading file.', errors: err.code});
        // send success
        return res.status(200).send ({status: true, message: 'Image successfully uploaded', data: {path: req.file.path}});
  });
}

/**
 * Update User
 */

let updateUser = (req, res) => {
    (models.user).findByIdAndUpdate (req.params._id, req.body, { runValidators: true }, (err, user) => {
        if (err) return res.status(500).send({status:false, message: 'unable to update user', error: err.message});

        return res.status(200).send({status:true, message: 'user detail successfully updated', data: {}});
    })
}

/**
 * Get Image
 */

let getImg = (req, res) => {
  let type = ((req.params.type).trim()).toUpperCase(),
    _id = ((req.params._id).trim());

  switch (type) {
    case 'AVATAR':
      (models.user).findById (_id, (err, user) => {
        if (user && user.image)  return fetchImg (res, user.image);
        else fetchImg (res);
      });
      break;
    default:
      return fetchImg (res);
  }
}

let fetchImg = (res, path) => {
  if (!path || !fs.existsSync(path)) {
    path = './uploads/no-img.png';
  }

  let image = fs.readFileSync(path);
  res.writeHead(200, {'Content-Type': 'image/*' });
  return res.end (image, 'binary');
}


module.exports = {
    detail:detail,
    get:getUserById,
    uploadimage:uploadImg,
    update:updateUser,
    getimage:getImg
}