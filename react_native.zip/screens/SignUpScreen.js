import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Button, TextInput, TouchableOpacity, Image, AsyncStorage, ScrollView} from 'react-native';

const ACCESS_TOKEN = 'access_token';
import css from '../assets/style/style';
import PickerSelect from "react-native-picker-select";


export default class SignUpScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			fname: "",
			lname: "",
			mobile: "",
			email: "",
			address:"",
			country: "",
			countryList: [],
			stateList: [],
			cityList: [],
			state: "",
			city: "",
			category: "",
			password: "",
			password_confirmation: "",
			errors: [],
		}
	}

	componentDidMount() {
		this.getCountryItems()		
	}
	async setProfileValues(profile) {
		try {
			
			await AsyncStorage.setItem(ACCESS_TOKEN,profile.access_token);
			await AsyncStorage.setItem("user_id",profile.users.user_id);
			await AsyncStorage.setItem("role_id",profile.users.role_id);
			await AsyncStorage.setItem("user_image",profile.users.image_link);
			await AsyncStorage.setItem("user_fname",profile.users.fname);
			await AsyncStorage.setItem("user_lname",profile.users.lname);
			await AsyncStorage.setItem("user_email",profile.users.email);
			await AsyncStorage.setItem("user_mobile",profile.users.mobile);
			await AsyncStorage.setItem("user_address",profile.users.address);
			await AsyncStorage.setItem("user_country",profile.users.country_id);
			await AsyncStorage.setItem("user_state",profile.users.state_id);
			await AsyncStorage.setItem("user_city",profile.users.city_id);
			await AsyncStorage.setItem("user_category",profile.users.role_id);
			await AsyncStorage.setItem("user_countrycode",profile.users.countrycode);
			await AsyncStorage.setItem("user_created",profile.users.created_at);

		}
		catch(error) {
			console.log('something went wrong! Please contact to Admin');
		}
	}
	async onLoginPressed() {
		this.props.navigation.navigate('SignIn');
	}
	async onRegisterPressed() {
		try {
			let device_token = await AsyncStorage.getItem('device_token')
			let response = await fetch('http://www.igo2.org/api/signUp', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					fname: this.state.fname,
					lname: this.state.lname,
					email: this.state.email,
					mobile: this.state.mobile,
					address: this.state.address,
					country: this.state.country,
					state: this.state.state,
					city: this.state.city,
					password: this.state.password,
					password_confirmation: this.state.password_confirmation,
					role_id: this.state.category,
					device_token: 'device_token',
				})
			});

			let result = await response.text();
			console.log(result);
			let responseArr = JSON.parse(result);
			if(responseArr.status_message == "success") {

				// let responseArr = JSON.parse(res);
				if(responseArr.status_code == 200){
					this.setState({errors: ''});
					this.setProfileValues(responseArr.data);
					this.props.navigation.navigate('Home');
				}
				else {
					throw(responseArr.errors);
				}
			}
			else {
				let errors = responseArr.errors;
				throw errors;
			}

		} catch(formErrors) {
			let errorsArray = [];
			if(formErrors.length > 0){
				for(let i = 0; i < formErrors.length; i++){
					errorsArray.push(formErrors[i]);
				}
			}
			else {
				errorsArray.push("Error in Sign up! please try again later");
			}
			this.setState({errors: errorsArray});

		}
	}

	async getCountryItems() {
		try{
			let response = await fetch('http://www.igo2.org/api/CountryList');
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({countryList:json,state:'',stateList:[],city:'',cityList:[]});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in country list api");
			this.setState({errors:errors})
		}
	}



	getCategory() {
		return [
			{
				label: 'Customer',
				value: '3'
			},
			{
				label: 'Booker',
				value: '2'
			}
		]
	}

	async getStateList(countryId){
		this.setState({country: countryId});
		try {
			let response = await fetch('http://www.igo2.org/api/StateList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					country: countryId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({stateList:json,city:'',cityList:[]});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in state list api");
			this.setState({errors:errors})
		}
		
	}

	async getCityList(stateId) {
		this.setState({state: stateId});
		try {
			let response = await fetch('http://www.igo2.org/api/CityList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					state: stateId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({cityList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in city list api");
			this.setState({errors:errors})
		}
	}

	render() {
		let countryItems = this.state.countryList;
		let stateList = this.state.stateList;
		let cityList = this.state.cityList;
		let category = this.getCategory();
		return (
			<ScrollView style={css.container}>
				<View style={styles.container}>
	      			<Image style={styles.logo}
		      	    source={require('../assets/img/logo.png')}
		      	 	/>
			      	<Errors errors={this.state.errors} />
			      	<View style={css.infoRow}>
			      		<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({fname: val})} style = {[css.input,css.halfWidth,css.lmargin]} placeholder='First Name' />
			      		<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({lname: val})} style = {[css.input,css.halfWidth]} placeholder='Last Name'/>
		      		</View>
		      		<View style={css.infoRow}>
						<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({email: val})} style={[css.input,css.halfWidth,css.lmargin]} placeholder="Email" />
						<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({mobile: val})} style={[css.input,css.halfWidth]} placeholder="Mobile Number" />
	      			</View>
	      			<View style={css.infoRow}>
						<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({address: val})} style={[css.input,css.lastname]} placeholder="Address" />
	      			</View>
	      			<View style={css.infoRow}>
	      				<View style={[css.input,css.halfWidth,css.lmargin]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'Country',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.country}
	      					    items={countryItems}
	      					    onValueChange={(val) => this.getStateList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      				<View style={[css.input,css.halfWidth]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'State',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.state}
	      					    items={stateList}
	      					    onValueChange={(val) => this.getCityList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
		      		</View>
		      		<View style={css.infoRow}>
	      				<View style={[css.input,css.halfWidth,css.lmargin]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'City',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.city}
	      					    items={cityList}
	      					    onValueChange={(val) => this.setState({city: val})}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      				<View style={[css.input,css.halfWidth]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'Category',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.category}
	      					    items={category}
	      					    onValueChange={(val) => this.setState({category: val})}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      			</View>
		      		<View style={css.infoRow}>
		      			<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({password: val})} style={[css.input,css.halfWidth,css.lmargin]} placeholder="Password" secureTextEntry={true} />
		      			<TextInput placeholderTextColor='#ccc' onChangeText={ (val) => this.setState({password_confirmation: val})} style={[css.input,css.halfWidth]} placeholder="Confirm password" secureTextEntry={true} />
		      		</View>

		      		<TouchableOpacity style={[css.button,{marginTop:30}]} onPress={this.onRegisterPressed.bind(this)}>
		      			<Text style={styles.submitButtonText}>Sign Up</Text>
		      		</TouchableOpacity>
	      			<TouchableOpacity style={styles.buttonIn} onPress={this.onLoginPressed.bind(this)}>
		      			<Text style={styles.singInText}>Log In to IGO2 App</Text>
		      		</TouchableOpacity>
	      		</View>
      		</ScrollView>
		)
	}
}

const Errors = (props) => {
	if(props.errors.length > 0){
		return (
			<View>
				{props.errors.map((error,i) => <Text key={i} style={styles.error}>{error}</Text>)}
			</View>
		)
	}
	else {
		return (
			<View>
			</View>
		);
	}
}


const styles = StyleSheet.create({
  container: {
    backgroundColor: '#050517',
    padding:10,
    alignItems:'center',
  }, 
  halfWidth:{
  	width:'48%',
  },
  buttonIn: {
  	paddingVertical:12,
    paddingHorizontal:12,
    marginVertical: 6,
    borderWidth:1,
    borderRadius: 50,
    alignItems: 'center',
    width: 300,
    backgroundColor: '#CFCECD',
  },
  singInText: {
	color: '#000000',
	fontWeight: '500',
  	fontSize:14,
  },
  registerText: {
  	fontSize:18,
  	fontWeight:'500',
  	color:'#ffffff',
  },
  signUpText: {
  	fontSize: 20,
  	fontWeight:'500',
  	color:'#000000',
  	margin: 10,
  },
  error: {
  	width: 300,
  	color: 'red',
  	padding: 1,
  }
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        color: '#ffffff',
    },
    inputAndroid: {
        color: '#ffffff',
    },
});