import React, {Component} from 'react';
import {Platform, StyleSheet, ActivityIndicator, AsyncStorage, Text, View, Image, Picker, TextInput, ScrollView, TouchableHighlight} from 'react-native';
import PickerSelect from "react-native-picker-select";

import { Icon, Card, Avatar } from 'react-native-elements';
import DatePicker from 'react-native-datepicker';

import styles from '../assets/style/style';
import Booking from '../components/BookingSummary';
import Payment from '../components/PaymentSummary';

export default class PassengerDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      salutation: 'Mr.',
      fname: '',
      lname: '',
      passport: '',
      age: '',
      membership: '',
      gender: '',
      nationality: '',
      expiry: '',
      passengerList: [],
      errors: [],

  }
}


updateSalutation = (salute) => {
    this.setState({ salutation: salute })
}

onButtonPressed = async () => {
  if(this.validate()){
    const { params } = this.props.navigation.state;
    this.props.navigation.navigate('ConfirmBooking',{searchList:params.searchList,flightDetails:params.flightDetails, passengerList:this.state.passengerList});    
  }
}

validate = () => {
  let details = this.state.passengerList;
  let messages = [];
    const { params } = this.props.navigation.state;
    const searchList = params.searchList;
     // searchList = [];
     // searchList.person = 2;
     fnameFlag = lnameFlag = salutationFlag = ageFlag = genderFlag = nationalityFlag = expiryFlag = false;
     try{
      for(let i = 0; i < searchList.person; i++){
        if(details[i].salutation !== 'undefined' && details[i].salutation){
         
        }
        else {
         salutationFlag = true;
        }
         if(details[i].fname !== 'undefined' && details[i].fname) {
         
         }
         else {
           fnameFlag = true;
         }
         if(details[i].lname !== 'undefined' && details[i].lname){
          
         }
         else {
          lnameFlag = true;
         }

         if(details[i].gender !== 'undefined' && details[i].gender){
          
         }
         else {
          genderFlag = true;
         }
         if(details[i].nationality !== 'undefined' && details[i].nationality){
          
         }
         else {
          nationalityFlag = true;
         }
        if(details[i].age !== 'undefined' && details[i].age){
            if(isNaN(details[i].age)){
              ageFlag = true;
            }
         }
         else {
            ageFlag = true;
         }
         if(details[i].expiry !== 'undefined' && details[i].expiry){
            if(!this.validateExpiryDate(details[i].expiry)){
              expiryFlag = true;
            }
         }
         
       }
       if(fnameFlag) {
         messages.push("Please enter First name.");
       }      
       if(lnameFlag) {
         messages.push("Please enter Last name.");
       }
       if(salutationFlag) {
         messages.push("Please enter Title.");
       }
       if(genderFlag) {
         messages.push("Please select gender.");
       } 
       if(nationalityFlag) {
         messages.push("Please enter nationality.");
       }
       if(ageFlag) {
         messages.push("Please enter correct age.");
       }
       if(expiryFlag){
        messages.push("Please ener valid expiry date in YYYY-MM format");
       }
     }
     catch (exception){
        messages.push("Please enter all the required fields");
     }

  if(messages.length == 0) {
    this.setState({"errors":""});
    return true;
  }
  else {
    this.setState({"errors":messages});
    return false;
  }
}

updateState = (index,value,key) => {
   let obj = {};
   obj[key] = value;
   let Textdata = this.state.passengerList;
   if (typeof Textdata[index] !== 'undefined') {
    Textdata[index][key] = value;
   }
   else {
    Textdata[index] = obj;
   }
  this.setState({ passengerList: Textdata });
}

validateExpiryDate(date)
{
    var d = new Date();
    var currentYear = d.getFullYear();
    var currentMonth = d.getMonth();
    console.log(currentMonth);
    let date_array = date.split("-");
    if(Array.isArray(date_array) && date_array.length == 2){
      let year = date_array[0];
      let month = date_array[1];
      if(year.length != 4 || year < currentYear){
        return false;
      }
      if(month.length != 2 || month > 12 || month < 1){
        return false;
      }
      if(year < currentYear && month < currentMonth){
        return false;
      }
      if(isNaN(month) || isNaN(year)){
        return false;
      }
    }
    else {
      return false;
    }
    return true;
}

salutationItems() {
  return [
      {
          label: 'Mr.',
          value: 'Mr',
      },
      {
          label: 'Ms.',
          value: 'Ms',
      },
      {
          label: 'Mrs.',
          value: 'Mrs',
      },
  ]
}
genderItems() {
  return [
      {
          label: 'Male',
          value: 'Male',
      },
      {
          label: 'Female',
          value: 'Female',
      }
  ]
}

PassengerView(i) {
    const salutationItems = this.salutationItems();
    const genderItems = this.genderItems();
    const index = i-1;

    return(
    <View style={styles.formView} key={i}>
       <Text style={styles.AdultText}>Adult {i}</Text>
           <View style={styles.infoRow}>
            <View style={styles.salutationContainer}>
             <PickerSelect
               placeholder={{
                   label: 'Title',
                   value: '',
               }}
               hideIcon={true}
               items={salutationItems}
               onValueChange={val => this.updateState(index, val,'salutation')}
               style={{...pickerSelectStyles}}
              useNativeAndroidPickerStyle={false}
              
           />
           <Text style={styles.star}>*</Text>
           </View>
           <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'fname')} style={[styles.input, styles.firstname]} placeholder="First Name"  />
           <Text style={styles.star}>*</Text>
           </View>
           <View style={styles.infoRow}>
           <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'lname')} style={[styles.input, styles.lastname]} placeholder="Last Name" />
           <Text style={styles.star}>*</Text>
           </View>
           <View style={styles.infoRow}>
           <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'expiry')} style={[styles.input, styles.halfWidth, styles.lmargin]} placeholder="Passport Expiry" />
    
        <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'passport')} style={[styles.input, styles.halfWidth]} placeholder="Passport Number" />
        </View>
        <View style={styles.infoRow}>
        <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'membership')} style={[styles.input, styles.lastname]} placeholder="Membership Number" />
        </View>
        <View style={styles.infoRow}>
          <View style={styles.ageInput}>
          <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'age')} style={[styles.input]} placeholder="Age" />
          <Text style={styles.star}>*</Text>
          </View>
          <View style={styles.genderContainer}>
          <PickerSelect
            placeholder={{
                label: 'Gender',
                value: '',
            }}
            hideIcon={true}
            items={genderItems}
            onValueChange={val => this.updateState(index, val,'gender')}
            style={{...pickerSelectStyles}}
           useNativeAndroidPickerStyle={false}
           
        />
        <Text style={styles.star}>*</Text>
        </View>
        <TextInput placeholderTextColor='#cccccc' onChangeText={val => this.updateState(index, val,'nationality')} style={[styles.input, styles.nationality]} placeholder="Nationality" />
        <Text style={styles.star}>*</Text>

        </View>
    </View>
    )
}

render() {
   var passengers = [];
   const { params } = this.props.navigation.state;
   const searchList = params.searchList;
    // searchList = [];
    // searchList.person = 2;
    for(let i = 1; i <= searchList.person; i++){
       passengers.push(
            this.PassengerView(i)
        )
    }

return (
    <ScrollView style={styles.container}>
        <Card title="Traveller Information" containerStyle={styles.card} titleStyle={styles.heading}>
            <Errors errors={this.state.errors} />
            { passengers }
        </Card>
        <View style={{flex:1,alignItems:'center',marginVertical:10}}>
            <TouchableHighlight style={styles.button} onPress={this.onButtonPressed.bind(this)}>
                <Text style={styles.blockText}>Submit</Text>
            </TouchableHighlight>
        </View>
    </ScrollView>
    )
}
}


const Errors = (props) => {
  if(props.errors.length > 0){
    return (
      <View>
        {props.errors.map((error,i) => <Text key={i} style={styles.error}>{error}</Text>)}
      </View>
    )
  }
  else {
    return (
      <View>
      </View>
    );
  }
}

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        paddingVertical:10,
        paddingHorizontal:10,
        borderBottomWidth:1,
        borderBottomColor: '#cccccc',
        borderRadius: 2,
        color: '#ffffff',
    },
    inputAndroid: {
        paddingVertical:10,
        paddingHorizontal:10,
        borderBottomWidth:1,
        borderBottomColor: '#cccccc',
        borderRadius: 2,
        color: '#ffffff',
    },
});