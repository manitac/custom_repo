import React, {Component} from 'react';
import {Platform, StyleSheet,TouchableOpacity,TouchableHighlight, Text, View, Image, TextInput, AsyncStorage, ScrollView} from 'react-native';

const ACCESS_TOKEN = 'access_token';

//import ImagePicker from 'react-native-image-picker';
import { Icon } from 'react-native-elements';
import css from '../assets/style/style';
import Loader from './Loader';
import PickerSelect from "react-native-picker-select";
import DatePicker from 'react-native-datepicker';



export default class Profile extends Component {
	constructor(props) {
		super(props);
		this.state = {
			salutation: 'Mr.',
			fname: "",
			lname: "",
			mobile: "",
			email: "",
			address:"",
			country: "",
			countryList: [],
			stateList: [],
			cityList: [],
			state: "",
			city: "",
			gender: '',
			dob:'',
			errors: [],
			loading: false,
		}
	}

	componentDidMount() {
		this.getCountryItems();
		this.getStateList(this.state.country);
		this.getCityList(this.state.state);
	}

	async getCountryItems() {
		try{
			let response = await fetch('http://www.igo2.org/api/CountryList');
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({countryList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in country list api");
			this.setState({errors:errors})
		}
	}

	salutationItems() {
		return [
				{
						label: 'Mr.',
						value: 'Mr',
				},
				{
						label: 'Ms.',
						value: 'Ms',
				},
				{
						label: 'Mrs.',
						value: 'Mrs',
				},
		]
	}

	genderItems() {
		return [
				{
						label: 'Male',
						value: 'Male',
				},
				{
						label: 'Female',
						value: 'Female',
				}
		]
	}

	async getStateList(countryId){
		this.setState({country: countryId});
		try {
			let response = await fetch('http://www.igo2.org/api/StateList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					country: countryId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({stateList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in state list api");
			this.setState({errors:errors})
		}
		
	}

	async getCityList(stateId) {
		this.setState({state: stateId});
		try {
			let response = await fetch('http://www.igo2.org/api/CityList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					state: stateId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({cityList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in city list api");
			this.setState({errors:errors})
		}
	}


	onSubmit(){
    
	}
	render() {
		const genderItems = this.genderItems();
    const salutationItems = this.salutationItems();
		if(!this.state.loading){

			let countryItems = this.state.countryList;
			let stateList = this.state.stateList;
			let cityList = this.state.cityList;
			return(
				<ScrollView style={css.container}>
				<View style={styles.container}>
			      	<Errors errors={this.state.errors} />
             
              <View style={{marginHorizontal:10,marginTop:10}}>
                         <Text style={{color:'#D9A253',fontSize:18,fontWeight:'bold'}}>Personal Information</Text>
                </View>
			      
			      	<View style={css.infoRow}>
									<View style={[styles.inputBox,css.halfWidth,css.lmargin,{paddingBottom:0}]}>
										<PickerSelect
													placeholder={{
															label: 'Title',
															value: '',
                          }}
                          style={{...pickerSelectStyles}}
													hideIcon={true}
                          items={salutationItems}
                          value={this.state.salutation}
                          onValueChange={(val) => this.setState({ salutation : val }) }
                          useNativeAndroidPickerStyle={false}
										    />
										</View>
	      						<View style={[styles.inputBox,css.halfWidth]}>
												<TextInput style={styles.input} placeholderTextColor='#ccc' value={this.state.fname} onChangeText={ (val) => this.setState({fname: val})} placeholder='First Name' />
			      				</View>
							</View>
		      		<View style={css.infoRow}>
                    <View style={[styles.inputBox,css.halfWidth,css.lmargin]}>
												<TextInput  style={styles.input} placeholderTextColor='#ccc' value={this.state.lname} onChangeText={ (val) => this.setState({lname: val})}  placeholder='Last Name'/>
                    </View>
	      						<View style={[styles.inputBox,css.halfWidth]}>			
											<TextInput style={styles.input} placeholderTextColor='#ccc' value={this.state.email} onChangeText={ (val) => this.setState({email: val})} placeholder="Email" />
                    </View>
              </View>
	      			<View style={[css.infoRow,styles.inputBox]}>
						<TextInput style={[styles.input,{ width:'100%'}]}  placeholderTextColor='#ccc' value={this.state.address} onChangeText={ (val) => this.setState({address: val})} placeholder="Address" />
	      			</View>
	      			<View style={css.infoRow}>
	      				<View style={[styles.inputBox,css.halfWidth,css.lmargin]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'Country',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.country}
	      					    items={countryItems}
	      					    onValueChange={(val) => this.getStateList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      				<View style={[styles.inputBox,css.halfWidth]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'State',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.state}
	      					    items={stateList}
	      					    onValueChange={(val) => this.getCityList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
		      		</View>
							<View style={css.infoRow}>
	      				<View style={[styles.inputBox,css.halfWidth,css.lmargin]}>
	      				<PickerSelect
                          placeholder={{
                              label: 'City',
                              value: '',
                          }}
                          style={{...pickerSelectStyles}}
                          hideIcon={true}
                          value={this.state.city}
                          items={cityList}
                          onValueChange={(val) => this.setState({city: val})}
                          useNativeAndroidPickerStyle={false}
                      />
	      				</View>
	      				<View style={[styles.inputBox,css.halfWidth]}>
	      				<DatePicker
										date={this.state.dob}
										mode="date"
										placeholder="Date of Birth"
										format="ddd, MMM D YYYY"
										confirmBtnText="Confirm"
										cancelBtnText="Cancel"
										showIcon={false}
										customStyles={{
											
											dateInput: {
                          borderWidth:0,
                          marginLeft:-25,
                          paddingTop:10,
													//margin:5,
											},
												dateText: {
													color: "#FFF",
                          fontSize:14,
												}
										}}
										onDateChange={(date) => {this.setState({dob: date})}}
									/>
                  
	      				</View>
		      		</View>
		      		<View style={css.infoRow}>
                    <View style={[styles.inputBox,css.halfWidth,css.lmargin]}>
                    <PickerSelect
											placeholder={{
													label: 'Gender',
													value: '',
											}}
											hideIcon={true}
											items={genderItems}
											onValueChange={val => {this.setState({gender: val})} }
											style={{...pickerSelectStyles}}
										useNativeAndroidPickerStyle={false}
										
									/>
                    </View>
                    <View style={[styles.inputBox,css.halfWidth]}>
                        <TextInput style={styles.input} placeholderTextColor='#ccc' value={this.state.mobile} onChangeText={ (val) => this.setState({mobile: val})}  placeholder="Mobile Number" />
                       
                    </View>
	      			</View>
		      		<TouchableHighlight style={[css.button,{marginTop:30}]} onPress={this.onSubmit.bind(this)}>
			      		<Text style={styles.submitButtonText}>Reserve Now</Text>
			      	</TouchableHighlight>
	      		</View>
      		</ScrollView>
			)
		}
		else {
			return(
				<Loader />
			)
		}
	}
}

const Errors = (props) => {
	if(props.errors.length > 0){
		return (
			<View>
				{props.errors.map((error,i) => <Text key={i} style={css.error}>{error}</Text>)}
			</View>
		)
	}
	else {
		return (
			<View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#050517',
    padding:10,
    alignItems:'center',
    borderColor: '#cccccc',
    borderWidth:1,
    width:'90%',
    marginHorizontal:'5%',
    marginTop:20
  }, 
  halfWidth:{
  	width:'48%',
  },
  inputBox: {
    paddingTop:10,
    paddingBottom:3,
    paddingHorizontal:10,
    borderBottomWidth:1,
    borderBottomColor: '#cccccc',
    borderRadius: 2,
    color: '#ffffff',
},
  input: {
    color:'#FFF',
  },
  buttonIn: {
  	paddingVertical:12,
    paddingHorizontal:12,
    marginVertical: 6,
    borderWidth:1,
    borderRadius: 50,
    alignItems: 'center',
    width: 300,
    backgroundColor: '#CFCECD',
  },
  singInText: {
	color: '#000000',
	fontWeight: '500',
  	fontSize:14,
  },
  registerText: {
  	fontSize:18,
  	fontWeight:'500',
  	color:'#ffffff',
  },
  signUpText: {
  	fontSize: 20,
  	fontWeight:'500',
  	color:'#000000',
  	margin: 10,
  },
  error: {
  	width: 300,
  	color: 'red',
  	padding: 1,
  },
  submitButtonText: {
    fontSize: 18,
  	fontWeight:'500',
  }

});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        color: '#FFF',
    },
    inputAndroid: {
        color: '#FFF',
    },
});