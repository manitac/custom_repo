import React, { Component } from 'react';
import { AppRegistry, Platform, StyleSheet, Text, View, Image, Picker, TextInput, TouchableHighlight, TouchableOpacity, ScrollView } from 'react-native';
import { Icon } from 'react-native-elements';
import Loader from './Loader';
import css from '../assets/style/style';
import carcss from '../assets/style/Cars';


export default class CarListing extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
        }
    }



    render() {

        if (!this.state.loading) {

            return (
                    <ScrollView style={css.scrollContainer}>
                        <View style={[css.SearchPageContainer,{marginVertical:10}]}>
                           <View style={carcss.recommended}>
                              <Icon
                                    name='car'
                                    type='font-awesome'
                                    color='#FFFFFF'
                                    containerStyle={carcss.iconlft}
                                  />
                                  <Text style={carcss.recommendedTxt}>Recommended Cars for you</Text>
                            </View>

                            <View style={carcss.recommendedinner}>
                                <View style={carcss.recommendedinnerRow}>
                                  <Icon
                                        name='car'
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={carcss.iconlft}
                                    />
                                    <Text style={carcss.recommendedinnerRowTxt}>Verified Drivers & Cars</Text>
                                </View>
                                <View style={carcss.recommendedinnerRow}>
                                  <Icon
                                        name='car'
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={carcss.iconlft}
                                    />
                                    <Text style={carcss.recommendedinnerRowTxt}>Breakdown Assistance</Text>
                                </View>
                                <View style={carcss.recommendedinnerRow}>
                                  <Icon
                                        name='car'
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={carcss.iconlft}
                                    />
                                    <Text style={carcss.recommendedinnerRowTxt}>24X7 Cutomer Care</Text>
                                </View>
                                <View style={carcss.recommendedinnerRow}>
                                  <Icon
                                        name='car'
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={carcss.iconlft}
                                    />
                                    <Text style={carcss.recommendedinnerRowTxt}>Great Price</Text>
                                </View>
                            </View>

                              <View style={carcss.carsView}>

                                  <View style={carcss.carsViewInner}>
                                     <View style={carcss.carsViewInnerupper}>
                                               <Text style={carcss.carsViewInnerTextTitle}>Van</Text>
                                                <View style={{alignItems:'center'}}>
                                                    <Image 
                                                          source={require('../assets/img/not_available.png')}
                                                        /> 
                                                </View>
                                                <View style={{ display:'flex',flexDirection: 'row',marginVertical:20,justifyContent: 'space-between'}}>                
                                                  <Text style={carcss.carsViewInnerText}>AC | Automatic | Unlimitedmilage</Text>
                                                   <Text style={carcss.carsViewInnerPrice}>$ 90.00</Text>  
                                                </View>
                                      </View>
                                      <View style={carcss.carsViewInnerlower}>
                                              <Text style={carcss.selectCabLftTxt}>Terminal</Text>
                                              <TouchableHighlight style={{backgroundColor:'#D9A253',paddingHorizontal:10, paddingVertical:5,}}>
                                                <Text style={carcss.selectCabTxt}>Select Cab</Text>
                                              </TouchableHighlight>
                                      </View>
                                  </View>
                                  
                              
                              </View>
                          </View>
                  </ScrollView>
            )
        } else {
            return (
                <Loader />
            )
        }
    }
}


const styles = StyleSheet.create({
  error:{
    color:'#FFFFFF',
    fontWeight:'bold',
  },
  errorContainer:{
    padding:10,
    backgroundColor: 'red',
    width:'100%',
  },
  searchText:{
    fontSize:14,
    fontWeight:'500',
    color:'#ffffff',
  },

  rows:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  autocompleteList:{
    position: 'relative',
    borderBottomWidth:1,
    borderBottomColor: '#ccc',
    paddingVertical:5,
  },
  atf1:{
    zIndex: 3,
  },
  atf2:{
    zIndex:2,
  }
})
