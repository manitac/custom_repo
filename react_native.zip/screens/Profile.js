import React, {Component} from 'react';
import {Platform, StyleSheet,TouchableOpacity,TouchableHighlight, Text, View, Image, TextInput, AsyncStorage, ScrollView} from 'react-native';

const ACCESS_TOKEN = 'access_token';

import ImagePicker from 'react-native-image-picker';
import { Icon } from 'react-native-elements';
import css from '../assets/style/style';
import Loader from './Loader';
import PickerSelect from "react-native-picker-select";

const options = {
  title: 'Select a Photo',
  takePhotoButtonTitle: 'Take Photo',
  chooseFromLibraryButtonTitle: 'Select from Library',
  mediaType: 'photo',
  quality: 1
};

export default class AuthLoadingScreen extends Component {
	constructor(props) {
		super(props);
		this.state = {
			postImageSource : "",
			fname: "",
			lname: "",
			mobile: "",
			email: "",
			address:"",
			country: "",
			countryList: [],
			stateList: [],
			cityList: [],
			state: "",
			city: "",
			category: "",
			errors: [],
			loading: false,
		}
		this.setProfileData();
	}

	componentDidMount() {
		this.getCountryItems();
		this.getStateList(this.state.country);
		this.getCityList(this.state.state);
	}

	async getCountryItems() {
		try{
			let response = await fetch('http://www.igo2.org/api/CountryList');
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({countryList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in country list api");
			this.setState({errors:errors})
		}
	}

	getCategory() {
		return [
			{
				label: 'Customer',
				value: '3'
			},
			{
				label: 'Booker',
				value: '2'
			}
		]
	}

	async getStateList(countryId){
		this.setState({country: countryId});
		try {
			let response = await fetch('http://www.igo2.org/api/StateList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					country: countryId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({stateList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in state list api");
			this.setState({errors:errors})
		}
		
	}

	async getCityList(stateId) {
		this.setState({state: stateId});
		try {
			let response = await fetch('http://www.igo2.org/api/CityList', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					state: stateId,
				})
			});
			let result = await response.text();
			let json = JSON.parse(result);
			this.setState({cityList:json});
		} catch (Exception) {
			let errors = [];
			errors.push("Error in city list api");
			this.setState({errors:errors})
		}
	}

	async setProfileData() {
		this.setState({
			fname: await AsyncStorage.getItem('user_fname'),
			lname: await AsyncStorage.getItem('user_lname'),
			email: await AsyncStorage.getItem("user_email"),
			mobile: await AsyncStorage.getItem("user_mobile"),
			address: await AsyncStorage.getItem('user_address'),
			country: await AsyncStorage.getItem('user_country'),
			state: await AsyncStorage.getItem('user_state'),
			city: await AsyncStorage.getItem('user_city'),
			category: await AsyncStorage.getItem('user_category'),
		})
		var photo = await AsyncStorage.getItem("user_image");
		if(photo != "" && photo != null) {
			const source = { uri: photo };
				console.log("hi",source);
			this.setState({postImageSource: source})
		}
		
	}


	uploadPhoto() {
		ImagePicker.showImagePicker(options, (response) => {
		  console.log('Response = ', response);
		  if (response.didCancel) {
		    console.log('User cancelled image picker');
		  } else if (response.error) {
		    console.log('ImagePicker Error: ', response.error);
		  } 
		  else {
		    const source = { uri: response.uri };

		    // You can also display the image using data:
		    // const source = { uri: 'data:image/jpeg;base64,' + response.data };
		    console.log("source",source)
		    this.setState({
		      postImageSource: source,
		    });
		  }
		});

	}

	async setProfileValues(profile) {
		try {
			await AsyncStorage.setItem("role_id",profile.role_id);
			await AsyncStorage.setItem("user_image",profile.image_link);
			await AsyncStorage.setItem("user_fname",profile.fname);
			await AsyncStorage.setItem("user_lname",profile.lname);
			await AsyncStorage.setItem("user_email",profile.email);
			await AsyncStorage.setItem("user_mobile",profile.mobile);
			await AsyncStorage.setItem("user_address",profile.address);
			await AsyncStorage.setItem("user_country",profile.country_id);
			await AsyncStorage.setItem("user_state",profile.state_id);
			await AsyncStorage.setItem("user_city",profile.city_id);
			await AsyncStorage.setItem("user_category",profile.role_id);
			await AsyncStorage.setItem("user_countrycode",profile.countrycode);
			await AsyncStorage.setItem("user_created",profile.created_at);
			// this.props.navigation.navigate('Home');

		}
		catch(error) {
			console.log('something went wrong! Please contact to Admin 2');
		}
	}

	async submitForm(){
		const apiUrl = 'http://www.igo2.org/api/profile';
		const user_id = await AsyncStorage.getItem('user_id');
		const uri = this.state.postImageSource.uri; 
		if(uri)
		{
			const uriParts = uri.split('.');
			const fileType = uriParts[uriParts.length - 1];
			const formData = new FormData();
			formData.append('user_id', user_id);
			formData.append('fname',this.state.fname);
			formData.append('lname',this.state.lname);
			formData.append('mobile',this.state.mobile);
			formData.append('email',this.state.email);
			formData.append('address',this.state.address);
			formData.append('country',this.state.country);
			formData.append('state',this.state.state);
			formData.append('city',this.state.city);
			formData.append('role_id',this.state.category);
			formData.append('photo', {
				uri: this.state.postImageSource.uri,
				name: 'photo.jpg',
				type: 'image/jpg',
			});
			try{
				this.setState({loading:true});
				let respons = await fetch(apiUrl, { 
					method: 'POST',
					headers: {
						'Accept': 'application/json',
						'Content-Type': 'multipart/form-data',
					},
					body: formData 
				});
				let res = await respons.text();
				this.setState({loading:false});
				console.log(res);
				let responseArr = JSON.parse(res);
				if(responseArr.status_code >= 200 && responseArr.status_code < 300) {
					if(responseArr.status_code == 200){
						this.setState({errors: ''});
						this.setState({success:'Profile Update Successfully!'});
						this.setProfileValues(responseArr.data.users);
						setTimeout(() => {this.setState({success: ''})}, 5000)
					}
					else {
						throw(responseArr.errors);
					}
				}
				else {
					let errors = responseArr.errors;
					throw errors;
				}
			} catch(formErrors) {
				let errorsArray = [];
				this.setState({success:''});
				if(formErrors.length > 0){
					for(let i = 0; i < formErrors.length; i++){
						errorsArray.push(formErrors[i]);
					}
				}
				else{
					errorsArray.push("JSON error");
				}
				this.setState({errors: errorsArray});
			}
		}
		else {
			let errorsArray = [];
			errorsArray.push("Please upload the image");
			this.setState({errors: errorsArray});
			
		}
}
	getSuccess(){
		if(this.state.success){
			return(
				<View style={css.successDiv}>
					<Icon
					  raised
					  name='check'
					  type='font-awesome'
					  color='green'
					/>
					<Text style={css.successDivText}>{this.state.success}</Text>
				</View>
				)
		}
		else {
			return null;
		}
	}
	render() {
		let success = this.getSuccess();
		if(!this.state.loading){

			let countryItems = this.state.countryList;
			let stateList = this.state.stateList;
			let cityList = this.state.cityList;
			let category = this.getCategory();
			return(
				<ScrollView style={css.container}>
				<View style={styles.container}>
			      	<Errors errors={this.state.errors} />
			      	{success}
			      	<View style={css.infoRow}>
			      		<TouchableHighlight onPress={this.uploadPhoto.bind(this)}>
							<Image style={css.profileimage} source={this.state.postImageSource != '' ? this.state.postImageSource : require('../assets/img/not_available.png')} />
			      		</TouchableHighlight>
			      	</View>
			      	<View style={css.infoRow}>
			      		<TextInput placeholderTextColor='#ccc' value={this.state.fname} onChangeText={ (val) => this.setState({fname: val})} style = {[css.input,css.halfWidth,css.lmargin]} placeholder='First Name' />
			      		<TextInput placeholderTextColor='#ccc' value={this.state.lname} onChangeText={ (val) => this.setState({lname: val})} style = {[css.input,css.halfWidth]} placeholder='Last Name'/>
		      		</View>
		      		<View style={css.infoRow}>
						<TextInput placeholderTextColor='#ccc' value={this.state.email} onChangeText={ (val) => this.setState({email: val})} style={[css.input,css.halfWidth,css.lmargin]} placeholder="Email" />
						<TextInput placeholderTextColor='#ccc' value={this.state.mobile} onChangeText={ (val) => this.setState({mobile: val})} style={[css.input,css.halfWidth]} placeholder="Mobile Number" />
	      			</View>
	      			<View style={css.infoRow}>
						<TextInput placeholderTextColor='#ccc' value={this.state.address} onChangeText={ (val) => this.setState({address: val})} style={[css.input,css.lastname]} placeholder="Address" />
	      			</View>
	      			<View style={css.infoRow}>
	      				<View style={[css.input,css.halfWidth,css.lmargin]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'Country',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.country}
	      					    items={countryItems}
	      					    onValueChange={(val) => this.getStateList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      				<View style={[css.input,css.halfWidth]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'State',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.state}
	      					    items={stateList}
	      					    onValueChange={(val) => this.getCityList(val)}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
		      		</View>
		      		<View style={css.infoRow}>
	      				<View style={[css.input,css.halfWidth,css.lmargin]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'City',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.city}
	      					    items={cityList}
	      					    onValueChange={(val) => this.setState({city: val})}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      				<View style={[css.input,css.halfWidth]}>
	      					<PickerSelect
	      					    placeholder={{
	      					        label: 'Category',
	      					        value: '',
	      					    }}
	      					    style={{...pickerSelectStyles}}
	      					    hideIcon={true}
	      					    value={this.state.category}
	      					    items={category}
	      					    onValueChange={(val) => this.setState({category: val})}
	      					    useNativeAndroidPickerStyle={false}
	      					/>
	      				</View>
	      			</View>
		      		<TouchableHighlight style={[css.button,{marginTop:30}]} onPress={this.submitForm.bind(this)}>
			      		<Text style={styles.submitButtonText}>Update</Text>
			      	</TouchableHighlight>
	      		</View>
      		</ScrollView>
			)
		}
		else {
			return(
				<Loader />
			)
		}
	}
}

const Errors = (props) => {
	if(props.errors.length > 0){
		return (
			<View>
				{props.errors.map((error,i) => <Text key={i} style={css.error}>{error}</Text>)}
			</View>
		)
	}
	else {
		return (
			<View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#050517',
    padding:10,
    alignItems:'center',
  }, 
  halfWidth:{
  	width:'48%',
  },
  buttonIn: {
  	paddingVertical:12,
    paddingHorizontal:12,
    marginVertical: 6,
    borderWidth:1,
    borderRadius: 50,
    alignItems: 'center',
    width: 300,
    backgroundColor: '#CFCECD',
  },
  singInText: {
	color: '#000000',
	fontWeight: '500',
  	fontSize:14,
  },
  registerText: {
  	fontSize:18,
  	fontWeight:'500',
  	color:'#ffffff',
  },
  signUpText: {
  	fontSize: 20,
  	fontWeight:'500',
  	color:'#000000',
  	margin: 10,
  },
  error: {
  	width: 300,
  	color: 'red',
  	padding: 1,
  }
});

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        color: '#FFF',
    },
    inputAndroid: {
        color: '#FFF',
    },
});