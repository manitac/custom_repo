import React, {Component} from 'react';
import {View, Text, TouchableHighlight} from 'react-native';
import styles from '../assets/style/style';
import { Icon } from 'react-native-elements';

export default class FlightSuccess extends Component{

  render(){
    const { params } = this.props.navigation.state;
    console.log(params);
    let locatorCode = params.data.locator_code;
    
    return (
        <View style = {{backgroundColor:'#0A092F', flex: 1,justifyContent:'center'}}>
            <View style={styles.successPageDiv}>
                <Icon
                  raised
                  name='check'
                  type='font-awesome'
                  color='#2CBDA1'
                />
                <Text style={{color:'#FFF',fontSize:28,fontWeight:'bold',marginBottom:20}}>SUCCESS</Text>
                
                <Text style={styles.successDivText}>Flight Ticket Booked Successfully.</Text>
                <Text style={styles.successDivText}>Locator Code: {locatorCode}</Text>
                <TouchableHighlight onPress = {() => this.props.navigation.navigate('Home')}>
                    <View style={{marginTop:40}}>
                        <Icon
                          raised
                          name='home'
                          type='font-awesome'
                          color='#2CBDA1'
                        
                        />
                        <Text style={styles.successDivText}>Home</Text>
                    </View>
                </TouchableHighlight>
            </View>
        </View>        
      );
    }
  }

