import React, {Component} from 'react';
import {View, Text, TouchableHighlight} from 'react-native';
import styles from '../assets/style/style';
import { Icon } from 'react-native-elements';

export default class FlightFail extends Component{

  render(){
    const { params } = this.props.navigation.state;
    message = params.message;
    
    return (
        <View style = {{backgroundColor:'#0A092F', flex: 1,justifyContent:'center',}}>
            <View style={styles.errorPageDiv}>
                <Icon
                  raised
                  name='times'
                  type='font-awesome'
                  color='#E00E1D'
                />
                <Text style={{color:'#FFF',fontSize:28,fontWeight:'bold',marginBottom:20}}>{message}</Text>
                
                <Text style={styles.errorPageDivText}>Fail to book Flight Ticket.</Text>
                <TouchableHighlight onPress = {() => this.props.navigation.navigate('Home')}>
                    <View style={{marginTop:40}}>
                        <Icon
                          raised
                          name='home'
                          type='font-awesome'
                          color='#E00E1D'
                        
                        />
                        <Text style={styles.errorPageDivText}>Home</Text>
                    </View>
                </TouchableHighlight>
            </View>
        </View>        
      );
    }
  }

