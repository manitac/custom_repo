import React, {Component} from 'react';
import {
Platform, StyleSheet, ActivityIndicator, AsyncStorage, Text, View, Image, ImageBackground,
FlatList,TouchableOpacity,ScrollView
} 
from 'react-native';
import {List, ListItem, SearchBar} from "react-native-elements";

import Loader from './Loader';

export default class FlightList extends Component {
	constructor(props) {
		super(props);
		this.state = {
		  loading: false,
		  data: [],
		  fullData: [],
		  page: 1,
		  seed: 1,
		  error: '',
		  refreshing: false,
		  filter:'departure',
		}

		// this.makeRemoteRequest();
	}

	componentDidMount() {
	  this.makeRemoteRequest();
	}

	makeRemoteRequest = async() => {
		const { params } = this.props.navigation.state;
		  this.setState({
		    data: params.details,
		    fullData: params.details,
		    searchList: params.searchList,
		    error: '',
		    loading: false,
		    refreshing: false
		  })
	}

	handleSearch = (property) => {
		let filter = this.state.filter;
		let fullData = this.state.fullData;
		if(property == 'all')
		{
			this.setState({data:fullData});			
		}
		else {
			if(filter == 'departure') {
				let timing = property.split("-");
				let inputHoursFrom = parseInt(timing[0]);
				let inputHoursTo = parseInt(timing[1]);

				const newData = fullData.filter(item => {
					if(this.validateTime(item.departureTime,inputHoursFrom,inputHoursTo)) {
						return item;
					}
				});
				this.setState({data:newData});
			}
			else if(filter == 'arrival') {
				let timing = property.split("-");
				let inputHoursFrom = parseInt(timing[0]);
				let inputHoursTo = parseInt(timing[1]);

				const newData = fullData.filter(item => {
					if(this.validateTime(item.arrivalTime,inputHoursFrom,inputHoursTo)) {
						return item;
					}
				});
				this.setState({data:newData});
			}
			else if(filter == 'price') {
				let price = property.split("-");
				let priceFrom = parseInt(price[0]);
				let priceTo = parseInt(price[1]);
				const newData = fullData.filter(item => {
					let costPerFlight = parseFloat(item.costPerFlight.substring(3));
					if(costPerFlight >= priceFrom && costPerFlight < priceTo){
						return item;
					}
				});
				this.setState({data:newData});
			}
			else if(filter == 'airlines') {
				let flightName = property;
				const newData = fullData.filter(item => {
					if(flightName == item.name) {
						return item;
					}
				});
				this.setState({data:newData});
			}
		}
		
	  // const textData = text.toLowerCase();
	  // const siteData = this.state.data;
	  // const newData = siteData.filter(item => {      
	  //     const itemData = item.name.toLowerCase();
	  //     return itemData.indexOf(textData) > -1;    
	  //   });
	  // if(text == '') {
	  //   const fullData = this.state.fullData;
	  //   this.setState({data: fullData})
	  // }
	  // else {
	  //   this.setState({data: newData})
	  // }
	}

	validateTime(time,inputHoursFrom,inputHoursTo) {
		const itemData = time.split(":");
		let hours = parseInt(itemData[0]);
		let minute = parseInt(itemData[1]);
		if(hours >= inputHoursFrom && hours < inputHoursTo) {
			return true;
		}
		else if(hours == inputHoursTo && hours == 0){
			return true;
		}
		return false;
	}

	getExtraItems(value) {
		if(value && value.trim() != '') {
			return(
				<Text style={[styles.cls, styles.small, styles.colorWhite]}>{value}</Text>
			)
		}
	}
	getFlightName(value) {
		if(value && value.trim() != '') {
			return(
				<Text style={[styles.flightName,styles.small, styles.colorGold]}>{value}</Text>
			)
		}
	}

	getDepartureProperties() {
		return(
			<View style={styles.filterPropertiesContainer}>
					<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
						<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('00-06')}>
						<Text style={[styles.filterOptionsText,styles.small]}>00 - 06</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('06-12')}>					
						<Text style={[styles.filterOptionsText,styles.small]}>06 - 12</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('12-18')}>					
						<Text style={[styles.filterOptionsText,styles.small]}>12 - 18</Text>
					</TouchableOpacity>
					<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('18-23')}>					
						<Text style={[styles.filterOptionsText,styles.small]}>18 - 00</Text>
					</TouchableOpacity>
			</View>
		)
	}

	getArrivalProperties() {
		return(
			<View style={styles.filterPropertiesContainer}>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
					<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('00-06')}>
					<Text style={[styles.filterOptionsText,styles.small]}>00 - 06</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('06-12')}>					
					<Text style={[styles.filterOptionsText,styles.small]}>06 - 12</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('12-18')}>					
					<Text style={[styles.filterOptionsText,styles.small]}>12 - 18</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('18-23')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>18 - 00</Text>
				</TouchableOpacity>
			</View>
		)
	}
	getPriceProperties() {
		return(
			<View style={styles.filterPropertiesContainer}>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
					<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('000-100')}>
					<Text style={[styles.filterOptionsText,styles.small]}>Below 100</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('100-300')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>100 - 300</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('300-500')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>300 - 500</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('500-1000')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>500 - 1000 </Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('1000-100000000000000')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>Above 1000 </Text>
				</TouchableOpacity>
			</View>
		)
	}

	flightNames(index) {
		return(
			<TouchableOpacity style={[styles.filterOptions]} key={index} onPress={() => this.handleSearch(index)}>					
				<Text style={[styles.filterOptionsText,styles.small]}>{index}</Text>
			</TouchableOpacity>
		)
	}
	getAirlinesProperties() {
		const { params } = this.props.navigation.state;
		let air = params.flightcompany_unique;

		let flight = [];
		air.filter(i => {
			flight.push(this.flightNames(i))
		})
		return(
			<View style={styles.filterPropertiesContainer}>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
					<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
				</TouchableOpacity>
				{flight}
			</View>
		)
	}

	FlightView(item,index) {
		let cabin = this.getExtraItems(item.cabinClass);
		let weight = this.getExtraItems(item.weight);
		let name = this.getFlightName(item.name);
		return (
			<TouchableOpacity onPress={() => this.props.navigation.navigate('PassengerDetails', {searchList: this.state.searchList,flightDetails:item })} key={index}>
				<View style={styles.repeatRow} >
					<View style={styles.flightIcon}>
							<Image
							style={{width: 40, height: 40}}
							source={{uri: item.image}}
							/>
							<Text style={[styles.seatNo, styles.small, styles.colorWhite, styles.mv3]}>{item.number}</Text>
							{name}
					</View>
					<View style={styles.middlePart}>
						<View style={styles.timelog}>
							<View style={styles.SourceTime}>
								<Text style={[styles.time,  styles.medium, styles.colorGold]}>{item.departureTime}</Text>
								<Text style={[styles.loc, styles.small, styles.colorWhite, styles.mv3]}>{this.state.searchList.from}</Text>						
							</View>
							<View style={styles.timeVariance}>
								<View style={styles.time}>
									<Text style={{textAlign:'center'}, [styles.small, styles.colorWhite]}>{item.departureEstimate}</Text>
								</View>
								<View style={[styles.seperator,  styles.mv3]}>
									<View style={styles.leftBullet}></View>
									<View style={styles.rightBullet}></View>
								</View>
								<View style={styles.stopPoint}>
									<Text style={{textAlign:'center'},[styles.small, styles.colorWhite]}>{item.stops}</Text>
								</View>
							</View>
							<View style={styles.DestinationTime}>
								<Text style={{textAlign:'center'},[styles.time,styles.medium, styles.colorGold]}>{item.arrivalTime}</Text>
								<Text style={{textAlign:'center'},[styles.loc,styles.small, styles.colorWhite,styles.mv3]}>{this.state.searchList.to}</Text>
							</View>						
						</View>
						<View style={styles.mealSec}>
							{cabin}
							{weight}
						</View>
					</View>
					<View style={styles.priceValue}>
						<Text style={[styles.medium, styles.colorGold]}>{item.costPerFlight}</Text>
						<Text style={{textAlign:'center'},[styles.small, styles.colorWhite]}>{item.seats}</Text>
					</View>
				</View>
			</TouchableOpacity>
		)
	}

	uniqueAirlinesFilter() {
		const { params } = this.props.navigation.state;
		let flightArr = params.flightcompany_unique;
		if(flightArr && flightArr.length > 0) {
			return(
				<TouchableOpacity style={[styles.priceTag, styles.width25]} onPress={ () => this.setState({filter:'airlines'})}>
					<Image
						source={require('../assets/img/icon.png')}
					/> 
					<Text style={[styles.small, styles.mv5, styles.colorWhite]}>Airlines</Text>
			 	</TouchableOpacity>
			)
		}
		else {
			return null;
		}
	}

	FilterRow() {
		let filter = this.state.filter;
		let uniqueAirlinesFilter = this.uniqueAirlinesFilter();
		let filterProperties = '';
		if(filter == 'arrival') {
			filterProperties = this.getArrivalProperties();
		}
		else if(filter == 'price') {
			filterProperties = this.getPriceProperties();
		}
		else if(filter == 'airlines' ) {
			filterProperties = this.getAirlinesProperties();
		}
		else {
			filterProperties = this.getDepartureProperties();
		}
		return(
		   <View style={{flex:1,backgroundColor: '#d9a352',width:'100%'}}>
			   <View style={styles.flightTags}>
			   		 <TouchableOpacity style={[styles.priceTag, styles.width25]} onPress={ () => this.setState({filter:'departure'})}>
			   			<Image
			   				source={require('../assets/img/clock.png')}
			   			/> 
			   			<Text style={[styles.small, stylparytes.mv5, styles.colorWhite]}>Departure Time</Text>
			   		 </TouchableOpacity>
			   		  <TouchableOpacity style={[styles.priceTag, styles.width25]} onPress={ () => this.setState({filter:'arrival'})}>
			   		 	<Image
			   		 		source={require('../assets/img/stop.png')}
			   		 	/> 
			   		 	<Text style={[styles.small, styles.mv5, styles.colorWhite]}>Arrival Time</Text>
			   		  </TouchableOpacity>
					<TouchableOpacity style={[styles.priceTag, styles.width25]} onPress={ () => this.setState({filter:'price'})}>
						<Image
							source={require('../assets/img/tag.png')}
						/> 
						<Text style={[styles.small, styles.mv5, styles.colorWhite]}>Price</Text>
					 </TouchableOpacity>
					 {uniqueAirlinesFilter}
					 
			  </View>
			  <ScrollView horizontal={true}>
			  		{ filterProperties }
				</ScrollView>
			</View>
		)
	}
	

	render() {
		let data = this.state.data;
		let flightRows = [];
		for(let i = 0; i < data.length; i++){
		    flightRows.push(
		         this.FlightView(data[i],i)
		     )
		 }
		 let topFilter = this.FilterRow();
		return (
		<ScrollView style={styles.scrollContainer}>
            <View style={styles.container}>
            	{ topFilter }
            	<Text style={styles.foundText}>Showing {this.state.data.length} of {this.state.fullData.length} flights</Text>
            	{ flightRows }
            </View>
		</ScrollView>
		)
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'flex-start',
    backgroundColor: '#0a092f',
	fontFamily:'Arial',
  },
  scrollContainer:{
  	flex: 1,
  	backgroundColor: '#0a092f',
  },
  foundText:{
  	color:'#FFF',
  	padding:6,
  },
  filterOptions:{
	flexDirection: 'row',
	borderRadius:2,
	margin:6,
	paddingHorizontal:10,
	paddingVertical:4,
	borderWidth:1,
	borderColor:'#0a092f',
	backgroundColor:'#0a092f',
  },
  filterPropertiesContainer:{
	flexDirection: 'row',
	},
  filterOptionsText:{
	fontSize:12,
	color:'#FFF',
  },
notificationLabel:{	
	 padding:10,
  },
  flightFilter:{
     flexDirection: 'row',
     alignItems: 'center',
	 justifyContent:'center',
	backgroundColor: '#d9a352',	   
  },
  flightTags:{
	 flex:1,
	 flexDirection: 'row',
     alignItems: 'center',
	 justifyContent:'space-between',
	 paddingBottom:0,
	 paddingTop:10,
  },
  width25:{
	  alignItems:'center',
	  width:'25%',
	  justifyContent:'space-between'
  },
  repeatRow:{
	 paddingHorizontal:10,
	 paddingVertical:15,
	borderBottomWidth: 1,
    borderBottomColor: "#5e5e5e",
	 flexDirection: 'row',
	   alignItems: 'center',
	 justifyContent:'center',

  },
  seperator:{
	  borderBottomWidth: 1,
	  width:'100%',
    borderBottomColor: "#ddd",
	 flexDirection: 'row',
	   alignItems: 'center',
	 justifyContent:'center',
	 position:'relative',
	 paddingRight:5,
  },
 mv3:{
	 marginVertical:3,
 },
mv5:{
	 marginVertical:5,
 },
leftBullet:{
	position: 'absolute',
    bottom: -2.5,
    left: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
	borderRadius:50,
	zIndex:1,
  },
 small:{
	 fontSize:11,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
 medium:{
	  fontSize:13,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
 large:{
	  fontSize:15,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
bold:{
	 fontWeight:'bold',
 },
 colorGold:{
	 color:'#d9a352',
 },
 cls:{
	 backgroundColor:'#d9a352',
	 color:'#fff',
	 borderRadius:3,
	 padding:3,
	 marginRight:4,
 },
rightBullet:{
	position: 'absolute',
    bottom: -2.5,
    right: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
	borderRadius:50,
	zIndex:1,
  },
  flightIcon:{
	  alignItems:'center',
	  width:'20%',
	  
  },
  SourceTime:{
	  alignItems:'center',
	  justifyContent:'flex-start',
  },
  DestinationTime:{
	  alignItems:'center',
	  justifyContent:'flex-start',
  },
 borderBottom:{flex:1, width:'100%', borderBottomWidth:1,
	 borderBottomColor:'#5e5e5e',},
priceFilter:{

	flexDirection:'row',
	alignItems:'center',
	paddingHorizontal:10,
	paddingBottom:10,
	paddingTop:5,	
},
  priceValue:{
	  alignItems:'center',
	  width:'20%',
	  alignItems:'flex-end',
	  
  }, 
  colorBlue:{
	  color:'#0a092f'
  },
  
 timelog:{
	  alignItems:'flex-start',
	  width:'100%',
	  flexDirection:'row',
	  justifyContent:'space-between',
	  
  },
  middlePart:{  
	alignItems:'flex-start',
	  width:'60%',
	  flexDirection:'column',
	  justifyContent:'space-between',
	 },
  colorWhite:{
	  color:'#fff',
  },

 timeButton:{
	  width:'20%',
	  padding:10,
	  borderRightColor:'#d9a352',
	  borderRightWidth:1,
	  color:'#fff',
  },
 priceButton:{
	  width:'20%',
	  padding:10,
	  alignItems:'flex-end',
	  color:'#fff',
  },
 durationButton:{
	  width:'60%',
	  padding:10,
	  alignItems:'center',
	  color:'#fff',
 },
 prices:{
	 borderWidth:1,
	 borderColor:'#e4e4dd',
	 padding:4,
	 borderRadius:5,
	 marginRight:10,	
	shadowColor: '#fff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
    elevation:6,
	 
 },
  label:{
	  fontSize:12,
	  textAlign:'left',
	  color:'#fff',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  mealSec:{
	  flexDirection:'row',
	  paddingVertical:5,
  },
});
