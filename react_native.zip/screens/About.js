import React, {Component} from 'react';
import {View, Text, TouchableHighlight} from 'react-native';
import styles from '../assets/style/style';
import { Icon } from 'react-native-elements';

export default class About extends Component{
   
    render(){
        return (
            <View style = {{backgroundColor:'#0A092F', flex: 1}}>
               <View style={{paddingTop:20}}>
                        <View style={{flexDirection:'row'}}>

                            <Text style={{fontSize:20, fontWeight:'700', color:'#D9A352', paddingHorizontal:20}}>
                                About
                            </Text>
                           
                        </View>
                       
                        
                        <View style={{marginTop:10, marginLeft:20}}>
                            <Text style={{color:'#fff'}}>
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry...  
                                
                            </Text>
                            <Text style={{color:'#fff'}}>
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries.
                            </Text>

                        </View>
                        <View style={{flex:1,alignItems:'flex-end'}}>
                            <Icon
                              reverse
                              name='arrow-left'
                              type='font-awesome'
                              color='#FF9901'
                              onPress={() => this.props.navigation.goBack()} />
                        </View>
                    </View>
            </View>        
        );
    }
}

