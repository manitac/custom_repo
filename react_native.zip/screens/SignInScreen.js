import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Button, TextInput, TouchableOpacity, Image, AsyncStorage,ScrollView} from 'react-native';

const ACCESS_TOKEN = 'access_token';

export default class SignInScreen extends Component {
	constructor(props) {
		super(props)
		this.state = {
		    email: "",
		    password: "",
		    errors: [],
		}
	}

	async setProfileValues(profile) {
		try {
			await AsyncStorage.setItem(ACCESS_TOKEN,profile.access_token);
			await AsyncStorage.setItem("user_id",profile.users.user_id);
			await AsyncStorage.setItem("role_id",profile.users.role_id);
			await AsyncStorage.setItem("user_image",profile.users.image_link);
			await AsyncStorage.setItem("user_fname",profile.users.fname);
			await AsyncStorage.setItem("user_lname",profile.users.lname);
			await AsyncStorage.setItem("user_email",profile.users.email);
			await AsyncStorage.setItem("user_mobile",profile.users.mobile);
			await AsyncStorage.setItem("user_address",profile.users.address);
			await AsyncStorage.setItem("user_country",profile.users.country_id);
			await AsyncStorage.setItem("user_state",profile.users.state_id);
			await AsyncStorage.setItem("user_city",profile.users.city_id);
			await AsyncStorage.setItem("user_category",profile.users.role_id);
			await AsyncStorage.setItem("user_countrycode",profile.users.countrycode);
			await AsyncStorage.setItem("user_created",profile.users.created_at);
			
		}
		catch(error) {
			console.log('something went wrong! Please contact to Admin 2');
		}
	}

	async onLoginPressed() {
		try {
			let device_token = await AsyncStorage.getItem('device_token')
			if(device_token == '' || device_token == undefined || device_token == null){
				device_token = 'simulator';
			}
			console.log(device_token);

			let response = await fetch('http://www.igo2.org/api/logIn', {
				method: 'POST',
				headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
				},
				body: JSON.stringify({
					email: this.state.email,
					password: this.state.password,
					device_token: 'device_token',
				})
			});

			let result = await response.text();
			console.log(result);
			let responseArr = JSON.parse(result);
			if(responseArr.status_message == "success") {
				if(responseArr.status_code == 200){
					this.setState({errors: ''});
					this.setProfileValues(responseArr.data);
					this.props.navigation.navigate('Home');
				}
				else {
					throw(responseArr.errors);
				}
			}
			else {
				let errors = responseArr.errors;
				throw errors;
			}

		}  catch(formErrors) {
			let errorsArray = [];
			if(formErrors.length > 0){
				for(let i = 0; i < formErrors.length; i++){
					errorsArray.push(formErrors[i]);
				}
			}
			else {
				errorsArray.push("Error in Sign In! please try again later");
			}
			this.setState({errors: errorsArray});

		}
	}


	async onRegisterPressed() {
		this.props.navigation.navigate('SignUp');		
	}


	_signInAsync = async () => {
	    // await AsyncStorage.setItem('userToken', 'abc');
	    this.props.navigation.navigate('App');
	};

	render() {
		return (
			<ScrollView style={{backgroundColor: '#050517'}}>
	      	<View style={styles.container}>
			     <View style={styles.part1}>
			     	<Image style={styles.logo}
			      	    source={require('../assets/img/logo.png')}
			      	 />
			     </View>
			     <View style={styles.part2}>
				    <Errors errors={this.state.errors} />
		      		<TextInput placeholderTextColor='#ffffff' onChangeText={ (val) => this.setState({email: val})} style={styles.input} placeholder="Enter Your Email" />
		      		<TextInput placeholderTextColor='#ffffff' onChangeText={ (val) => this.setState({password: val})} style={styles.input} placeholder="Enter Your password" secureTextEntry={true} />
		      		<TouchableOpacity style={styles.button} onPress={this.onLoginPressed.bind(this)}>
		      			<Text style={styles.registerText}>Login</Text>
		      		</TouchableOpacity>
		      		
		      	</View>
		      	<View style={styles.part3}>
		      		<TouchableOpacity style={styles.buttonUp} onPress={this.onRegisterPressed.bind(this)}>
		      			<Text style={styles.signRegisterText}>Create an Account</Text>
		      		</TouchableOpacity>
		      	</View>
	      	</View>
	      	</ScrollView>
		)
	}
}

const Errors = (props) => {
	if(props.errors.length > 0){
		return (
			<View>
				{props.errors.map((error,i) => <Text key={i} style={styles.error}>{error}</Text>)}
			</View>
		)
	}
	else {
		return (
			<View>
			</View>
		);
	}
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#050517',
  },
  part1:{
  },
  part2:{
  	marginTop:80,
  	marginBottom:80,
  },
  part3:{

  },
  input: {
    paddingVertical:6,
    paddingHorizontal:12,
    marginVertical: 6,
    width: 300,
    borderWidth:1,
    borderColor: '#cccccc',
    borderRadius: 50,
    color: '#ffffff',
  },
  button: {
  	paddingVertical:12,
    paddingHorizontal:12,
    marginVertical: 6,
    borderWidth:1,
    borderRadius: 50,
    backgroundColor: '#D9A253',
    alignItems: 'center',
    width: 300,
  },
  buttonUp: {
  	paddingVertical:12,
    paddingHorizontal:12,
    marginVertical: 6,
    borderWidth:1,
    borderRadius: 50,
    alignItems: 'center',
    width: 300,
    backgroundColor: '#CFCECD'
  },
  registerText: {
  	fontSize:14,
  	fontWeight:'500',
  	color:'#ffffff',
  },
   signRegisterText: {
	color: '#000000',
	fontWeight: '500',
  	fontSize:14,
  },

  signUpText: {
  	fontSize: 18,
  	fontWeight:'500',
  	color:'#000000',
  	margin: 10,
  },
  error: {
  	width: 300,
  	color: 'red',
  	padding: 1,
  	alignItems: 'center',
  }
});
