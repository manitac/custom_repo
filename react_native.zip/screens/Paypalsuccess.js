import React, {Component} from 'react';
import {Platform, StyleSheet,View, Text, Image, AsyncStorage } from 'react-native';

import Loader from './Loader';

export default class Paypalsuccess extends Component{
    constructor(props) {
        super(props);
        this.state = {
            errors: [],
            loading: true,
        }
    }

    componentDidMount() {
        this.BookTicket()
    }

    async BookTicket(){
        const { params } = this.props.navigation.state;
        let passenger = params.passenger;
        let bookingRow = params.bookingRow;
        let paymentid = params.paymentid;
        let userId = await AsyncStorage.getItem('user_id');
        console.log(passenger,bookingRow,paymentid,userId);
      try {
        let response = await fetch('http://www.igo2.org/api/FlightBookingPaypal', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userInfo: passenger,
            bookingRow: bookingRow,
            userId: userId,
            payment_type: "paypal",
            payment_id: paymentid,
          })
        });

        let result = await response.text();
        let responseArr = JSON.parse(result);
        if(responseArr.status_message == "success") {
          if(responseArr.status_code == 200){
            this.props.navigation.navigate('FlightSuccess',{'data':responseArr.data})
          }
          else {
            throw(responseArr.errors);
          }
        }
        else {
          let errors = responseArr.errors;
          throw errors;
        }

      }  catch(formErrors) {
        let errorsArray = [];
        if(formErrors.length > 0){
          for(let i = 0; i < formErrors.length; i++){
            errorsArray.push(formErrors[i]);
          }
        }
        else {
          errorsArray.push("Error in Booking API! please try again later");
        }
        this.setState({errors: errorsArray});
        let message = errorsArray.join();
        this.props.navigation.navigate('FlightFail',{message:message})
      } 
    }


    render(){
        if(this.state.loading){
            return (
                <View style={styles.container}>
                    <Image
                        source={require('../assets/img/paypallogo.png')}
                        resizeMode='stretch'
                     />
                     <Text style={styles.waitText}>Please wait...</Text>
                </View>        
            );
        }
        else {
            return null;
        }
    }
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor: '#FFF',
        alignItems:'center', 
        justifyContent:'center',
    },
    waitText:{
        fontSize:20,
        color:'#242F60',
        marginTop:10,
    }
})