import React, {Component} from 'react';
import {
Platform, StyleSheet, ActivityIndicator, AsyncStorage, Text, View, Image, ImageBackground,
FlatList,TouchableOpacity,ScrollView,TextInput
} 
from 'react-native';
import {List, ListItem, SearchBar, Slider, Icon } from "react-native-elements";
import Loader from './Loader';
//import RangeSlider from 'react-native-range-slider';

export default class HotelList extends Component {
	constructor(props) {
		super(props);
		var data = [
				    { "name":"CROWNE PLAZA GURGAON", "price":"GBP 100", "details": "SITE NO.2 SECTOR 29, 14.5 km to DELHI INDIRA GANDHI INTL", "rating": "5","image":"https://travelport.leonardocontentcloud.com/imageRepo/3/0/73/604/246/NDEGG_4422096283_J.jpg"},
				    { "name":"THE LODHI", "price":"GBP 200", "details": "SITE NO.2 SECTOR 29, 14.5 km to DELHI INDIRA GANDHI INTL", "rating": "4","image":"https://travelport.leonardocontentcloud.com/imageRepo/2/0/46/834/326/LTDELCCN01_J.jpg"},
				    { "name":"HOLIDAY INN", "price":"GBP 300", "details": "SITE NO.2 SECTOR 29, 14.5 km to DELHI INDIRA GANDHI INTL", "rating": "3","image":"https://travelport.leonardocontentcloud.com/imageRepo/5/0/83/309/833/Porte_Cochere_01_J.jpg"},
				  ]
		this.state = {
		  loading: false,
		  data: data,
		  fullData: data,
		  page: 1,
		  seed: 1,
		  error: '',
		  refreshing: false,
		  filter:'price',
		  pricevalue:10
		}

		// this.makeRemoteRequest();
	}

	handleSearch = (property) => {
		let filter = this.state.filter;
		let fullData = this.state.fullData;
		if(property == 'all')
		{
			this.setState({data:fullData});			
		}
		else {
			if(filter == 'price') {
				let price = property.split("-");
				let priceFrom = parseInt(price[0]);
				let priceTo = parseInt(price[1]);
				const newData = fullData.filter(item => {
					let costPerFlight = parseFloat(item.price.substring(3));
					if(costPerFlight >= priceFrom && costPerFlight < priceTo){
						return item;
					}
				});
				this.setState({data:newData});
			}
			else if(filter == 'hotel') {
				let flightName = property;
				const newData = fullData.filter(item => {
					if(flightName == item.name) {
						return item;
					}
				});
				this.setState({data:newData});
			}
		}
}
	getPriceProperties() {
		return(
			<View style={styles.filterPropertiesContainer}>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
					<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('000-100')}>
					<Text style={[styles.filterOptionsText,styles.small]}>Below 100</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('100-300')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>100 - 300</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('300-500')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>300 - 500</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('500-1000')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>500 - 1000 </Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('1000-100000000000000')}>				
					<Text style={[styles.filterOptionsText,styles.small]}>Above 1000 </Text>
				</TouchableOpacity>
			</View>
		)
	}

	flightNames(index) {
		return(
			<TouchableOpacity style={[styles.filterOptions]} key={index} onPress={() => this.handleSearch(index)}>					
				<Text style={[styles.filterOptionsText,styles.small]}>{index}</Text>
			</TouchableOpacity>
		)
	}
	getHotelProperties() {

		var hotelcompany_unique = [ "THE LODHI", "LEMON TREE", "HYATT PLACE " ];

		let air = hotelcompany_unique;

		let flight = [];
		air.filter(i => {
			flight.push(this.flightNames(i))
		})
		return(
			<View style={styles.filterPropertiesContainer}>
				<TouchableOpacity style={[styles.filterOptions]} onPress={() => this.handleSearch('all')}>
					<Text style={[styles.filterOptionsText,styles.small]}>All</Text>
				</TouchableOpacity>
				{flight}
			</View>
		)
	}

	FilterRow() {
		let filter = this.state.filter;
		let filterProperties = '';
		if(filter == 'price') {
			filterProperties = this.getPriceProperties();
		}
		else if(filter == 'hotel' ) {
			filterProperties = this.getHotelProperties();
		}
		else {
			filterProperties = this.getPriceProperties();
		}
		return(
		   <View style={{flex:1,flexDirection: 'row', backgroundColor: '#d9a352',width:'100%',padding:10}}>
			   <View style={styles.flightTags}>
			   		 
			   			<Text style={{marginLeft:'10'},[styles.medium, styles.mv5, styles.colorWhite]}>Price:{this.state.pricevalue}</Text>
			   </View>
			   <View style={{ flex: 1, alignItems: 'stretch',width:'100%', marginTop:'4%' }}>
				  		<Slider
					    value={this.state.pricevalue}
					      step='1'
					    minimumValue='0'
					    maximumValue='1000'
					    onValueChange={value => this.setState({ pricevalue : value })}
					  />
			   			
				  
				</View>
			    
	
			</View>
		)
	}

	SortRow() {

		let filter = this.state.filter;
		
		return(
		   <View style={{flex:1,width:'100%',magrin:'10%'}}>
			   <View style={styles.SortRow}>
			  			<Text style={[styles.foundText]}>Sort By</Text>
			   		  <TouchableOpacity style={[styles.sort]} onPress={ () => this.setState({filter:'recommended'})}>
			   			<Text style={[styles.small, styles.colorWhite]}>Recommended</Text>
			   		 </TouchableOpacity>
			   		  <TouchableOpacity style={[styles.sort]} onPress={ () => this.setState({filter:'price'})}>
			   		 	
			   		 	<Text style={[styles.small, styles.colorWhite]}>Price</Text>
			   		  </TouchableOpacity>
			   		    <TouchableOpacity style={[styles.sort]} onPress={ () => this.setState({filter:'rating'})}>
			   		 	
			   		 	<Text style={[styles.small,styles.colorWhite]}>Guest Rating</Text>
			   		  </TouchableOpacity>


			  </View>
			  	<View style={[styles.searchHotelrow]}>
			   		<Text style={[styles.medium, styles.mv5, styles.colorWhite]}>Serach Hotel</Text>
			   		<TextInput style={styles.searchHotel} placeholderTextColor='#FFFFFF'  placeholder="Enter name here.." />
				</View>
			</View>
		)
	}
	
HotelView(item,index) {

	let rating = item.rating;
	let ratingStars = [];
	for(let i = 1; i <= 5; i++){

		if(i <= rating){
		ratingStars.push(
		         <Icon
	              name='star'
	               size={10} 
	              type='font-awesome'
	              color='#d9a352'
	              containerStyle={styles.icon}
	            />
	     )
		}else{
			 ratingStars.push(
	         <Icon
              name='star'
               size={10} 
              type='font-awesome'
              color='#FFFFFF'
              containerStyle={styles.icon}
            />
	     	)
		}
	   
	 }

		return (
			<TouchableOpacity>
				<View style={styles.repeatRow} >
					<View style={styles.flightIcon}>
							<Image
							style={{width: 40, height: 40}}
							source={{uri: item.image}}
							/>
							<View style={{flex: 1, flexDirection: 'row'}}>{ratingStars}</View>
					</View>

					<View style={styles.middleDetails}>
							<Text style={[styles.itemName]}>{item.name}</Text>	
						<Text style={[ styles.itemDetails, styles.colorWhite]}>{item.details}</Text>			
							
					</View>
					<View>
						<Text style={{textAlign:'left'},[ styles.small,styles.colorGold]}>For 1 night</Text>
						<Text style={[ styles.small,styles.colorGold]}> {item.price}</Text>
						<TouchableOpacity style={[styles.hotelbtn]} >
			   				<Text style={[styles.small, styles.colorWhite]}>Choose Hotel</Text>
			   		 	</TouchableOpacity>
					</View>
				</View>
			</TouchableOpacity>
		)
	}

	render() {

		let data = this.state.data;
		let hotelRows = [];
		for(let i = 0; i < data.length; i++){
		    hotelRows.push(
		         this.HotelView(data[i],i)
		     )
		 }
		 let topFilter = this.FilterRow();
		 let sortFilter = this.SortRow();
		return (

			<ScrollView style={styles.scrollContainer}>
	            <View style={styles.container}>
	            	{ topFilter }
	            { sortFilter }
					  
	            	<Text style={styles.foundText}>Showing {this.state.data.length} of {this.state.fullData.length} Hotels</Text>
	            	{ hotelRows }
	            		
	            </View>
			</ScrollView>
		)
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'flex-start',
    backgroundColor: '#0a092f',
	fontFamily:'Arial',
  },
  scrollContainer:{
  	flex: 1,
  	backgroundColor: '#0a092f',
  },
  foundText:{
  	color:'#FFF',
  	padding:6,
  },
  filterOptions:{
	flexDirection: 'row',
	borderRadius:2,
	margin:6,
	paddingHorizontal:10,
	paddingVertical:4,
	borderWidth:1,
	borderColor:'#0a092f',
	backgroundColor:'#0a092f',
  },
  filterPropertiesContainer:{
	flexDirection: 'row',
	},
  filterOptionsText:{
	fontSize:12,
	color:'#FFF',
  },
notificationLabel:{	
	 padding:10,
  },
  flightFilter:{
     flexDirection: 'row',
     alignItems: 'center',
	 justifyContent:'center',
	backgroundColor: '#d9a352',	   
  },
  flightTags:{
	 flex:1,
	 flexDirection: 'row',
     alignItems: 'center',
	 justifyContent:'space-between',
	 paddingBottom:0,
	 paddingTop:10,
  },
  width25:{
	  alignItems:'center',
	  width:'50%',
	  justifyContent:'center'
  },
  repeatRow:{
	 paddingHorizontal:10,
	 paddingVertical:15,
	//borderBottomWidth: 1,
    //borderBottomColor: "#5e5e5e",
	 flexDirection: 'row',
	   alignItems: 'center',
	 justifyContent:'center',

  },
  seperator:{
	  borderBottomWidth: 1,
	  width:'100%',
    borderBottomColor: "#ddd",
	 flexDirection: 'row',
	   alignItems: 'center',
	 justifyContent:'center',
	 position:'relative',
	 paddingRight:5,
  },

 mv3:{
	 marginVertical:3,
 },
mv5:{
	 marginVertical:5,
 },
leftBullet:{
	position: 'absolute',
    bottom: -2.5,
    left: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
	borderRadius:50,
	zIndex:1,
  },
 small:{
	 fontSize:11,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
 medium:{
	  fontSize:13,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
 large:{
	  fontSize:15,
	 textAlign:'center',
	 fontFamily:'Arial',
 },
bold:{
	 fontWeight:'bold',
 },
 colorGold:{
	 color:'#d9a352',
 },
 cls:{
	 backgroundColor:'#d9a352',
	 color:'#fff',
	 borderRadius:3,
	 padding:3,
	 marginRight:4,
 },
rightBullet:{
	position: 'absolute',
    bottom: -2.5,
    right: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
	borderRadius:50,
	zIndex:1,
  },
  flightIcon:{
	  alignItems:'center',
	  width:'20%',
	  
  },
  SourceTime:{
	  alignItems:'center',
	  justifyContent:'flex-start',
  },
  DestinationTime:{
	  alignItems:'center',
	  justifyContent:'flex-start',
  },
 borderBottom:{flex:1, width:'100%', borderBottomWidth:1,
	 borderBottomColor:'#5e5e5e',},
priceFilter:{

	flexDirection:'row',
	alignItems:'center',
	paddingHorizontal:10,
	paddingBottom:10,
	paddingTop:5,	
},
  priceValue:{
	  alignItems:'center',
	  width:'20%',
	  alignItems:'flex-end',
	  
  }, 
  colorBlue:{
	  color:'#0a092f'
  },
  
 timelog:{
	  alignItems:'flex-start',
	  width:'100%',
	  flexDirection:'row',
	  justifyContent:'space-between',
	  
  },
  middlePart:{  
	alignItems:'flex-start',
	  width:'60%',
	  flexDirection:'column',
	  justifyContent:'space-between',
	 },
  colorWhite:{
	  color:'#fff',
  },

 timeButton:{
	  width:'20%',
	  padding:10,
	  borderRightColor:'#d9a352',
	  borderRightWidth:1,
	  color:'#fff',
  },
 priceButton:{
	  width:'20%',
	  padding:10,
	  alignItems:'flex-end',
	  color:'#fff',
  },
 durationButton:{
	  width:'60%',
	  padding:10,
	  alignItems:'center',
	  color:'#fff',
 },
 prices:{
	 borderWidth:1,
	 borderColor:'#e4e4dd',
	 padding:4,
	 borderRadius:5,
	 marginRight:10,	
	shadowColor: '#fff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.8,
    shadowRadius: 5,
    elevation:6,
	 
 },
  label:{
	  fontSize:12,
	  textAlign:'left',
	  color:'#fff',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
  mealSec:{
	  flexDirection:'row',
	  paddingVertical:5,
  },
sort:{
		backgroundColor: '#d9a352',
		paddingVertical:5,
		paddingHorizontal:10,
		margin:10
},
SortRow:{
	width:'100%',
    paddingBottom:10,
    paddingRight:5,
    margin:10,
    flex:1,
	 flexDirection: 'row',
     alignItems: 'center',
	 justifyContent:'center',

},
hotelbtn:{
		backgroundColor: '#d9a352',
		paddingVertical:5,
		paddingHorizontal:5,
		marginTop:5,
		borderRadius:5,
		
},
icon: { 
        position: 'relative',
        top: 5,
        right:0,
        margin:2
},
itemDetails: {
	fontSize:11,
	textAlign:'left',
	fontFamily:'Arial',
 },
 itemName: {
 	fontSize:16,
 	color: '#d9a352',
 	position:'relative',
 	top:-10
 },
 middleDetails:{  
    width:'60%',
    alignItems:'center',
	justifyContent:'center',
	marginLeft:10

},
searchHotel:{
	borderWidth:1,
	 borderColor:'#e4e4dd',
	 textAlign:'center',
	 width:'50%',
	 marginLeft:'5%',
	 color:'#FFFFFF',
	 fontSize:12,
	 paddingVertical:2,
	 marginBottom:15,
},
searchHotelrow:{
	width:'100%',
    flex:1,
	 flexDirection: 'row',
    // alignItems: 'center',
	 justifyContent:'center',
	borderWidth:1,
	 borderBottomColor:'#e4e4dd',
	 //paddingLeft:30,
}

});
