import React, { Component } from 'react';
import { AppRegistry, Platform, StyleSheet, Text, View, Image, Picker, TextInput, TouchableHighlight, TouchableOpacity, ScrollView } from 'react-native';
import DatePicker from 'react-native-datepicker';
import Autocomplete from "react-native-autocomplete-input";
import Loader from './Loader';
import css from '../assets/style/style';
import hotelcss from '../assets/style/Hotels';
import { Icon } from 'react-native-elements';
import PickerSelect from "react-native-picker-select";


export default class HotelSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            CheckIn: new Date(),
            checkOut: new Date(),
            rooms: '1',
            adults: '1',
            data: [],
            data2: [],
            location: 'Location',
            // selectedTo:'DES',
            errors: [],
            loading: false,
        }
    }


    GetFormattedDate(todayTime) {
        var day = todayTime.getDate();
        let month = todayTime.getMonth() + 1; //Months are zero based
        var year = todayTime.getFullYear();
        if (month <= 9) {
            month = '0' + month;
        }
        if (day <= 9) {
            day = '0' + day;
        }
        return year + "-" + month + "-" + day;
    }

    SearchHotel = async () => {

        let checkIn = this.GetFormattedDate(new Date(this.state.checkIn));
        let checkOut = this.GetFormattedDate(new Date(this.state.checkOut));

        let adults = this.state.adults;
        let location = this.sate.location;

        try {
            this.setState({ loading: true });
            let response = await fetch('http://www.igo2.org/api/HotelList', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    location: location,
                    checkIn: checkIn,
                    checkOut: checkOut,
                    adults: adults,
                })
            });

            let result = await response.text();
            console.log(result);
            this.setState({ loading: false });
            let responseArr = JSON.parse(result);
            if (responseArr.status_message == "success") {
                if (responseArr.status_code == 200) {
                    this.setState({ errors: '' });
                    let searchList = { from: this.state.from, to: this.state.to, departing: this.state.departing, returning: this.state.returning, person: this.state.person };
                    this.props.navigation.navigate('FlightList', { details: responseArr.data, searchList: searchList, flightcompany_unique: responseArr.flightcompany_unique });
                } else {
                    throw (responseArr.errors);
                }
            } else if (responseArr.status_message == "failure") {
                let errors = responseArr.errors;
                throw errors;
            } else {
                let errorsArr = [];
                errorsArr.push("No Hotel Found");
                throw errorsArr;
            }

        } catch (formErrors) {
            this.setState({ loading: false });
            let errorsArray = [];
            if (formErrors.length > 0) {
                for (let i = 0; i < formErrors.length; i++) {
                    errorsArray.push(formErrors[i]);
                }
            } else {
                errorsArray.push("Error in Search API! please try again later");
            }
            this.setState({ errors: errorsArray });
        }
        // const arr = {"from" : from, "to" : to, "departing": departing, "returning": returning, "person": person};
    }

    async getData(text, stateValue) {
        try {
            let response = await fetch('http://www.igo2.org/api/HotelList', {
                method: 'POST',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    search_word: text
                })
            });

            let result = await response.text();
            let responseArr = JSON.parse(result);
            if (responseArr.status_message == "success") {
                if (responseArr.status_code == 200) {
                    if (stateValue == 'from') {
                        this.setState({ data: responseArr.data });
                    } else {
                        this.setState({ data2: responseArr.data });
                    }
                } else {
                    throw (responseArr.errors);
                }
            } else if (responseArr.status_message == "failure") {

            }

        } catch (formErrors) {
            let errorsArray = [];
            if (formErrors.length > 0) {
                for (let i = 0; i < formErrors.length; i++) {
                    errorsArray.push(formErrors[i]);
                }
            } else {
                errorsArray.push("Error in Search API! please try again later");
            }
            this.setState({ errors: errorsArray });
        }
    }



    handleAutoComplete = (text, stateValue) => {
        if (text.length >= 3) {
            this.getData(text, stateValue);
        }

        if (stateValue == 'from') {
            this.setState({ from: text })
        } else {
            this.setState({ to: text })
        }
    }


    handleAutoCompleteSelection = (airport_code, airport_name, stateValue) => {
        if (stateValue == 'from') {
            this.setState({ from: airport_code, fromText: airport_name, selectedFrom: airport_code })
        } else {
            this.setState({ to: airport_code, toText: airport_name, selectedTo: airport_code })
        }
        this.setState({ data: [], data2: [] })
    }
    Items = () => {
        let arr = [];
        for (i = 1; i <= 10; i++) {
            let obj = {};
            obj['label'] = String(i);
            obj['value'] = String(i);
            arr.push(obj);
        }
        return arr
    }

    updateState(key, val) {
        this.setState({
            [key]: val })
    }

    render() {
        const { from, to } = this.state;
        const data = this.state.data;
        const data2 = this.state.data2;
        let Items = this.Items();
        if (!this.state.loading) {

            return (
                    <ScrollView style={css.scrollContainer}>
                        <View style={css.SearchPageContainer}>
                          <Errors errors={this.state.errors} />
                          <View style={[css.textBoxContainer,styles.atf1]}>
                            <View style={[css.srcView,hotelcss.txtView]}><Text style={css.srcText}>{this.state.location}</Text></View>
                            <View style={[styles.atf1]}>
                                <Autocomplete
                                    autoCapitalize="none"
                                    autoCorrect={false}
                                    style={css.autocomplete}
                                    data={data}
                                    inputContainerStyle={css.autoCompleteContainerStyle}
                                    listStyle={css.listStyle}
                                    listContainerStyle={css.listContainerStyle}
                                    defaultValue={this.state.fromText}
                                    onChangeText={(text) => this.handleAutoComplete(text,'loc')}
                                    placeholder="Enter Location"
                                    placeholderTextColor='#ffffff'
                                    renderItem={({ airport_name, airport_code }) => (
                                      <View style={styles.autocompleteList}>
                                          <TouchableOpacity onPress={() => this.handleAutoCompleteSelection(airport_code,airport_name,'from')}>
                                            <Text style={styles.itemText}>
                                              {airport_name} ({airport_code})
                                            </Text>
                                          </TouchableOpacity>
                                      </View>
                                    )}
                                    
                                  />
                            </View>
                            <View style={css.IconView}>
                                  <Image
                                      style={{width: 30, height:35}}
                                      source={require('../assets/img/h-icon.png')}
                                    /> 
                            </View>
                          </View>

                          <View style={hotelcss.rooms}>
                              <View style={hotelcss.textBoxContainer}>
                                  <View style={[css.srcView,hotelcss.txtView1]}><Text style={css.srcText}>No. of Rooms</Text></View>
                                  <View >
                                      <PickerSelect
                                        value={this.state.rooms}
                                        hideIcon={true}
                                        items={Items}
                                        onValueChange={val => this.updateState('rooms',val)}
                                        style={{...pickerSelectStyles}}
                                       useNativeAndroidPickerStyle={false}
                                       placeholder={{
                                           label: 'Select',
                                           value: 1,
                                       }}
                                      /><Icon
                                          name='hotel'
                                          type='font-awesome'
                                          color='#FFFFFF'
                                          containerStyle={hotelcss.icon}
                                        />
                                      
                                  </View>
                              </View>
                              <View style={hotelcss.textBoxContainer}>
                                <View style={[css.srcView,hotelcss.txtView1]}><Text style={css.srcText}>No. of Adults</Text></View>
                                <View>
                                  <PickerSelect
                                    value={this.state.adults}
                                    hideIcon={true}
                                    items={Items}
                                    onValueChange={val => this.updateState('adults',val)}
                                    style={{...pickerSelectStyles}}
                                   useNativeAndroidPickerStyle={false}
                                   placeholder={{
                                       label: 'Select',
                                       value: 1,
                                   }}
                                  /><Icon
                                      name='user'
                                      type='font-awesome'
                                      color='#FFFFFF'
                                      containerStyle={hotelcss.icon}
                                    />
                                </View>
                              </View>
                          </View>

                          <View style={hotelcss.chkinout}>
                            <View style={[css.partitionContainer,css.alignRow,hotelcss.chkinContainer]}>
                              <View style={hotelcss.dateBorder}>
                                <View style={css.datepickerDiv}><Text style={css.passengerText2}>Check In</Text>
                                    <DatePicker
                                        style={css.datepicker}
                                        date={this.state.checkIn}
                                        mode="date"
                                        placeholder="select"
                                        format="dddd, MMM D YYYY"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        showIcon={false}
                                        customStyles={{
                                          dateIcon: {
                                           
                                          },
                                          dateInput: {
                                              borderWidth:0,
                                              margin:5,
                                          },
                                            dateText: {
                                              color: "#FFFFFF",
                                              textAlign:'center',
                                            }
                                        }}
                                        onDateChange={(date) => {this.setState({checkIn: date})}}
                                      />
                                </View>
                              </View>
                            </View>
                            <View style={hotelcss.chkoutContainer}>
                                <View style={hotelcss.dateBorder}>
                                  <View style={css.datepickerDiv}>
                                    <Text style={css.passengerText2}>Check Out</Text>
                                    <DatePicker
                                          style={css.datepicker}
                                          date={this.state.checkOut}
                                          mode="date"
                                          placeholder="select"
                                          format="dddd, MMM D YYYY"
                                          confirmBtnText="Confirm"
                                          cancelBtnText="Cancel"
                                          showIcon={false}
                                          customStyles={{
                                            dateIcon: {
                                             
                                            },
                                            dateInput: {
                                                borderWidth:0,
                                                margin:5,
                                            },
                                              dateText: {
                                                color: "#FFFFFF",
                                                textAlign:'center',
                                              }
                                          }}
                                          onDateChange={(date) => {this.setState({checkOut: date})}}
                                        />
                                  </View>
                                </View>
                            </View>
                          </View>
                      </View>
                      <View style={styles.rows}>
                        <TouchableHighlight style={css.button} onPress={this.SearchHotel.bind(this)}>
                          <Text style={styles.searchText}>Search Now</Text>
                        </TouchableHighlight>
                      </View>
                  </ScrollView>
            )
        } else {
            return (
                <Loader />
            )
        }
    }
}

const Errors = (props) => {
    if (props.errors.length > 0) {
        return (
            <View style={styles.errorContainer}>
                {props.errors.map((error,i) => <Text key={i} style={styles.error}>{error}</Text>)}
            </View>
        )
    } else {
        return null
    }
}

const styles = StyleSheet.create({
  error:{
    color:'#FFFFFF',
    fontWeight:'bold',
  },
  errorContainer:{
    padding:10,
    backgroundColor: 'red',
    width:'100%',
  },
  searchText:{
    fontSize:14,
    fontWeight:'500',
    color:'#ffffff',
  },

  rows:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  autocompleteList:{
    position: 'relative',
    borderBottomWidth:1,
    borderBottomColor: '#ccc',
    paddingVertical:5,
  },
  atf1:{
    zIndex: 3,
  },
  atf2:{
    zIndex:2,
  }
})

const pickerSelectStyles = StyleSheet.create({
    inputIOS: {
        paddingVertical:10,
        paddingHorizontal:10,
        borderBottomColor: '#cccccc',
        borderRadius: 2,
        color: '#ffffff',
        fontSize:14,
    },
    inputAndroid: {
        paddingVertical:10,
        paddingHorizontal:30,
        borderBottomColor: '#cccccc',
        borderRadius: 2,
        color: '#ffffff',
        fontSize:14,
    },
});