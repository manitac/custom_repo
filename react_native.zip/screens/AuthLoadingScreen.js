import React, {Component} from 'react';
import {Platform, StyleSheet, ActivityIndicator, AsyncStorage, Text, View, StatusBar} from 'react-native';
import PushNotification from 'react-native-push-notification';

const ACCESS_TOKEN = 'access_token';

import Loader from './Loader';

export default class AuthLoadingScreen extends Component {
	constructor(props) {
		super(props);
		this._bootstrapAsync();
	}

	componentDidMount() {
    	// this.InitializeNotification();
	}

	InitializeNotification() {
      	PushNotification.configure({
          onRegister: function(token) {
              let device_token = token.token;
              let os = token.os;
              AsyncStorage.setItem("device_token",device_token);
              AsyncStorage.setItem("os",os);                
          },
          onNotification: function(notification) {
              console.log("Notification: ",notification);
              notification.finish(PushNotificationIOS.FetchResult.NoData);
          },
          senderID: "361577241980",
          permissions: {
                  alert: true,
                  badge: true,
                  sound: true
              },
         popInitialNotification: true,
         requestPermissions: true,
	    })
	}

	_bootstrapAsync = async () => {
	    const userToken = await AsyncStorage.getItem(ACCESS_TOKEN);
	    // This will switch to the App screen or Auth screen and this loading
	    // screen will be unmounted and thrown away.
	    this.props.navigation.navigate(userToken ? 'App' : 'Auth');
	};



	render() {
		return (
			<Loader />
		)
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  wait: {
  	fontSize: 20,
  	color: '#FFFFFF',

  }
})