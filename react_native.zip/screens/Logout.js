import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, AsyncStorage} from 'react-native';

const ACCESS_TOKEN = 'access_token';

export default class Logout extends Component {
	constructor(props) {
		super(props);
		this._signOutAsync();
	}

	async _signOutAsync() {
		// let device_token = await AsyncStorage.getItem("device_token");
		let device_token = "device_token";
	   	await AsyncStorage.clear();
	   	AsyncStorage.setItem('device_token',device_token);
	   	this.props.navigation.navigate('Auth');
	 }

	render() {
		return (
	      	<View style={styles.container}>
	      		<Text>Logout</Text>
	      	</View>
		)
	}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  }
})