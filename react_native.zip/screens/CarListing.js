import React, { Component } from 'react';
import { AppRegistry, Platform, StyleSheet, Text, View, Image, Picker, TextInput, TouchableHighlight, TouchableOpacity, ScrollView } from 'react-native';
import { Icon, Avatar  } from 'react-native-elements';
import Loader from './Loader';
import css from '../assets/style/style';
//import styles from '../assets/style/Cars';


export default class CarListing extends Component {
    constructor(props) {
        super(props);
        var data = [
            { "name":"Van", "price":"100.00", "details": "AC | Automatic | Unlimitedmilage","image":"https://cdn.travelport.com/cmavis/ZI_general_large_8580.jpg"},
            { "name":"Wagonar", "price":"90.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
            { "name":"INN", "price":"30.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
            { "name":"Car", "price":"30.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
            { "name":"Van", "price":"100.00", "details": "AC | Automatic | Unlimitedmilage","image":"https://cdn.travelport.com/cmavis/ZI_general_large_8580.jpg"},
            { "name":"SUV", "price":"90.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
            { "name":"INN", "price":"30.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
            { "name":"Car", "price":"30.00", "details": "AC | Automatic | Unlimitedmilage", "image":"https://cdn.travelport.com/cmavis/ZI_general_large_42872.jpg"},
          ]
        this.state = {
            loading: false,
            data:data
        }
       
    }

  RecommendedRow() {
        return(
            <View style={styles.recommendedinner}>  
                  <View style={[styles.recommendedinnerRow]}>
                    <Icon
                        name='check-circle'
                        type='font-awesome'
                        color='#FFF'
                      /> 
                      
                    <Text style={styles.recommendedinnerRowTxt}>Recommended Cars for you</Text>
                  </View>
                  <View style={[styles.recommendedinnerRow]}>
                      <Icon
                        name='car'
                        type='font-awesome'
                        color='#FFF'
                      />
                      <Text style={styles.recommendedinnerRowTxt}>Breakdown Assistance</Text>
                  </View>                                  
                  <View style={[styles.recommendedinnerRow]}>
                     
                      <Icon
                        name='user'
                        type='font-awesome'
                        color='#FFF'
                      />
                      <Text style={styles.recommendedinnerRowTxt}>24X7 Cutomer Care</Text>
                  </View>  
                  <View style={[styles.recommendedinnerRow]}>
                     <Icon
                        name='tag'
                        type='font-awesome'
                        color='#FFF'
                      /> 
                      <Text style={styles.recommendedinnerRowTxt}>Great Price</Text>
                  </View>  
           </View>  
        )
  }


CarView(item,index) {

      return (
        
          <View style={styles.carsViewInner}>
                    <View style={{alignItems:'center'}}>
                        <Text style={styles.carsViewInnerTextTitle}>{item.name}</Text>
                        <Image
                            style={styles.carsViewImg}
                            source={{uri: item.image}}
                            />

                        <Text style={styles.carsViewInnerText}>{item.details}</Text>
                        <Text style={styles.carsViewInnerPrice}>GBP {item.price}</Text> 
                    </View>
                    
                      <View style={styles.carsViewInnerlower}>
                              <Text style={styles.selectCabLftTxt}>Terminal</Text>
                              <TouchableHighlight style={styles.selectCab}>
                                <Text style={styles.selectCabTxt}>Select Cab</Text>
                              </TouchableHighlight>
                      </View>
              </View>
      )
  }


    render() {

        if (!this.state.loading) {
          
          let data = this.state.data;
          let CarRows = [];
          for(let i = 0; i < data.length; i++){
              CarRows.push(
                   this.CarView(data[i],i)
               )
           }
           let recommendedRow = this.RecommendedRow();

            return (
                    <ScrollView style={css.scrollContainer}>
                        <View style={styles.recommended}>
                              <Icon
                                name='car'
                                type='font-awesome'
                                color='#FFFFFF'
                                containerStyle={styles.iconlft}
                              />
                              <Text style={styles.recommendedTxt}>Recommended Cars for you</Text>
                        </View>
                        {recommendedRow}
                        <View style={styles.carsView}>
                              { CarRows }
                        </View>
                    </ScrollView>
            )
        } else {
            return (
                <Loader />
            )
        }
    }
}


const styles = StyleSheet.create({
   CarListingPageContainer: {
        marginTop:20
    },
    recommended: {
        display:'flex',
        flexDirection: 'row',
        marginTop:20,
        marginHorizontal:10
    },
  
    recommendedinner: {
        width:'100%',
        marginVertical:20,
        paddingLeft:20,
        borderColor:'#FFFFFF',
        borderWidth:1,
        backgroundColor:'#D9A253',
        display:'flex',
        flexDirection: 'row',
         justifyContent:'space-between',
        flexWrap:'wrap',
        alignItems:'center'
    },
    recommendedTxt: {
        color:'#FFFFFF',
        marginLeft:40,
        fontSize:20,
    },
    recommendedinnerRow: {
        marginVertical:5,
         width:'48%',
         display:'flex',
         alignItems:'center',
         flexDirection:'row',
         flexWrap:'wrap'
    },
    recommendedinnerRowTxt: {
        color:'#FFFFFF',
        marginLeft:10,
        fontSize:15,
        width:'72%'

    },
    carsView: {
        marginLeft:10,
        marginRight:10,
        marginBottom:20,
         display:'flex',
        flexDirection: 'row',
        flexWrap:'wrap',
        justifyContent:'space-between'
    },
    carsViewImg: {
        width:100,
        height:80,
        resizeMode: 'contain',
        
    },
    carsViewInner: {
        backgroundColor:'#FFFFFF',
        borderRadius:10,
        borderBottomWidth:2,
        marginVertical:10,
        marginRight:1,
        width:'49%'
 
    },
    carsViewInnerlower: {
        display:'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor:'#CCC',
        padding:10,
        borderBottomLeftRadius:10,
        borderBottomRightRadius:10,
    },
    selectCab: {
        backgroundColor:'#D9A253',
        paddingHorizontal:10, 
        paddingVertical:5,
    },
    selectCabLftTxt: {
        fontSize:14,
        fontWeight:'bold',
        marginVertical:5,
        marginLeft:0,
        color:'#000',

    },
    selectCabTxt: {
        fontSize:16,
        color:'#FFF',
    },
    carsViewInnerTextTitle: {
        fontSize:20,
        marginTop:10,
        color:'#050517',
        fontWeight:'bold',
        
    },
    carsViewInnerText: {
        fontSize:16,
        color:'#050517',
        textAlign:'center',
        marginBottom:5
        
    },
    carsViewInnerPrice:{
        fontSize:18,
        fontWeight:'bold',
        color:'#050517',
        textAlign:'center',
        marginBottom:10
    }

})
