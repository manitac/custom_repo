import React, {Component} from 'react';
import {StyleSheet,
        View, 
        Text, 
        Image, 
        Dimensions,
        ScrollView,
        Linking,
        TouchableOpacity
    } from 'react-native';
//import { Directions } from 'react-native-gesture-handler';

import { Icon, SocialIcon } from 'react-native-elements';


import HomeCategory from '../components/HomeCategory';

var { height } = Dimensions.get('window');
var box_count = 3;
var box_height = height / box_count;

export default class HomeScreen extends Component {
    
    render() {
        return (
            <ScrollView style={{backgroundColor:'#050517'}} scrollEventThrottle={16}>
            <View style={styles.container}>
                <View style={styles.box}>
                    <View style={styles.bIcon}> 
                        <Icon
                          reverse
                          name='flight'
                          type='g-translate'
                          color='#D9A253'
                          onPress={() => this.props.navigation.navigate('FlightSearching')} />
                        <Text>Flight</Text>
                    </View>

                    <View style={styles.bIcon}>
                        <Icon
                          reverse
                          name='hotel'
                          type='g-translate'
                          color='#D9A253'
                          onPress={() => this.props.navigation.navigate('Home')} />
                        <Text>Hotel</Text>
                    </View>

                    <View style={styles.bIcon}>
                        <Icon
                          reverse
                          name='car'
                          type='font-awesome'
                          color='#D9A253'
                          onPress={() => this.props.navigation.navigate('Home')} />
                        <Text>Car</Text>
                    </View>

                    <View style={styles.bIcon}>
                        <Icon
                          reverse
                          name='train'
                          type='font-awesome'
                          color='#D9A253'
                          onPress={() => this.props.navigation.navigate('Home')} />
                        <Text>Rail</Text>
                    </View>                
                  
                </View>                
                    <View style={{flex:1, paddingTop:20}}>
                        <Text style={{fontSize:20, fontWeight:'700', color: '#D9A352',}}>
                            Rooms Available
                        </Text>
                        <View style={{height:130, marginTop:20}}>
                            <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
                                <HomeCategory imageUri={require('../assets/img/hotel2.jpg')} catName={'Family room'}/>
                                <HomeCategory imageUri={require('../assets/img/hotel3.jpg')} catName={'Double room'}/>
                                <HomeCategory imageUri={require('../assets/img/hotel4.jpg')} catName={'Apartment'}/>
                                <HomeCategory imageUri={require('../assets/img/hotel5.jpg')} catName={'Luxry room'}/>
                            </ScrollView>
                        </View>
                    </View>
                    <View style={{flex:1, marginTop:20}}>
                        <View style={{paddingTop:0}}>
                            <View style={{flexDirection:'row'}}>
                                <Text style={{fontSize:20, fontWeight:'700', color:'#D9A352', paddingBottom:20}}>
                                    About
                                </Text>
                                <Text style={{ fontSize:13, fontWeight:'bold', color:'#D9A352', position:'absolute', right:0}} onPress={()=>this.props.navigation.navigate('About')}>
                                        see all >
                                </Text>
                            </View>
                           
                            
                            <View>
                                <Text style={{color:'#fff'}} >
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum is simply dummy text of the printing and typesetting industry...  
                                    
                                </Text>

                            </View>

                        </View>
                    </View>
                    <View style={styles.box2}>
                       <Text style={styles.socialTitleText}>Social</Text>
                       <ScrollView horizontal={true}>
                        <View style={styles.box2Inner}>
                        
                            <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.facebook.com/igotwo.igotwo.3/')}>
                            <SocialIcon type='facebook'
                                        iconTag='facebook-square'

                             />
                                <Text>Facebook</Text>
                            </TouchableOpacity> 
        
                            <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.twitter.com/')}>
                            <SocialIcon type='twitter'
                                        name='facebook-square'

                             />
                                <Text>Twitter</Text>
                            </TouchableOpacity>

                            <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.instagram.com/igo2bt/')}>
                            <SocialIcon type='instagram'
                                        name='facebook-square'

                             />
                                <Text>Instagram</Text>
                            </TouchableOpacity>
                            
                            <TouchableOpacity style={styles.socialIcon} onPress={()=> Linking.openURL('https://www.youtube.com/channel/UC--pv_ZlF2v0C4XKyk_YZNA?view_as=subscriber')}>
                            <SocialIcon type='youtube'
                                        name='facebook-square'

                             />
                                <Text>YouTube</Text>
                            </TouchableOpacity>
                        </View>
                       </ScrollView>
                    </View>
            </View>
            </ScrollView>
        );
      }
}

const styles = StyleSheet.create({
    container: {
      backgroundColor: '#050517',
      paddingHorizontal:6,
    },
    box: {
      height: box_height,
      flexDirection: 'row',
      height: 100,
      backgroundColor: '#FBFBFB',
      marginTop: 30,
      justifyContent:'space-between',
      borderRadius: 5,
      shadowColor: '#04000C',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.8,
      shadowRadius: 5,
      elevation:3
    },
    box2: {
        backgroundColor: '#FBFBFB',
        marginTop: 50,
        marginBottom: 20,
        borderRadius: 5,
        shadowColor: '#04000C',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.8,
        shadowRadius: 5,
        elevation:3,
      },
      box2Inner:{
        justifyContent:'space-between',
        flexDirection: 'row',

      },
    bIcon:{
        padding: 10,
        alignItems: 'center'
    },
    
    socialIcon:{
        padding: 10,
        alignItems: 'center'
    },
    socialTitleText: {
        fontSize: 20,
        fontWeight: 'bold',
        padding:8
      }
  });
