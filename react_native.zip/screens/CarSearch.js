import React, { Component } from 'react';
import { AppRegistry, Platform, StyleSheet, Text, View, Image, Picker, TextInput, TouchableHighlight, TouchableOpacity, ScrollView } from 'react-native';
import DatePicker from 'react-native-datepicker';
import Autocomplete from "react-native-autocomplete-input";
import Loader from './Loader';
import css from '../assets/style/style';
import carcss from '../assets/style/Cars';
import { Icon, CheckBox  } from 'react-native-elements';
import PickerSelect from "react-native-picker-select";


export default class CarSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showDroploc: false,
            Pickuploc:'',
            PickupDate: new Date(),
            PickupTime:'00:00:00',
            Dropoffloc:'',
            DropoffDate: new Date(),
            DropoffTime:'00:00:00',
            CheckIn: new Date(),
            data: [],
            data2: [],
            loading: false,
            errors: [],
        }
    }
  
  handleTimePicked = (date,type) => {
     if(type == 'pickup'){
        this.setState({PickupTime: date});
     }else if(type == 'drop'){
        this.setState({DropoffTime: date});
     }
  };



  async getData(text,stateValue) {
        try {
          let response = await fetch('http://www.igo2.org/api/AirportList', {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              search_word: text
            })
          });

          let result = await response.text();
          let responseArr = JSON.parse(result);
          if(responseArr.status_message == "success") {
            if(responseArr.status_code == 200){
                if(stateValue == 'Pickuploc'){
                    this.setState({data:responseArr.data});
                }else if(stateValue == 'Dropoffloc'){
                    this.setState({data2:responseArr.data});
                }
            }
            else {
              throw(responseArr.errors);
            }
          }
          else if(responseArr.status_message == "failure"){
            
          }

        }  catch(formErrors) {
          let errorsArray = [];
          if(formErrors.length > 0){
            for(let i = 0; i < formErrors.length; i++){
              errorsArray.push(formErrors[i]);
            }
          }
          else {
            errorsArray.push("Error in Search API! please try again later");
          }
          this.setState({errors: errorsArray});
        }
  }

    handleAutoComplete = (text,stateValue) => {

        if(text.length >= 3) {
           this.getData(text,stateValue);
        }
    }
    

    handleAutoCompleteSelection = (airport_code,airport_name,stateValue) => {
  
        if(stateValue == 'Pickuploc'){
              this.setState({Pickuploc:airport_name})
        } else if(stateValue == 'Dropoffloc'){
              this.setState({Dropoffloc:airport_name})
        }
        this.setState({ data:[], data2:[] })
    }




    render() {

        if (!this.state.loading) {
           const data = this.state.data;
           const data2 = this.state.data2;
            return (
                    <ScrollView style={css.scrollContainer}>
                        <View style={css.SearchPageContainer}>
                            <View style={[carcss.textBoxContainer]}>
                              <View><Text style={carcss.srcText}>Pick-up Location</Text></View>
                              <View style={{marginTop:-10}}>
                                  <Autocomplete
                                        autoCapitalize="none"
                                        autoCorrect={false}
                                        style={css.autocomplete}
                                        data={data}
                                        inputContainerStyle={css.autoCompleteContainerStyle}
                                        listStyle={css.listStyle}
                                        listContainerStyle={css.listContainerStyle}
                                        defaultValue={this.state.Pickuploc}
                                        onChangeText={(text) => this.handleAutoComplete(text,'Pickuploc')}
                                        placeholder=""
                                        placeholderTextColor='#ffffff'
                                        renderItem={({ airport_name, airport_code }) => (
                                          <View style={styles.autocompleteList}>
                                              <TouchableOpacity onPress={() => this.handleAutoCompleteSelection(airport_code,airport_name,'Pickuploc')}>
                                                <Text style={styles.itemText}>
                                                  {airport_name} ({airport_code})
                                                </Text>
                                              </TouchableOpacity>
                                          </View>
                                        )}
                                      />
                                      <Icon
                                        name='map-marker'
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={carcss.icon}
                                      />
                                   </View>
                            </View>
                            <View className="dropLoc"  style={this.state.showDroploc ? carcss.dropLoc : { display: "none" }}>
                                <View><Text style={carcss.srcText}>Drop-off Location</Text></View>
                                <View style={{marginTop:-10}}>
                                    <Autocomplete
                                          autoCapitalize="none"
                                          autoCorrect={false}
                                          style={css.autocomplete}
                                          data={data2}
                                          inputContainerStyle={css.autoCompleteContainerStyle}
                                          listStyle={css.listStyle}
                                          listContainerStyle={css.listContainerStyle}
                                          defaultValue={this.state.Dropoffloc}
                                          onChangeText={(text) => this.handleAutoComplete(text,'Dropoffloc')}
                                          placeholder=""
                                          placeholderTextColor='#ffffff'
                                           renderItem={({ airport_name, airport_code }) => (
                                            <View style={styles.autocompleteList}>
                                                <TouchableOpacity onPress={() => this.handleAutoCompleteSelection(airport_code,airport_name,'Dropoffloc')}>
                                                  <Text style={styles.itemText}>
                                                    {airport_name} ({airport_code})
                                                  </Text>
                                                </TouchableOpacity>
                                            </View>
                                          )}
                                        />
                                   <Icon
                                      name='map-marker'
                                      type='font-awesome'
                                      color='#FFFFFF'
                                      containerStyle={carcss.icon}
                                    />
                              </View>
                          </View>
                        

                          <View style={carcss.chkinout}>
                            <View style={[css.partitionContainer,css.alignRow,carcss.chkinContainer]}>
                              <View style={carcss.dateBorder}>
                                <View style={css.datepickerDiv}>
                                <View  style={{borderBottomColor:'#D9A253', borderBottomWidth:1,paddingBottom:10}}>
                                    <Text style={[css.passengerText2,carcss.pickdropTxt]}>Pick-up Date</Text> 
                                  
                                    <DatePicker
                                        style={css.datepicker}
                                         date={this.state.PickupDate}
                                        mode="date"
                                        placeholder="select"
                                        format="ddd, MMM D YYYY"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        showIcon={false}
                                        customStyles={{
                                          dateIcon: {
                                           
                                          },
                                          dateInput: {
                                              borderWidth:0,
                                              margin:5,
                                          },
                                            dateText: {
                                              color: "#FFFFFF",
                                              fontSize:12,
                                              textAlign:'center',
                                            }
                                        }}
                                        onDateChange={(date) => {this.setState({PickupDate: date})}}
                                      /> 
                                      <Icon
                                        name='calendar'
                                        size={20}
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={styles.iconCalender}
                                        />
                                    </View>
                                    <View style= {{paddingTop:5}}>
                                      <Text style={[css.passengerText2,carcss.pickdropTxt]}>Pick-up Time</Text> 
                                        <DatePicker
                                          style={css.datepicker}
                                          date={this.state.PickupTime}
                                          mode="time"
                                          placeholder="select"
                                          confirmBtnText="Confirm"
                                          cancelBtnText="Cancel"
                                          showIcon={false}
                                          customStyles={{
                                            dateIcon: {
                                             
                                            },
                                            dateInput: {
                                                borderWidth:0,
                                                margin:5,
                                            },
                                              dateText: {
                                                color: "#FFFFFF",
                                                fontSize:12,
                                                textAlign:'center',
                                              }
                                          }}
                                          onDateChange={(date) => this.handleTimePicked(date , 'pickup')}
                                        /> 
                                        <Icon
                                          name='clock-o'
                                          size={20}
                                          type='font-awesome'
                                          color='#FFFFFF'
                                           containerStyle={styles.iconTime}
                                          />
                                    </View>
                                  </View>
                              </View>

                                
                            </View>
                            <View style={[carcss.chkoutContainer,{marginLeft:20}]}>
                                <View style={carcss.dateBorder}>
                                  <View style={css.datepickerDiv}>
                                    <View  style={{borderBottomColor:'#D9A253', borderBottomWidth:1,paddingBottom:10}}>
                                    <Text style={[css.passengerText2,carcss.pickdropTxt]}>Drop-off Date</Text> 
                                  
                                    <DatePicker
                                        style={css.datepicker}
                                        date={this.state.DropoffDate}
                                        mode="date"
                                        placeholder="select"
                                        format="ddd, MMM D YYYY"
                                        confirmBtnText="Confirm"
                                        cancelBtnText="Cancel"
                                        showIcon={false}
                                        customStyles={{
                                          dateIcon: {
                                           
                                          },
                                          dateInput: {
                                              borderWidth:0,
                                              margin:5,
                                          },
                                            dateText: {
                                              color: "#FFFFFF",
                                              fontSize:12,
                                              textAlign:'center'
                                            }
                                        }}
                                        onDateChange={(date) => {this.setState({DropoffDate: date})}}
                                      />
                                      <Icon
                                        name='calendar'
                                        size={20}
                                        type='font-awesome'
                                        color='#FFFFFF'
                                        containerStyle={styles.iconCalender}
                                        />
                                    </View>
                                    <View style= {{paddingTop:5}}>
                                      <Text style={[css.passengerText2,carcss.pickdropTxt]}>Drop-off Time</Text> 
                                  
                                      <DatePicker
                                          style={css.datepicker}
                                          date={this.state.DropoffTime}
                                          mode="time"
                                          placeholder="select"
                                          confirmBtnText="Confirm"
                                          cancelBtnText="Cancel"
                                          showIcon={false}
                                          customStyles={{
                                            dateIcon: {
                                             
                                            },
                                            dateInput: {
                                                borderWidth:0,
                                                margin:5,
                                            },
                                              dateText: {
                                                color: "#FFFFFF",
                                                fontSize:12,
                                                textAlign:'center',
                                              }
                                          }}
                                          onDateChange={(date) => this.handleTimePicked(date , 'drop')}
                                        /> 
                                        <Icon
                                          name='clock-o'
                                          size={20}
                                          type='font-awesome'
                                          color='#FFFFFF'
                                           containerStyle={styles.iconTime}
                                          />
                                      </View>
                                  </View>
                                </View>
                            </View>
                         
                      </View>
                         <View style={carcss.selctdrop}>
                          <CheckBox
                              title='Select Dropoff'
                              containerStyle={{backgroundColor:'transparent',borderColor:'transparent'}}
                              textStyle={{color:'#FFFFFF',fontSize:14}}
                              checked={this.state.showDroploc}
                              checkedColor='#FFFFFF'
                              onPress={() => this.setState({showDroploc: !this.state.showDroploc})}
                            />

                      </View>
                      </View>
                   
                      <View style={styles.rows}>
                        <TouchableHighlight style={css.button} >
                          <Text style={[styles.searchText,{fontSize:16}]}>Search Now</Text>
                        </TouchableHighlight>
                      </View>
                  </ScrollView>
            )
        } else {
            return (
                <Loader />
            )
        }
    }
}


const styles = StyleSheet.create({
  error:{
    color:'#FFFFFF',
    fontWeight:'bold',
  },
  errorContainer:{
    padding:10,
    backgroundColor: 'red',
    width:'100%',
  },
  searchText:{
    fontSize:14,
    fontWeight:'500',
    color:'#ffffff',
  },

  rows:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent: 'center',
    marginVertical: 10,
  },
  autocompleteList:{
    position: 'relative',
    borderBottomWidth:1,
    borderBottomColor: '#ccc',
    paddingVertical:5,
  },
  atf1:{
    zIndex: 3,
  },
  atf2:{
    zIndex:2,
  },
  iconCalender: {
    position:'absolute',
    right:0,
    bottom:20
  },
  iconTime: {
    position:'absolute',
    right:0,
    bottom:10

  }
})
