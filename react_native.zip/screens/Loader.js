import React, {Component} from 'react';
import {Platform, StyleSheet, ActivityIndicator, AsyncStorage, Text, View, StatusBar} from 'react-native';

export default class Loader extends Component {
	constructor(props) {
		super(props);
	}

	render() {
		return (
			<View style={styles.container}>
				<Text style={styles.wait}>Please wait...</Text>
				<ActivityIndicator />
				<StatusBar barStyle="default" />
			</View>
		)
	}
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#050517',
  },
  wait: {
  	fontSize: 20,
  	color: '#FFFFFF',

  }
})