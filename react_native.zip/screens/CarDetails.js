import React, { Component } from 'react';
import { AppRegistry, Platform, StyleSheet, Text, View, Image, Picker, TextInput, TouchableHighlight, TouchableOpacity, ScrollView } from 'react-native';
import { Icon, Avatar  } from 'react-native-elements';
import Loader from './Loader';
import css from '../assets/style/style';

export default class CarListing extends Component {
    constructor(props) {
        super(props);
        var data = [
            { "name":"Van", "price":"100.00", "details": "AC | Automatic | Unlimitedmilage","image":"https://cdn.travelport.com/cmavis/ZI_general_large_8580.jpg",
              "pickuploc":"Los Angeles Intl","dropoffloc":"Los Angeles Intl","pickupdate":"28 Feb, Thu","pickuptime":"07:00","dropoffdate":"28 Feb, Thu","dropofftime":"08:00"
            },
          ]
        this.state = {
            loading: false,
            data:data
        }
       
    }

  carTopSection() {
        return(
              <View style={styles.carDetailsTop}>
                  <View style={{textAlign:'center', width:'30%'}}>
                      <Text style={styles.pickDate}>28 Feb, Thu</Text>
                      <Text style={styles.pickLoc}>Los Angeles Intl</Text>
                      <Text style={styles.pickLoc}>Arpt(LAX)</Text>
                  </View>
                  <View style={{width:'32%'}}>
                      <View style={{alignItems:'center'}}><Text style={[styles.pickTimetxt,{paddingVertical:1,textAlign:'center',width:'50%'}]}>Trip</Text></View>
                      <View style={[styles.seperator,styles.mv3]}>                     
                        <View style={styles.leftBullet}></View>
                        <View style={styles.rightBullet}></View>                      
                      </View>
                      <View style={{color:'#FFF',textAlign:'center'}}>
                          <Icon
                              name='car'
                              type='font-awesome'
                              color='#FFFFFF'
                              size={20}
                              containerStyle={{textAlign:'center',color:'#FFF'}}
                            />
                        </View>
                  </View>
                  <View style={{textAlign:'center', width:'30%'}}>
                      <Text style={styles.pickDate}>28 Feb, Thu</Text>
                      <Text style={styles.pickLoc}>Los Angeles Intl</Text>
                      <Text style={styles.pickLoc}>Arpt(LAX)</Text>
                  </View>
              </View> 
        )
  }


  carView() {

      return (
        <View>
            <View style={styles.carDetailsMiddle}>
                    <View>
                        <Text style={[styles.carTitle]}>Van</Text>
                        <Image
                          style={styles.carsViewImg}
                          source={{uri: 'https://cdn.travelport.com/cmavis/ZI_general_large_8580.jpg'}}
                      />
                        <Text style={[styles.carProp]}>AC | Automatic | Unlimitedmilage</Text>
                    </View>

                    <View style={{textAlign:'center'}}>
                        <Text style={styles.price}>GBP 26.00</Text>
                    </View>
            </View>
            <View style={[styles.carDetailsTopTime,{marginTop:-15}]}>
                    <View>
                        <Text style={styles.pickTimetxt}>Pickup time</Text>
                        <Text style={styles.pickTime}>07:00 AM</Text>
                    </View>
                    <View style={{textAlign:'center'}}>
                     <Text style={styles.pickTimetxt}>Drop time</Text>
                      <Text style={styles.pickTime}>08:00 AM</Text>
                    </View>
            </View>
        </View>
      )
  }


    render() {

        if (!this.state.loading) {

            let data = this.state.data;
            let carTopSection = this.carTopSection();
            let carView = this.carView();
            return (
                    <ScrollView style={css.scrollContainer}>
                          <View style={{marginHorizontal:10,marginTop:10}}>
                              <Icon
                                name='car'
                                type='font-awesome'
                                color='#FFFFFF'
                                containerStyle={styles.iconlft}
                              />
                              <Text style={styles.titleTop}>Car Details</Text>
                          </View>
                          { carView }
                          { carTopSection }
                          
                          <View style={{marginHorizontal:10,marginTop:20}}>
                            <Text style={styles.additionalTitle}>Additional Information</Text>
                          </View>
                          <View style={styles.carAdditional}>
                              <View style={styles.carExtra}>
                                  <Text style={styles.carExtraTitle}>Extra Days/Hours charge</Text>
                                  <Text style={styles.carExtraTxt}>Hourly Late Charge : $ 11.54 Unlimitedmileage: Yes</Text>
                                  <Text style={styles.carExtraTxt}>Extra mileage Charge : $ 11.54 Daily Late Charge : $ 11.54 </Text>
                             
                              </View>
                              <View style={styles.carExtra}>
                                  <Text style={styles.carExtraTitle}>Operation Time</Text>
                                  <Text style={styles.carExtraTxt}>Drop Off Hours OPEN 07.00 to 22.00</Text>
                                  <Text style={styles.carExtraTxt}>Hours Of Operation OPEN 07.00 to 22.00 </Text>
                             
                              </View>
                              <View style={styles.carExtra}>
                                  <Text style={styles.carExtraTitle}>Sales tax</Text>
                                  <Text style={styles.carExtraTxt}>Sales taxt included in total 10.00 percent</Text>
                               </View>
                               <View style={[styles.carExtra,{borderBottomWidth:0}]}>
                                  <Text style={styles.carExtraTitle}>General</Text>
                                  <Text style={styles.carExtraTxt}>Received Unlimited mileage on rental of 4 days</Text>
                               </View>
                          </View>

                          
                    </ScrollView>
            )
        } else {
            return (
                <Loader />
            )
        }
    }
}


const styles = StyleSheet.create({
  titleTop: {
        color:'#FFFFFF',
        marginLeft:40,
        fontSize:22,
        fontWeight:'bold'
  },
  carDetailsTop: {
        flex:1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        borderBottomWidth:1,
        borderTopWidth:1,
        marginHorizontal:10,
        marginTop:35,
        borderBottomColor:'#CCC',
        borderTopColor:'#CCC',
        paddingTop:15,
        paddingBottom:10
    },
  iconlft: {
      position:'absolute',
      left:0,
      top:5,
  },
  carDetailsMiddle: {
      flex:1,
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor:'#FFF',
        borderBottomWidth:2,
        margin:10,
        padding:20,
      },
  carAdditional: {
        borderBottomWidth:2,
        marginHorizontal:10,
        padding:10,
  },
  carDetailsTopTime: {
        display:'flex',
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor:'#FFF',
        borderBottomWidth:2,
        marginHorizontal:10,
        paddingHorizontal:20,
        paddingBottom:10
  },
  carsViewImg: {
        width:100,
        height:80,
        resizeMode: 'contain',
        
    },
  price:{
      color:'#D9A253',
      textAlign:'center',
      fontSize:16,
      fontWeight:'bold'
  },
  pickDate: {
    color:'#D9A253',
    textAlign:'center'
  },
  dropDate: {
    color:'#D9A253',
    textAlign:'center'
  },
  tripLine: {
    backgroundColor:'#D9A253',
    paddingHorizontal:5,
    paddingVertical:1,
    textAlign:'center',
    borderRadius:10,
    color:'#FFF',
    width:'40%',
    marginHorizontal:'20%',
    marginTop:10,
     marginBottom:-10,
  },
  tripLineBottom: {
    borderBottomWidth:1,
    borderBottomColor:'#FFF',
    paddingTop:-20,
  },
  leftBullet:{
    position: 'absolute',
    bottom: -2.5,
    left: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
    borderRadius:50,
    zIndex:1,
  },
  rightBullet:{
    position: 'absolute',
    bottom: -2.5,
    right: -2,
    width: 5,
    height: 5,
    backgroundColor: '#d9a352',
    borderRadius:50,
    zIndex:1,
  },
  seperator:{
    borderBottomWidth: 1,
    width:'100%',
    borderBottomColor: "#ddd",
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent:'center',
    position:'relative',
    paddingRight:5,
  },
  mv3:{
   marginTop:10,
  marginBottom:5,
 },
  pickLoc: {
    color:'#FFF',
    textAlign:'center',
  },
 
  pickTimetxt: {
    backgroundColor:'#D9A253',
    paddingHorizontal:15,
    paddingVertical:5,
    borderRadius:10,
    color:'#FFF',
  },
  pickTime: {
    color:'#050517',
    textAlign:'center',
    fontWeight:'bold',
    marginTop:5
  },
  carTitle: {
       textAlign:'left',
       fontSize:18,
       color:'#050517',
       fontWeight:'bold'
  },
  carProp:{ 
       textAlign:'left',
       //marginTop:5,
       color:'#050517',
       fontWeight:'bold'
  },
  carExtra: {
    borderBottomColor:'#CCCC',
    borderBottomWidth:1,
    paddingVertical:10
  },
  carExtraTitle: {
      color:'#FFF',
      fontSize:18,
      fontWeight:'bold'
  },
  carExtraTxt: {
      color:'#FFF',
      fontSize:14,
      marginTop:5,
      marginBottom:5
  },
  additionalTitle: {
    color:'#D9A253',
    fontSize:20,
    textAlign:'center'
  }

})
