import React, {Component} from 'react';
import {Platform, StyleSheet} from 'react-native';
import { Icon } from 'react-native-elements';

import { createBottomTabNavigator, createAppContainer } from 'react-navigation';

import CreditCard from '../components/CreditCard';
import DebitCard from '../components/DebitCard';
import Cash from '../components/Cash';
import Paypal from '../components/Paypal';

const TabNavigator = createBottomTabNavigator({
  CreditCard: CreditCard,
  DebitCard:DebitCard,
  Paypal:Paypal,
  Cash:Cash
},
{
    initialRouteName: 'Paypal',
    defaultNavigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, horizontal, tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;
        if (routeName === 'CreditCard') {
          iconName = 'credit-card';
        }
        else if (routeName === 'DebitCard') {
          iconName = 'credit-card-alt';
        }
        else if (routeName === 'Cash') {
          iconName = 'money';
        }
        else if (routeName === 'Paypal') {
          iconName = 'paypal';
        }
        // You can return any component that you like here! We usually use an
        // icon component from react-native-vector-icons
        return <Icon name={iconName} type='font-awesome' size={horizontal ? 20 : 25} color={tintColor} />;
      },
    }),
    tabBarOptions: {
      activeTintColor: '#D9A253',
      inactiveTintColor: '#050517',
    },
  }
);

export default createAppContainer(TabNavigator);