import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, ScrollView, TouchableHighlight, AsyncStorage} from 'react-native';

import Booking from '../components/BookingSummary';
import Payment from '../components/PaymentSummary';
import Booker from '../components/Booker';
import PassengerList from '../components/PassengerList';
import styles from '../assets/style/style';

export default class ConfirmBooking extends Component {
  constructor(props) {
    super(props)
}

getPassengerDetails(){
    const { params } = this.props.navigation.state;
    return params.passengerList;
}

proceedPayment = async() => {
    const { params } = this.props.navigation.state;
    const flightDetails = params.flightDetails;
    const searchList = params.searchList;
    const passenger = this.getPassengerDetails();
    const user_id = await AsyncStorage.getItem('user_id');
    console.log(user_id);
    let details = {'flightDetails':flightDetails,'searchList':searchList,'passenger':passenger,'user_id':user_id}
    this.props.navigation.navigate('Payment',details);
}

render() {
    const { params } = this.props.navigation.state;
    const flightDetails = params.flightDetails;
    const searchList = params.searchList;
    const passenger = this.getPassengerDetails();
    return (
        <ScrollView>
            <View style={styles.container}>
                <Payment flightDetails={flightDetails} title="Payment Summary" />
                <PassengerList passenger={passenger} />
                <Booking flightDetails={flightDetails} searchList={searchList} title="Booking Summary" />
                <Booker  />
                <View style={{flex:1,alignItems:'center',marginVertical:10}}>
                    <TouchableHighlight style={styles.button} onPress={ () => this.proceedPayment()}>
                        <Text style={styles.blockText}>Proceed to Payment</Text>
                    </TouchableHighlight>
                </View>
            </View>
        </ScrollView>
        )
    }
}
