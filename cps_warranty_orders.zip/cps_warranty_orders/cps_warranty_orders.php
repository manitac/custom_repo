<?php
/**
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2018 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_')) {
    exit;
}

class Cps_warranty_orders extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'cps_warranty_orders';
        $this->tab = 'others';
        $this->version = '1.0.0';
        $this->author = 'chetu';
        $this->need_instance = 0;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('CPS Warranty ');
        $this->description = $this->l('This module is used to send order to cps team..');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        
        include(dirname(__FILE__).'/sql/install.php');

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('backOfficeHeader') &&
            $this->registerHook('displayOrderConfirmation');
    }

    public function uninstall()
    {

        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitCps_warranty_ordersModule')) == true) {
            $this->postProcess();
        }
        $this->context->smarty->assign('module_dir', $this->_path);

        $output = $this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');

        return $output.$this->renderForm();
        
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitCps_warranty_ordersModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
     protected function getConfigForm()
    {
        
           $all_status = array_unique($this->getAllStatus(), SORT_REGULAR);
        return array(
            'form' => array(
                'legend' => array(
                'title' => $this->l('Settings'),
                'icon' => 'icon-cogs',
                ),

                'input' => array(
                        array(
                                'col' => 3,
                                'type' => 'text',
                                'desc' => $this->l('Enter dealer id here.'),
                                'name' => 'CPS_Dealer_ID',
                                'label' => 'CPS Dealer ID',
                        ),
                        array(
                                'col' => 3,
                                'type' => 'text',
                                'desc' => $this->l('Enter sub account id, if not any then set as 0'),
                                'name' => 'CPS_Subaccount_ID',
                                'label' => 'Sub Account ID',
                        ),
                        array(
                                'col' => 3,
                                'type' => 'text',
                                'desc' => $this->l('Enter Api key'),
                                'name' => 'CPS_ApiKey',
                                'label' => 'CPS Api key',
                        ),
                        array(
                            'col' => 3,
                            'type' => 'text',
                            'desc' => $this->l('Enter comma separated warranty product id\'s'),
                            'name' => 'PS_WARRANTY_IDS',
                            'label' => 'Warranty product id\'s',
                        ),
                        array(
                            'col' => 3,
                            'type' => 'select',
                            'desc' => $this->l('order status used to send order cps'),
                            'name' => 'PS_Order_States',
                            'label' => $this->l('Select order status for sending order to cps '),
                            'default_value' => 'none',
                            'options' => array(
                                'default' => array(
                                    'label' => 'none',
                                    'value' => 0
                                ),
                                'query' => $all_status,
                                'id' => 'id_order_state',
                                'name' => 'name'
                            ),
                        ),
                    ),
                    'submit' => array(
                    'title' => $this->l('Save'),
                    ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
       return array(
            'CPS_Dealer_ID' => Configuration::get('CPS_Dealer_ID', null),
            'CPS_Subaccount_ID' => Configuration::get('CPS_Subaccount_ID', null),
            'CPS_ApiKey' => Configuration::get('CPS_ApiKey', null),
            'PS_WARRANTY_IDS' => Configuration::get('PS_WARRANTY_IDS', null),
            'PS_Order_States' => Configuration::get('PS_Order_States', null),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookBackOfficeHeader()
    {
        if (Tools::getValue('module_name') == $this->name) {
            $this->context->controller->addJS($this->_path.'views/js/back.js');
            $this->context->controller->addCSS($this->_path.'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
    }
    /**
     * Add the code on order confirmation page
     */
    public function hookDisplayOrderConfirmation($param)
    {
        $order = $param['order'];

        Db::getInstance()->execute('UPDATE `'._DB_PREFIX_.'cps_warranty_sku_info` SET `id_order` = '.
            $order->id.' WHERE `id_cart` = '.(int) $order->id_cart
            );
    }
    
    /**
     * Return all the status created in admin for orders
     */
    public function getAllStatus()
    {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT *
            FROM `'._DB_PREFIX_.'order_state_lang` ');
    }
}
