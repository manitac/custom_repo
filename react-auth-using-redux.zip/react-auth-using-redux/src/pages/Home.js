import React, { Component } from 'react';
import Modal from 'react-bootstrap/lib/Modal'
import { Button } from 'react-bootstrap'
import { connect } from 'react-redux';
class Home extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
          <div className="modal-container" style={{ height: 200 }}>
              <p>Home {this.props.user.email}</p>
          </div>
        );
    }
}


const mapStateToProps = (state) => ({  
    user: state.user
});
  
export default connect(mapStateToProps)(Home)