import React, { Component } from 'react';
import Modal from 'react-bootstrap/lib/Modal'
import { Button } from 'react-bootstrap'
import { connect } from 'react-redux';

class About extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        const user = this.props.user;
        return (
          <div className="modal-container" style={{ height: 200 }}>
              <p>token:  {user.token}</p>
                <p>first name:  {user.name.first}</p>
                  <p>last name:  {user.name.last}</p>
                    <p>email:  {user.email}</p>
          </div>
        );
    }
}



function mapStateToProps(state) {
    return {
        user: state.user
    }
}
  
export default connect(mapStateToProps)(About)