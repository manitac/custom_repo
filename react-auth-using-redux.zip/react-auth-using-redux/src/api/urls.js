
export const BASE_URL = 'http://192.168.6.218:3001/';
export const ASSET_URL = 'http://192.168.6.218:3001/';

export const urls = {
    login: `${BASE_URL}login`,
    register: `${BASE_URL}signup`,
    profile: `${BASE_URL}user/profile`,
}