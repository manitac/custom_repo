<?php

class QuoteDetail extends ObjectModel
{

	public $id_jewelry_quote_items;
	public $id_quote;
	public $brand_name;
	public $model_no;
	public $item;
	public $items_condition;
	public $does_item_functional_properly;
	public $metal_type;	 
	public $weight;	 
	public $clarity;	 
	public $carat_size;	 
	public $center_stone;	 
	public $secondary_stone;	 
	public $Additional_stone;	 
	public $center_stone_cut;	 
	public $description;	 
	public $how_much_hoping_to_get;	 
	public $looking_for;
	public $images;
	public static $definition = array(
		'table' => 'quote_items', 'primary' => 'id_quote_items', 'multilang' => false,
	);
	
	public function getCustomerDetail($id_quote){
		$customerinfo = Db::getInstance()->executeS(' SELECT `id_customer`
		FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$id_quote);
		$customer = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'customer` where `id_customer` ='.$customerinfo[0]['id_customer']);
		
		return $customer;
	}
	
	public function getMainQuote($id_quote){
		$detail = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$id_quote);
		
		return $detail;
	}

	public function getQuoteDetail($id_quote){
		$detail = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote_items` where `id_quote` ='.$id_quote);
		
		return $detail;
	}

	public function getQuoteMessages($id_quote){
		
		$messages = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote_messages` where `id_quote` ='.$id_quote.' ORDER BY `date_add` DESC' );
	
		return $messages;
	}
	
	public function getPending(){
		$detail = Db::getInstance()->executeS(' SELECT count(*)
		FROM `'._DB_PREFIX_.'quote_items`');
		return $detail;
	}

	public function getStatus($status){
        $detail = Db::getInstance()->executeS(' SELECT count(*)
        FROM `'._DB_PREFIX_.'quote` where `status` ="'.$status.'" ');
        return array_values($detail[0])[0];
    }
    
	public  function previewTemplate($REQUEST){
		//set_time_limit(0);
		$this->context = Context::getContext();
		$arrayStreamContext = @stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 8)));
		if($REQUEST['quote_status'] == 1){
			
			$quotedetails = $this->getQuoteDetail($REQUEST['id_quote']);
			$i = 0; $j = 1;
			$items = "";
			foreach ($quotedetails as $quotedetail){

				$items = $items.$j.') '.$quotedetail['item'].'...'.'Price from $'.$REQUEST['from'][$i].' to $'.$REQUEST['to'][$i].'<br/>';

				$i++;
				$j++;
			}
			$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html', false, $arrayStreamContext);
			$content = str_replace("{firstname}",$REQUEST['customer_name'],$content);
			$content = str_replace("{lastname}",$REQUEST['customer_lname'],$content);
			$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
			$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
			$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
			$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
			echo $content = str_replace("{items}",$items ,$content);
			die();
		}else{
			
			$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.html', false, $arrayStreamContext);
			$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
			$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
			$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
			$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
			echo  $content = str_replace("{message}",nl2br($REQUEST['reply_message']),$content);
			die();
		}	
    }

	public  function saveMessage($request){
		
		$this->context = Context::getContext();

		if($request['quote_status'] == 1){
			$quotedetails = $this->getQuoteDetail($request['id_quote']);
			$i = 0; $j=1;
			$items = "";
			foreach ($quotedetails as $quotedetail){

				$items = $items.$j.') '.$quotedetail['item'].'...'.'Price from $'.$request['from'][$i].' to $'.$request['to'][$i].'<br/>';

				$i++;
				$j++;
			}

			$request['reply_message'] = str_replace("<FirstName>",$request['customer_name'],$request['reply_message']);
			$request['reply_message'] = str_replace("<ItemList>",$items,$request['reply_message']);
		}
      	Db::getInstance()->execute('INSERT INTO `'._DB_PREFIX_.'quote_messages`(`id_quote`,`id_customer`, `message`,`message_to`,`quote_status`,`date_add`) VALUES ('.$request['id_quote'].','.$request['id_customer'].',"'.nl2br($request['reply_message']).'","customer","'.$request['quote_status'].'",NOW())');

		Db::getInstance()->execute('Update 
         `'._DB_PREFIX_.'quote` set `status` = 2 , `date_upd` = NOW() where `id_quote` ='.$request['id_quote']);

		
		$issentmail = $this->sendMailForNewMessage($request['id_quote'],$request['quote_status'],$request['reply_message'],$items);

		if($issentmail){
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=true');
		}else{
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=false');
		}
    }

    public function setStatus($request){
        $this->context = Context::getContext();
        Db::getInstance()->execute('Update 
         `'._DB_PREFIX_.'quote` set `status` ="'.$request['setstatus'].'" , `date_upd` = NOW() where `id_quote` ='.$request['id_quote']);
		$issentmail = $this->sendMailForStatusChange($request['id_quote'], $request['setstatus']);
		if($issentmail){
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=true');
		}else{
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=false');
		}
	}


	public function sendMailForStatusChange($id_quote, $quote_status){
		$this->context = Context::getContext();
		$customer = $this->getCustomerDetail($id_quote);
		$this->context->customer = (object)$customer[0];
		$vars = array(
			'{firstname}' => $this->context->customer->firstname,
			'{lastname}' => $this->context->customer->lastname,
			'{email}' => $this->context->customer->email,
			'{id_quote}' => $id_quote,
			'{qoute_status}' => $quote_status,
			'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
		);
		
		if(Mail::Send(
			(int) $this->context->language->id,
			'quote_status_change',
			Context::getContext()->getTranslator()->trans(
			'Quote#'.$id_quote.' status updated to '.$quote_status,
			array(),
			'Emails.Subject',
			$this->context->language->locale
			),
			$vars,
			$this->context->customer->email,
			$this->context->customer->firstname.' '.$this->context->customer->lastname,
			null,
			null,
			null,
			null,
			_PS_MAIL_DIR_,
			false
		)){

			return true;
			
		}else{
			return false;
			
		}
	}

	public function sendMailForNewMessage($id_quote,$quote_status, $message, $items){

		$this->context = Context::getContext();
		$customer = $this->getCustomerDetail($id_quote);
		$this->context->customer = (object)$customer[0];
		
		
		if($quote_status == 1){
			$vars = array(
				'{firstname}' => $this->context->customer->firstname,
				'{lastname}' => $this->context->customer->lastname,
				'{email}' => $this->context->customer->email,
				'{id_quote}' => $id_quote,
				'{items}'  => $items,
				'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			);
			$email_template = 'pending_quote_message_to_customer';
		}else{
			$vars = array(
				'{firstname}' => $this->context->customer->firstname,
				'{lastname}' => $this->context->customer->lastname,
				'{email}' => $this->context->customer->email,
				'{id_quote}' => $id_quote,
				'{message}'  => nl2br($message),
				'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			);
			$email_template = 'quote_message_to_customer';
		}

		if(Mail::Send(
			(int) $this->context->language->id,
			$email_template,
			Context::getContext()->getTranslator()->trans(
			'New message for your quote#'.$id_quote.' from admin',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			),
			$vars,
			$this->context->customer->email,
			$this->context->customer->firstname.' '.$this->context->customer->lastname,
			null,
			null,
			null,
			null,
			_PS_MAIL_DIR_,
			false
		)){
			return true;
			
		}else{
			return false;
			
		}
	}
	
}