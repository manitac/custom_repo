<?php

class QuoteDetail extends ObjectModel
{

	public $id_jewelry_quote_items;
	public $id_quote;
	public $brand_name;
	public $model_no;
	public $item;
	public $items_condition;
	public $does_item_functional_properly;
	public $metal_type;	 
	public $weight;	 
	public $clarity;	 
	public $carat_size;	 
	public $center_stone;	 
	public $secondary_stone;	 
	public $Additional_stone;	 
	public $center_stone_cut;	 
	public $description;	 
	public $how_much_hoping_to_get;	 
	public $looking_for;
	public $images;
	public $price_range_from;
	public $price_range_to;
	public static $definition = array(
		'table' => 'quote_items', 'primary' => 'id_quote_items', 'multilang' => false,
	);
	
	public function getCustomerDetail($id_quote){
		$customerinfo = Db::getInstance()->executeS(' SELECT `id_customer`
		FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$id_quote);
		$customer = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'customer` where `id_customer` ='.$customerinfo[0]['id_customer']);
		
		return $customer;
	}
	
	public function getMainQuote($id_quote){
		$detail = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$id_quote);
		
		return $detail;
	}

	public function getQuoteDetail($id_quote){
		$detail = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote_items` where `id_quote` ='.$id_quote);
		
		return $detail;
	}
	public function getStoreDetail($id_quote){
		$store_info = Db::getInstance()->executeS(' SELECT `id_store`
		FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$id_quote);
		$store = (object)$store_info[0];
		$store_details =  Db::getInstance()->executeS(' SELECT * FROM `'._DB_PREFIX_.'store` where `id_store` ='.$store->id_store);
		return (object)$store_details[0];
	}

	public function getQuoteMessages($id_quote){
		
		$messages = Db::getInstance()->executeS(' SELECT *
		FROM `'._DB_PREFIX_.'quote_messages` where `id_quote` ='.$id_quote.' ORDER BY `date_add` DESC' );
	
		return $messages;
	}
	
	public function getPending(){
		$detail = Db::getInstance()->executeS(' SELECT count(*)
		FROM `'._DB_PREFIX_.'quote_items`');
		return $detail;
	}

	public function getStatus($status){
		$this->context = Context::getContext();
		if($this->context->employee->id_profile == 1){

                  $detail = Db::getInstance()->executeS(' SELECT count(*)
				        FROM `'._DB_PREFIX_.'quote` where `status` ="'.$status.'" ');
				        return array_values($detail[0])[0];

            }else{

               
			    $detail = Db::getInstance()->executeS(' SELECT count(*)
			        FROM `'._DB_PREFIX_.'quote` where `status` ="'.$status.'" and `id_store`= '.$this->context->employee->id_store);
			  
			        return array_values($detail[0])[0];

            }
      
    }

    public function unableQuoteItems($REQUEST){
    	$quotedetails = $this->getQuoteDetail($REQUEST['id_quote']);
    	$items=""; 
			foreach ($quotedetails as $quotedetail){

				if($REQUEST['unable_quote'] == "goods"){
						
						$items = $items.'<div class="product_info col-md-12"><label>Product info: '.$quotedetail['item'].'</label></div>
						<div class="col-md-6">';
						if(isset($REQUEST['quality_photo'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" name="quality_photo['.$quotedetail['id_quote_items'].']" checked value="More/Higher Quality Photos">More/Higher Quality Photos
							    					</div>';
						}
						if(isset($REQUEST['more_detailed_desc'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" name="more_detailed_desc['.$quotedetail['id_quote_items'].']" checked value="More Detailed Product Description">More Detailed Product Description
							    					</div>';
						}
						if(isset($REQUEST['product_model'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    					<input type="checkbox" name="product_model['.$quotedetail['id_quote_items'].']" checked value="Product Model/Serial Number">Product Model/Serial Number
							    				</div>';
						}

			    		$items = $items.'</div>
			    			<div class="col-md-6">';
						if(isset($REQUEST['product_condition'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    					<input type="checkbox" name="product_condition['.$quotedetail['id_quote_items'].']" checked value="Product Condition (working, for parts only, like new etc) ">Product Condition (working, for parts only, like new etc)
							    				</div>';
						}
						if(isset($REQUEST['product_brand'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    				<input type="checkbox" name="product_brand[{$quotedetail['.$quotedetail['id_quote_items'].']" checked value="Product Model/Serial Number">Product Brand 
							    				</div>';
						}
						if(isset($REQUEST['more'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" class="myCheck" name="more['.$quotedetail['id_quote_items'].']" checked value="yes">More?
						                                <input type="text" class="more_text" value="'.$REQUEST['more_text'][$quotedetail['id_quote_items']].'" name="more_text['.$quotedetail['id_quote_items'].']">
							    				</div>';
						}

			    		$items = $items.'</div>';

			    	}else{

			    		$items = $items.'<div class="product_info col-md-12"><label>Product info: '.$quotedetail['item'].'</label></div>
						<div class="col-md-6">';
						if(isset($REQUEST['quality_photo'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" name="quality_photo['.$quotedetail['id_quote_items'].']" checked value="More/Higher Quality Photos">More/Higher Quality Photos
							    					</div>';
						}
						if(isset($REQUEST['more_detailed_desc'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" name="more_detailed_desc['.$quotedetail['id_quote_items'].']" checked value="More Detailed Product Description">More Detailed Product Description
							    					</div>';
						}
						if(isset($REQUEST['metal_weight'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" name="metal_weight['.$quotedetail['id_quote_items'].']" checked value="Metal Weight">Metal Weight
							    					</div>';
						}
						if(isset($REQUEST['metal_karat'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    					<input type="checkbox" name="product_model['.$quotedetail['id_quote_items'].']" checked value="Metal Karat">Metal Karat
							    				</div>';
						}
						$items = $items.'</div>
			    			<div class="col-md-6">';

			    		if(isset($REQUEST['stone_weight'][$quotedetail['id_quote_items']])){
						    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
						    					<input type="checkbox" name="product_model['.$quotedetail['id_quote_items'].']" checked value="Stone Weight">Stone Weight
						    				</div>';
						}
						if(isset($REQUEST['stone_type'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    					<input type="checkbox" name="product_condition['.$quotedetail['id_quote_items'].']" checked value="Stone Type">Stone Type
							    				</div>';
						}
						if(isset($REQUEST['stone_carat'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    				<input type="checkbox" name="product_brand[{$quotedetail['.$quotedetail['id_quote_items'].']" checked value="Stone Carat">Stone Carat
							    				</div>';
						}
						if(isset($REQUEST['more'][$quotedetail['id_quote_items']])){
							    		$items = $items.'<div class="item_details" style="margin-bottom: 5px;">
							    						<input type="checkbox" class="myCheck" name="more['.$quotedetail['id_quote_items'].']" checked value="yes">More?
						                                <input type="text" class="more_text" value="'.$REQUEST['more_text'][$quotedetail['id_quote_items']].'" name="more_text['.$quotedetail['id_quote_items'].']">
							    				</div>';
						}

			    		$items = $items.'</div>';

			    	}
		  	}


		  	return $items;
    }

    public function unableQuoteItemsID($REQUEST){

    	$quotedetails = $this->getQuoteDetail($REQUEST['id_quote']);
    	$items_id = array();
    	
		foreach ($quotedetails as $quotedetail){

				if(isset($REQUEST['quality_photo'][$quotedetail['id_quote_items']]) || isset($REQUEST['more_detailed_desc'][$quotedetail['id_quote_items']]) || isset($REQUEST['product_model'][$quotedetail['id_quote_items']]) || isset($REQUEST['product_condition'][$quotedetail['id_quote_items']]) || isset($REQUEST['product_brand'][$quotedetail['id_quote_items']]) || isset($REQUEST['metal_weight'][$quotedetail['id_quote_items']]) || isset($REQUEST['metal_karat'][$quotedetail['id_quote_items']]) || isset($REQUEST['stone_weight'][$quotedetail['id_quote_items']]) || isset($REQUEST['stone_type'][$quotedetail['id_quote_items']]) || isset($REQUEST['stone_carat'][$quotedetail['id_quote_items']]) || !empty($REQUEST['more_text'][$quotedetail['id_quote_items']])){

						$items_id[] = $quotedetail['id_quote_items'];
				}
		}
		return $items_id;
    }

    /************preview of messages of quotes **************/

    public function previewMessageTemplate($REQUEST){

    	$store_details = $this->getStoreDetail($REQUEST['id_quote']);
		$this->context = Context::getContext();
		$arrayStreamContext = @stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 8)));

		if( $_REQUEST['quote_pending'] == "unable_to_quote" ){
			$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/unable_to_quote_jewelry.html', false, $arrayStreamContext);
		}
		if( $_REQUEST['quote_pending'] == "accepted_the_quote" ){

			$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html', false, $arrayStreamContext);

		}

		$messages = Db::getInstance()->executeS('SELECT `message` FROM `'._DB_PREFIX_.'quote_messages` where `id_quote_message` ='.$_REQUEST['message_id'] );
		$items = (object)$messages[0];
		$items = $items->message;

		$content = str_replace("{firstname}",$REQUEST['customer_name'],$content);
		$content = str_replace("{lastname}",$REQUEST['customer_lname'],$content);
		$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
		$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
		$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
		$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
		echo $content = str_replace("{items}",$items ,$content);
		die();

    }

    
	public  function previewTemplate($REQUEST){


		$store_details = $this->getStoreDetail($REQUEST['id_quote']);
		$this->context = Context::getContext();
		$arrayStreamContext = @stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 8)));

		if(isset($REQUEST['unable_quote'])){

			$quotedetails = $this->getQuoteDetail($REQUEST['id_quote']);
			$items = $this->unableQuoteItems($REQUEST);

				$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/unable_to_quote_jewelry.html', false, $arrayStreamContext);
				$content = str_replace("{firstname}",$REQUEST['customer_name'],$content);
				$content = str_replace("{lastname}",$REQUEST['customer_lname'],$content);
				$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
				$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
				$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
				$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
				echo $content = str_replace("{items}",$items ,$content);
				die();
		}else{
			
			if($REQUEST['quote_status'] == 1){
				
				$quotedetails = $this->getQuoteDetail($REQUEST['id_quote']);
				$i = 0; $j = 1;
				$items = "";
				foreach ($quotedetails as $quotedetail){

					$items = $items.'<span class="title">Product: <b>'.$quotedetail['item'].'</b></span> <br><span>	Loan Range*: <b>$'.$REQUEST['from'][$i].' - $'.$REQUEST['to'][$i].'</b></span><br><span>Pawn Broker: <b>'.$store_details->name.'</b></span><br><span>Images</span><br>';

					$images = $quotedetail['images'];
					$images = explode(",",$images);
					foreach($images as $image){
					$items = $items.'<img width="80" class="item_imgs" src="'.Context::getContext()->shop->getBaseURL(true).'images/quotes/'.$REQUEST['id_quote'].'-'.$image.'" style="margin-left: 10px;border: solid 1px thistle;">';
					}
					$items = $items.'<br><br>';	

					$i++;
					$j++;
				}

				$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html', false, $arrayStreamContext);
				$content = str_replace("{firstname}",$REQUEST['customer_name'],$content);
				$content = str_replace("{lastname}",$REQUEST['customer_lname'],$content);
				$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
				$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
				$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
				$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
				echo $content = str_replace("{items}",$items ,$content);
				die();
			}else{
				
				$content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.html', false, $arrayStreamContext);
				$content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
				$content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
				$content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
				$content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
				echo  $content = str_replace("{message}",nl2br($REQUEST['reply_message']),$content);
				die();
			}	
		}
   }

	public  function saveMessage($request){

		if(isset($request['unable_quote'])){
				$quotedetails = $this->getQuoteDetail($request['id_quote']);
				$items = $this->unableQuoteItems($request);
				$request['reply_message']="";

			$values = array(
	           'id_quote' => (int)$request['id_quote'],
	           'id_customer' => (int)$request['id_customer'],
	           'message' => $items,
	           'message_to' => "customer",
	           'message_status' => 0,
	           'quote_status' => "1-5",
	           'type' => 0,
	           'date_add' => date('Y-m-d H:i:s'),
	       );

			$res = Db::getInstance()->insert('quote_messages', $values);

		/**********update quote status to following up*****************/

			Db::getInstance()->execute('Update 
	         `'._DB_PREFIX_.'quote` set `status` = 5 , `date_upd` = NOW() where `id_quote` ='.$request['id_quote']);

		/**********update quote items `is_complete` param to 1*****************/

			$items_to_edit = $this->unableQuoteItemsID($request);

			foreach ($items_to_edit as $item_id){
				Db::getInstance()->execute('Update 
		         `'._DB_PREFIX_.'quote_items` set `is_complete` = 1 where `id_quote_items` ='.$item_id);
			}
		/**********save message in quote_message table*****************/

			$values = array(
	           'id_quote' => (int)$request['id_quote'],
	           'id_customer' => (int)$request['id_customer'],
	           'message' => 5,
	           'message_status' => 0,
	           'type' => 1,
	           'date_add' => date('Y-m-d H:i:s'),
	       );

			$res = Db::getInstance()->insert('quote_messages', $values);

			$issentmail = $this->sendMailForNewMessage($request['id_quote'],5,$request['reply_message'],$items);

		}else{
		
			$this->context = Context::getContext();
			$store_details = $this->getStoreDetail($request['id_quote']);
			$items = "";
			if($request['quote_status'] == 1){
				$quotedetails = $this->getQuoteDetail($request['id_quote']);
				$i = 0; $j=1;
				
				foreach ($quotedetails as $quotedetail){

					$items = $items.'<span class="title">Product: <b>'.$quotedetail['item'].'</b></span> <br><span>	Loan Range*: <b>$'.$request['from'][$i].' - $'.$request['to'][$i].'</b></span><br><span>Pawn Broker: <b>'.$store_details->name.'</b></span><br><span>Images</span><br>';

					$images = $quotedetail['images'];
					$images = explode(",",$images);
					foreach($images as $image){
						$items = $items.'<img width="80" class="item_imgs" src="'.Context::getContext()->shop->getBaseURL(true).'images/quotes/'.$request['id_quote'].'-'.$image.'" style="margin-left: 10px;border: solid 1px thistle;">';
					}
					$items = $items.'<br><br>';	
						
						Db::getInstance()->execute('Update 
		         `'._DB_PREFIX_.'quote_items` set `price_range_from` = '.$request['from'][$i].', `price_range_to` = '.$request['to'][$i].' where `id_quote_items` ='.$quotedetail['id_quote_items']);

						$i++;
						$j++;
					}

					$request['reply_message'] = str_replace("<FirstName>",$request['customer_name'],$request['reply_message']);
					$request['reply_message'] = str_replace("<LastName>",$request['customer_lname'],$request['reply_message']);
					$request['reply_message'] = str_replace("<ItemList>",$items,$request['reply_message']);


					$values = array(
				           'id_quote' => (int)$request['id_quote'],
				           'id_customer' => (int)$request['id_customer'],
				           'message' => $items,
				           'message_to' => "customer",
				           'message_status' => 0,
				           'quote_status' => "1-2",
				           'type' => 0,
				           'date_add' => date('Y-m-d H:i:s'),
				       );

					$res = Db::getInstance()->insert('quote_messages', $values);


					$issentmail = $this->sendMailForNewMessage($request['id_quote'],$request['quote_status'],$request['reply_message'],$items);

					Db::getInstance()->execute('Update 
			         `'._DB_PREFIX_.'quote` set `status` = 2 , `date_upd` = NOW() where `id_quote` ='.$request['id_quote']);

					$values = array(
			           'id_quote' => (int)$request['id_quote'],
			           'id_customer' => (int)$request['id_customer'],
			           'message' => 2,
			           'message_status' => 0,
			           'type' => 1,
			           'date_add' => date('Y-m-d H:i:s'),
			       );
				   $res = Db::getInstance()->insert('quote_messages', $values);

			}else{
					$values = array(
				           'id_quote' => (int)$request['id_quote'],
				           'id_customer' => (int)$request['id_customer'],
				           'message' => nl2br($request['reply_message']),
				           'message_to' => "customer",
				           'message_status' => 0,
				           'type' => 0,
				           'date_add' => date('Y-m-d H:i:s'),
				       );

					$res = Db::getInstance()->insert('quote_messages', $values);


					$issentmail = $this->sendMailForNewMessage($request['id_quote'],$request['quote_status'],$request['reply_message'],$items);

			}

			
		}

		if($issentmail){
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=true');
		}else{
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=false');
		}
    }

    public function setStatus($request){
    	$id_quote = $request['id_quote'];
    	$quotedetails = $this->getQuoteDetail($id_quote);
		$store_details = $this->getStoreDetail($id_quote);
		$i = 0; $j=1;
		$items = "";
		foreach ($quotedetails as $quotedetail){
			$items = $items.'<span class="title">Product: <b>'.$quotedetail['item'].'</b></span> <br><span>Pawn Broker: <b>'.$store_details->name.'</b></span><br>';

			$images = $quotedetail['images'];
			$images = explode(",",$images);
				foreach($images as $image){
					$items = $items.'<img width="80" class="item_imgs" src="'.Context::getContext()->shop->getBaseURL(true).'images/quotes/'.$id_quote.'-'.$image.'" style="margin-left: 10px;border: solid 1px thistle;">';
				}
			$items = $items.'<br><br>';	


			$i++;
			$j++;
		}

        $this->context = Context::getContext();

        Db::getInstance()->execute('Update 
         `'._DB_PREFIX_.'quote` set `status` ="'.$request['setstatus'].'" , `date_upd` = NOW() where `id_quote` ='.$request['id_quote']);

		$values = array(
	           'id_quote' => (int)$request['id_quote'],
	           'id_customer' => $request['id_customer'],
	           'message' => $request['setstatus'],
	           'message_status' => 0,
	           'type' => 1,
	           'date_add' => date('Y-m-d H:i:s'),
	    );
		$res = Db::getInstance()->insert('quote_messages', $values);

		$issentmail = $this->sendMailForStatusChange($request['id_quote'], $request['setstatus']);
		if($issentmail){
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=true');
		}else{
				Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote').'&id_quote='.(int)$request['id_quote'].'&viewquote&mailsent=false');
		}
	}


	public function sendMailForStatusChange($id_quote, $quote_status){
		$this->context = Context::getContext();
		$customer = $this->getCustomerDetail($id_quote);
		$this->context->customer = (object)$customer[0];
		$quotedetails = $this->getQuoteDetail($id_quote);
		$store_details = $this->getStoreDetail($id_quote);
		$i = 0; $j=1;
		$items = "";
		foreach ($quotedetails as $quotedetail){
			$items = $items.'<span class="title">Product: <b>'.$quotedetail['item'].'</b></span> <br><span>Pawn Broker: <b>'.$store_details->name.'</b></span><br>';


			$images = $quotedetail['images'];
				$images = explode(",",$images);
				foreach($images as $image){
					$items = $items.'<img width="80" class="item_imgs" src="'.Context::getContext()->shop->getBaseURL(true).'images/quotes/'.$id_quote.'-'.$image.'" style="margin-left: 10px;border: solid 1px thistle;">';
				}
			$items = $items.'<br><br>';	

			$i++;
			$j++;
		}

		$vars = array(
			'{firstname}' => $this->context->customer->firstname,
			'{lastname}' => $this->context->customer->lastname,
			'{email}' => $this->context->customer->email,
			'{id_quote}' => $id_quote,
			'{qoute_status}' => $quote_status,
			'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			'{items}' => $items
		);


		if($quote_status == 3){
			$email_template = 'incomplete_quote';
			$subject = Context::getContext()->getTranslator()->trans(
			'Your Quote#'.$id_quote.' is in-complete!',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			);

		}else{

			$email_template = 'complete_quote';
			$subject = Context::getContext()->getTranslator()->trans(
			'Your Quote#'.$id_quote.' is complete!',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			);
		}

		
		if(Mail::Send(
			(int) $this->context->language->id,
			$email_template,
			$subject,
			$vars,
			$this->context->customer->email,
			$this->context->customer->firstname.' '.$this->context->customer->lastname,
			null,
			null,
			null,
			null,
			_PS_MAIL_DIR_,
			false
		)){

			return true;
			
		}else{
			return false;
			
		}
	}

	public function sendMailForNewMessage($id_quote,$quote_status, $message, $items){

		$this->context = Context::getContext();
		$customer = $this->getCustomerDetail($id_quote);
		$this->context->customer = (object)$customer[0];
		if($quote_status == 1){
			$vars = array(
				'{firstname}' => $this->context->customer->firstname,
				'{lastname}' => $this->context->customer->lastname,
				'{email}' => $this->context->customer->email,
				'{id_quote}' => $id_quote,
				'{items}'  => $items,
				'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			);
			//$email_template = 'pending_quote_message_to_customer';
			$email_template = 'quote_notify';
			$subject = Context::getContext()->getTranslator()->trans(
			'Your Quote is Ready!',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			);
		}else if($quote_status == 5){

			$vars = array(
				'{firstname}' => $this->context->customer->firstname,
				'{lastname}' => $this->context->customer->lastname,
				'{email}' => $this->context->customer->email,
				'{id_quote}' => $id_quote,
				'{items}'  => $items,
				'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			);
			//$email_template = 'unable_to_quote_jewelry';
			$email_template = 'quote_notify';
			$subject = Context::getContext()->getTranslator()->trans(
			'Won’t Accept Item',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			);
		}else{
			$vars = array(
				'{firstname}' => $this->context->customer->firstname,
				'{lastname}' => $this->context->customer->lastname,
				'{email}' => $this->context->customer->email,
				'{id_quote}' => $id_quote,
				'{message}'  => nl2br($message),
				'{account_quote_url}' =>$this->context->shop->getBaseURL(true).'quotedetails?id='.$id_quote,
			);
			$email_template = 'quote_message_to_customer';
			$subject = Context::getContext()->getTranslator()->trans(
			'New message for your quote#'.$id_quote.' from admin',
			array(),
			'Emails.Subject',
			$this->context->language->locale
			);
		}

		if(Mail::Send(
			(int) $this->context->language->id,
			$email_template,
			$subject,
			$vars,
			$this->context->customer->email,
			$this->context->customer->firstname.' '.$this->context->customer->lastname,
			null,
			null,
			null,
			null,
			_PS_MAIL_DIR_,
			false
		)){
			return true;
			
		}else{
			return false;
			
		}
	}
	
}