<?php
/**
 * This source file is used for sending quote stats everyday to brokers/suppliers
 *
 */
require_once(__DIR__.'/../../config/config.inc.php');

$all_stores = Db::getInstance()->executeS(' SELECT `id_store` FROM `'._DB_PREFIX_.'quote`');

//$stores = array();
foreach ($all_stores as $all_store){
	$stores[] = $all_store['id_store'];
} 

$stores =array_unique(array_values($stores));

foreach($stores as $store)
{

	$total = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store);
	$total = $total[0]['count(*)'];
	$pending = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 1');
	$pending = $pending[0]['count(*)'];
	$in_progress = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 2');
	$in_progress = $in_progress[0]['count(*)'];

	$unsuccessful = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 3');
	$unsuccessful = $unsuccessful[0]['count(*)'];

	$complete = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 4');
	$complete = $complete[0]['count(*)'];

	$following_up = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 5');
	$following_up = $following_up[0]['count(*)'];

	$needs_review = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 6');
	$needs_review = $needs_review[0]['count(*)'];

	$timed_out = Db::getInstance()->executeS(' SELECT count(*) FROM `'._DB_PREFIX_.'quote` where `id_store` ='.$store.' and `status` = 7');
	$timed_out = $timed_out[0]['count(*)'];

	$store_email =  Db::getInstance()->executeS(' SELECT `email` FROM `'._DB_PREFIX_.'store` where `id_store` ='.$store);
	$supplier = (object)$store_email[0];

	$vars = array(
		'{total}' => $total,
		'{pending}' => $pending,
		'{in-progress}' => $in_progress,
		'{unsuccessful}' => $unsuccessful,
		'{complete}' => $complete,
		'{following-up}' => $following_up,
		'{needs-review}' => $needs_review,
		'{timed-out}' => $timed_out,
	);        
				$email_template = 'quote_stats_report';
				$subject = Context::getContext()->getTranslator()->trans(
				'Stats summary for your store',
				array(),
				'Emails.Subject',
				$context->language->locale
				);
			if(Mail::Send(
				(int) $context->language->id,
				$email_template,
				$subject,
				$vars,
				$supplier->email,
				$customer->firstname.' '.$customer->lastname,
				null,
				null,
				null,
				null,
				_PS_MAIL_DIR_,
				false,
				null,
				null,
				null,
				null
			)){
				$mailsent = true;
			}else{
				$mailsent = false;
			}
}

if($mailsent){
		echo "mail sent successfully";
}else{
		echo "mail can not be sent. Please try later";
}


