<?php
/**
 * This source file is used for updating the quote status to complete if no-one reponde to the quote from 4 days.
 *
 */


require_once(__DIR__.'/../../config/config.inc.php');

$quotes = Db::getInstance()->executeS(' SELECT * FROM `'._DB_PREFIX_.'quote`');

$mailsent = false;

foreach ($quotes as $quote){
	
    /****************if status is in-progress i.e. 2 or following up i.e. 5************************/
    if ( $quote['status'] == 2 || $quote['status'] == 5 ){

      
		$quote_date_upd = date_create($quote['date_upd']);
		$today = date('Y-m-d');
		$today = date_create($today);
		$diff = date_diff($quote_date_upd,$today); 
                
        if ($diff->format("%a") >= 3){
        	
         	/*****************query to update quote status to timed out by default after 4 days**************/
         	
     		Db::getInstance()->execute('Update `'._DB_PREFIX_.'quote` set `status` = 7 , `date_upd` = NOW() where `id_quote` ='.$quote['id_quote']);
     				
 			/*********send mail to customer************************/
				$context = Context::getContext();
				$customerinfo = Db::getInstance()->executeS(' SELECT `firstname`,`lastname`,`email` FROM `'._DB_PREFIX_.'customer` where `id_customer` ='.$quote['id_customer']);
				$customer = (object)$customerinfo[0];
		
				$vars = array(
					'{firstname}' => $customer->firstname,
					'{lastname}' => $customer->lastname,
					'{email}' => $customer->email,
					'{id_quote}' => $quote['id_quote'],
				);
				$email_template = 'autocomplete_quote';
				$subject = Context::getContext()->getTranslator()->trans(
				'Your Quote #'.$quote['id_quote'].' is auotmatically completed',
				array(),
				'Emails.Subject',
				$context->language->locale
				);
			if(Mail::Send(
				(int) $context->language->id,
				$email_template,
				$subject,
				$vars,
				$customer->email,
				$customer->firstname.' '.$customer->lastname,
				null,
				null,
				null,
				null,
				_PS_MAIL_DIR_,
				false,
				null,
				null,
				null,
				null
			)){
				$mailsent = true;
			}else{
				$mailsent = false;
			}
        }
	}
}
if($mailsent){
		echo "mail sent successfully";
}else{
		echo "mail can not be sent. Please try later";
}
