<?php
/**
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2018 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

$sql = array();


$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'emp_store` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `id_emp` int(20) NOT NULL,
  `id_store` int(20) NOT NULL,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'quote` (
  `id_quote` int(20) NOT NULL AUTO_INCREMENT,
  `id_customer` int(20) NOT NULL,
  `id_store` int(20) NOT NULL,
  `store_location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  `supplier_email` varchar(100) NOT NULL,
  PRIMARY KEY (`id_quote`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;';


$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'quote_items` (
  `id_quote_items` int(20) NOT NULL AUTO_INCREMENT,
  `id_quote` int(20) NOT NULL,
  `brand_name` varchar(100) NOT NULL,
  `model_no` varchar(100) NOT NULL,
  `item` varchar(100) NOT NULL,
  `items_condition` varchar(100) NOT NULL,
  `does_item_functional_properly` varchar(100) NOT NULL,
  `metal_type` varchar(100) NOT NULL,
  `weight` varchar(100) NOT NULL,
  `clarity` varchar(100) NOT NULL,
  `carat_size` varchar(100) NOT NULL,
  `center_stone` varchar(100) NOT NULL,
  `secondary_stone` varchar(100) NOT NULL,
  `Additional_stone` varchar(100) NOT NULL,
  `center_stone_cut` varchar(100) NOT NULL,
  `description` varchar(255) NOT NULL,
  `how_much_hoping_to_get` varchar(100) NOT NULL,
  `looking_for` varchar(100) NOT NULL,
  `images` varchar(255) NOT NULL,
  PRIMARY KEY (`id_quote_items`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'quote_messages` (
  `id_quote_message` int(20) NOT NULL AUTO_INCREMENT,
  `id_quote` int(20) NOT NULL,
  `id_customer` varchar(100) NOT NULL,
  `message` varchar(255) NOT NULL,
  `message_to` varchar(100) NOT NULL,
  `message_status` int(100),
  `quote_status` varchar(100) NOT NULL,
  `date_add` datetime NOT NULL,
  PRIMARY KEY (`id_quote_message`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'survey` (
  `id_survey` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `how_did_hear` varchar(255) NOT NULL,
  `other` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `additional_comments` varchar(255) NOT NULL,
  `date_add` datetime NOT NULL,
  `date_upd` datetime NOT NULL,
  PRIMARY KEY (`id_survey`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;';



foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
