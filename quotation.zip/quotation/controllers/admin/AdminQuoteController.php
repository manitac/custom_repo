<?php
/**
*  Copyright (C) Prestalia - All Rights Reserved
*
*  Unauthorized copying of this file, via any medium is strictly prohibited
*  Proprietary and confidential
*
*  @author    Prestalia
*  @copyright 2015-2016 Prestalia
*  @license   This is proprietary software thus it cannot be distributed or reselled
*/

class AdminQuoteController extends ModuleAdminController
{
   
   public function __construct()
    {
            // Enable bootstrap
            $this->bootstrap = true;
            $this->context = Context::getContext();
            $this->table = 'quote';
            $this->className = 'QuoteDetail';

            $this->context->controller = $this;
            // Call of the parent constructor method
            parent::__construct();

            $status_array = array('1' => 'pending', '2' => 'in-progress', '3' => 'in-complete', '4' => 'complete', '5' => 'Following Up (Information Needed)');
            $type_array = array('jewelry' => 'jewelry', 'goods' => 'goods');
            $this->fields_list = array(
                'id_quote' => array('title' => 'ID Quote', 'align' => 'center', 'width' => 25),
                'customer_firstname' => array('title' => 'Customer Name', 'width' => 120,'filter_key' => 'cs!firstname'),
                'customer_email' => array('title' => 'email', 'width' => 120,'filter_key' => 'cs!email'),
                'store_location' => array('title' => 'store location', 'width' => 120,'filter_key' => 'a!store_location'),
                'type' => array(
                    'title' => 'Type',
                    'type' => 'select',
                    'list' => $type_array,
                    'align' => 'center',
                    'filter_key' => 'a!type',
                ),
                 'pending_status' => array(
                    'title' => 'Status',
                    'type' => 'select',
                    'list' => $status_array,
                    'align' => 'center',
                    'filter_key' => 'a!status',
                    'class' => 'quote_status',
                ),
                'date_add' => array('title' => 'Date add', 'type' => 'datetime','filter_key' => 'a!date_add'),

            );
            
            // Update the SQL request of the HelperList
            $this->_select = "cs.`firstname` as customer_firstname,cs.`lastname` as customer_lastname,cs.`email` as customer_email, CASE WHEN a.status = 1 THEN 'pending'
                    WHEN a.status = 2 THEN 'in-progress'
                    WHEN a.status = 3 THEN 'in-complete'
                    WHEN a.status = 4 THEN 'complete'
                    ELSE 'Following Up (Information Needed)' 
                END AS pending_status";
           if($this->context->employee->id_profile == 1){

                $this->_join = 'INNER JOIN `'._DB_PREFIX_.'customer` cs ON (cs.`id_customer` = a.`id_customer`)';

            }else{

                $this->_join = 'INNER JOIN `'._DB_PREFIX_.'customer` cs ON (cs.`id_customer` = a.`id_customer`) AND a.`id_store` = '.$this->context->employee->id_store;

            }
            $this->addRowAction('view');
            
            $QuoteDetail = new QuoteDetail();
           
            // Define meta and toolbar title
            //$this->meta_title = ' Total Quotes';
           // $this->toolbar_title[] = $this->meta_title;

           

            if(isset($_REQUEST['action'])){
                
                 $QuoteDetail->saveMessage($_REQUEST);
            }
           if(isset($_REQUEST['setstatus'])){
                    $QuoteDetail->setStatus($_REQUEST);
            }

            if(isset($_REQUEST['template_preview'])){

                if(isset($_REQUEST['quote_pending'])){

                    $QuoteDetail->previewMessageTemplate($_REQUEST);
                   
                }else{
                    $QuoteDetail->previewTemplate($_REQUEST);
                }
            }
    }
    public function renderView()
    {

        $tpl = $this->context->smarty->createTemplate(dirname(__FILE__). '/../../views/templates/admin/view.tpl');
        
        $tpl->assign( array(
                            'mainquote' => $this->object->getMainQuote(Tools::getValue('id_quote')),
                            'quotedetails'=> $this->object->getQuoteDetail(Tools::getValue('id_quote')),
                            'quotemessages'  => $this->object->getQuoteMessages(Tools::getValue('id_quote')),
                            'customerdetails'=> $this->object->getCustomerDetail(Tools::getValue('id_quote')),
                            'admin_quote_url' => $this->context->link->getAdminLink('AdminQuote'),
                            'site_url' => $this->context->shop->getBaseURL(true),
                            'img_url'  => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',
                            'status_array' =>  array('1' => 'pending','2' => 'in-progress', '3' => 'in-complete', '4' => 'complete', '5' => 'Following Up (Information Needed)'),
            ));
        if(Tools::getValue('mailsent')){
             $tpl->assign('mailstatus', Tools::getValue('mailsent'));
        }
        if(Tools::getValue('template_preview')){
             $tpl->assign('template_preview', Tools::getValue('template_preview'));
        }
        return $tpl->fetch();
    }
    public function renderKpis()
    {
        $time = time();
        $kpis = array();

        /* The data generation is located in AdminStatsControllerCore */
        $QuoteDetail = new QuoteDetail();

        $helper = new HelperKpi();
        $helper->id = 'box-pending-messages';
        $helper->icon = 'icon-envelope';
        $helper->color = 'color1';
        $helper->href = $this->context->link->getAdminLink('AdminQuote');
        $helper->title = $this->trans('Total Pending Quotes', array(), 'Quotation');
        $helper->value = $QuoteDetail->getStatus(1);
        $kpis[] = $helper->generate();

        $helper = new HelperKpi();
        $helper->id = 'box-age';
        $helper->icon = 'icon-envelope';
        $helper->color = 'color1';
        $helper->href = $this->context->link->getAdminLink('AdminQuote');
        $helper->title = $this->trans('Total In-Progress Quotes', array(), 'Quotation');
        $helper->value = $QuoteDetail->getStatus(2);
        $kpis[] = $helper->generate();

        $helper = new HelperKpi();
        $helper->id = 'box-age';
        $helper->icon = 'icon-envelope';
        $helper->color = 'color1';
        $helper->href = $this->context->link->getAdminLink('AdminQuote');
        $helper->title = $this->trans('Total In-Complete Quotes', array(), 'Quotation');
        $helper->value = $QuoteDetail->getStatus(3);
        $kpis[] = $helper->generate();

        $helper = new HelperKpi();
        $helper->id = 'box-age';
        $helper->icon = 'icon-envelope';
        $helper->color = 'color1';
        $helper->href = $this->context->link->getAdminLink('AdminQuote');
        $helper->title = $this->trans('Total Complete Quotes', array(), 'Quotation');
        $helper->value = $QuoteDetail->getStatus(4);
        $kpis[] = $helper->generate();

        $helper = new HelperKpiRow();
        $helper->kpis = $kpis;
        return $helper->generate();
    }

}
