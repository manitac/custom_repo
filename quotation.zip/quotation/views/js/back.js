/**
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2018 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/
jQuery(document).ready(function(){

	$( "td.quote_status" ).each(function( index ) {

		if($(this).text().match('Unsuccessful')) {
	        $(this).html('<span class="btn-danger" style="background-color: #FFC000;">Unsuccessful</span>');
	    }else if($(this).text().match('Info Needed')) {
	         $(this).html('<span class="btn-warning" style="background-color: #2E75B6;">Info Needed</span>');
	    }else if($(this).text().match('Complete')) {
	    	$(this).html('<span class="btn-success" style="background-color: #00B050;">Complete</span>');
	    }else if($(this).text().match('New Quote')) {
	         $(this).html('<span class="btn-warning" style="background-color: #FF0000;">New Quote</span>');
	    }else if($(this).text().match('Offer Sent')) {
	         $(this).html('<span class="btn-info" style="background-color: #2E75B6;">Offer Sent</span>');
	    }else if($(this).text().match('Needs Review')) {
	        $(this).html('<span class="btn-info" style="background-color: #FF0000;">Needs Review</span>');
	    }else{ 
	        $(this).html('<span class="btn-info" style="background-color: #FFC000;">Quote Expired</span>');
	    } 
	});
		
	$(".box-stats").on('click',function(){

		if($(this).find('.title').text().match('New Quote')){
			    $('.filtercenter').val(1).change();
		}else if($(this).find('.title').text().match('Offer Sent')){
			$('.filtercenter').val(2).change();
		}else if($(this).find('.title').text().match('Unsuccessful')){
			$('.filtercenter').val(3).change();
		}else if($(this).find('.title').text().match('Complete')){
			$('.filtercenter').val(4).change();
		}
		
	});

	$(".to").focusout(function(){

		var from = parseInt($(this).closest('.items_price_range').find('input.from').val()); 
		var to = parseInt($(this).val());
		if ( to < from ){ 
			alert("please enter correct range value");
			$(this).css('border','solid 1px red');
			$('.submitReply').addClass('disabled');
		}else{
			$(this).css('border','1px solid #C7D6DB');
			$('.submitReply').removeClass('disabled');
		}

	});
});