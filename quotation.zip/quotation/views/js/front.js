/**
* 2007-2018 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author    PrestaShop SA <contact@prestashop.com>
*  @copyright 2007-2018 PrestaShop SA
*  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*
* Don't forget to prefix your containers with your own identifier
* to avoid any conflicts with others containers.
*/


$(document).ready(function() {
   if ($('#desktop_user_info .user-info .account').length <= 0) {
            $('.getquote_menu a').attr("href","#");
            $('.getquote_menu a').attr("data-toggle", "modal"); 
            $('.getquote_menu a').attr("data-target", "#signin");
    }

    var inputs = document.querySelectorAll( '.inputfile' ); 
    Array.prototype.forEach.call( inputs, function( input )
    {
        var label  = input.nextElementSibling,
        labelVal = label.innerHTML;
        input.addEventListener( 'change', function( e )
        {
            var files = $(".inputfile").prop("files");
            var fileName = $.map(files, function (val) { return val.name; }).join(',');
         
            var totalsize = 0;
            var fi = document.getElementById('file-7'); 
            for (var i = 0; i <= fi.files.length - 1; i++) {
                  var fsize = fi.files.item(i).size;  
                  totalsize = totalsize + fsize;
            }
            if(totalsize >= 10485760){
                      alert("Total Size of all images must not exceed 10MB ")
                      $('button[type="submit"]').attr('disabled','disabled');
                      $('.input_files').css('border','solid 1px red');
            }else if( this.files && this.files.length < 3 ){
                  alert("Please add minimum of 3 images.");
                  $('button[type="submit"]').attr('disabled','disabled');
                  $('.input_files').css('border','solid 1px red');
             }else{
                  if( fileName && this.files.length >= 3 && totalsize <= 10485760){
                      $('.input_files span').html(fileName);
                      $('button[type="submit"]').removeAttr('disabled');
                      $('.input_files').css('border','initial');
                  }
            }
        });

      // Firefox bug fix
      input.addEventListener( 'focus', function(){ input.classList.add( 'has-focus' ); });
      input.addEventListener( 'blur', function(){ input.classList.remove( 'has-focus' ); });
    });

}); 
//quotation form js
$("#quote .postcode, #goodsquote .postcode, .how_much_hoping_to_get, .phone1, .phone2, .phone3").keypress(function (e) {
   //if the letter is not digit then display error and don't type anything
   if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
      //display error message
      $(this).siblings('.input-message').html("Digits Only").fadeIn("slow");
      //alert("please enter no. only");
             return false;
  }
  else{
    $(this).siblings('.input-message').html("Digits Only").fadeOut("slow");
  }
 });

$('#customer-form input[name="optin"]').siblings('label').css( "margin-left", "0px" );
