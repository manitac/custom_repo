<?php
/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
class HandlequoteControllerCore extends FrontController
{
    public $php_self = 'handlequote';
     /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    { 
	   
	   if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){
			// get number of unread message count in each quote
		    $msql ="SELECT id_quote,COUNT(*) as number FROM "._DB_PREFIX_."quote_messages Where message_status=0 AND id_customer=".(int) $this->context->customer->id." GROUP BY id_quote";
		    $message_count = Db::getInstance()->executeS($msql);
			$quote = $this->getTemplateVarOrders();
			$getstoredata = $this->get_allstore($quote[0]['preferred_store_locations']);
			$this->context->smarty->assign(array(
				'quotes' => $quote,
				'stores' => $getstoredata,
				'message' => $message_count,
			));

			parent::initContent();
			$this->setTemplate('cms/handlequote');
	   } else {
			Tools::redirect('index.php'); 
	   }
    }
	//get all data of quotes
	public function getTemplateVarOrders()
    {
       $quotes = array();
       //  get all quotes of current customers
	   $sql = 'SELECT DISTINCT qt.`id_quote`,q.type,q.status,q.date_add,q.store_location,q.id_store
			    FROM `' . _DB_PREFIX_ . 'quote` q INNER JOIN `' . _DB_PREFIX_ . 'quote_items` qt
                        ON q.id_quote=qt.id_quote where q.id_customer='.(int) $this->context->customer->id.' order by id_quote DESC';
       $quotes = Db::getInstance()->executeS($sql);
        return $quotes;
    }
	//all stores details 
	function get_allstore($store_id) {
		
		$stores = Db::getInstance()->getrow('
        SELECT s.email,s.city,s.name, cl.name country
        FROM '._DB_PREFIX_.'store s
        '.Shop::addSqlAssociation('store', 's').'
        LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = s.id_country)
        WHERE s.active = 1 AND s.id_store=5 AND cl.id_lang = '.(int)$this->context->language->id);
		return $stores;
	}

}
