<?php
/**
 * Author: Chetu Team
 * Controller for jewelry quote submission page
 * Class: QuoteController
*/
class GoodsquoteController extends FrontController {

    /**
     * Mapping of PS Store id to PA store id
     * Created For: mnt file store id
    */
    public $store_ids_conversion = [
                    '2' => 231,
                    '3' => 232,
                    '4' => 233,
                    '5' => 234,
                    '6' => 235,
                    '7' => 236,
                    '8' => 237,
                    '9' => 238,
                    '10' => 240,
                    '11' => 241,
                    '12' => 242,
                    '13' => 243,
                    '14' => 245,
                    '15' => 246,
                    '16' => 247,
                    '17' => 248,
                    '18' => 250,
                    '19' => 251,
                    '20' => 252,
                    '21' => 253,
                    '22' => 254,
                    '23' => 255,
                    '24' => 258,
                    '25' => 259,
    ];

    /**
     * Initial function called when controller loaded
     * Function: initContent
    */
   public function initContent()
    {
        if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){
            
            // get order information-customer-service page id from database
            $queryhowit_work=Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow("SELECT id_cms FROM `"._DB_PREFIX_."cms_lang` where `link_rewrite`='how-it-works'");
            
            $states = State::getStatesByIdCountry(21);

            $customer = new CustomerCore($this->context->customer->id);
            $sql = 'SELECT * FROM `'._DB_PREFIX_.'address` 
                        WHERE `id_customer` = '.(int)$customer->id;
            $customer_address = Db::getInstance()->executeS($sql);

            parent::initContent();
            $this->context->smarty->assign(array(
                        'customer' => $customer,
                        'address' => (object)$customer_address[0],
                        'states' => $states,
                        'img_url' => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',
                        'pawn_work' => $queryhowit_work['id_cms'],
                        ));

            
            if(isset($_FILES["item_images"]["type"])){
            
                    /****** CUSTOMER INFO UPDATED HERE ***********/
                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'customer set 
                                            `firstname` = "'.$_POST['firstname'].'",
                                            `lastname` = "'.$_POST['lastname'].'" 
                                            WHERE `id_customer` = '.(int)$this->context->customer->id
                                    );
                
                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'address set 
                                                `firstname` = "'.$_POST['firstname'].'",
                                                `lastname` = "'.$_POST['lastname'].'",
                                                `phone` = "'.$_POST['phone1'].$_POST['phone2'].$_POST['phone3'].'",
                                                `address1` = "'.$_POST['address1'].'",
                                                `address2` = "'.$_POST['address2'].'",
                                                `city` = "'.$_POST['city'].'",
                                                `id_state` = '.(int)$_POST['id_state'].',
                                                `postcode` = '.(int)$_POST['postcode'].'
                                                 WHERE `id_customer` = '.(int)$customer->id
                                            );
                    /****************** QUOTE INFO ADDED HERE ********/ 

                    
                    if($_POST['quoteid'] == 0){
                        
                        $query = 'INSERT INTO `'._DB_PREFIX_.'quote`(`id_customer`, `status`, `type`, `id_store`, `store_location`,`date_add`, `date_upd`) VALUES ('.(int)$customer->id.',"3","goods",'.$_POST['id_store'].',"'.$_POST['preferred_store_locations'].'",NOW(),NOW())';

                        Db::getInstance()->execute($query);
                    
                        $quote_id = Db::getInstance()->Insert_ID();

                        if ($_POST['submit_quotes'] == 1) {

                            $status = 1;

                            $query = 'UPDATE `' . _DB_PREFIX_ . 'quote`  SET `status` = "' . $status . '" WHERE `id_quote` =' . $quote_id;
                            Db::getInstance()->execute($query);
                        }

                    }else{

                        $quote_id = $_POST['quoteid'];

                        if ($_POST['submit_quotes'] == 1) {

                            $status = 1;
                            $query = 'UPDATE `' . _DB_PREFIX_ . 'quote`  SET `status` = "' . $status . '" WHERE `id_quote` =' . $quote_id;
                            Db::getInstance()->execute($query);
                        }

                    }

                    if($quote_id != 0){
                        $query = 'INSERT INTO `'._DB_PREFIX_.'quote_items`(
                                                            `id_quote`,
                                                            `brand_name`,
                                                            `model_no`,
                                                            `item`,
                                                            `items_condition`,
                                                            `does_item_functional_properly`,
                                                            `description`,
                                                            `how_much_hoping_to_get`,
                                                            `looking_for`
                                                        )VALUES (
                                                            '.(int)$quote_id.',
                                                            "'.$_POST['brand_name'].'",
                                                            "'.$_POST['model_no'].'",
                                                            "'.$_POST['item'].'",
                                                            "'.$_POST['items_condition'].'",
                                                            "'.$_POST['does_item_functional_properly'].'",
                                                            "'.$_POST['description'].'",
                                                            "'.$_POST['how_much_hoping_to_get'].'",
                                                            "'.$_POST['looking_for'].'"
                                )';
                                Db::getInstance()->execute($query);
								$quote_item_id = Db::getInstance()->Insert_ID(); 
                                    
                                // File upload configuration
                                $targetDir =  "./././images/quotes/large-thumbnails/".$quote_id.'-';
                                $targetDirsmall =  "./././images/quotes/small-thumbnails/".$quote_id.'-';

                                
                                $images_arr = array();
                                foreach($_FILES as $key){
                                    $image_name = $key['name'];
                                    $tmp_name   = $key['tmp_name'];
                                    $size       = $key['size'];
                                    $type       = $key['type'];
                                    $error      = $key['error'];
                                    // File upload path
                                    $fileName = uniqid().'_'.basename($key['name']);
                                    $sourcefile= $key['tmp_name'];
                                    
                                    ImageManager::resize(
                                        $key['tmp_name'],
                                        $targetDirsmall.$fileName,
                                        (int)100, (int)100
                                    );

                                    // image aspect ratio calculated here
                                    $image_info = getimagesize($sourcefile);
                                    $image_width = $image_info[0];
                                    $image_height = $image_info[1];
                                    if($image_width < 800 && $image_height < 600){
                                        move_uploaded_file($sourcefile,$targetDir.$fileName);
                                    }else{
                                        $aspectRatio = ( $image_width / $image_height );
                                        
                                        if($image_width >= 800 ){
                                             $newWidth = 800;
                                         }else{
                                            $newWidth = $image_width;
                                         }
                                       
                                        $newHeight = floor( $newWidth / $aspectRatio );
                                        $newWidth = floor( $newHeight * $aspectRatio );
                                        ImageManager::resize(
                                            $sourcefile,
                                            $targetDir.$fileName,
                                            (int)$newWidth, (int)$newHeight
                                        );

                                    }
                                    $images_arr[] = $fileName;
                                }
                                if($images_arr){

                                    $images = implode(",",$images_arr);

                                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
                                            `images` = "'.$images.'"
                                            WHERE `id_quote_items` = '.(int)$quote_item_id
                                    );
                                }
                            // sending email to customer for quotation
                                $vars = array(
                                    '{firstname}' => $this->context->customer->firstname,
                                    '{lastname}' => $this->context->customer->lastname,
                                    '{email}' => $this->context->customer->email,
                                );
                                
                                Mail::Send(
                                    (int) $this->context->language->id,
                                    'customer_quote',
                                    Context::getContext()->getTranslator()->trans(
                                    'Pawn America has received your quote #'.$quote_id,
                                    array(),
                                    'Emails.Subject',
                                    $language->locale
                                    ),
                                    $vars,
                                    $this->context->customer->email,
                                    $this->context->customer->firstname.' '.$this->context->customer->lastname,
                                    null,
                                    null,
                                    null,
                                    null,
                                    _PS_MAIL_DIR_,
                                    false
                                );
                    //send mail to supplier for quote
                    $supplier_email = Db::getInstance()->executeS('SELECT `email` FROM `'._DB_PREFIX_.'store` 
                        WHERE `id_store` = '.(int)$_POST['id_store']);

                    if ( $supplier_email && !empty($supplier_email[0]['email'])) {

                            if($_SERVER['REMOTE_ADDR'] == '182.156.245.130'){
                                //Your email id
                                $supplier_email = 'manitak@chetu.com';
                            } else {
                                // Supplier email id
                                $supplier_email = $supplier_email[0]['email'];
                            }

                            Mail::Send(
                                (int) $this->context->language->id,
                                'quote_mail_supplier',
                                Context::getContext()->getTranslator()->trans(
                                'Customer has requested quote #'.$quote_id.' for your store',
                                array(),
                                'Emails.Subject',
                                $language->locale
                                ),
                                $vars,
                                $supplier_email,
                                $this->context->customer->firstname.' '.$this->context->customer->lastname,
                                null,
                                null,
                                null,
                                null,
                                _PS_MAIL_DIR_,
                                false
                            );
                    }

                    // check if customer has filled survey or not

                    $query = 'SELECT * FROM `'._DB_PREFIX_.'survey` where `customer_id` = '.(int)$customer->id;
                    $customer = Db::getInstance()->executeS($query);
                    if($customer){
                        $result['customer_type'] = 'existing';
                    }else{
                        $result['customer_type'] = 'new';
                    }
					/* create mmt file code start here */
                    $_POST['id_store'] = (array_key_exists($_POST['id_store'],$this->store_ids_conversion) ? $this->store_ids_conversion[$_POST['id_store']] : '');

					if(!file_exists($_SERVER['DOCUMENT_ROOT'] . "/quote_mnt/download.OQR.".$_POST['id_store']."097".$quote_id.".mnt")) {
						$content = '<Header download_id="OQR.'.$quote_id.'" application_date="'.date('Y-m-d').'" target_org_node="STORE:'.$_POST['id_store'].'" deployment_name="OQR.'.$quote_id.'" download_time="IMMEDIATE" apply_immediately="true" /> ';
						$content .= " \r\n";
						$content .= 'INSERT|EMPLOYEE_TASK|'.$_POST['id_store'].'|'.$_POST['id_store'].'097'.$quote_id.'|'.date('Y-m-d').' 00:00:00|'.date('Y-m-d', strtotime(' +1 day')).' 00:00:00|QUOTE|Online Quote Request|'.$quote_id.' - '.$this->context->customer->firstname.' '.$this->context->customer->lastname.'|HIGH|STORE|null|false|OPEN';
						$result['content'] = $content;
						$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/quote_mnt/download.OQR.".$_POST['id_store']."097".$quote_id.".mnt","wb");
						fwrite($fp,$content);
						fclose($fp);
					}
					/* create mmt file code end here */
                    $result['quoteid'] = $quote_id;
					
                    echo $result = json_encode( $result );
                    die();
                }
            }
            $this->setTemplate('cms/goodsquote');    
           
        }else{
             Tools::redirect('index.php'); 
        }
    }
}