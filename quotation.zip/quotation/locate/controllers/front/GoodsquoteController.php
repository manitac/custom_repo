<?php
class GoodsquoteController extends FrontController {
  
   public function initContent()
    {
        if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){
            
            
            $states = State::getStatesByIdCountry(21);

            $customer = new CustomerCore($this->context->customer->id);
            $sql = 'SELECT * FROM `'._DB_PREFIX_.'address` 
                        WHERE `id_customer` = '.(int)$customer->id;
            $customer_address = Db::getInstance()->executeS($sql);

            parent::initContent();
            $this->context->smarty->assign(array(
                        'customer' => $customer,
                        'address' => (object)$customer_address[0],
                        'states' => $states,
                        'img_url' => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',
                        ));

            
            if(isset($_FILES["item_images"]["type"])){
            
                    /****** CUSTOMER INFO UPDATED HERE ***********/
                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'customer set 
                                            `firstname` = "'.$_POST['firstname'].'",
                                            `lastname` = "'.$_POST['lastname'].'" 
                                            WHERE `id_customer` = '.(int)$this->context->customer->id
                                    );
                
                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'address set 
                                                `firstname` = "'.$_POST['firstname'].'",
                                                `lastname` = "'.$_POST['lastname'].'",
                                                `phone` = "'.$_POST['phone1'].$_POST['phone2'].$_POST['phone3'].'",
                                                `address1` = "'.$_POST['address1'].'",
                                                `address2` = "'.$_POST['address2'].'",
                                                `city` = "'.$_POST['city'].'",
                                                `id_state` = '.(int)$_POST['id_state'].',
                                                `postcode` = '.(int)$_POST['postcode'].'
                                                 WHERE `id_customer` = '.(int)$customer->id
                                            );
                    /****************** QUOTE INFO ADDED HERE ********/ 

                    
                    if($_POST['quoteid'] == 0){
                        
                        $query = 'INSERT INTO `'._DB_PREFIX_.'quote`(`id_customer`, `status`, `type`, `id_store`, `store_location`,`date_add`, `date_upd`) VALUES ('.(int)$customer->id.',"3","goods",'.$_POST['id_store'].',"'.$_POST['preferred_store_locations'].'",NOW(),NOW())';

                        Db::getInstance()->execute($query);
                    
                        $quote_id = Db::getInstance()->Insert_ID();

                        if ($_POST['submit_quotes'] == 1) {

                            $status = 1;

                            $query = 'UPDATE `' . _DB_PREFIX_ . 'quote`  SET `status` = "' . $status . '" WHERE `id_quote` =' . $quote_id;
                            Db::getInstance()->execute($query);
                        }

                    }else{

                        $quote_id = $_POST['quoteid'];

                        if ($_POST['submit_quotes'] == 1) {

                            $status = 1;
                            $query = 'UPDATE `' . _DB_PREFIX_ . 'quote`  SET `status` = "' . $status . '" WHERE `id_quote` =' . $quote_id;
                            Db::getInstance()->execute($query);
                        }

                    }
                        $query = 'INSERT INTO `'._DB_PREFIX_.'quote_items`(
                                                            `id_quote`,
                                                            `brand_name`,
                                                            `model_no`,
                                                            `item`,
                                                            `items_condition`,
                                                            `does_item_functional_properly`,
                                                            `description`,
                                                            `how_much_hoping_to_get`,
                                                            `looking_for`
                                                        )VALUES (
                                                            '.(int)$quote_id.',
                                                            "'.$_POST['brand_name'].'",
                                                            "'.$_POST['model_no'].'",
                                                            "'.$_POST['item'].'",
                                                            "'.$_POST['items_condition'].'",
                                                            "'.$_POST['does_item_functional_properly'].'",
                                                            "'.$_POST['description'].'",
                                                            "'.$_POST['how_much_hoping_to_get'].'",
                                                            "'.$_POST['looking_for'].'"
                                )';
                                Db::getInstance()->execute($query);
                                    
                                // File upload configuration
                                $targetDir =  "./././images/quotes/".$quote_id.'-';
                                
                                $images_arr = array();
                                foreach($_FILES['item_images']['name'] as $key=>$val){
                                    $image_name = $_FILES['item_images']['name'][$key];
                                    $tmp_name   = $_FILES['item_images']['tmp_name'][$key];
                                    $size       = $_FILES['item_images']['size'][$key];
                                    $type       = $_FILES['item_images']['type'][$key];
                                    $error      = $_FILES['item_images']['error'][$key];
                                    
                                    // File upload path
                                    $fileName = basename($_FILES['item_images']['name'][$key]);
                                    $targetFilePath = $targetDir . $fileName;
                                    
                                    // Check whether file type is valid
                                    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
                                    if(move_uploaded_file($_FILES['item_images']['tmp_name'][$key],$targetFilePath)){
                                            $images_arr[] = $fileName;
                                    }
                                }
                                if($images_arr){

                                    $images = implode(",",$images_arr);

                                    Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
                                            `images` = "'.$images.'"
                                            WHERE `id_quote` = '.(int)$quote_id
                                    );
                                }
                            // sending email to customer for quotation
                                $vars = array(
                                    '{firstname}' => $this->context->customer->firstname,
                                    '{lastname}' => $this->context->customer->lastname,
                                    '{email}' => $this->context->customer->email,
                                );
                                
                                Mail::Send(
                                    (int) $this->context->language->id,
                                    'customer_quote',
                                    Context::getContext()->getTranslator()->trans(
                                    'Pawn America has received your quote',
                                    array(),
                                    'Emails.Subject',
                                    $language->locale
                                    ),
                                    $vars,
                                    $this->context->customer->email,
                                    $this->context->customer->firstname.' '.$this->context->customer->lastname,
                                    null,
                                    null,
                                    null,
                                    null,
                                    _PS_MAIL_DIR_,
                                    false
                                );
                    //send mail to supplier for quote

                                Mail::Send(
                                    (int) $this->context->language->id,
                                    'quote_mail_supplier',
                                    Context::getContext()->getTranslator()->trans(
                                    'Customer has requested quote for your store',
                                    array(),
                                    'Emails.Subject',
                                    $language->locale
                                    ),
                                    $vars,
                                    'manitak@chetu.com',
                                    $this->context->customer->firstname.' '.$this->context->customer->lastname,
                                    null,
                                    null,
                                    null,
                                    null,
                                    _PS_MAIL_DIR_,
                                    false
                                );

                    // check if customer has filled survey or not

                    $query = 'SELECT * FROM `'._DB_PREFIX_.'survey` where `customer_id` = '.(int)$customer->id;
                    $customer = Db::getInstance()->executeS($query);
                    if($customer){
                        $result['customer_type'] = 'existing';
                    }else{
                        $result['customer_type'] = 'new';
                    }
                    $result['quoteid'] = $quote_id;
                    echo $result = json_encode( $result );
                    die();
            }
            $this->setTemplate('cms/goodsquote');    
           
        }else{
             Tools::redirect('index.php'); 
        }
    }
}