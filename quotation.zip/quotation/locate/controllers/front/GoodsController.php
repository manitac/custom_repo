<?php
class GoodsController extends FrontController {
  
  	public function initContent()
  	{
  		if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){

  			parent::initContent();
	  		$this->context->smarty->assign(array(
	                        'img_url' => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',
	        ));
			$this->setTemplate('cms/goods');
          
        }else{ 
	  		
			Tools::redirect('index.php'); 
		}
	}	
}