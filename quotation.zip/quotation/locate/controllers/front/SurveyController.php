<?php
/**
 * Author: Chetu Team
 * Controller for Survey page
 * Class: SurveyController
*/
class SurveyController extends FrontController {
  
  	public function initContent()
  	{
  		
		if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){
            
					$query = 'SELECT * FROM `'._DB_PREFIX_.'survey` where `customer_id` = '.(int)$this->context->customer->id;
                    $customer = Db::getInstance()->executeS($query);
                    if($customer){
                    	Tools::redirect('index.php');
                    }else{

                    	parent::initContent();
                    	$this->context->smarty->assign(array(
	                        'img_url' => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',
	        			));
		  	
						if(isset($_REQUEST['how_did_hear'])) {
						
							$customer_id = $this->context->customer->id;
							
							if(isset($_REQUEST['quote_id'])) {
								$query = 'INSERT INTO `'._DB_PREFIX_.'survey` (`customer_id`,`quote_id`,`how_did_hear`,`other`,`rating`,`additional_comments`,`date_add`, `date_upd`) VALUES ('.(int)$customer_id.',
								'.$_REQUEST['quote_id'].',"'.$_REQUEST['how_did_hear'].'","'.$_REQUEST['other'].'","'.$_REQUEST['rating'].'","'.$_REQUEST['additional_comments'].'",NOW(),NOW())';
			                    Db::getInstance()->execute($query);

			                   $vars = array(
									'{firstname}' => $this->context->customer->firstname,
									'{lastname}' => $this->context->customer->lastname,
									'{email}' => $this->context->customer->email,
								);
								
								Mail::Send(
									(int) $this->context->language->id,
									'customer_survey',
									Context::getContext()->getTranslator()->trans(
									'Thanks for participating in survey',
									array(),
									'Emails.Subject',
									$language->locale
									),
									$vars,
									$this->context->customer->email,
									$this->context->customer->firstname.' '.$this->context->customer->lastname,
									null,
									null,
									null,
									null,
									_PS_MAIL_DIR_,
									false
								);
								echo "success";
								die();
							}
					}
				}
				
				$this->setTemplate('cms/survey'); // name of the smarty template (see next section)
			}else{
            	Tools::redirect('index.php');
        	}	
	}
}