<?php
/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
class QuotedetailsControllerCore extends FrontController
{
    public $php_self = 'quotedetails';
    /**
     * Assign template vars related to page content.
     *
     * @see FrontController::initContent()
     */
    public function initContent()
    {   
		 if ($this->context->customer->isLogged() && Module::isEnabled('quotation')){
			if($_POST['quote_pending']) {
                                $this->previewMessageTemplate($_POST);die;                            
                        }
			$sql = 'UPDATE `' . _DB_PREFIX_ . 'quote_messages` set message_status = 1 where id_quote='.$_GET['id'].' AND id_customer='.(int) $this->context->customer->id ;
			$quotes = Db::getInstance()->execute($sql);
			if(isset($_POST['id_customer'])) {
				if($result = $this->savedata($_POST)) {
					echo true;	
				} else {
					echo false;
				}
			    die;
		    }
			
			$quotedata = $this->getquotedata($_GET['id']);
			$getmessagedata = $this->getmessagedata($_GET['id']);
			//get all stores data 
			//$getstoredata = $this->get_allstore($quotedata[0]['preferred_store_locations']);
			$this->context->smarty->assign(array(
				'quotedata' => $quotedata,
				'messagedata' => $getmessagedata,
				
			));
			parent::initContent();
			$this->setTemplate('cms/quotedetails');
		 }else{ 
				
				Tools::redirect('index.php'); 
		}
    }
	
	//get all data of quotes
	function getquotedata($quote_id) {
		$quotes = array();
       //  get all quotes of current customers
	    $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'quote` q INNER JOIN `' . _DB_PREFIX_ . 'quote_items` qt
                ON q.id_quote=qt.id_quote where qt.id_quote='.(int) $quote_id.' and q.id_customer='.(int) $this->context->customer->id;
       $quotes = Db::getInstance()->executeS($sql);
        return $quotes;
	}
	//get all data of quotes
	function getmessagedata($quote_id) {
		$quotes = array();
       //  get all quotes of current customers
	   $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'quote_messages` where id_quote='.(int) $quote_id.' ORDER BY `id_quote_message`' ;
       $quotes = Db::getInstance()->executeS($sql);
        return $quotes;
	}
	// save data in message tables
	function savedata($data) {
		$mailParams = array(
						'{email}' => $this->context->customer->email,
						'{lastname}' => $this->context->customer->lastname,
						'{firstname}' => $this->context->customer->firstname,
						'{message}' => nl2br($data['reply_message']),
						'{quote_id}' => $data['id_quote'],
					);
			if (
				Mail::Send(
					$this->context->language->id,
					'quote_message',
					$this->trans(
						'Quote-#'.$data['id_quote']." message submitted by customer",
						array(),
						'Emails.Subject'
					),
					$mailParams,
					'arunk4@chetu.com',
					$this->context->customer->firstname.' '.$this->context->customer->lastname
				)
			) { 
				$sql = 'INSERT into `' . _DB_PREFIX_ . 'quote_messages`(`id_quote`,`id_customer`,`message`,`message_to`,`message_status`,`quote_status`,`type`,`date_add`)
						values('.$data['id_quote'].','.$data['id_customer'].',"'.nl2br($data['reply_message']."Regards \n".$this->context->customer->firstname."  ".$this->context->customer->lastname."\n").'","Customer Service",0,'.$data['quote_status'].',0,NOW())';
				$quotes = Db::getInstance()->execute($sql);
				return $quotes;
			}
	}
	//all stores details 
	function get_allstore($store_id) {
		
		$stores = Db::getInstance()->getrow('
        SELECT s.email,s.city,s.name, cl.name country
        FROM '._DB_PREFIX_.'store s
        '.Shop::addSqlAssociation('store', 's').'
        LEFT JOIN '._DB_PREFIX_.'country_lang cl ON (cl.id_country = s.id_country)
        WHERE s.active = 1 AND s.id_store='.$store_id.' AND cl.id_lang = '.(int)$this->context->language->id);
		return $stores;
	}
        /* GET MESSAGE TEMPLATE DATA    */
         public function previewMessageTemplate($REQUEST){
             
           // $store_details = $this->getStoreDetail($REQUEST['id_quote']);
                    $this->context = Context::getContext();
                    $arrayStreamContext = @stream_context_create(array('http' => array('method' => 'GET', 'timeout' => 8)));

                    if( $_REQUEST['quote_pending'] == "unable_to_quote" ){
                            $content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/unable_to_quote_jewelry.html', false, $arrayStreamContext);
                    }
                    if( $_REQUEST['quote_pending'] == "accepted_the_quote" ){

                            $content = Tools::file_get_contents(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html', false, $arrayStreamContext);

                    }
                    
                    $messages = Db::getInstance()->executeS('SELECT `message` FROM `'._DB_PREFIX_.'quote_messages` where `id_quote_message` ='.$_REQUEST['message_id'] );
                    $items = (object)$messages[0];
                    $items = $items->message;

                    $content = str_replace("{firstname}",$REQUEST['customer_name'],$content);
                    $content = str_replace("{lastname}",$REQUEST['customer_lname'],$content);
                    $content = str_replace("{shop_name}",Configuration::get('PS_SHOP_NAME'),$content);
                    $content = str_replace("{shop_logo}",_PS_BASE_URL_.__PS_BASE_URI__.'/img/'.Configuration::get('PS_LOGO'),$content);
                    $content = str_replace("{shop_url}",Context::getContext()->shop->getBaseURL(true),$content);
                    $content = str_replace("{account_quote_url}",$this->context->link->getPageLink('index',true).'quotedetails?id='.$REQUEST['id_quote'],$content);
                    echo $content = str_replace("{items}",$items ,$content);
                    die();

        }

}
