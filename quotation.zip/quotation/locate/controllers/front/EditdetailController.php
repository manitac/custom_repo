<?php

/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */
class EditdetailControllerCore extends FrontController {

    public function initContent() {
        if ($this->context->customer->isLogged() && Module::isEnabled('quotation')) {
			
			if(isset($_POST['image'])){
				$quotdata= $this->getquotedata(Tools::getValue('item_id'));
				//break into string to array 
				$imag_array = explode(",",$quotdata[0]['images']); 
				//$imag_arr = explode(',',Tools::getValue('image'));
				//check key of image occurance
				 $key = array_search(Tools::getValue('image'), $imag_array);
				if(empty($imag_array)) {
					$images_url = '';
				} else {
					unset($imag_array[$key]);
					$images_url = implode(",",$imag_array);
				}
				//delete image from folder
				@unlink(_PS_ROOT_DIR_.'/images/quotes/'.$quotedata[0]['id_quote'].'-'.Tools::getValue('image'));
				//delete image from database
				if(Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
							`images` = "'.$images_url.'"
							WHERE `id_quote_items` = '.(int)Tools::getValue('item_id')
					)) {
					echo "success";
				} else {
					echo "fail"; 
				}
				
			die;	
			}
			
            //update quuote item data 
			if(isset($_POST['quoteid'])){
				$results = $this->update_quotedata($_POST,$_FILES);
				$result['file'] = $_FILES;
				if($results) {
					$result['action'] = "success";
				} else {
					$result['action'] = "fail";
				}
                echo json_encode($result);
                die;
            }
            $quotedata = $this->getquotedata($_GET['id']); 
            //get all stores data 
            $this->context->smarty->assign(array(
                'quotedata' => $quotedata
            ));

            parent::initContent();
            $this->setTemplate('cms/editdetail');
        } else {

            Tools::redirect('index.php');
        }
    }

    //get all data of quotes
    function getquotedata($quote_item_id) {
        $quotes = array();
        //  get all quotes of current customers
        $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'quote` q INNER JOIN `' . _DB_PREFIX_ . 'quote_items` qt
                ON q.id_quote=qt.id_quote where qt.id_quote_items=' . (int) $quote_item_id . ' and q.id_customer=' . (int) $this->context->customer->id;
        $quotes = Db::getInstance()->executeS($sql);
        return $quotes;
    }
    function update_quotedata($data,$_FILE) {
			//sql query for quote type goods 
			if($data['type'] == 'goods') { 
				$sql = "UPDATE `" . _DB_PREFIX_ . "quote_items` SET 
						`brand_name` = '".$data['brand_name']."',
						`model_no` = '".$data['model_no']."',
						`item` = '".$data['item']."',
						`items_condition` = '".$data['items_condition']."',
						`does_item_functional_properly` = '".$data['does_item_functional_properly']."',
						`description` = '".$data['description']."',
						`how_much_hoping_to_get` = '".$data['how_much_hoping_to_get']."',
						`looking_for` = '".$data['looking_for']."',
						`is_complete` = 0 
						WHERE `id_quote_items` = ".$data['quote_item_id'];
			}
			//sql query for quote type jewelry
			if($data['type'] == 'jewelry') {
				$sql = "UPDATE `" . _DB_PREFIX_ . "quote_items` SET
						`brand_name` = '".$data['brand_name']."',
						`model_no` = '".$data['model_no']."',
						`item` = '".$data['item']."',
						`items_condition` = '".$data['items_condition']."',
						`does_item_functional_properly` = '".$data['does_item_functional_properly']."',
						`metal_type` = '".$data['metal_type']."',
						`weight` = '".$data['weight']."',
						`clarity` = '".$data['clarity']."',
						`carat_size` = '".$data['carat_size']."',
						`center_stone` = '".$data['center_stone']."',
						`secondary_stone` = '".$data['secondary_stone']."',
						`Additional_stone` = '".$data['Additional_stone']."',
						`center_stone_cut` = '".$data['center_stone_cut']."',
						`description` = '".$data['description']."',
						`how_much_hoping_to_get` = '".$data['how_much_hoping_to_get']."',
						`looking_for` = '".$data['looking_for']."',
						`is_complete` = 0 
						WHERE `id_quote_items` = '".$data['quote_item_id']."'";
			}
                        $q_sql ="SELECT count(*) as number FROM `" . _DB_PREFIX_ . "quote_items` WHERE `id_quote` = '".$data['quoteid']."' AND `is_complete` = '1'";
                        $q_result = Db::getInstance()->getRow($q_sql);
                        if($q_result['number'] <= 1) {
                            $quote_sql = "UPDATE `" . _DB_PREFIX_ . "quote` SET	`status` = '1' WHERE `id_quote`=".$data['quoteid'];
                            Db::getInstance()->execute($quote_sql);
                        }
			//execute sql query and update data in database 
			$result = Db::getInstance()->execute($sql);
			if(isset($_FILE)){ 
				// File upload configuration
				$targetDir =  "./././images/quotes/".$data['quoteid'].'-';
				$images_arr = array();
				foreach($_FILE as $key){
					$image_name = $key['name'];
					$tmp_name   = $key['tmp_name'];
					$size       = $key['size'];
					$type       = $key['type'];
					$error      = $key['error'];
					
					// File upload path
					$fileName = basename($key['name']);
					$targetFilePath = $targetDir . $fileName;
					
					// Check whether file type is valid
					$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
					if(move_uploaded_file($key['tmp_name'],$targetFilePath)){ 
							$images_arr[] = $fileName;
					}
				} 
				if($images_arr){
					$images = implode(",",$images_arr);
					Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
							`images` = concat(ifnull(`images`,""), ",'.$images.'")
							WHERE `id_quote_items` = '.(int)$data['quote_item_id']
					);
				}
			}
			if($result) {
				return $result;
			} else {
				return false;
			}
    }

}
