<?php

/**
 * Author: Chetu Team
 * Controller for Edit quote processing
 * Class: EditdetailControllerCore
*/
class EditdetailControllerCore extends FrontController {

    /**
     * Mapping of PS Store id to PA store id
     * Created For: mnt file store id
    */
    public $store_ids_conversion = [
                    '2' => 231,
                    '3' => 232,
                    '4' => 233,
                    '5' => 234,
                    '6' => 235,
                    '7' => 236,
                    '8' => 237,
                    '9' => 238,
                    '10' => 240,
                    '11' => 241,
                    '12' => 242,
                    '13' => 243,
                    '14' => 245,
                    '15' => 246,
                    '16' => 247,
                    '17' => 248,
                    '18' => 250,
                    '19' => 251,
                    '20' => 252,
                    '21' => 253,
                    '22' => 254,
                    '23' => 255,
                    '24' => 258,
                    '25' => 259,
    ];

    /**
     * Initial function called when controller loaded
     * Function: initContent
    */
    public function initContent() {
        if ($this->context->customer->isLogged() && Module::isEnabled('quotation')) { 
			if(isset($_POST['image'])){
				$quotdata= $this->getquotedata(Tools::getValue('item_id'));
				//break into string to array 
				$imag_array = explode(",",$quotdata[0]['images']); 
				//check key of image occurance
				 $key = array_search(Tools::getValue('image'), $imag_array);
				if(empty($imag_array)) {
					$images_url = '';
				} else {
					unset($imag_array[$key]);
					$images_url = implode(",",$imag_array);
				}
				//delete image from folder
				@unlink(_PS_ROOT_DIR_.'/images/quotes/large-thumbnails/'.$quotedata[0]['id_quote'].'-'.Tools::getValue('image'));
                @unlink(_PS_ROOT_DIR_.'/images/quotes/small-thumbnails/'.$quotedata[0]['id_quote'].'-'.Tools::getValue('image'));
				//delete image from database
				if(Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
							`images` = "'.$images_url.'"
							WHERE `id_quote_items` = '.(int)Tools::getValue('item_id')
					)) {
					echo "success";
				} else {
					echo "fail"; 
				}
				
			die;	
			}
			
            //update quuote images
            if(($_POST['uplodimage'] == 'succes')){
                    $results = $this->upload_images($_POST,$_FILES);
                    
                    if($results) {
                            $div_id = "quoteitem".rand(); 
                            $upload = "delete_image('img_url_uploaded',".Tools::getValue('quote_item_id').",'".$div_id."');";
                            $result['html'] = '<div class="custom-pr-img" id="'.$div_id.'"> 
                                                    <img style="height:200px;" src="'.Tools::getHttpHost(true).__PS_BASE_URI__.'images/quotes/small-thumbnails/'.Tools::getValue('quoteid').'-'.$results.'">
                                                    <a>
                                                        <button class="btn btn-primary btn-space pull-xs-right radius10 delete_button" onclick="'.$upload.'" name="get_quote" id="efgdvfjc" type="button">
                                                            Delete
                                                        </button> 
                                                    </a>
                                                </div>';
                            $result['action'] = "success";
                    } else {
                            $result['action'] = "fail";
                    }
                    echo json_encode($result);
                die;
            }
            //update quote item data 
            if(isset($_POST['quoteid'])){
                    $results = $this->update_quotedata($_POST);
                    if($results) {
                            $result['action'] = "success";
                    } else {
                            $result['action'] = "fail";
                    }
                echo json_encode($result);
                die;
            }
            $quotedata = $this->getquotedata($_GET['id']); 
            //get all stores data 
            $this->context->smarty->assign(array(
                'quotedata' => $quotedata
            ));

            parent::initContent();
            $this->setTemplate('cms/editdetail');
        } else {

            Tools::redirect('index.php');
        }
    }

    /**
     * Funtion for geting all data of quotes
     * function: update_quotedata
    */
    function getquotedata($quote_item_id) {
        $quotes = array();
        //  get all quotes of current customers
        $sql = 'SELECT * FROM `' . _DB_PREFIX_ . 'quote` q INNER JOIN `' . _DB_PREFIX_ . 'quote_items` qt
                ON q.id_quote=qt.id_quote where qt.id_quote_items=' . (int) $quote_item_id . ' and q.id_customer=' . (int) $this->context->customer->id;
        $quotes = Db::getInstance()->executeS($sql);
        return $quotes;
    }

    /**
     * Funtion for updating the quote data
     * function: update_quotedata
    */
    function update_quotedata($data) {
		//sql query for quote type goods 

		if($data['type'] == 'goods') { 
			$sql = "UPDATE `" . _DB_PREFIX_ . "quote_items` SET 
					`brand_name` = '".$data['brand_name']."',
					`model_no` = '".$data['model_no']."',
					`item` = '".$data['item']."',
					`items_condition` = '".$data['items_condition']."',
					`does_item_functional_properly` = '".$data['does_item_functional_properly']."',
					`description` = '".$data['description']."',
					`how_much_hoping_to_get` = '".$data['how_much_hoping_to_get']."',
					`looking_for` = '".$data['looking_for']."',
					`is_complete` = 0 
					WHERE `id_quote_items` = ".$data['quote_item_id'];
		}
		//sql query for quote type jewelry
		if($data['type'] == 'jewelry') {
			$sql = 'UPDATE `' . _DB_PREFIX_ . 'quote_items` SET
					`brand_name` = "'.$data['brand_name'].'",
					`model_no` = "'.$data['model_no'].'",
					`item` = "'.$data['item'].'",
					`items_condition` = "'.$data['items_condition'].'",
					`does_item_functional_properly` = "'.$data['does_item_functional_properly'].'",
					`metal_type` = "'.$data['metal_type'].'",
					`metal_weight_unit` = "'.$data['metal_weight_unit'].'",
					`metal_weight` = "'.$data['metal_weight'].'",
					`clarity` = "'.$data['clarity'].'",
					`carat_size` = "'.$data['carat_size'].'",
					`primary_stone` = "'.$data['primary_stone'].'",
					`secondary_stone` = "'.$data['secondary_stone'].'",
					`diamond_color` = "'.$data['diamond_color'].'",
					`primary_stone_cut` = "'.$data['primary_stone_cut'].'",
					`description` = "'.$data['description'].'",
					`how_much_hoping_to_get` = "'.$data['how_much_hoping_to_get'].'",
					`looking_for` = "'.$data['looking_for'].'",
					`is_complete` = 0 
					WHERE `id_quote_items` = "'.$data['quote_item_id'].'"';
	    }
        
        $q_sql ="SELECT count(*) as number FROM `" . _DB_PREFIX_ . "quote_items` WHERE `id_quote` = '".$data['quoteid']."' AND `is_complete` = '1'";
        $q_result = Db::getInstance()->getRow($q_sql);
        if($q_result['number'] == 1) {
            $quote_sql = "UPDATE `" . _DB_PREFIX_ . "quote` SET	`status` = '1' WHERE `id_quote`=".$data['quoteid'];
            Db::getInstance()->execute($quote_sql);
            $messagesql = 'INSERT into `' . _DB_PREFIX_ . 'quote_messages`(`id_quote`,`id_customer`,`message`,`message_to`,`message_status`,`quote_status`,`type`,`date_add`)
		values(' . $data['quoteid'] . ',' . $this->context->customer->id . ',"1","Customer Service",1,' . $data['quote_status'] . ',1,NOW())';
            Db::getInstance()->execute($messagesql);
        }

        /* create mmt file code start here */
        $store_info = Db::getInstance()->executeS(' SELECT `id_store` FROM `'._DB_PREFIX_.'quote` where `id_quote` ='.$data['quoteid']);
        $store = (object)$store_info[0];
        $_POST['id_store'] = (array_key_exists($store->id_store,$this->store_ids_conversion) ? $this->store_ids_conversion[$store->id_store] : '');
        $quote_id = $data['quoteid'];
        if(file_exists($_SERVER['DOCUMENT_ROOT'] . "/quote_mnt/download.OQR.".$_POST['id_store']."097".$quote_id.".mnt")) {
            $content = '<Header download_id="OQR.'.$quote_id.'" application_date="'.date('Y-m-d').'" target_org_node="STORE:'.$_POST['id_store'].'" deployment_name="OQR.'.$quote_id.'" download_time="IMMEDIATE" apply_immediately="true" /> ';
            $content .= " \r\n";
            $content .= 'INSERT|EMPLOYEE_TASK|'.$_POST['id_store'].'|'.$_POST['id_store'].'097'.$quote_id.'|'.date('Y-m-d H:i:s').'|'.date('Y-m-d H:i:s', strtotime(' +1 day')).'|QUOTE|Online Quote Needs Review|'.$quote_id.' - '.$this->context->customer->firstname.' '.$this->context->customer->lastname.'|HIGH|STORE|null|false|OPEN';
            $result['content'] = $content;
            $fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/quote_mnt/download.OQR.".$_POST['id_store']."097".$quote_id.".mnt","wb");
            fwrite($fp,$content);
            fclose($fp);
        }
        /* create mmt file code end here */
		//execute sql query and update data in database 
		$result = Db::getInstance()->execute($sql);
		if($result) {
			return $result;
		} else {
			return false;
		}
    }

    /**
     * Funtion for uploading/editing quote image
     * function: upload_images
    */
    function upload_images($data,$_FILE) {
        if(isset($_FILE)){ 
            // File upload configuration
            $targetDir =  "./././images/quotes/large-thumbnails/".$data['quoteid'].'-';
            $targetDirsmall =  "./././images/quotes/small-thumbnails/".$data['quoteid'].'-';
            $images_arr = array();
            foreach($_FILE as $key){
                    $image_name = $key['name'];
                    $tmp_name   = $key['tmp_name'];
                    $size       = $key['size'];
                    $type       = $key['type'];
                    $error      = $key['error'];

                    // File upload path
                    $fileName = uniqid().'_'.basename($key['name']);
                    $targetFilePath = $targetDir . $fileName;
                    $sourcefile= $key['tmp_name'];

                    // Check whether file type is valid
                    $fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
                    $images_arr[] = $fileName;
                    ImageManager::resize(
                            $key['tmp_name'],
                            $targetDirsmall.$fileName,
                            (int)100, (int)100
                    );
                    // image aspect ratio calculated here
                        $image_info = getimagesize($sourcefile);
                        $image_width = $image_info[0];
                        $image_height = $image_info[1];
                        if($image_width < 800 && $image_height < 600){
                            move_uploaded_file($sourcefile,$targetDir.$fileName);
                        }else{
                            $aspectRatio = ( $image_width / $image_height );
                            
                            if($image_width >= 800 ){
                                 $newWidth = 800;
                             }else{
                                $newWidth = $image_width;
                             }
                           
                            $newHeight = floor( $newWidth / $aspectRatio );
                            $newWidth = floor( $newHeight * $aspectRatio );
                            ImageManager::resize(
                                $sourcefile,
                                $targetDir.$fileName,
                                (int)$newWidth, (int)$newHeight
                            );

                        }
            } 
            if($images_arr){
                $img_res = Db::getInstance()->getrow( 'select images from '._DB_PREFIX_.'quote_items
                                WHERE `id_quote_items` = '.(int)$data['quote_item_id']
                );
                $img_res = explode(",", $img_res['images']);
                if(($img_res[0])) {
                    $images_arr = array_merge($images_arr,$img_res);
                }
                $images = implode(",",$images_arr);
                $result =Db::getInstance()->execute( 'UPDATE '._DB_PREFIX_.'quote_items set 
                                `images` ="'.$images.'" WHERE `id_quote_items` = '.(int)$data['quote_item_id']
                );
                if($result) {
                    return $fileName;
	             } else {
		            return false;
                }
            }
        }
    }
}
