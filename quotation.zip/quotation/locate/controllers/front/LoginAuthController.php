<?php
/**
 * 2007-2017 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/OSL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright 2007-2017 PrestaShop SA
 * @license   https://opensource.org/licenses/OSL-3.0 Open Software License (OSL 3.0)
 * International Registered Trademark & Property of PrestaShop SA
 */

class LoginAuthController extends FrontController
{
    public $ssl = true;
    public $php_self = 'loginauth';
    public $auth = false;

    public function checkAccess()
    {
        if ($this->context->customer->isLogged() && !$this->ajax) {
            $this->redirect_after = ($this->authRedirection) ? urlencode($this->authRedirection) : 'my-account';
            $this->redirect();
        }

        return parent::checkAccess();
    }

    public function initContent()
    { 
        $should_redirect = false;

        
		// login quote user code start here
        if(Tools::getValue("login_type") == 'quote_user') {
			$login_form = $this->makeLoginForm()->fillWith(
                Tools::getAllValues()
            );

            if (Tools::isSubmit('submit')) {
                if ($login_form->submit()) {
                   echo $should_redirect = true;
                } else {
				  echo "2";
				} 
            } die;
		}
		// registeration form code start here 
	if($_POST['register_type'] == 'quote_user') { 

			if (Tools::isSubmit('submitreg') || Tools::isSubmit('create_account')) {
            $register_form = $this
                ->makeCustomerForm()
                ->setGuestAllowed(false)
                ->fillWith(Tools::getAllValues())
            ;

            if (Tools::isSubmit('submitreg')) {
                $hookResult = array_reduce(
                    Hook::exec('actionSubmitAccountBefore', array(), null, true),
                    function ($carry, $item) {
                        return $carry && $item;
                    },
                    true
                );
				// check email already exist or not. if email already exist then send error to popup
				$customer = new Customer();
				$customer->getByEmail(Tools::getValue('email'));
				if(Validate::isLoadedObject($customer)) {
				   echo "3"; die;	
				} 
                if ($hookResult && $register_form->submit()) {
                    $should_redirect = true;
					echo true;
                } else {
				echo "2";
			    }
            }
			
			} die;
		}
		// forgot quote user code start here
        if(Tools::getValue("forgot_type") == 'forgot_user') {
			if (!($email = trim(Tools::getValue('email'))) || !Validate::isEmail($email)) {
            echo $this->trans('Invalid email address.', array(), 'Shop.Notifications.Error');
			} else {
				$customer = new Customer();
				$customer->getByEmail($email);
				if (is_null($customer->email)) {
					$customer->email = Tools::getValue('email');
				}

				if (!Validate::isLoadedObject($customer)) {
					echo $this->trans(
						'If this email address has been registered in our shop, you will receive a link to reset your password at %email%.',
						array('%email%' => $customer->email),
						'Shop.Notifications.Success'
					);
				  
				} elseif (!$customer->active) {
				   echo $this->trans('You cannot regenerate the password for this account.', array(), 'Shop.Notifications.Error');
				} elseif ((strtotime($customer->last_passwd_gen.'+'.($minTime = (int) Configuration::get('PS_PASSWD_TIME_FRONT')).' minutes') - time()) > 0) {
				   echo $this->trans('You can regenerate your password only every %d minute(s)', array((int) $minTime), 'Shop.Notifications.Error');
				} else {
					if (!$customer->hasRecentResetPasswordToken()) {
						$customer->stampResetPasswordToken();
						$customer->update();
					}

					$mailParams = array(
						'{email}' => $customer->email,
						'{lastname}' => $customer->lastname,
						'{firstname}' => $customer->firstname,
						'{url}' => $this->context->link->getPageLink('password', true, null, 'token='.$customer->secure_key.'&id_customer='.(int) $customer->id.'&reset_token='.$customer->reset_password_token),
					);

					if (
						Mail::Send(
							$this->context->language->id,
							'password_query',
							$this->trans(
								'Password query confirmation',
								array(),
								'Emails.Subject'
							),
							$mailParams,
							$customer->email,
							$customer->firstname.' '.$customer->lastname
						)
					) { echo "1";
						//$this->success[] = $this->trans('If this email address has been registered in our shop, you will receive a link to reset your password at %email%.', array('%email%' => $customer->email), 'Shop.Notifications.Success');
						//$this->setTemplate('customer/password-infos');
					} else {
						echo $this->trans('An error occurred while sending the email.', array(), 'Shop.Notifications.Error');
					}
				}
			}
			die('');
		}
	}
}
