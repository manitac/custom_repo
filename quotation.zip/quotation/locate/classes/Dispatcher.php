<?php 

class Dispatcher extends DispatcherCore { 
  public function __construct(){ 
    // add routes custom
    $this->default_routes['quote'] = [
      'controller' => 'quote', // will be linked to QuoteController
      'rule' => 'quote',
      'keywords' => [],
    ];
    $this->default_routes['goodsquote'] = [
      'controller' => 'goodsquote', // will be linked to GoodsquoteController
      'rule' => 'goodsquote',
      'keywords' => [],
    ];
  $this->default_routes['survey'] = [
      'controller' => 'survey', // will be linked to SurveyController
      'rule' => 'survey',
      'keywords' => [],
    ];
    $this->default_routes['goods'] = [
      'controller' => 'goods', // will be linked to goods controller
      'rule' => 'goods',
      'keywords' => [],
    ];
    $this->default_routes['loginauth'] = [
      'controller' => 'loginauth', // will be linked to loginauth controller
      'rule' => 'loginauth',
      'keywords' => [],
    ];
   $this->default_routes['handlequote'] = [
      'controller' => 'handlequote', // will be linked to loginauth controller
      'rule' => 'handlequote',
      'keywords' => [],
    ];
   $this->default_routes['quotedetails'] = [
      'controller' => 'quotedetails', // will be linked to loginauth controller
      'rule' => 'quotedetails',
      'keywords' => [],
    ];

    parent::__construct();
  }
}