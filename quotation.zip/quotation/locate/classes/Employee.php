<?php

/**
 * Class EmployeeCore
 */
class Employee extends EmployeeCore
{
    /** @var int $id Employee ID */
    public $id;

    /** @var string Determine employee profile */
    public $id_profile;

    /** @var string employee language */
    public $id_lang;

    /** @var string Lastname */
    public $lastname;

    /** @var string Firstname */
    public $firstname;

    /** @var string e-mail */
    public $email;

    /** @var string Password */
    public $passwd;

    /** @var datetime Password */
    public $last_passwd_gen;

    public $stats_date_from;
    public $stats_date_to;

    public $stats_compare_from;
    public $stats_compare_to;
    public $stats_compare_option = 1;

    public $preselect_date_range;

    /** @var string Display back office background in the specified color */
    public $bo_color;

    public $default_tab;

    /** @var string employee's chosen theme */
    public $bo_theme;

    /** @var string employee's chosen css file */
    public $bo_css = 'admin-theme.css';

    /** @var int employee desired screen width */
    public $bo_width;

    /** @var bool, false */
    public $bo_menu = 1;

    /* Deprecated */
    public $bo_show_screencast = false;

    /** @var bool Status */
    public $active = 1;

    /** @var bool Optin status */
    public $optin = 1;

    public $remote_addr;

    /* employee notifications */
    public $id_last_order;
    public $id_last_customer_message;
    public $id_last_customer;

    /** @var string Unique token for forgot passsword feature */
    public $reset_password_token;

    /** @var string token validity date for forgot password feature */
    public $reset_password_validity;

    public $id_store;

    /**
     * @see ObjectModel::$definition
     */
    public static $definition = array(
        'table' => 'employee',
        'primary' => 'id_employee',
        'fields' => array(
            'lastname' => array('type' => self::TYPE_STRING, 'validate' => 'isName', 'required' => true, 'size' => 32),
            'firstname' => array('type' => self::TYPE_STRING, 'validate' => 'isName', 'required' => true, 'size' => 32),
            'email' => array('type' => self::TYPE_STRING, 'validate' => 'isEmail', 'required' => true, 'size' => 128),
            'id_lang' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt', 'required' => true),
            'passwd' => array('type' => self::TYPE_STRING, 'validate' => 'isPasswd', 'required' => true, 'size' => 60),
            'last_passwd_gen' => array('type' => self::TYPE_STRING),
            'active' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'optin' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'id_profile' => array('type' => self::TYPE_INT, 'validate' => 'isInt', 'required' => true),
            'bo_color' => array('type' => self::TYPE_STRING, 'validate' => 'isColor', 'size' => 32),
            'default_tab' => array('type' => self::TYPE_INT, 'validate' => 'isInt'),
            'bo_theme' => array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 32),
            'bo_css' => array('type' => self::TYPE_STRING, 'validate' => 'isGenericName', 'size' => 64),
            'bo_width' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'bo_menu' => array('type' => self::TYPE_BOOL, 'validate' => 'isBool'),
            'stats_date_from' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'stats_date_to' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'stats_compare_from' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'stats_compare_to' => array('type' => self::TYPE_DATE, 'validate' => 'isDate'),
            'stats_compare_option' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'preselect_date_range' => array('type' => self::TYPE_STRING, 'size' => 32),
            'id_last_order' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'id_last_customer_message' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'id_last_customer' => array('type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'),
            'reset_password_token' => array('type' => self::TYPE_STRING, 'validate' => 'isSha1', 'size' => 40, 'copy_post' => false),
            'reset_password_validity' => array('type' => self::TYPE_DATE, 'validate' => 'isDateOrNull', 'copy_post' => false),
            'id_store' => array('type' => self::TYPE_INT, 'validate' => 'isInt'),
        ),
    );

}
