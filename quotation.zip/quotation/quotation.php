<?php
/**
 * Author: Chetu 
 * Desc: Module created for Quote Management
 * Created at: july 2018 
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
require_once(dirname(__FILE__).'/classes/admin/QuoteDetail.php');

class Quotation extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'quotation';  
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'chetu';
        $this->need_instance = 0;
        $this->bootstrap = true;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Quotation');
        $this->description = $this->l('module for quotation of jewelry & goods');

        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
    }

    /**
     * Executes when module is installed
     */
    public function install()
    {
        include(dirname(__FILE__).'/sql/install.php');

        return parent::install() &&
            $this->registerHook('header') &&
            $this->registerHook('displayTop') &&
            $this->registerHook('displayCustomerAccount') &&
            $this->installTab('AdminTools', 'AdminQuote', 'All Quotes') &&
            $this->moveFiles() &&
            $this->registerHook('backOfficeHeader')&&
            $this->registerHook('actionCustomerAccountAdd');
    }
	/**
     * Created For: Creating tab for quotes
     */
    public function installTab($parent, $class_name, $name)
    {
        $tab = new Tab();
        $tab->id_parent = (int)Tab::getIdFromClassName($parent);
        $tab->name = array();
        foreach (Language::getLanguages(true) as $lang)
            $tab->name[$lang['id_lang']] = $name;
        $tab->class_name = $class_name;
        $tab->module = $this->name;
        $tab->active = 1;
        return $tab->add();
    }

    /**
     * Created For: Creating tab for moving files to respected locations
    */
 
    public function moveFiles()
    { 
    	@Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/admin/AdminEmployeesController.php', _PS_OVERRIDE_DIR_.'controllers/admin/AdminEmployeesController.php');

    	@Tools::copy(_PS_MODULE_DIR_.'quotation/locate/classes/Employee.php', _PS_OVERRIDE_DIR_.'classes/Employee.php');

        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/GoodsController.php', _PS_OVERRIDE_DIR_.'controllers/front/GoodsController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/GoodsquoteController.php', _PS_OVERRIDE_DIR_.'controllers/front/GoodsquoteController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/QuoteController.php', _PS_OVERRIDE_DIR_.'controllers/front/QuoteController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/SurveyController.php', _PS_OVERRIDE_DIR_.'controllers/front/SurveyController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/LoginAuthController.php', _PS_OVERRIDE_DIR_.'controllers/front/LoginAuthController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/HandlequoteController.php', _PS_OVERRIDE_DIR_.'controllers/front/HandlequoteController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/QuotedetailsController.php', _PS_OVERRIDE_DIR_.'controllers/front/QuotedetailsController.php');
        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/controllers/front/EditdetailController.php', _PS_OVERRIDE_DIR_.'controllers/front/EditdetailController.php');

        Tools::copy(_PS_MODULE_DIR_.'quotation/locate/classes/Dispatcher.php', _PS_OVERRIDE_DIR_.'classes/Dispatcher.php');
		
		@Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/goods.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/goods.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/goodsquote.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/goodsquote.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/quote.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/quote.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/survey.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/survey.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/handlequote.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/handlequote.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/quotedetails.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/quotedetails.tpl');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/views/templates/front/editdetail.tpl', _PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/editdetail.tpl');

        /*@Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/customer_quote.html', _PS_ROOT_DIR_.'/mails/en/customer_quote.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/customer_quote.txt', _PS_ROOT_DIR_.'/mails/en/customer_quote.txt');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/customer_survey.html', _PS_ROOT_DIR_.'/mails/en/customer_survey.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/customer_survey.txt', _PS_ROOT_DIR_.'/mails/en/customer_survey.txt');

        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/quote_message_to_customer.html', _PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/quote_message_to_customer.txt', _PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.txt');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/pending_quote_message_to_customer.html', _PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/pending_quote_message_to_customer.txt', _PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.txt');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/incomplete_quote.html', _PS_ROOT_DIR_.'/mails/en/incomplete_quote.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/incomplete_quote.txt', _PS_ROOT_DIR_.'/mails/en/incomplete_quote.txt');

        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/complete_quote.html', _PS_ROOT_DIR_.'/mails/en/complete_quote.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/complete_quote.txt', _PS_ROOT_DIR_.'/mails/en/complete_quote.txt');
		@Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/quote_message.html', _PS_ROOT_DIR_.'/mails/en/quote_message.html');
        @Tools::copy(_PS_MODULE_DIR_.'quotation/locate/mails/en/quote_message.txt', _PS_ROOT_DIR_.'/mails/en/quote_message.txt');*/

        return true;
    }
    /**
     * Called when module is uninstalled
    */
    public function uninstall()
    {
        include(dirname(__FILE__).'/sql/uninstall.php');

        return parent::uninstall() && $this->delFiles() && $this->uninstallTab('AdminQuote');;
    }
    public function uninstallTab($class_name)
    {
        // Retrieve Tab ID
        $id_tab = (int)Tab::getIdFromClassName($class_name);

        // Load tab
        $tab = new Tab((int)$id_tab);

        // Delete it
        return $tab->delete();
    }
    
    public function delFiles()
    {
    	@unlink(_PS_OVERRIDE_DIR_.'controllers/admin/AdminEmployeesController.php');
        @unlink(_PS_OVERRIDE_DIR_.'classes/Employee.php');
        @unlink(_PS_OVERRIDE_DIR_.'controllers/front/GoodsController.php');
        @unlink(_PS_OVERRIDE_DIR_.'controllers/front/GoodsquoteController.php');
        @unlink(_PS_OVERRIDE_DIR_.'controllers/front/QuoteController.php');
        @unlink(_PS_OVERRIDE_DIR_.'controllers/front/SurveyController.php');
        @unlink(_PS_OVERRIDE_DIR_.'controllers/front/LoginAuthController.php');
        @unlink(_PS_OVERRIDE_DIR_.'classes/Dispatcher.php');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/goods.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/goodsquote.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/quote.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/survey.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/handlequote.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/customer/my-account.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/cms/quotedetails.tpl');
        @unlink(_PS_ROOT_DIR_.'/themes/'._THEME_NAME_.'/templates/cms/editdetail.tpl');
        

        /*@unlink(_PS_ROOT_DIR_.'/mails/en/customer_quote.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/customer_quote.txt');
        @unlink(_PS_ROOT_DIR_.'/mails/en/customer_survey.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/customer_survey.txt');
        @unlink(_PS_ROOT_DIR_.'/mails/en/incomplete_quote.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/incomplete_quote.txt');
        @unlink(_PS_ROOT_DIR_.'/mails/en/complete_quote.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/complete_quote.txt');
        @unlink(_PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/quote_message_to_customer.txt');
        @unlink(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.html');
        @unlink(_PS_ROOT_DIR_.'/mails/en/pending_quote_message_to_customer.txt');*/

        return true;
    }

    /**
     * Load the configuration form
    */
    public function getContent()
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('AdminQuote'));
    }

    /**
    * Add the CSS & JavaScript files you want to be loaded in the BO.
    */
    public function hookBackOfficeHeader()
    {
        $this->context->controller->addJquery();
        $this->context->controller->addJS($this->_path.'views/js/back.js');
        $this->context->controller->addCSS($this->_path.'views/css/back.css');
        
    }
	 /**
     * Add the get a quote button.
     */
    public function hookDisplayTop()
    {
      $sql = 'SELECT count(`id_quote_message`) as number_message FROM `' . _DB_PREFIX_ . 'quote_messages` where message_status = 0 AND message_to = "customer" AND id_customer='.(int) $this->context->customer->id;
       $number_message = (Db::getInstance()->executeS($sql));
       $quote_sql = 'SELECT DISTINCT q.id_quote,qm.message_to,q.store_location FROM `' . _DB_PREFIX_ . 'quote_messages` qm LEFT JOIN
                    `' . _DB_PREFIX_ . 'quote` q ON qm.id_quote = q.id_quote where qm.message_status = 0 AND qm.id_customer='.(int) $this->context->customer->id.' LIMIT 3' ;
        $quote_messages = (Db::getInstance()->executeS($quote_sql));
        
        $this->context->smarty->assign(array('number_message'=>$number_message['0']['number_message'],'quote_messages'=>$quote_messages));
      return $this->context->smarty->fetch($this->local_path.'views/templates/front/get_quote_buuton.tpl');
	}
    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookHeader()
    {   
        if(Tools::getValue('controller') != 'stores') {
			$this->context->controller->addJS($this->_path.'/views/js/stores_17.js');
		}
        $this->context->controller->addJS($this->_path.'/views/js/front.js');
        $this->context->controller->addCSS($this->_path.'/views/css/front.css');
        $this->context->smarty->assign(array('logged_user'=>($this->context->customer->isLogged()==1)?1:0,'home_url'=>Tools::getHttpHost(true).__PS_BASE_URI__,
            'img_url' => $this->context->link->getPageLink('index',true).'/modules/quotation/images/',));
        return $this->context->smarty->fetch($this->local_path.'views/templates/front/get_quote.tpl');
    }
    public function hookActionCustomerAccountAdd($customer)
    {
        if(empty($_POST['phone'])) {
            $_POST['phone'] = $_POST['phone1'].$_POST['phone2'].$_POST['phone3'];
        }
        if(empty($_POST['phone_mobile'])) {
            $_POST['phone_mobile'] = $_POST['phone_mobile1'].$_POST['phone_mobile2'].$_POST['phone_mobile3'];
        } 
        if($this->context->customer->id) {
          // save customer address
            $address                = new Address();
            $this->errors           = $address->validateController();
            $address->id_customer   = (int)$this->context->customer->id;        
            $address->firstname     = trim(Tools::getValue('firstname'));
            $address->lastname      = trim(Tools::getValue('lastname'));
            $address->address1      = trim(Tools::getValue('address1'));
            $address->address2      = trim(Tools::getValue('address2'));
            $address->postcode      = trim(Tools::getValue('postcode'));
            $address->city          = trim(Tools::getValue('city'));
            $address->country       = (int)trim(Tools::getValue('id_country'));
            $address->state         = (int)trim(Tools::getValue('id_state'));
            $address->phone         = trim(Tools::getValue('phone'));
            $address->phone_mobile  = trim(Tools::getValue('phone_mobile'));
            $address->alias         = "My Address";

            // Check the requires fields which are settings in the BO
            $this->errors = array_merge($this->errors, $address->validateFieldsRequiredDatabase());
           // Don't continue this process if we have errors !

            if (!$this->errors && !$this->ajax) { 
                return;
            }else{
                 // Save address
                 $address->save();
            } 
        }
    }
	public function hookDisplayCustomerAccount() 
	{
	   return $this->context->smarty->fetch($this->local_path.'views/templates/front/my-account.tpl');
	}
	
}
