<?php
/**
 * Class Mage_Adminhtml_Block_Catalog_Product_Renderer_PromotionIsActive
 *
 * @category    Local
 * @package     Mage_Adminhtml
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Mage_Adminhtml_Block_Catalog_Product_Renderer_PromotionIsActive extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{

	public function render(Varien_Object $row)
	{
		$value =  $row->getData($this->getColumn()->getIndex());
		if($value==0){
		$img=Mage::getDesign()->getSkinBaseUrl(array('_area'=>'adminhtml')).'images/enabled-true.png';
		// $id=$row->getData('entity_id');
		return "<span>Enabled</span><img src='".$img."' style='width: 15px; position: relative; top: 3px;left: 2px;'/>";
		}else{
			return "<span>Disabled</span>";
		}
	 
	}
 
}
?>