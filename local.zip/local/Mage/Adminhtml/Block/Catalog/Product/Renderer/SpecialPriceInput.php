<?php
/**
 * Class Mage_Adminhtml_Block_Catalog_Product_Renderer_SpecialPriceInput
 *
 * @category    Local
 * @package     Mage_Adminhtml
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Mage_Adminhtml_Block_Catalog_Product_Renderer_SpecialPriceInput extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{

	public function render(Varien_Object $row)
	{
		$value =  $row->getData($this->getColumn()->getIndex());
		 $id=$row->getData('entity_id');
		return '<input onchange="updateSpecialPrice(this.value,'.$id.')" name="special_price_item['.$id.']" id="special_price_item" value="'.round($value,2).'" style="width:60px;margin-left: 33px;"/>';
	 
	}
 
}
?>