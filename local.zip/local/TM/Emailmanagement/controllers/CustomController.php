<?php
/**
 * Custom Controller class is defined here
 */
class TM_Emailmanagement_CustomController extends Mage_Core_Controller_Front_Action
{
    
    /**
     * all email action send to customer
     */
    public function emailcustomerAction()
    {
        /*
         * all email management is done here 
         */
        $type = $this->getRequest()->getPost("type"); 
        $order_id = $this->getRequest()->getPost("order_id"); 
        $_order = Mage::getModel('sales/order')->load($order_id);
        $customer_email = $_order->getCustomerEmail();
        if ($type == 'order') {
            $_order->setCustomerEmail($customer_email);
            $_order->sendNewOrderEmail();
        }
        elseif ($type == 'invoice') {
            if ($_order->hasInvoices()){
                foreach ($_order->getInvoiceCollection() as $inv){

                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    $email_template_variables = array(
                            'order' => $_order,
                            'invoice' => $inv,
                            'payment_html' => $paymentBlockHtml
                        );
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_invoice_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Invoice # '.$inv->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'invoice' => $inv,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    $emailTemplate->send($customer_email,$store_name, $emailTemplateVariables,$storeId=null);
                }
            }
        }
        elseif ($type == 'shipment') {

             if ($_order->hasShipments()){
                foreach ($_order->getShipmentsCollection() as $shipment){
                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_shipment_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Shipment # '.$shipment->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'shipment' => $shipment,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    $emailTemplate->send($customer_email,$store_name, $emailTemplateVariables,$storeId=null);
                }
            }
        }
    }

    /**
     * all email action send to nfi
     */
    public function emailnfiAction()
    {
        /*
         * all email management is done here 
         */
        $type = $this->getRequest()->getPost("type"); 
        $order_id = $this->getRequest()->getPost("order_id"); 
        $_order = Mage::getModel('sales/order')->load($order_id);
        $nfi_emails = Mage::getStoreConfig(
                            'general/nfi_emails/set_emails_for_nfi', Mage::app()->getStore()->getId());
        $nfi_emails = explode(",", $nfi_emails);
        if ($type == 'order') {
            foreach ($nfi_emails as $key => $email) {
                    $_order->setCustomerEmail($email);
                    $_order->sendNewOrderEmail();
            } 
        }
        elseif ($type == 'invoice') {
            if ($_order->hasInvoices()){
                foreach ($_order->getInvoiceCollection() as $inv){

                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    $email_template_variables = array(
                            'order' => $_order,
                            'invoice' => $inv,
                            'payment_html' => $paymentBlockHtml
                        );
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_invoice_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Invoice # '.$inv->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'invoice' => $inv,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    
                    foreach ($nfi_emails as $key => $email) {
                        $emailTemplate->send($email,$store_name, $emailTemplateVariables,$storeId=null);
                    }
                }
            }
        }
        elseif ($type == 'shipment') {
            if ($_order->hasShipments()){
                foreach ($_order->getShipmentsCollection() as $shipment){
                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_shipment_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Shipment # '.$shipment->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'shipment' => $shipment,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    foreach ($nfi_emails as $key => $email) {
                        $emailTemplate->send($email,$store_name, $emailTemplateVariables,$storeId=null);
                    }
                }
            }
        }
    }

    /**
     * all email action send to custom added email ids
     */
    public function emailcustomAction()
    {
        /*
         * all email management is done here 
         */
        $type = $this->getRequest()->getPost("type"); 
        $order_id = $this->getRequest()->getPost("order_id"); 
        $_order = Mage::getModel('sales/order')->load($order_id);
        $custom_emails=$this->getRequest()->getPost("custom_mails");
        $custom_emails = explode(",", $custom_emails);
        if ($type == 'order') {
            foreach ($custom_emails as $key => $email) {
                $_order->setCustomerEmail($email);
                $_order->sendNewOrderEmail();
            } 
        }
        elseif ($type == 'invoice') {

            if ($_order->hasInvoices()){
                foreach ($_order->getInvoiceCollection() as $inv){

                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    $email_template_variables = array(
                            'order' => $_order,
                            'invoice' => $inv,
                            'payment_html' => $paymentBlockHtml
                        );
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_invoice_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Invoice # '.$inv->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'invoice' => $inv,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    foreach ($custom_emails as $key => $email) {
                        $emailTemplate->send($email,$store_name, $emailTemplateVariables,$storeId=null);
                    }
                }
            }
        }
        elseif ($type == 'shipment') {
            if ($_order->hasShipments()){
                foreach ($_order->getShipmentsCollection() as $shipment){
                    $paymentBlock = Mage::helper('payment')->getInfoBlock($_order->getPayment())->setIsSecureMode(true);
                    $paymentBlockHtml = $paymentBlock->toHtml();
                    
                    $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                    $store_name = Mage::getModel('core/website')->load(1)->getName();
                    $emailTemplate  = Mage::getModel('core/email_template')
                                                    ->loadDefault('sales_email_shipment_template');               
                    $emailTemplate->setDesignConfig(array('area' => 'frontend', 'store' => $iDefaultStoreId));
                    $emailTemplate->setSenderName(Mage::getStoreConfig('trans_email/ident_general/name'));
                    $emailTemplate->setSenderEmail(Mage::getStoreConfig('trans_email/ident_general/email')); 
                    $subject =' Shipment # '.$shipment->getIncrementId().' for Order # '.$_order->getIncrementId();
                    $emailTemplate->setTemplateSubject($subject);  
                    $emailTemplateVariables = array(
                                                'order' => $_order,
                                                'shipment' => $shipment,
                                                'payment_html' => $paymentBlockHtml
                                            );        
                    $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                    foreach ($custom_emails as $key => $email) {
                        $emailTemplate->send($email,$store_name, $emailTemplateVariables,$storeId=null);
                    }
                }
            }
        }
    }
}