<?php

class TM_Sendorder_Block_Sendorder extends Mage_Core_Block_Template {

    public function _prepareLayout() {
        return parent::_prepareLayout();
    }
 
}
