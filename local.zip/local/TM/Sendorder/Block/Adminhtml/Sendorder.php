<?php

class TM_Sendorder_Block_Adminhtml_Sendorder extends Mage_Adminhtml_Block_Widget_Grid_Container {

    public function __construct() {

        $this->_controller = "adminhtml_sendorder";
        $this->_blockGroup = "sendorder";
        $this->_headerText = Mage::helper("sendorder")->__("Send Order");
        $this->_addButtonLabel = Mage::helper("sendorder")->__("Add New Item");
        parent::__construct();
    }

    /**
     * show the list of folders of orders
     * return array
     */
    public function show_list() {
        $file = new Varien_Io_File();
        $dir = Mage::getBaseDir('var') . DS . 'NFI' . DS;
        $file->open(array('path' => $dir));

        return $file->ls();
    }

    /**
     * show the csv files to to download from admin section
     * @param type $folders
     * @param folders to get related files
     */
    public function show_csv_files($folders) {

        $file = new Varien_Io_File();
        $dir = Mage::getBaseDir('var') . DS . 'NFI' . DS . $folders;
        $file->open(array('path' => $dir));
        return $file->ls();
    }

}
