<?php
/**
 * Class TM_Sendorder_Block_Adminhtml_Sendorder_Edit
 *
 * @category    Local
 * @package     TM_Sendorder
 * @author      Shila kumari <shilak@chetu.com>
 */
class TM_Sendorder_Block_Adminhtml_Sendorder_Edit extends Mage_Adminhtml_Block_Widget_Form_Container {

    public function __construct() {

        parent::__construct();
        $this->_objectId = "sendorder_id";
        $this->_blockGroup = "sendorder";
        $this->_controller = "adminhtml_sendorder";
        $this->_updateButton("save", "label", Mage::helper("sendorder")->__("Save Item"));
        $this->_updateButton("delete", "label", Mage::helper("sendorder")->__("Delete Item"));

        $this->_addButton("saveandcontinue", array(
            "label" => Mage::helper("sendorder")->__("Save And Continue Edit"),
            "onclick" => "saveAndContinueEdit()",
            "class" => "save",
                ), -100);



        $this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
    }

    public function getHeaderText() {
        if (Mage::registry("sendorder_data") && Mage::registry("sendorder_data")->getId()) {

            return Mage::helper("sendorder")->__("Edit Item '%s'", $this->htmlEscape(Mage::registry("sendorder_data")->getId()));
        } else {

            return Mage::helper("sendorder")->__("Add Item");
        }
    }

}
