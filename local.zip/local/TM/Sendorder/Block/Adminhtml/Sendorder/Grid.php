<?php

class TM_Sendorder_Block_Adminhtml_Sendorder_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    public function __construct() {
        parent::__construct();
        $this->setId("sendorderGrid");
        $this->setDefaultSort("sendorder_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection() {
        //$collection = Mage::getModel("teddymountain/sliderbanner")->getCollection();
        //$this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns() {
        $this->addColumn("sliderbanner_id", array(
            "header" => Mage::helper("teddymountain")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "sliderbanner_id",
        ));


        $this->addColumn('image', array(
            'header' => Mage::helper('catalog')->__('Image'),
            'width' => '50px',
            'index' => 'image',
            'frame_callback' => array($this, 'callback_image')
        ));

        $this->addColumn("title", array(
            "header" => Mage::helper("teddymountain")->__("Title"),
            "index" => "title",
        ));
        $this->addColumn('status', array(
            'header' => Mage::helper('teddymountain')->__('Status'),
            'index' => 'status',
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Grid::getOptionArray3(),
        ));

//        $this->addColumn("store", array(
//            "header" => Mage::helper("teddymountain")->__("Store"),
//            "index" => "store",
//        ));
        $this->addColumn("sort_order", array(
            "header" => Mage::helper("teddymountain")->__("Sort Order"),
            "index" => "sort_order",
        ));
        $this->addColumn("link", array(
            "header" => Mage::helper("teddymountain")->__("Link"),
            "index" => "link",
        ));
        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row) {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField('sliderbanner_id');
        $this->getMassactionBlock()->setFormFieldName('sliderbanner_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_sliderbanner', array(
            'label' => Mage::helper('teddymountain')->__('Remove Sliderbanner'),
            'url' => $this->getUrl('*/adminhtml_sliderbanner/massRemove'),
            'confirm' => Mage::helper('teddymountain')->__('Are you sure?')
        ));
        return $this;
    }

    static public function getOptionArray3() {
        $data_array = array();
        $data_array[0] = 'Enabled';
        $data_array[1] = 'Disabled';
        return($data_array);
    }

    static public function getValueArray3() {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Grid::getOptionArray3() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }

    public function callback_image($value) {
        $width = 150;
        $height = 70;
        return "<img src='" . Mage::getBaseUrl('media') . $value . "' width=" . $width . " height=" . $height . "/>";
    }

}
