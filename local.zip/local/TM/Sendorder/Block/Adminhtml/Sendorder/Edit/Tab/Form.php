<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Edit_Tab_Form
 *
 * @category    Local
 * @package     TM_Sendorder
 * @author      Shila kumari <shilak@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("teddymountain_form", array("legend"=>Mage::helper("teddymountain")->__("Item information")));

				
						$fieldset->addField("title", "text", array(
						"label" => Mage::helper("teddymountain")->__("Title"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "title",
						));
									
						$fieldset->addField('image', 'image', array(
						'label' => Mage::helper('teddymountain')->__('Image'),
						'name' => 'image',
						'note' => '(*.jpg, *.png, *.gif)',
						));
						$fieldset->addField("description", "textarea", array(
						"label" => Mage::helper("teddymountain")->__("Description"),
						"name" => "description",
						));
									
						 $fieldset->addField('status', 'select', array(
						'label'     => Mage::helper('teddymountain')->__('Status'),
						'values'   => Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Grid::getValueArray3(),
						'name' => 'status',
						));
//						$fieldset->addField("store", "text", array(
//						"label" => Mage::helper("teddymountain")->__("Store"),
//						"name" => "store",
//						));
					
						$fieldset->addField("sort_order", "text", array(
						"label" => Mage::helper("teddymountain")->__("Sort Order"),
						"name" => "sort_order",
						));
					
						$fieldset->addField("link", "text", array(
						"label" => Mage::helper("teddymountain")->__("Link"),
						"name" => "link",
						));
					

				if (Mage::getSingleton("adminhtml/session")->getSliderbannerData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getSliderbannerData());
					Mage::getSingleton("adminhtml/session")->setSliderbannerData(null);
				} 
				elseif(Mage::registry("sliderbanner_data")) {
				    $form->setValues(Mage::registry("sliderbanner_data")->getData());
				}
				return parent::_prepareForm();
		}
}
