<?php
/**
 * Class TM_Sendorder_Block_Adminhtml_Sendorder_Grid
 *
 * @category    Local
 * @package     TM_Sendorder
 * @author      Shila kumari <shilak@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Sliderbanner_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
		public function __construct()
		{
				parent::__construct();
				$this->setId("sliderbanner_tabs");
				$this->setDestElementId("edit_form");
				$this->setTitle(Mage::helper("teddymountain")->__("Item Information"));
		}
		protected function _beforeToHtml()
		{
				$this->addTab("form_section", array(
				"label" => Mage::helper("teddymountain")->__("Item Information"),
				"title" => Mage::helper("teddymountain")->__("Item Information"),
				"content" => $this->getLayout()->createBlock("teddymountain/adminhtml_sliderbanner_edit_tab_form")->toHtml(),
				));
				return parent::_beforeToHtml();
		}

}
