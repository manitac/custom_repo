<?php
/**
 * Class TM_Sendorder_Block_Adminhtml_Pagination
 *
 * @category    Local
 * @package     TM_Sendorder
 * @author      Shila kumari <shilak@chetu.com>
 */
class TM_Sendorder_Block_Adminhtml_Pagination  extends Mage_Adminhtml_Block_Widget_Grid_Container {

     public function methodblock()
    {
        return 'text here';
    }

}
