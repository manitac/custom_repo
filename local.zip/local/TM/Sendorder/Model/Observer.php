<?php

class TM_Sendorder_Model_Observer {

    /**
     * function changes the order status to On Hold when order is having any comment in it
     */
     public function orderstatus(Varien_Event_Observer $observer) {

        $order = $observer->getEvent()->getOrderIds();
        $order_id = $order[0];
        $order = Mage::getModel('sales/order')->load($order_id);
        $order_comment_checkout=$order->getCdrOrderComment();
        if(!empty($order_comment_checkout)){
			$order->setState('holded', true);
            $order->save();
        }
        return $this;
    }
    /**
     * function generates csv file with order information.
     * return csv file to download from server.
     * email template path-  app\locale\en_US\template\email\send_order.html
     */
    public function sendOrderNFI(Varien_Event_Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        $order_id = $order->getId();
        $order = Mage::getModel('sales/order')->load($order_id);
        $order_comment_checkout=$order->getCdrOrderComment();
        if (($this->_getPaymentMethod($order) == 'cashondelivery') || !empty($order_comment_checkout)) {
            return $this;
        }

        try {
            $order = Mage::getModel('sales/order')->load($order_id);
            $customer_order_id = $order->getIncrementId();
            $shippingAddress = $order->getShippingAddress();
            
            $hdr = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $hdr_name = 'HDR_TZOrder_' . $customer_order_id;
            $hdr_file = $path . DS . $hdr_name . '.csv';
            $hdr->setAllowCreateFolders(true);
            $hdr->open(array('path' => $path));
            $hdr->streamOpen($hdr_file, 'w+');
            $hdr->streamLock(true);
            $get_method = $this->fetchShippingMethod($order->getShippingMethod());
            $hdrdata = array(
                $get_method, $customer_order_id, $shippingAddress->getCompany(), $shippingAddress->getName(), '', $shippingAddress->getStreetFull(), $shippingAddress->getCity(), $shippingAddress->getRegion(), $shippingAddress->getCountry(), $shippingAddress->getPostcode()
            );
            $hdr->streamWriteCsv($hdrdata);
            $hdr->streamClose();

            $io = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $name = 'DET_TZOrder_' . $customer_order_id;
            $file = $path . DS . $name . '.csv';
            $io->setAllowCreateFolders(true);
            $io->open(array('path' => $path));
            $io->streamOpen($file, 'w+');
            $io->streamLock(true);
            $serial = 1;
            $items = $order->getAllItems();

            foreach ($items as $item) {
                $rowdata = array(
                    $serial, $customer_order_id, $item->getSku(), intval($item->getQtyOrdered())
                );

                $io->streamWriteCsv($rowdata);
                $serial++;
            }

            $io->streamClose();
            /* send email to admin */
            $store_name = Mage::getModel('core/website')->load(1)->getName();
            $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
            $store_phone = Mage::getStoreConfig('general/store_information/phone');

            $emailTemplate = Mage::getModel('core/email_template')
                    ->loadDefault('send_order_email_template');

            //Array of variables to assign to template
            $emailTemplateVariables = array();
            $emailTemplateVariables['order_no'] = $customer_order_id;

            $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
            $attachment1 = file_get_contents($file);
            $attachment2 = file_get_contents($hdr_file);

            $nfi_email = Mage::getStoreConfig(
                            'general/nfi_emails/set_emails_for_nfi', Mage::app()->getStore()->getId()
            );
            $to = explode(",", $nfi_email);

            $subject = 'Updated Order from Direct Wholasale';
            try {
                $z_mail = new Zend_Mail('utf-8');

                $z_mail->setBodyHtml($processedTemplate)
                        ->setSubject($subject)
                        ->addTo($to)
                        ->setFrom($store_email, "From direct wholesale");

                $attach = new Zend_Mime_Part($attachment1);
                $attach->type = 'application/csv';
                $attach->disposition = Zend_Mime::DISPOSITION_INLINE;
                $attach->encoding = Zend_Mime::ENCODING_8BIT;
                $attach->filename = "DET_TZOrder_" . $customer_order_id . '.csv';

                $z_mail->addAttachment($attach);

                $attachdr = new Zend_Mime_Part($attachment2);
                $attachdr->type = 'application/csv';
                $attachdr->disposition = Zend_Mime::DISPOSITION_INLINE;
                $attachdr->encoding = Zend_Mime::ENCODING_8BIT;
                $attachdr->filename = "HDR_TZOrder_" . $customer_order_id . '.csv';

                $z_mail->addAttachment($attachdr);
                $z_mail->send();
                
            } catch (Exception $e) {
                return false;
            }
            /* close code for send email */
            /* send order To nfi emails */
        } catch (Exception $e) {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }
        return $this;
    }

    /**
     * Fetch shipping method based on code
     * @param type $method
     */
    function fetchShippingMethod($method) {

        if ($method == 'customshipping_Hold_for_pick_up') {
            return 'customshipping_Hold_for_pick_up';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_EXPRESS_SAVER') {
            return 'FEXP';
        } else if ($method == 'customshipping_FEDEX_2_DAY') {
            return 'F2D';
        } else if ($method == 'customshipping_STANDARD_OVERNIGHT') {
            return 'FSO';
        } else {
            return $method;
        }
    }

    /**
     * Get used payment method from order 
     * @param type $order
     */
    private function _getPaymentMethod($order) {
        $code = $order->getPayment()->getMethodInstance()->getCode();
        return $code;
    }

}
