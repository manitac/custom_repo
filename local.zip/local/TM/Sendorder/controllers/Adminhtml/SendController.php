<?php

class TM_Sendorder_Adminhtml_SendController extends Mage_Adminhtml_Controller_action
{
    protected function _initAction()
    {
        $this->loadLayout()->_setActiveMenu("tm/sendorder")->_addBreadcrumb(Mage::helper("adminhtml")->__("Send Order"), Mage::helper("adminhtml")->__("Send Order"));
        return $this;
    }

    public function IndexAction()
    {
        $this->loadLayout();
        $this->renderLayout();
    }

    public function SendnfiAction()
    {
        $order_id = $this->getRequest()->getParam("order_id");
        try {
            $order = Mage::getModel('sales/order')->load($order_id);
            $customer_order_id = $order->getIncrementId();
            $shippingAddress = $order->getShippingAddress();
            $hdr = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $hdr_name = 'HDR_TZOrder_' . $customer_order_id;
            $hdr_file = $path . DS . $hdr_name . '.csv';
            $hdr->setAllowCreateFolders(true);
            $hdr->open(array('path' => $path));
            $hdr->streamOpen($hdr_file, 'w+');
            $hdr->streamLock(true);
            $get_method = $this->fetchShippingMethod($order->getShippingMethod());
            $hdrdata = array(
                $get_method, $customer_order_id, $shippingAddress->getCompany(), $shippingAddress->getName(), '', $shippingAddress->getStreetFull(), $shippingAddress->getCity(), $shippingAddress->getRegion(), $shippingAddress->getCountry(), $shippingAddress->getPostcode()
            );
            $hdr->streamWriteCsv($hdrdata);
            $hdr->streamClose();

            $io = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $name = 'DET_TZOrder_' . $customer_order_id;
            $file = $path . DS . $name . '.csv';
            $io->setAllowCreateFolders(true);
            $io->open(array('path' => $path));
            $io->streamOpen($file, 'w+');
            $io->streamLock(true);
            

            $creditMemos = Mage::getResourceModel('sales/order_creditmemo_collection');
            $creditMemos->addFieldToFilter('order_id', $order_id);
            $creditMemos->setOrder('created_at', 'DESC');
            $creditMemos->load();
            
            foreach ($creditMemos as $creditMemo) {
                $serial = 1;
                $items = $creditMemo->getAllItems();
                foreach ($items as $item) {
                    $items_order = $order->getAllItems();
                    $ordered_qty = 0;
                    foreach ($items_order as $item_order) {
                        if ($item->getSku() == $item_order->getSku()) {
                            $ordered_qty = intval($item_order->getQtyOrdered());
                        }
                    }
                    
                    $qty_left = $ordered_qty- intval($item->getQty());
                    $rowdata = array(
                        $serial, $customer_order_id,$item->getSku(), $qty_left
                    );
                    $io->streamWriteCsv($rowdata);
                    $serial++;
                }
                break;
            }

            $io->streamClose();

            
            /* send email to admin */
            $store_name = Mage::getModel('core/website')->load(1)->getName();
            $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
            $store_phone = Mage::getStoreConfig('general/store_information/phone');

            $emailTemplate = Mage::getModel('core/email_template')
                    ->loadDefault('send_order_email_template');

            //Array of variables to assign to template
            $emailTemplateVariables = array();
            $emailTemplateVariables['order_no'] = $customer_order_id;
            $emailTemplateVariables['comment'] = $this->getRequest()->getParam("comment");

            $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
            $attachment1 = file_get_contents($file);
            $attachment2 = file_get_contents($hdr_file);

            $nfi_email =  Mage::getStoreConfig(
                   'general/nfi_emails/set_emails_for_nfi',
                   Mage::app()->getStore()->getId()
               );
            $to  = explode(",", $nfi_email);

            $subject = 'Updated Order from Direct Wholasale';
            try {
                $z_mail = new Zend_Mail('utf-8');

                $z_mail->setBodyHtml($processedTemplate)
                        ->setSubject($subject)
                        ->addTo($to)
                        ->setFrom($store_email, "From direct wholesale");

                $attach = new Zend_Mime_Part($attachment1);
                $attach->type = 'application/csv';
                $attach->disposition = Zend_Mime::DISPOSITION_INLINE;
                $attach->encoding = Zend_Mime::ENCODING_8BIT;
                $attach->filename = "DET_TZOrder_" . $customer_order_id . '.csv';

                $z_mail->addAttachment($attach);

                $attachdr = new Zend_Mime_Part($attachment2);
                $attachdr->type = 'application/csv';
                $attachdr->disposition = Zend_Mime::DISPOSITION_INLINE;
                $attachdr->encoding = Zend_Mime::ENCODING_8BIT;
                $attachdr->filename = "HDR_TZOrder_" . $customer_order_id . '.csv';

                $z_mail->addAttachment($attachdr);

                /********Invoice Attachment**********/
                $invoices = Mage::getResourceModel('sales/order_invoice_collection')
                    ->setOrderFilter($order->getId())
                    ->load();
                
                foreach ($invoices as $invoice) {
                    $invoice_subtotal = 0;
                    $invoice_tax = 0;
                    foreach ($invoice->getAllItems() as $item) {
                        $item['qty'] = intval($item->getOrderItem()->getQtyOrdered()) - intval($item->getOrderItem()->getQtyRefunded());
                        $item['row_total'] = $item['qty'] * $item['price'] ;
                        $item['tax_amount'] = $item->getOrderItem()->getTaxAmount() - $item->getOrderItem()->getTaxRefunded();
                        //Mage::log($item->getOrderItem()->getData() , null,'order_item_data.log');
                        //Mage::log($item->getData() , null,'invoice_item_data.log');
                        $invoice_subtotal = $invoice_subtotal + $item['row_total'];
                        $invoice_tax =  $invoice_tax + $item['tax_amount'];
                    }
                    $invoice_grandtotal = $invoice->getGrandTotal() - $invoice->getBaseTotalRefunded();
                    $invoice->setSubtotal($invoice_subtotal);
                    $invoice->setTaxAmount($invoice_tax);
                    $invoice->setShippingAmount($invoice_grandtotal - ($invoice_subtotal + $invoice_tax));
                    $invoice->setGrandTotal($invoice_grandtotal);
                    //Mage::log($invoice->getData() , null,'invoice_data.log');
                }
                
                if ($invoices->getSize() > 0) {
                    $pdf = Mage::getModel('sales/order_pdf_invoice')->getPdf($invoices);
                    $invoice_file = $pdf->render();

                    $pdftemplate = Mage::getModel('core/email_template');
                    $attachinvoice = $pdftemplate->getMail()->createAttachment($invoice_file);
                    $attachinvoice->type = 'application/pdf';
                    $attachinvoice->filename = "Invoice_" . $customer_order_id . ".pdf";

                    $z_mail->addAttachment($attachinvoice);
                }
                /********End Invoice Attachment**********/

                $z_mail->send();
            } catch (Exception $e) {
                return false;
            }
            /* close code for send email */
        } catch (Exception $e) {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }
        return true;
        // exit;
    }

    public function fetchShippingMethod($method)
    {
        if ($method == 'customshipping_Hold_for_pick_up') {
            return 'customshipping_Hold_for_pick_up';
        } elseif ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } elseif ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } elseif ($method == 'customshipping_FEDEX_EXPRESS_SAVER') {
            return 'FEXP';
        } elseif ($method == 'customshipping_FEDEX_2_DAY') {
            return 'F2D';
        } elseif ($method == 'customshipping_STANDARD_OVERNIGHT') {
            return 'FSO';
        } else {
            return $method;
        }
    }
}
