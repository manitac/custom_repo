<?php
/**
 * Class TM_Sendorder_adminSendController
 *
 * @category    Local
 * @package     TM_Sendorder
 * @author      Shila kumari <shilak@chetu.com>
 */
class TM_Sendorder_adminSendController extends Mage_Adminhtml_Controller_Action {

    public function IndexAction() {
        echo 88; exit;
     
        // "Fetch" display
        $this->loadLayout();
       // $this->_addContent($this->getLayout()->createBlock('core/template'));
        
  
        $this->renderLayout();
    }

 
}
