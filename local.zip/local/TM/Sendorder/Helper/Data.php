<?php
/**
 * Class TM_Sendorder_Helper_Data
 *
 * @category    Local
 * @package     TM_Sendorder
 */
 class TM_Sendorder_Helper_Data extends Mage_Core_Helper_Abstract {


}