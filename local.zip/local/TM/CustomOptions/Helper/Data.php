<?php
class TM_CustomOptions_Helper_Data extends Mage_Core_Helper_Abstract
{
}
