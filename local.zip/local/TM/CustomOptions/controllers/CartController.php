<?php
require_once 'Mage/Checkout/controllers/CartController.php';

class TM_CustomOptions_CartController extends Mage_Checkout_CartController
{
    /**
     * Minicart ajax qty refresh action
     */
    public function ajaxqtyrefreshAction()
    {
        return;
    }
}
