<?php
class TM_CustomOptions_CountryController extends Mage_Core_Controller_Front_Action 
{
    
    public function selectedcountryAction()
    {

    	$country = $this->getRequest()->getPost("country"); 
    	Mage::getSingleton('core/session')->setMySelectedCountry($country);
        return $country;
    }
}
