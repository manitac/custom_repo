<?php
require_once 'Mage/Catalog/controllers/ProductController.php';

class TM_CustomOptions_ProductController extends Mage_Catalog_ProductController
{
    /**
     * ajax price action
     */
    public function ajaxpriceAction()
    {
        /*
         * All custom option price for quantity*price dropdown on product details page 
         */
        $price = $this->getRequest()->getPost("price"); 
        $packsize = $this->getRequest()->getPost("packsize"); 

        ?>
        <select name="qty" id="qty"  maxlength="12"  class="qty">
            <?php
			for ($option = $packsize; $option <= ($packsize * 10); $option+= $packsize){
                $totalprice = $option * $price; 
                $totalprice1 = Mage::helper('core')->currency($totalprice, true, false);
                $price1 = Mage::helper('core')->currency($price, true, false);
                ?>
                <option <?php
                if ($option == 6) {
                    echo 'selected="selected"';
                } ?> value="<?php echo $option; ?>"><?php echo $option; ?> x <span><?php echo $price1; ?> = <?php echo $totalprice1; ?> </option>
            <?php 
            } ?>
        </select><?php 
    }
}
