<?php
/**
 * Class TM_Changepayment_Helper_Data
 *
 * @category    Local
 * @package     TM_Changepayment
 */
 class TM_Changepayment_Helper_Data extends Mage_Core_Helper_Abstract
 {
 }