<?php

/**
 * Class TM_Changepayment_Block_Adminhtml_Changepayment
 *
 * @category    Local
 * @package     TM_Changepayment
 */
class TM_Changepayment_Block_Adminhtml_Changepayment extends Mage_Core_Block_Template {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Get active payment methods from backend.
     */
    public function getActivePaymentMethods() {
        $payments = Mage::getSingleton('payment/config')->getActiveMethods();

        $methods = array();

        foreach ($payments as $paymentCode => $paymentModel) {
            $paymentTitle = Mage::getStoreConfig('payment/' . $paymentCode . '/title');
            $methods[$paymentCode] = array(
                'label' => $paymentTitle,
                'value' => $paymentCode,
            );
        }
        unset($methods['free']);
        unset($methods['paypal_express']);
        unset($methods['paypal_billing_agreement']);
        return $methods;
    }

    /**
     * Get Current Invoice Id .
     */
    public function getInvoiceId() {
        $invoiceId = Mage::app()->getRequest()->getParam('invoice_id');
        return $invoiceId;
    }

    /**
     * Get Credit Card type for payment method form.
     */
    public function getCcType() {
        $cards = Mage::getModel('payment/config')->getCcTypes();
        unset($cards['JCB']);
        unset($cards['SM']);
        unset($cards['SO']);
        unset($cards['OT']);
        return $cards;
    }

    /**
     * Change payment method for pending invoice
     */
    public function UpdatePaymentMethodAction() {
        $orderId = $this->getRequest()->getPost('order_id');
        $payment_method = $this->getRequest()->getPost('payment_method');
        $order = Mage::getModel('sales/order')->load($orderId);
        $payment = $order->getPayment();
        $payment->resetExistingPaymentInfo();
        $payment->setMethod($payment_method);
        $payment->setCcType($this->getRequest()->getPost('cc_type'));
        $payment->setCcExpMonth($this->getRequest()->getPost('expiration'));
        $payment->setCcExpYear($this->getRequest()->getPost('expiration_yr'));
        $payment->setCcNumber($this->getRequest()->getPost('cc_number'));
        $payment->setCcNumberEnc(Mage::helper('core')->encrypt($this->getRequest()->getPost('cc_number')));
        $payment->setCcCid($this->getRequest()->getPost('cc_id'));
        $payment->setCcLast4(substr($this->getRequest()->getPost('cc_number'), -4));
        $order->save();
        $order->getPayment()->save();
        echo "Payment method has been changed successfully";
    }

    /**
     * Get invoice Status to display payment method form.
     */
    function invoiceStatus() {
        $invoice_id = $this->getInvoiceId();
        $invoice = Mage::getModel('sales/order_invoice')->load($invoice_id);
        return $invoice->getState();
    }

}
