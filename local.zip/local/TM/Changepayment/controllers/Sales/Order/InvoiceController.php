<?php

include_once("Mage/Adminhtml/controllers/Sales/Order/InvoiceController.php");

class TM_Changepayment_Sales_Order_InvoiceController extends Mage_Adminhtml_Sales_Order_InvoiceController
{
    /**
     * Change payment method for pending invoice
     */
     public function UpdatePaymentMethodAction()
    {
          $orderId = $this->getRequest()->getPost('order_id');
          $payment_method = $this->getRequest()->getPost('payment_method');
          $order = Mage::getModel('sales/order')->load($orderId);       
          $payment = $order->getPayment();
          $payment->resetExistingPaymentInfo();
          $payment->setMethod($payment_method);
          $payment->setCcType($this->getRequest()->getPost('cc_type'));
          $payment->setCcExpMonth($this->getRequest()->getPost('expiration'));
          $payment->setCcExpYear($this->getRequest()->getPost('expiration_yr'));
          $Cc_number = trim($this->getRequest()->getPost('cc_number'));
          $payment->setCcNumber($Cc_number);
          $payment->setCcNumberEnc(Mage::helper('core')->encrypt($Cc_number));
          $payment->setCcCid($this->getRequest()->getPost('cc_id')); 
          $payment->setCcLast4(substr($Cc_number, -4));
          $order->save();
          $order->getPayment()->save();         
         echo "Payment method has been changed successfully";
    }
}
