<?php
/**
 * Customer custom edit tab form block
 *
 * @category   TM
 * @package    TM_Customernotes
 */
class TM_Customernotes_Block_Adminhtml_Customer_Edit_Tab_Customernotes extends Mage_Adminhtml_Block_Template implements Mage_Adminhtml_Block_Widget_Tab_Interface
{
    //change _constuct to _construct()
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('customernotes/customer/tab/notes.phtml');
    }
    public function getTabLabel()
    {
        return $this->__('Customer Notes');
    }

    public function getTabTitle()
    {
        return $this->__('Customer Notes');
    }

    public function canShowTab()
    {
        $customer = Mage::registry('current_customer');
        return (bool)$customer->getId();
    }

    public function isHidden()
    {
        return false;
    }
    public function getAfter()
    {
        return 'tags';
    }
    public function getCustomer()
    {
        return Mage::registry('current_customer');
    }
}
