<?php
/**
 * Class TM_Customernotes_Helper_Data
 *
 * @category    Local
 * @package     TM_Customernotes
 */
class TM_Customernotes_Helper_Data extends Mage_Core_Helper_Abstract
{
}
