<?php
/**
 * Class TM_Fedex_Helper_Data
 *
 * @category    Local
 * @package     TM_Fedex
 */
 class TM_Fedex_Helper_Data extends Mage_Core_Helper_Abstract
 {
 }
