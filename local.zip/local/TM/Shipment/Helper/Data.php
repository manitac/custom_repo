<?php
/**
 * Class TM_Shipment_Helper_Data
 *
 * @category    Local
 * @package     TM_Shipment
 */
 class TM_Shipment_Helper_Data extends Mage_Core_Helper_Abstract
 {
 }
