<?php
$installer = $this;
$installer->startSetup();

$installer->getConnection()
->addColumn($installer->getTable('sales_flat_shipment_track'), 'shipment_amount', array(
    'type'      => Varien_Db_Ddl_Table::TYPE_FLOAT,
    'nullable'  => true,
    'length'    => 10,4,
    'default'   => null,
    'comment'   => 'Shipment amount'
    ));
$installer->endSetup();
