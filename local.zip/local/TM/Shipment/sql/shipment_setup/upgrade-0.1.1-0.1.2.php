<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
ALTER TABLE cataloginventory_stock_item
ADD COLUMN low_inventory INT(30) UNSIGNED NOT NULL AFTER min_qty,
ADD COLUMN medium_inventory_from INT(30) UNSIGNED NOT NULL AFTER low_inventory,
ADD COLUMN medium_inventory_to INT(30) UNSIGNED NOT NULL AFTER medium_inventory_from,
ADD COLUMN high_inventory INT(30) UNSIGNED NOT NULL AFTER medium_inventory_to;
SQLTEXT;

$installer->run($sql);
$installer->endSetup();