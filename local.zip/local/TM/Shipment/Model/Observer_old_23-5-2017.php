<?php

class TM_Shipment_Model_Observer
{
    public function Checkpayment(Varien_Event_Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        $shipmentCollection = $order->getShipmentsCollection();
        foreach ($shipmentCollection as $shipment) {
            $shipmentIncrementId = $shipment->getIncrementId();
            $shipment = Mage::getModel('sales/order_shipment')->loadByIncrementId($shipmentIncrementId);
            foreach ($shipment->getAllTracks() as $track) {
                $track = $track->getShipmentAmount();
            }
        }
        if ($order->getStatus() == 'ship_pending_payment' && $order->getTotalDue() == 0 && !empty($track)) {
            //$order->setState('order_completed');
            $order->setStatus('finish');
            $order->addStatusHistoryComment('Order has been completed', 'finish')
                    ->setIsVisibleOnFront(false)
                    ->setIsCustomerNotified(false);
            $order->save();
            //Mage::log($order->getStatus() . ' ' . $order->getTotalDue(), null, 'test2.log');
        }
    }

    public function Captureevent(Varien_Event_Observer $observer)
    {
        $invoice = $observer->getEvent()->getInvoice();
        $Order = $invoice->getOrder();
        $order_id = $Order->getId();
        $invoiceData = $invoice->getData();
        $order = Mage::getModel("sales/order")->load($order_id);
//        $order->setStatus('finish');
//        $order->addStatusHistoryComment('Order has been completed', 'finish')
//                    ->setIsVisibleOnFront(false)
//                    ->setIsCustomerNotified(false);
//        Mage::log($order->getData(), null, 'orderdata.log');
//        $order->save();
        $payment = $order->getPayment();
        $payment_method_title = $payment->getMethodInstance()->getTitle();
        $cc_type = '';
        $cc_no = '';
        $cc_exp_month = '';
        $cc_exp_year = '';
        $add_data = $payment->getData();
        if (!empty($add_data)) {
            $cc_type = $add_data['cc_type'];
            $cc_no = $add_data['cc_last4'];
            $cc_exp_month = $add_data['cc_exp_month'];
            $cc_exp_year = $add_data['cc_exp_year'];
        }
        $payment_data = array(
            "order_id" => $order_id,
            "amount" => $invoiceData['grand_total'],
            "method" => $payment_method_title,
            "cc_type" => $cc_type,
            "cc_no" => $cc_no,
            "cc_exp_month" => $cc_exp_month,
            "cc_exp_year" => $cc_exp_year,
            "created_time" => Mage::getModel('core/date')->date('Y-m-d H:i:s')
        );
        $model = Mage::getModel('paymentinfo/payinfo');
        $model->setData($payment_data);
        $model->save();
    }
}
