<?php

class TM_Shipment_Model_Observer
{

    /**
     * function generates to check pending invoice after shipment.
     * Update the order status accordingly.
     * Obesere event sales_order_save_after
     */
    public function Checkpayment(Varien_Event_Observer $observer)
    {
    }

    /**
     * function generates to capture invoice to save credit card information.
     * when we create order from backend or do the payment from admin.
     * Obesere event sales_order_payment_capture
     */
    public function Captureevent(Varien_Event_Observer $observer)
    {
        $invoice = $observer->getEvent()->getInvoice();
        $invoiceId = $observer->getEvent()->getInvoice()->getId();
        $Order = $invoice->getOrder();
        if ($Order->getPayment()->getMethodInstance()->getCode() != 'paypal_express' && isset($invoiceId)) {
            $order_id = $Order->getId();
            $invoiceData = $invoice->getData();
            $order = Mage::getModel("sales/order")->load($order_id);
            $payment = $order->getPayment();
            $payment_method_title = $payment->getMethodInstance()->getTitle();
            $cc_type = '';
            $cc_no = '';
            $cc_exp_month = '';
            $cc_exp_year = '';
            $add_data = $payment->getData();
            if (!empty($add_data) && $payment->getMethod() == 'authorizenet' && $invoiceData['requested_capture_case'] != 'not_capture') {
                $cc_type = $add_data['cc_type'];
                $cc_no = $add_data['cc_last4'];
                $cc_exp_month = $add_data['cc_exp_month'];
                $cc_exp_year = $add_data['cc_exp_year'];
            }
            if (isset($invoiceData['requested_capture_case']) && $invoiceData['requested_capture_case'] == 'not_capture') {
                $manual_ship = 1;
            } else {
                $manual_ship = 0;
            }
            if (array_key_exists('requested_capture_case',$invoiceData) || $invoiceData['is_paid']==1) {
                $payment_data = array(
                "order_id" => $order_id,
                "invoice_id" => $invoiceData['entity_id'],
                "amount" => $invoiceData['grand_total'],
                "manual_ship" => $manual_ship,
                "method" => $payment_method_title,
                "cc_type" => $cc_type,
                "cc_no" => $cc_no,
                "cc_exp_month" => $cc_exp_month,
                "cc_exp_year" => $cc_exp_year,
                "created_time" => Mage::getModel('core/date')->date('Y-m-d H:i:s')
            );
            $model = Mage::getModel('paymentinfo/payinfo');
            $model->setData($payment_data);
            $model->save();
            }
        }
    }
}
