<?php

require_once 'Mage/Adminhtml/controllers/Sales/Order/ShipmentController.php';

class TM_Shipment_Adminhtml_Sales_Order_ShipmentController extends Mage_Adminhtml_Sales_Order_ShipmentController
{

    /**
     * To Save shipment amount in database 
     * Trigger the function to create invoice and update comment history
     * Return html response
     */
    public function addTrackAction()
    {
        try {
            $carrier = $this->getRequest()->getPost('carrier');
            $number = $this->getRequest()->getPost('number');
            $title = $this->getRequest()->getPost('title');
            $shipment_amount = $this->getRequest()->getPost('shipment_amount');
            if (empty($carrier)) {
                Mage::throwException($this->__('The carrier needs to be specified.'));
            }
            if (empty($number)) {
                Mage::throwException($this->__('Tracking number cannot be empty.'));
            }
            $shipment = $this->_initShipment();
            if ($shipment) {
                $track = Mage::getModel('sales/order_shipment_track')
                        ->setNumber($number)
                        ->setCarrierCode($carrier)
                        ->setTitle($title)
                        ->setShipmentAmount($shipment_amount);
                $shipment->addTrack($track)
                        ->save();

                $increment_id = $shipment->getOrder()->getIncrementId();
                $this->orderUpdatePayment($increment_id, $shipment_amount, $number, $title);

                $this->loadLayout();
                $response = $this->getLayout()->getBlock('shipment_tracking')->toHtml();
            } else {
                $response = array(
                    'error' => true,
                    'message' => $this->__('Cannot initialize shipment for adding tracking number.'),
                );
            }
        } catch (Mage_Core_Exception $e) {
            $response = array(
                'error' => true,
                'message' => $e->getMessage(),
            );
        } catch (Exception $e) {
            $response = array(
                'error' => true,
                'message' => $this->__('Cannot add tracking number.'),
            );
        }
        if (is_array($response)) {
            $response = Mage::helper('core')->jsonEncode($response);
        }
        $this->getResponse()->setBody($response);
    }

    /**
     * Save shipment
     * We can save only new shipment. Existing shipments are not editable
     *
     * @return null
     */
    public function saveAction()
    {
        $data = $this->getRequest()->getPost('shipment');
        if (!empty($data['comment_text'])) {
            Mage::getSingleton('adminhtml/session')->setCommentText($data['comment_text']);
        }

        try {
            $shipment = $this->_initShipment();
            if (!$shipment) {
                $this->_forward('noRoute');
                return;
            }

            $shipment->register();
            $comment = '';
            if (!empty($data['comment_text'])) {
                $shipment->addComment(
                        $data['comment_text'], isset($data['comment_customer_notify']), isset($data['is_visible_on_front'])
                );
                if (isset($data['comment_customer_notify'])) {
                    $comment = $data['comment_text'];
                }
            }

            if (!empty($data['send_email'])) {
                $shipment->setEmailSent(true);
            }

            $shipment->getOrder()->setCustomerNoteNotify(!empty($data['send_email']));
            $responseAjax = new Varien_Object();
            $isNeedCreateLabel = isset($data['create_shipping_label']) && $data['create_shipping_label'];

            if ($isNeedCreateLabel && $this->_createShippingLabel($shipment)) {
                $responseAjax->setOk(true);
            }

            $this->_saveShipment($shipment);
            $increment_id = $shipment->getOrder()->getIncrementId();

            $tracks = $this->getRequest()->getPost('tracking');
            if ($tracks) {
                foreach ($tracks as $data) {
                    if (empty($data['number'])) {
                        Mage::throwException($this->__('Tracking number cannot be empty.'));
                    }
                    $this->orderUpdatePayment($increment_id, $data['shipment_amount'], $data['number'], $data['title']);
                }
            }

            $shipment->sendEmail(!empty($data['send_email']), $comment);

            $shipmentCreatedMessage = $this->__('The shipment has been created.');
            $labelCreatedMessage = $this->__('The shipping label has been created.');

            $this->_getSession()->addSuccess($isNeedCreateLabel ? $shipmentCreatedMessage . ' ' . $labelCreatedMessage : $shipmentCreatedMessage);
            Mage::getSingleton('adminhtml/session')->getCommentText(true);
        } catch (Mage_Core_Exception $e) {
            if ($isNeedCreateLabel) {
                $responseAjax->setError(true);
                $responseAjax->setMessage($e->getMessage());
            } else {
                $this->_getSession()->addError($e->getMessage());
                $this->_redirect('*/*/new', array('order_id' => $this->getRequest()->getParam('order_id')));
            }
        } catch (Exception $e) {
            Mage::logException($e);
            if ($isNeedCreateLabel) {
                $responseAjax->setError(true);
                $responseAjax->setMessage(
                        Mage::helper('sales')->__('An error occurred while creating shipping label.'));
            } else {
                $this->_getSession()->addError($this->__('Cannot save shipment.'));
                $this->_redirect('*/*/new', array('order_id' => $this->getRequest()->getParam('order_id')));
            }
        }
        if ($isNeedCreateLabel) {
            $this->getResponse()->setBody($responseAjax->toJson());
        } else {
            $this->_redirect('*/sales_order/view', array('order_id' => $shipment->getOrderId()));
        }
    }

    /**
     * To Save comment invoice and create invoice for addded shipemt amount.
     */
    public function orderUpdatePayment($increment_id, $amount, $num, $shipping_name)
    {
        $postData['ship_price'] = $amount;
        $postData['ship_inc_price'] = $amount;
        $postData['custom_shipping_method'] = 'Fedex';
        $postData['custom_name'] = $shipping_name;
        $order = Mage::getModel('sales/order')->loadByIncrementId($increment_id);

        $orderPreShipingAmount = $order->getShippingAmount();
        $orderPreShipingTaxAmount = $order->getShippingTaxAmount();
        $activeShippingMethods = Mage::getSingleton('shipping/config')->getActiveCarriers();
        $oldGrandTotal = $order->getGrandTotal();
        $preShippingDesc = $order->getShippingDescription();
        $currencyCode = Mage::app()->getLocale()->currency($order->getOrderCurrencyCode())->getSymbol();
        $logEnabled = Mage::getStoreConfig('editorder/orderlog/detail_edit_log');

        $order->setBaseShippingAmount($postData['ship_price']); // shipping excl amount
        $order->setShippingAmount($postData['ship_price']);

        $order->setShippingInclTax($postData['ship_inc_price'] + $orderPreShipingTaxAmount); // shipping incl amount
        $order->setBaseShippingInclTax($postData['ship_inc_price'] + $orderPreShipingTaxAmount);
        /* set custom shipping metdhod session price */
        Mage::getSingleton('core/session')->setCustomshippriceAmount($postData['ship_price'] + $orderPreShipingAmount);
        Mage::getSingleton('core/session')->setCustomshippriceBaseAmount($postData['ship_price'] + $orderPreShipingAmount);
        /* set custom shipping metdhod session price */

        if (isset($activeShippingMethods['customshipprice']) && is_object($activeShippingMethods['customshipprice'])) {
            $order->setShippingMethod('customshipprice_customshipprice');
            $order->setShippingDescription($postData['custom_shipping_method'] . " - " . $postData['custom_name']);
            /* set custom shipping metdhod session description */
            Mage::getSingleton('core/session')->setCustomshippriceDescription($postData['custom_shipping_method'] . " - " . $postData['custom_name']);
        } else {
            if (isset($postData['custom_shipping_method']) && $postData['custom_shipping_method'] != '') {
                $newMethod = strtolower($postData['custom_shipping_method']);
                if ($newMethod == 'other' || $newMethod == "none") {
                    $newMethod = 'freeshipping';
                }
                $order->setShippingMethod($newMethod);
                $order->setShippingDescription($postData['custom_shipping_method'] . " - " . $postData['custom_name']);
            }
        }

        $newShippingAmount = number_format($order->getShippingAmount() - $orderPreShipingAmount, 2);
        $final_ship_price = $newShippingAmount;
        $order->setBaseGrandTotal($oldGrandTotal + $final_ship_price);
        $order->setGrandTotal($oldGrandTotal + $final_ship_price);
        if ($logEnabled == 1) {
            $orderEditedBy = '<i>' . ('Order is Edited By admin to add shipment amount: ') . '</i>';
            $logShipDesc = $postData['custom_shipping_method'] . " - " . $postData['custom_name'];
            if ($preShippingDesc != $logShipDesc) {
                $shippingLogComments = '<b>' . ('Shipping was updated from ') . '</b>' . '<br/>';
                $shippingLogComments .= '&nbsp;' . $preShippingDesc . (' -to- ') . $logShipDesc . '<br/>';
            }
            if ($postData['ship_price'] != $orderPreShipingAmount) {
                $logShippingPrice = number_format($postData['ship_price'], 2);
                $shippingLogComments .= '<b>' . ('Shipping amount was Added ') . '</b>';
                $shippingLogComments .= '&nbsp; Added shipping cost from NFI ' . $currencyCode . $logShippingPrice . '<br/>';

                if ($final_ship_price > 0) {
                    $shippingLogComments .= '&nbsp; Pending shipping cost is ' . $currencyCode . $final_ship_price . '<br/>';
                } else {
                    $shippingLogComments .= '&nbsp; Refund shipping cost is ' . $currencyCode . $final_ship_price . ' and this cost should refund manually' . '<br/>';
                }
            }
            if ($postData['ship_price'] == $orderPreShipingAmount) {
                $shippingLogComments .= '&nbsp; There is not due amount and shipping NFI shipping cost is same as in system ' . '<br/>';
            }

            $shippingLogComments .= '<b>' . ('Tracking Number') . '&nbsp;' . $num . '</b><br/>';
            if ($postData['ship_price'] == $orderPreShipingAmount) {
                $status = 'complete';
            } else {
                $status = 'ship_pending_payment';
            }
            if ($shippingLogComments != "") {
                $editComments = $orderEditedBy . $shippingLogComments;
                $order->addStatusHistoryComment($editComments, $status)
                        ->setIsVisibleOnFront(false)
                        ->setIsCustomerNotified(false);
            }
        }

        $order->save();
        if ($final_ship_price > 0) {
            try {
                $payment = $order->getPayment();
                $payinfo = $payment->getData();
                $payment->setBaseAmountAuthorized($payinfo['amount_authorized']);
                $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();

                $invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::NOT_CAPTURE);
                $invoice->register();
                $invoice->setState(Mage_Sales_Model_Order_Invoice::STATE_OPEN);

                $transactionSave = Mage::getModel('core/resource_transaction')
                        ->addObject($invoice)
                        ->addObject($invoice->getOrder());

                $transactionSave->save();
                $invoice->sendEmail(true, '');
                $order->addStatusHistoryComment('Invoice has been created with amount ' . $currencyCode . $invoice->getShippingAmount() . ' and invoice id is ' . $invoice->getIncrementId(), $status)
                        ->setIsVisibleOnFront(false)
                        ->setIsCustomerNotified(false);
                $order->save();
            } catch (Mage_Core_Exception $e) {
                Mage::throwException(Mage::helper('core')->__('Cannot create an invoice.'));
            }
        }
    }
}
