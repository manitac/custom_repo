<?php
/**
 * Class TM_Addquantity_Helper_Data
 *
 * @category    Local
 * @package     TM_Addquantity
 */
 class TM_Addquantity_Helper_Data extends Mage_Core_Helper_Abstract {


}