<?php

/**
 * Class TM_Aboutusoptions_Model_Mysql4_Sliderbanner_Collection
 *
 * @category    Local
 * @package     TM_Aboutusoptions
 */
class TM_Aboutusoptions_Model_Mysql4_Aboutusoptions_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {

    public function _construct() {
        $this->_init("aboutusoptions/aboutusoptions");
    }

}
