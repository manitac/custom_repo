<?php
/**
 * Class TM_Aboutusoptions_Model_Mysql4_Aboutusoptions
 *
 * @category    Local
 * @package     TM_Aboutusoptions

 */
class TM_Aboutusoptions_Model_Mysql4_Aboutusoptions extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("aboutusoptions/aboutusoptions", "aboutusoptions_id");
    }
}