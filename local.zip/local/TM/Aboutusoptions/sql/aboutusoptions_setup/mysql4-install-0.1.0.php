<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table aboutusoptions(aboutusoptions_id int not null auto_increment, title text, status tinyint(2),primary key(aboutusoptions_id));

		
SQLTEXT;

$installer->run($sql);
//demo 
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 