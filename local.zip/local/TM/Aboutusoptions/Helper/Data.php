<?php
/**
 * Class TM_Aboutusoptions_Helper_Data
 *
 * @category    Local
 * @package     TM_Aboutusoptions
 */
class TM_Aboutusoptions_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 