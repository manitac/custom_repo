<?php
	
class TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
		public function __construct()
		{

				parent::__construct();
				$this->_objectId = "aboutusoptions_id";
				$this->_blockGroup = "aboutusoptions";
				$this->_controller = "adminhtml_aboutusoptions";
				$this->_updateButton("save", "label", Mage::helper("aboutusoptions")->__("Save Item"));
				$this->_updateButton("delete", "label", Mage::helper("aboutusoptions")->__("Delete Item"));

				$this->_addButton("saveandcontinue", array(
					"label"     => Mage::helper("aboutusoptions")->__("Save And Continue Edit"),
					"onclick"   => "saveAndContinueEdit()",
					"class"     => "save",
				), -100);



				$this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
		}

		public function getHeaderText()
		{
				if( Mage::registry("aboutusoptions_data") && Mage::registry("aboutusoptions_data")->getId() ){

				    return Mage::helper("aboutusoptions")->__("Edit Item '%s'", $this->htmlEscape(Mage::registry("aboutusoptions_data")->getId()));

				} 
				else{

				     return Mage::helper("aboutusoptions")->__("Add Item");

				}
		}
}