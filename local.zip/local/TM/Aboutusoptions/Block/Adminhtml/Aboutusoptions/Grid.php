<?php

class TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    public function __construct() {
        parent::__construct();
        $this->setId("aboutusoptionsGrid");
        $this->setDefaultSort("aboutusoptions_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection() {
        $collection = Mage::getModel("aboutusoptions/aboutusoptions")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns() {
        $this->addColumn("aboutusoptions_id", array(
            "header" => Mage::helper("aboutusoptions")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "aboutusoptions_id",
        ));
$this->addColumn("title", array(
            "header" => Mage::helper("aboutusoptions")->__("Title"),
            "type" => "text",
            "index" => "title",
        ));
        $this->addColumn('status', array(
            'header' => Mage::helper('aboutusoptions')->__('Status'),
            'index' => 'status',
            'type' => 'options',
            'options' => TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Grid::getOptionArray1(),
        ));

        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row) {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField('aboutusoptions_id');
        $this->getMassactionBlock()->setFormFieldName('aboutusoptions_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_aboutusoptions', array(
            'label' => Mage::helper('aboutusoptions')->__('Remove Aboutusoptions'),
            'url' => $this->getUrl('*/adminhtml_aboutusoptions/massRemove'),
            'confirm' => Mage::helper('aboutusoptions')->__('Are you sure?')
        ));
        return $this;
    }

    static public function getOptionArray1() {
        $data_array = array();
        $data_array[0] = 'Enabled';
        $data_array[1] = 'Disabled';
        return($data_array);
    }

    static public function getValueArray1() {
        $data_array = array();
        foreach (TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Grid::getOptionArray1() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }

}
