<?php
class TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("aboutusoptions_form", array("legend"=>Mage::helper("aboutusoptions")->__("Item information")));

				
						$fieldset->addField("title", "textarea", array(
						"label" => Mage::helper("aboutusoptions")->__("Options Title"),					
						"class" => "required-entry",
						"required" => true,
						"name" => "title",
						));
									
						 $fieldset->addField('status', 'select', array(
						'label'     => Mage::helper('aboutusoptions')->__('Status'),
						'values'   => TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions_Grid::getValueArray1(),
						'name' => 'status',					
						"class" => "required-entry",
						"required" => true,
						));

				if (Mage::getSingleton("adminhtml/session")->getAboutusoptionsData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getAboutusoptionsData());
					Mage::getSingleton("adminhtml/session")->setAboutusoptionsData(null);
				} 
				elseif(Mage::registry("aboutusoptions_data")) {
				    $form->setValues(Mage::registry("aboutusoptions_data")->getData());
				}
				return parent::_prepareForm();
		}
}
