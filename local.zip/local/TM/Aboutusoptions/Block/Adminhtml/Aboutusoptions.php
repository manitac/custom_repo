<?php


class TM_Aboutusoptions_Block_Adminhtml_Aboutusoptions extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_aboutusoptions";
	$this->_blockGroup = "aboutusoptions";
	$this->_headerText = Mage::helper("aboutusoptions")->__("Aboutusoptions Manager");
	$this->_addButtonLabel = Mage::helper("aboutusoptions")->__("Add New Item");
	parent::__construct();
	
	}

}