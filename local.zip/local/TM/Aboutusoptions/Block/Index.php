<?php

/**
 * Class TM_Aboutusoptions_Block_Index
 *
 * @category    Local
 * @package     TM_Aboutusoptions
 */
class TM_Aboutusoptions_Block_Index extends Mage_Core_Block_Template {

    /**
     * Load all option informtion from created in admin panel to show on frontend.
     * 
     * @return Array
     */
    public function getAboutUsOption() {
        if (is_null($this->_optionInfo)) {
            $this->_optionInfo = Mage::getModel('aboutusoptions/aboutusoptions')
                            ->getCollection()->addFieldToFilter('status', 0);
        }
        return $this->_optionInfo;
    }

}
