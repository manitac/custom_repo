<?php  

class TM_CustomProducts_Block_Adminhtml_CustomProductsbackend extends Mage_Adminhtml_Block_Template {
    
    /**
     * Load the view info of current custom product details.
     *
     * @return array
     */
    public function viewinfo()
    {
        $id = $this->getRequest()->getParam("id");
        $custom_product = Mage::getModel("customproducts/customproduct")->load($id);  
        return $custom_product;
    }
    /**
     * Return type of custom product based on the boolen value.
     *
     * @return string
     */
    public function get_type($type)
    {
        if($type == 1){
             return 'Stuffed';
        } else {
                 return 'Unstuffed';
             }
        
        
    }

}