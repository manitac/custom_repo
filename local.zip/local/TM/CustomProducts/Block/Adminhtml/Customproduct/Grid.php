<?php

class TM_CustomProducts_Block_Adminhtml_Customproduct_Grid extends Mage_Adminhtml_Block_Widget_Grid {

    public function __construct() {
        parent::__construct();
        $this->setId("customproductGrid");
        $this->setDefaultSort("custom_products_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection() {
        $collection = Mage::getModel("customproducts/customproduct")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns() {
        $this->addColumn("custom_products_id", array(
            "header" => Mage::helper("customproducts")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "custom_products_id",
        ));

        $this->addColumn('date', array(
            'header' => Mage::helper('customproducts')->__('Date'),
            'index' => 'date',
            'type' => 'datetime',
        ));
         $this->addColumn('prod_desc', array(
            'header' => Mage::helper('customproducts')->__('Description'),
            'index' => 'prod_desc',
            
        ));
         
          $this->addColumn('sample', array(
            'header' => Mage::helper('catalog')->__('Image'),
            'width' => '50px',
            'index' => 'sample',
            'frame_callback' => array($this, 'callback_image')
        ));

        $this->addColumn("no_of_pieces", array(
            "header" => Mage::helper("customproducts")->__("No of pieces"),
            "index" => "no_of_pieces",
        ));
        $this->addColumn("size", array(
            "header" => Mage::helper("customproducts")->__("Size"),
            "index" => "size",
        ));
        $this->addColumn('type', array(
            'header' => Mage::helper('customproducts')->__('Type'),
            'index' => 'type',
            'type' => 'options',
            'options' => TM_CustomProducts_Block_Adminhtml_Customproduct_Grid::getOptionArray5(),
        ));

        $this->addColumn("special_event_desc", array(
            "header" => Mage::helper("customproducts")->__("Special Event Description"),
            "index" => "special_event_desc",
        ));
        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row) {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction() {
        $this->setMassactionIdField('custom_products_id');
        $this->getMassactionBlock()->setFormFieldName('custom_products_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_customproduct', array(
            'label' => Mage::helper('customproducts')->__('Remove Customproduct'),
            'url' => $this->getUrl('*/adminhtml_customproduct/massRemove'),
            'confirm' => Mage::helper('customproducts')->__('Are you sure?')
        ));
        return $this;
    }

    static public function getOptionArray5() {
        $data_array = array();
        $data_array[0] = 'Stuffed';
        $data_array[1] = 'Unstuffed';
        return($data_array);
    }

    static public function getValueArray5() {
        $data_array = array();
        foreach (TM_CustomProducts_Block_Adminhtml_Customproduct_Grid::getOptionArray5() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }
     public function callback_image($value) {
        $width = 150;
        $height = 70;
        return  "<img src='" . Mage::getBaseUrl('media') . $value . "' width=" . $width . " height=" . $height . "/>";
    }

}
