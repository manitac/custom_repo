<?php

class TM_CustomProducts_Block_Adminhtml_Customproduct extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_customproduct";
	$this->_blockGroup = "customproducts";
	$this->_headerText = Mage::helper("customproducts")->__("Customproduct Manager");
	$this->_addButtonLabel = Mage::helper("customproducts")->__("Add New Item");
	parent::__construct();
	$this->_removeButton('add');
	}
        public function viewinfo()
    {
        $id = $this->getRequest()->getParam("id");
        $custom_product = Mage::getModel("customproducts/customproduct")->load($id);  
        return $custom_product;
    }
    /**
     * Return type of custom product based on the boolen value.
     *
     * @return string
     */
    public function get_type($type)
    {
        if($type == 1){
             return 'Stuffed';
        } else {
                 return 'Unstuffed';
             }
        
        
    }
        
       

}