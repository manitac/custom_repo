<?php

class TM_CustomProducts_IndexController extends Mage_Core_Controller_Front_Action {

    public function IndexAction() {

        $this->loadLayout();
        $this->getLayout()->getBlock("head")->setTitle($this->__("Custom Products"));
        $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
        $breadcrumbs->addCrumb("home", array(
            "label" => $this->__("Home Page"),
            "title" => $this->__("Home Page"),
            "link" => Mage::getBaseUrl()
        ));

        $breadcrumbs->addCrumb("custom products", array(
            "label" => $this->__("Custom Products"),
            "title" => $this->__("Custom Products")
        ));

        $this->renderLayout();
    }

    public function customProductsAction() {
        
        $post_data = $this->getRequest()->getPost();
        $today_date = Mage::getModel('core/date')->date('Y-m-d');
        if ($post_data) {
            if(strtotime($post_data['date']) >= (strtotime($today_date)))
            { 
                try {

                    //save image
                    try {

                        if ((bool) $post_data['sample']['delete'] == 1) {

                            $post_data['sample'] = '';
                        } else {

                            unset($post_data['sample']);

                            if (isset($_FILES)) {

                                if ($_FILES['sample']['name']) {

                                    if ($this->getRequest()->getParam("id")) {
                                        $model = Mage::getModel("customproducts/customproduct")->load($this->getRequest()->getParam("id"));
                                        if ($model->getData('sample')) {
                                            $io = new Varien_Io_File();
                                            $io->rm(Mage::getBaseDir('media') . DS . implode(DS, explode('/', $model->getData('sample'))));
                                        }
                                    }
                                    $path = Mage::getBaseDir('media') . DS . 'customproducts' . DS . 'customproduct' . DS;
                                    $uploader = new Varien_File_Uploader('sample');
                                    $uploader->setAllowedExtensions(array('jpg', 'png', 'gif'));
                                    $uploader->setAllowRenameFiles(false);
                                    $uploader->setFilesDispersion(false);
                                    $destFile = $path . $_FILES['sample']['name'];
                                    $filename = $uploader->getNewFileName($destFile);
                                    $uploader->save($path, $filename);

                                    $post_data['sample'] = 'customproducts/customproduct/' . $filename;
                                }
                            }
                        }
                    } catch (Exception $e) {
                        Mage::getSingleton('core/session')->addError($e->getMessage());
                        $this->_redirect("custom-products/");
                        return;
                    }
    //save image


                    $model = Mage::getModel("customproducts/customproduct");

                    $model->addData($post_data)
                            ->setId($this->getRequest()->getParam("id"))
                            ->save();
                    $this->sendMail($post_data, $filename, $path.$filename);
                    Mage::getSingleton("core/session")->addSuccess(Mage::helper("adminhtml")->__("Thanks for requesting custom product information. We will contact you shortly"));
                    Mage::getSingleton("core/session")->setCustomproductData(false);
                    $this->_redirect("custom-products/");
                    return;
                } catch (Exception $e) {
                    Mage::getSingleton("core/session")->addError($e->getMessage());
                    Mage::getSingleton("core/session")->setCustomproductData($this->getRequest()->getPost());
                    $this->_redirect("custom-products/", array("id" => $this->getRequest()->getParam("id")));
                    return;
                }
            }
            else{
                Mage::getSingleton("core/session")->addError(Mage::helper("adminhtml")->__("Invalid Date"));
            }
        }
        $this->_redirect("custom-products/");
    }
    
    private function sendMail($post_data,$filename="",$file="")
    {   
        $emailTemplate = Mage::getModel('core/email_template')
                    ->loadDefault('custom_products_email_template');
        $emailTemplateVariables = $post_data;
        $emailTemplateVariables['attachment'] = $filename;
        $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
        if($file)
            $attachment1 = file_get_contents($file);
        else
            $attachment1 = "";
        $to = $post_data['email'];
        $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
        $subject = 'Custom Product Upload Information - Teddymountain';
        try {
            $z_mail = new Zend_Mail('utf-8');
            $z_mail->setBodyHtml($processedTemplate)
                    ->setSubject($subject)
                    ->addTo(array($to,$store_email))
                    ->setFrom($store_email, "From direct wholesale");
            if($attachment1)
            {
                $attach = new Zend_Mime_Part($attachment1);
                //$attach->type = 'application/csv';
                $attach->disposition = Zend_Mime::DISPOSITION_INLINE;
                $attach->encoding = Zend_Mime::ENCODING_BASE64;
                $attach->filename = $filename;
                $z_mail->addAttachment($attach);
            }
            $z_mail->send();
        } catch (Exception $e) {
            return false;
        }
    }

}
