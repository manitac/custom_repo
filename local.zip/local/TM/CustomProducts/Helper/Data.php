<?php
/**
 * Class TM_CustomProducts_Helper_Data
 *
 * @category    Local
 * @package     TM_CustomProducts
 */
class TM_CustomProducts_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 