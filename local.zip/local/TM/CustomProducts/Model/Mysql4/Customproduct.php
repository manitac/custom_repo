<?php
class TM_CustomProducts_Model_Mysql4_Customproduct extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("customproducts/customproduct", "custom_products_id");
    }
}