<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE {$this->getTable('custom_products')} 
ADD COLUMN email VARCHAR(255) NOT NULL AFTER custom_products_id;
");
$installer->endSetup();