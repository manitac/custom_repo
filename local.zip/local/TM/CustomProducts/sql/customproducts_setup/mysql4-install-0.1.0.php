<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table custom_products(custom_products_id int not null auto_increment, date DATE , prod_desc TEXT, sample varchar(255), no_of_pieces varchar(100), size varchar(255), type varchar(100), special_feature text,artwork text, packaging_requirment text, special_event_desc text ,primary key(custom_products_id));

		
SQLTEXT;

$installer->run($sql);

$installer->endSetup();
	 