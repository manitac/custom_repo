<?php

class Hardik_Ajaxcart_QuickviewController extends Mage_Core_Controller_Front_Action {
    
    public function indexAction() {
        
       $quickview_id= $this->getRequest()->getParam('quickview_id');
       
        Mage::register('quickview_id', $quickview_id);
        if(!empty($quickview_id)){
            echo $this->getLayout()->createBlock('catalog/product_list')->setTemplate('ajaxcart/quick-view.phtml')->toHtml();
        }
        exit;
    }
    
    
}
