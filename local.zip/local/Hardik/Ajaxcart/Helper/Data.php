<?php
class Hardik_Ajaxcart_Helper_data extends Mage_Core_Helper_Abstract {}