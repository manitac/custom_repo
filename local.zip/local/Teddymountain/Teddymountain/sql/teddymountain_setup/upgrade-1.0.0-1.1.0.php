<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
create table leftsidebarlinks
(
leftsidebarlinks_id int not null auto_increment, 
title varchar(200), 
image varchar(200),
description text,
status varchar(200),
store varchar(200),
sort_order varchar(10),
link varchar(220),
primary key(leftsidebarlinks_id)
);
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
