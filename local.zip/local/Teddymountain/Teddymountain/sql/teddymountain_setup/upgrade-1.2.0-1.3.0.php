<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
ALTER TABLE preregistration
ADD COLUMN expiry INT(10) UNSIGNED NOT NULL AFTER approved;
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
