<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
ALTER TABLE preregistration
DROP COLUMN expiry,
ADD COLUMN expiry enum('0','1') default '0' 
AFTER approved;
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
