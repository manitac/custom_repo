<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
create table promotions
(
promotions_id int not null auto_increment, 
name varchar(200), 
store varchar(200),
description text,
start_date text,
end_date text,        
is_active varchar(10),
promotion_items text,
sales_result varchar(220),
html_code text,
primary key(promotions_id)
);
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
