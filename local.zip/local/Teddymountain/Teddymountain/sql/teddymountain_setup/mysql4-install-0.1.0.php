<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table sliderbanner
(
sliderbanner_id int not null auto_increment, 
title varchar(200), 
image varchar(200),
description text,
status varchar(200),
store varchar(200),
sort_order varchar(10),
link varchar(220),
primary key(sliderbanner_id)
);

create table preregistration
(
preregistration_id int not null auto_increment, 
registration_code varchar(50),
name varchar(200),
telephone varchar(200),
email varchar(100),
hearsource varchar(100),
query text,
approved  varchar(100),
primary key(preregistration_id)

);
SQLTEXT;

$installer->run($sql);
//demo
//Mage::getModel('core/url_rewrite')->setId(null);
//demo
$installer->endSetup();
