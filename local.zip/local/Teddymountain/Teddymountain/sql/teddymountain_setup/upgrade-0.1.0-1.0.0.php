<?php

$installer = $this;
$installer->startSetup();
$sql = <<<SQLTEXT
create table pagecustommenu
(
pagecustommenu_id int not null auto_increment, 
pattern_a text null,
primary key(pagecustommenu_id)

);
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
