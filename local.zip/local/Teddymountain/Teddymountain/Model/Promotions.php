<?php
/**
 * Class Teddymountain_Teddymountain_Model_Promotions
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Model_Promotions extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init("teddymountain/promotions");
    }
}
