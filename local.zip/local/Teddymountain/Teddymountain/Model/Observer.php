<?php
/**
 * Class Teddymountain_Teddymountain_Model_Observer
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Model_Observer
{
    public function varifyRegsiatrtionCode(Varien_Event_Observer $observer)
    {
        $action = Mage::app()->getRequest()->getActionName();
        $registration_id = Mage::app()->getRequest()->getParam('registrtaion_code');
        $email = Mage::app()->getRequest()->getParam('email');
        if ($action != "createpost") {
            return;
        }
        // $user = $observer->getEvent()->getUser();
        $preregistration_email = Mage::getModel("teddymountain/preregistration")->getCollection()
                                                                        ->addFieldToFilter('registration_code', array('eq' => $registration_id))
                                                                        ->getFirstItem()->getEmail();
        $msg="Please enter the email that was used for registration code request.";
        if (strtolower($preregistration_email) != strtolower($email)) {
            Mage::throwException($msg);
        }
    }
    
    public function expireRegsiatrtionCode(Varien_Event_Observer $observer)
    {
        $action = Mage::app()->getRequest()->getActionName();
        $registration_id = Mage::app()->getRequest()->getParam('registrtaion_code');
        $email = Mage::app()->getRequest()->getParam('email');
        if ($action != "createpost") {
            return;
        }
        Mage::getModel("teddymountain/preregistration")->load($registration_id, 'registration_code')
                                                    ->setexpiry('1')->save();
    }
}
