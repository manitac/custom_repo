<?php
/**
 * Class Teddymountain_Teddymountain_Model_Mysql4_Leftsidebarlinks
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Model_Mysql4_Leftsidebarlinks extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("teddymountain/leftsidebarlinks", "leftsidebarlinks_id");
    }
}
