<?php
/**
 * Class Teddymountain_Teddymountain_Model_Mysql4_Pagecustommenu
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Model_Mysql4_Pagecustommenu extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init("teddymountain/pagecustommenu", "pagecustommenu_id");
    }
}
