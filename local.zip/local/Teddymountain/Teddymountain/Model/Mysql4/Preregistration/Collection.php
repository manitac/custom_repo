<?php
/**
 * Class Teddymountain_Teddymountain_Model_Mysql4_Preregistration_Collection
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Model_Mysql4_Preregistration_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        $this->_init("teddymountain/preregistration");
    }
}
