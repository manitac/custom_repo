<?php
/**
 * Class Teddymountain_Teddymountain_Adminhtml_PromotionsController
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Adminhtml_PromotionsController extends Mage_Adminhtml_Controller_Action {

    protected function _initAction() {
        $this->loadLayout()->_setActiveMenu("teddymountain/promotions")->_addBreadcrumb(Mage::helper("adminhtml")->__("Promotions  Manager"), Mage::helper("adminhtml")->__("Promotions Manager"));
        return $this;
    }

    public function indexAction() {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Manager Promotions"));

        $this->_initAction();
        $this->renderLayout();
    }

    public function editAction() {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Promotions"));
        $this->_title($this->__("Edit Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("teddymountain/promotions")->load($id);
        if ($model->getId()) {
            Mage::register("promotions_data", $model);
            $this->loadLayout();
            $this->_setActiveMenu("teddymountain/promotions");
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Promotions Manager"), Mage::helper("adminhtml")->__("Promotions Manager"));
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Promotions Description"), Mage::helper("adminhtml")->__("Promotions Description"));
            $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
            $this->_addContent($this->getLayout()->createBlock("teddymountain/adminhtml_promotions_edit"))->_addLeft($this->getLayout()->createBlock("teddymountain/adminhtml_promotions_edit_tabs"));
            $this->renderLayout();
        } else {
            Mage::getSingleton("adminhtml/session")->addError(Mage::helper("teddymountain")->__("Item does not exist."));
            $this->_redirect("*/*/");
        }
    }

    public function newAction() {

        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Promotions"));
        $this->_title($this->__("New Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("teddymountain/promotions")->load($id);

        $data = Mage::getSingleton("adminhtml/session")->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        Mage::register("promotions_data", $model);

        $this->loadLayout();
        $this->_setActiveMenu("teddymountain/promotions");

        $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Promotions Manager"), Mage::helper("adminhtml")->__("Promotions Manager"));
        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Promotions Description"), Mage::helper("adminhtml")->__("Promotions Description"));


        $this->_addContent($this->getLayout()->createBlock("teddymountain/adminhtml_promotions_edit"))->_addLeft($this->getLayout()->createBlock("teddymountain/adminhtml_promotions_edit_tabs"));

        $this->renderLayout();
    }

    public function saveAction() {

        $post_data = $this->getRequest()->getPost();
        $updater = Mage::getSingleton('catalog/product_action');
        
        $json_promotion_products = '';   
        if (isset($post_data['links'])) {   //position input field data

            $promotions_products = Mage::helper('adminhtml/js')->decodeGridSerializedInput($post_data['links']['products']);
            $json_promotion_products = json_encode($promotions_products);
            $post_data['position'] = $json_promotion_products;

            //un-assign special price from excluded products
            $data_row_id= $this->getRequest()->getParam("id"); 
            if($data_row_id){
                   
                    $promotional_products_beforesave = Mage::helper('teddymountain')->getSelectedPromotionalProducts($data_row_id);
                    $promotional_products_beforesave=array_keys($promotional_products_beforesave);
                    $promotional_products_tosave=array_keys($promotions_products);

                    $excluded_products= array_diff($promotional_products_beforesave, $promotional_products_tosave);                   
                    
                    if (sizeof($excluded_products)>0) {                        
                        $updater->updateAttributes($excluded_products, array('special_from_date' => null, 'special_to_date' => null,'special_price'=>null), 0);
                    }
                }
        }



        if ($post_data) {
            $post_data = $this->_filterDates($post_data, array("start_date", "end_date"));
            //print_r($post_data); exit();
            // Mage::log($post_data);
            $is_active = $post_data['is_active'];

            unset($post_data['name']);
            unset($post_data['sku']);
            unset($post_data['price']);
            unset($post_data['special_price']);
            unset($post_data['generatedHtml']);

            try {


               
                

                $model = Mage::getModel("teddymountain/promotions")
                                ->addData($post_data)
                                ->setId($this->getRequest()->getParam("id"))
                                ->save();

                    

                //dates might have been changed so update the promotional items fromDate & toDate accordingly       
                    $savedRowId=$model->getId(); 
                    $promotional_products1 = Mage::helper('teddymountain')->getSelectedPromotionalProducts($savedRowId);

                if (isset($post_data['links'])) {

                    $promotions_products = Mage::helper('adminhtml/js')->decodeGridSerializedInput($post_data['links']['products']);
                    $promotions_products_id = array_keys($promotions_products);

                    /*  manage is_active by startdate and enddate 
                     *  is_active post value: 1-disble, 0-enable
                     */

                    $startDate = $post_data['start_date'];
                    $endDate = $post_data['end_date'];
                    if ($is_active == 1) {
                        $startDate = '2015-10-10'; //expired date
                        $endDate = '2015-11-11';
                    }

                    $updater->updateAttributes($promotions_products_id, array('special_from_date' => $startDate, 'special_to_date' => $endDate), 0);
                }else if (sizeof($promotional_products1) > 0) {                 

                    $promotions_products_id_1 = array_keys($promotional_products1);
                    // Mage::log($promotions_products_id_1);
                    $startDate = $post_data['start_date'];
                    $endDate = $post_data['end_date'];
                    if ($is_active == 1) {
                        $startDate = '2015-10-10'; //expired date
                        $endDate = '2015-11-11';
                    }
                  
                    $updater->updateAttributes($promotions_products_id_1, array('special_from_date' => $startDate, 'special_to_date' => $endDate), 0);
                
                }


                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Promotions was successfully saved"));
                Mage::getSingleton("adminhtml/session")->setPromotionsData(false);

                if ($this->getRequest()->getParam("back")) {
                    $this->_redirect("*/*/edit", array("id" => $model->getId()));
                    return;
                }
                $this->_redirect("*/*/");
                return;
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                Mage::getSingleton("adminhtml/session")->setPromotionsData($this->getRequest()->getPost());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
                return;
            }
        }
        $this->_redirect("*/*/");
    }

    public function deleteAction() {
        
        $updater = Mage::getSingleton('catalog/product_action');
        if ($this->getRequest()->getParam("id") > 0) {
            try { 
                /***********set products date to past date when promotion rule is deleted************/
                    $model1 = Mage::getModel("teddymountain/promotions")->load($this->getRequest()->getParam("id"));
                    $promotions_products_ids =  array_keys((json_decode($model1->getPosition(), true)));    
                    if (sizeof($promotions_products_ids) > 0) {
                        $startDate = '2015-10-10'; //expired date
                        $endDate = '2015-11-11';
                        $updater->updateAttributes($promotions_products_ids, array('special_from_date' => $startDate, 'special_to_date' => $endDate), 0);
                    }
                    
                $model = Mage::getModel("teddymountain/promotions");
                $model->setId($this->getRequest()->getParam("id"))->delete();
                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
                $this->_redirect("*/*/");
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
            }
        }
        $this->_redirect("*/*/");
    }

    public function massRemoveAction() {
        $updater = Mage::getSingleton('catalog/product_action');
        try {
            $ids = $this->getRequest()->getPost('Promotions_ids', array());
           
            foreach ($ids as $id) {
                /***********set products date to past date when there respective promotion rule is deleted**********/
                    $model1 = Mage::getModel("teddymountain/promotions")->load($id);
                    $promotions_products_ids =  array_keys((json_decode($model1->getPosition(), true)));    
                    if (sizeof($promotions_products_ids) > 0) {
                        $startDate = '2015-10-10'; //expired date
                        $endDate = '2015-11-11';
                        $updater->updateAttributes($promotions_products_ids, array('special_from_date' => $startDate, 'special_to_date' => $endDate), 0);
                    }

                $model = Mage::getModel("teddymountain/promotions");
                $model->setId($id)->delete();
            }

            Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
        } catch (Exception $e) {
            Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
        }
        $this->_redirect('*/*/');
    }

    /**
     * Export order grid to CSV format
     */
    public function exportCsvAction() {
        $fileName = 'promotions.csv';
        $grid = $this->getLayout()->createBlock('teddymountain/adminhtml_promotions_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }

    /**
     *  Export order grid to Excel XML format
     */
    public function exportExcelAction() {
        $fileName = 'promotions.xml';
        $grid = $this->getLayout()->createBlock('teddymountain/adminhtml_promotions_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }

    public function productAction() {
        $this->loadLayout();
        $tmp = $this->getRequest()->getPost('products', null);
        $this->getLayout()->getBlock('product.grid')
                ->setProducts($tmp);
        $this->renderLayout();
    }

    public function productgridAction() {
        $this->loadLayout();
        $tmp = $this->getRequest()->getPost('products', null);
        $this->getLayout()->getBlock('product.grid')
                ->setProducts($tmp);
        $this->renderLayout();
    }

    public function buildHTMLAction() {
        $id = $this->getRequest()->getParam("id");
        $promotional_products = Mage::helper('teddymountain')->getSelectedPromotionalProducts($id);

        //generate html code
        $html = '<table class="promotional-items-html" style="width: 100%;padding:0 2%" cellspacing="0" cellpadding="0">';
        $html.='<tr>';

        $productModel = Mage::getModel('catalog/product');
        $imageHelper = Mage::helper('catalog/image');
        $count = 0;
        foreach ($promotional_products as $product_id => $data) {
            $product = $productModel->load($product_id);

            $img = $imageHelper->init($product, 'thumbnail')->resize(100);
            $name = $product->getName();
            $name = Mage::helper('core')->escapeHtml($name);

            $price = $product->getFinalPrice();
            $price = Mage::helper('core')->currency($price, true, false);
            $special_price = $product->getSpecialPrice();
            $special_price = Mage::helper('core')->currency($special_price, true, false);
            $details_page_link = $product->getProductUrl();
            $vendor = $product->getSku();
            $barcode = $product->getBarcode();
            $title = $name . '&#13' . ' UPC: ' . $barcode . ',&nbsp; Vendor: ' . $vendor;

            $html.='<td title="' . $title . '" style="text-align:center;width: 24%;">';
            $html.='<div class="html-container">';
            $html.='<div><a href="' . $details_page_link . '"><img src="' . $img . '" width="130" height="150"></a></div>';
            $html.='<div><p><strong>' . $name . '</strong></p><p><strong>Price: ' . $special_price . '</strong></p></div>';
            $html.='</div>';
            $html.='</td>';

            if (++$count == 4) {
                $count = 0;
                $html.='</tr><tr>';
            }
        }

        $html.='</table>';

        echo $html;
        exit;
    }

    public function updatePromotionalSpecialPriceAction() {

        $postData = $this->getRequest()->getPost();
        $postData = $this->_filterDates($postData, array("startDate", "endDate"));

        $id = $postData['id'];
        $special_price = $postData['special_price'];
        $special_price = ($special_price == 0) ? null : $special_price;

        $startDate = $postData["startDate"];
        $endDate = $postData["endDate"];

        $storeId = Mage::app()->getStore()->getId();    //specific store id

        try {
            $updateed_prod_id = Mage::getModel('catalog/product')
                    ->setStoreId($storeId)
                    ->load($id)
                    ->setSpecialPrice($special_price)
                    // Sets the Start Date
                    ->setSpecialFromDate($startDate)
                    ->setSpecialFromDateIsFormated(true)
                    ->setSpecialToDate($endDate)
                    ->setSpecialToDateIsFormated(true)
                    ->save()
                    ->getId();

            echo "product $updateed_prod_id is updated";
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }


    public function gridAction()
     {
        $this->loadLayout();
        $this->getResponse()->setBody(
               $this->getLayout()->createBlock('teddymountain/adminhtml_promotions_grid')->toHtml()
        );
     }

    /**
    * allow resource in user permision
    *
    */
    protected function _isAllowed()
    {
        return true;
    }

}
