<?php
/**
 * Class Teddymountain_Teddymountain_Adminhtml_MenuController
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Adminhtml_MenuController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Manager Pagecustommenu"));

        $this->loadLayout();
        $this->renderLayout();
    }

    public function saveAction()
    {
        echo $pattern_a = $this->getRequest()->getParam('pattern_a');
        $pattern_b = $this->getRequest()->getParam('pattern_b');
//        $id = Mage::getModel('teddymountain/pagecustommenu')->getCollection()->getData('pagecustommenu_id');
        $resource = Mage::getSingleton('core/resource');
        $writeConnection = $resource->getConnection('core_write');
        $tableName = $resource->getTableName('teddymountain/pagecustommenu');

        $id = 1;


        $query = "UPDATE {$tableName} SET pattern_a = '{$pattern_a}' WHERE pagecustommenu_id = "
                . (int) $id;

        if (!empty($pattern_a)) {
            $writeConnection->query($query);
        }

        exit;
    }


    /**
    * allow resource in user permision
    *
    */
    protected function _isAllowed()
    {
        return true;
    }
}
