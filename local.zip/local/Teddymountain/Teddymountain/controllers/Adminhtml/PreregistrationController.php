<?php

/**
 * Class Teddymountain_Teddymountain_Adminhtml_PreregistrationController
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Adminhtml_PreregistrationController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
        $this->loadLayout()->_setActiveMenu("teddymountain/preregistration")->_addBreadcrumb(Mage::helper("adminhtml")->__("Preregistration  Manager"), Mage::helper("adminhtml")->__("Preregistration Manager"));
        return $this;
    }

    public function indexAction()
    {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Manager Preregistration"));

        $this->_initAction();
        $this->renderLayout();
    }

    public function editAction()
    {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Preregistration"));
        $this->_title($this->__("Edit Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("teddymountain/preregistration")->load($id);
        if ($model->getId()) {
            Mage::register("preregistration_data", $model);
            $this->loadLayout();
            $this->_setActiveMenu("teddymountain/preregistration");
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Preregistration Manager"), Mage::helper("adminhtml")->__("Preregistration Manager"));
            $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Preregistration Description"), Mage::helper("adminhtml")->__("Preregistration Description"));
            $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);
            $this->_addContent($this->getLayout()->createBlock("teddymountain/adminhtml_preregistration_edit"))->_addLeft($this->getLayout()->createBlock("teddymountain/adminhtml_preregistration_edit_tabs"));
            $this->renderLayout();
        } else {
            Mage::getSingleton("adminhtml/session")->addError(Mage::helper("teddymountain")->__("Item does not exist."));
            $this->_redirect("*/*/");
        }
    }

    public function newAction()
    {
        $this->_title($this->__("Teddymountain"));
        $this->_title($this->__("Preregistration"));
        $this->_title($this->__("New Item"));

        $id = $this->getRequest()->getParam("id");
        $model = Mage::getModel("teddymountain/preregistration")->load($id);

        $data = Mage::getSingleton("adminhtml/session")->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        Mage::register("preregistration_data", $model);

        $this->loadLayout();
        $this->_setActiveMenu("teddymountain/preregistration");

        $this->getLayout()->getBlock("head")->setCanLoadExtJs(true);

        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Preregistration Manager"), Mage::helper("adminhtml")->__("Preregistration Manager"));
        $this->_addBreadcrumb(Mage::helper("adminhtml")->__("Preregistration Description"), Mage::helper("adminhtml")->__("Preregistration Description"));


        $this->_addContent($this->getLayout()->createBlock("teddymountain/adminhtml_preregistration_edit"))->_addLeft($this->getLayout()->createBlock("teddymountain/adminhtml_preregistration_edit_tabs"));

        $this->renderLayout();
    }

    public function saveAction()
    {
        $post_data = $this->getRequest()->getPost();


        if ($post_data) {
            if (empty($post_data['registration_code'])) {
                Mage::getSingleton("adminhtml/session")->addError("Registration code can't be blank.");
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
                return;
            }



            try {
                $model = Mage::getModel("teddymountain/preregistration")
                        ->addData($post_data)
                        ->setId($this->getRequest()->getParam("id"))
                        ->save();
                //send email
                if ($post_data['mail_send'] != 1 && $post_data['approved'] != 0) {
                    $this->sendMail($post_data, $post_data['registration_code']);
                }

                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Preregistration data was successfully saved"));
                Mage::getSingleton("adminhtml/session")->setPreregistrationData(false);

                if ($this->getRequest()->getParam("back")) {
                    $this->_redirect("*/*/edit", array("id" => $model->getId()));
                    return;
                }
                $this->_redirect("*/*/");
                return;
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                Mage::getSingleton("adminhtml/session")->setPreregistrationData($this->getRequest()->getPost());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
                return;
            }
        }
        $this->_redirect("*/*/");
    }

    public function deleteAction()
    {
        if ($this->getRequest()->getParam("id") > 0) {
            try {
                $model = Mage::getModel("teddymountain/preregistration");
                $model->setId($this->getRequest()->getParam("id"))->delete();
                Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item was successfully deleted"));
                $this->_redirect("*/*/");
            } catch (Exception $e) {
                Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
                $this->_redirect("*/*/edit", array("id" => $this->getRequest()->getParam("id")));
            }
        }
        $this->_redirect("*/*/");
    }

    public function massRemoveAction()
    {
        try {
            $ids = $this->getRequest()->getPost('preregistration_ids', array());
            foreach ($ids as $id) {
                $model = Mage::getModel("teddymountain/preregistration");
                $model->setId($id)->delete();
            }
            Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("Item(s) was successfully removed"));
        } catch (Exception $e) {
            Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
        }
        $this->_redirect('*/*/');
    }

    /**
     * Export order grid to CSV format
     */
    public function exportCsvAction()
    {
        $fileName = 'preregistration.csv';
        $grid = $this->getLayout()->createBlock('teddymountain/adminhtml_preregistration_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }

    /**
     *  Export order grid to Excel XML format
     */
    public function exportExcelAction()
    {
        $fileName = 'preregistration.xml';
        $grid = $this->getLayout()->createBlock('teddymountain/adminhtml_preregistration_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }

    /**
     * email template path-  app\locale\en_US\template\email\registration_code.html
     * @param type $post_data
     * @param type 
     */
    public function sendMail($post_data, $code)
    {
        $store_name = Mage::getModel('core/website')->load(1)->getName();
        $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
        $store_phone = Mage::getStoreConfig('general/store_information/phone');
        $template_path_xml = 'customer/quote_email/exist_user_quote_template';
        $register_link = Mage::getUrl('customer/account/create');
        //Array of variables to assign to template
        $emailTemplateVariables = array();
        $emailTemplateVariables['registration_code'] = $code;
        $emailTemplateVariables['name'] = $post_data['name'];
        $emailTemplateVariables['telephone'] = $post_data['telephone'];
        $emailTemplateVariables['email'] = $post_data['email'];
        $emailTemplateVariables['store_name'] = $store_name;
        $emailTemplateVariables['store_email'] = $store_email;
        $emailTemplateVariables['store_phone'] = $store_phone;
        $emailTemplateVariables['register_link'] = $register_link;
        

        $translate = Mage::getSingleton('core/translate');
        /* @var $translate Mage_Core_Model_Translate */
        $translate->setTranslateInline(false);
        $storeId = Mage::app()->getStore()->getId();
        $sender=Mage::getStoreConfig('registration_code/email/custom_identity', Mage::app()->getStore()->getId());
        $emailTemplate=Mage::getStoreConfig('registration_code/email/template', $storeId);

        Mage::getModel('core/email_template')
                ->setDesignConfig(array('area' => 'frontend', 'store' => $storeId))
                ->sendTransactional(
                $emailTemplate, $sender, $post_data['email'], $post_data['name'], $emailTemplateVariables);

        $translate->setTranslateInline(true);
    }

    /**
     * allow resource in user permision
     *
     */
    protected function _isAllowed()
    {
        return true;
    }
}
