    <?php

    /**
     * Class Teddymountain_Teddymountain_IndexController
     *
     * @category    Local
     * @package     Teddymountain_Teddymountain
     * @author      Mukesh Pandit <mukeshp@chetu.com>
     */
    class Teddymountain_Teddymountain_IndexController extends Mage_Core_Controller_Front_Action
    {
        public function IndexAction()
        {
            $this->loadLayout();
            $this->getLayout()->getBlock("head")->setTitle($this->__("Titlename"));
            $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
            $breadcrumbs->addCrumb("home", array(
                "label" => $this->__("Home Page"),
                "title" => $this->__("Home Page"),
                "link" => Mage::getBaseUrl()
            ));

            $breadcrumbs->addCrumb("titlename", array(
                "label" => $this->__("Titlename"),
                "title" => $this->__("Titlename")
            ));

            $this->renderLayout();
        }

        /**
         * varify the registration_code
         * @return type
         */
        public function preRegisterCodeAction()
        {
            $post_data = $this->getRequest()->getPost();
            $code = $post_data['registration_code'];
            $id = -1;
            if ($post_data) {
                $errorMsg = "<span style='color:red'>Invalid Registration Code Entered !</span>";
                if (!empty($code)) {
                    $preregistration = Mage::getModel("teddymountain/preregistration")->getCollection()
                                                                                    ->addFieldToFilter('registration_code', array('eq' => $code))
                                                                                    ->addFieldToFilter('approved', array('eq' => '1'))
                                                                                    ->addFieldToFilter('expiry', array('eq' => '0'))
                                                                                    ->getFirstItem()->getId();
                    Mage::getSingleton('core/session')->setRegistrationCode($code);
                    if (!empty($preregistration)) {
                        $successMsg = 'Redirecting to registration, please wait..';
                        $successMsg .= '@';
                        $successMsg .= Mage::getUrl("customer/account/create");
                        Mage::app()->getResponse()->setBody($successMsg);
                        return;
                    } else {
                        Mage::app()->getResponse()->setBody($errorMsg);
                    }
                } else {
                    Mage::app()->getResponse()->setBody($errorMsg);
                }
            }
        }

        /**
         * Create registration code & send it on the customer email
         * Used email template- app\locale\en_US\template\email\registration_code.html
         * @return type
         */
        public function preRegisterAction()
        {
            $post_data = $this->getRequest()->getPost();
            if ($post_data) {
                try {
                    //check duplicate entry
                    $model = Mage::getModel("teddymountain/preregistration");
                    $email_exists = $model->getCollection()
                                    ->addFieldToFilter('email', array('eq' => $post_data['email']))
                                    ->getFirstItem()->getId();
                                    
                    $customer = Mage::getModel('customer/customer');
                    $customer->setWebsiteId(Mage::app()->getWebsite()->getId());
                    $customer->loadByEmail($post_data['email']);

                    if (!empty($email_exists) || $customer->getId()) {
                        Mage::getSingleton("core/session")->addError("This email address is already in use. Please contact us or try with another email address.");
                        // session_write_close();
                        $this->_redirect("pre-register/");
                        return;
                    }
                    $model->addData($post_data)
                            ->setId($this->getRequest()->getParam("id"))
                            ->save();
                    $code = 'TM' . mt_rand(100000, 999999);
                    $code_exists = $model->getCollection()
                                    ->addFieldToFilter('registration_code', array('eq' => $code))
                                    ->getFirstItem()->getId();
                    $flag = true;
                    while ($flag) {
                        if (!empty($code_exists)) {
                            $code = 'TM' . mt_rand(100000, 999999);
                            $code_exists = $model->getCollection()
                                    ->addFieldToFilter('registration_code', array('eq' => $code))
                                    ->getFirstItem()->getId();
                        } else {
                            $flag = false;
                        }
                    }
                    $created_id = $model->getId();
                    Mage::getModel("teddymountain/preregistration")->load($created_id)->setregistration_code($code)->save();
                    $this->sendMail($post_data, $code, $created_id);
                    Mage::getSingleton("core/session")->addSuccess(Mage::helper("adminhtml")->__("Thanks for requesting registration code, We will contact you shortly"));
                    Mage::getSingleton("core/session")->setPreregistrationData(false);
                    $this->_redirect("pre-register/");
                    return;
                } catch (Exception $e) {
                    Mage::getSingleton("core/session")->addError($e->getMessage());
                    Mage::getSingleton("core/session")->setPreregistrationData($this->getRequest()->getPost());
                    $this->_redirect("pre-register/", array("id" => $this->getRequest()->getParam("id")));
                    return;
                }
            }
            $this->_redirect("pre-register/");
        }

        /**
         * email template path-  app\locale\en_US\template\email\registration_code_req_notificaton_admin.html
         * @param type $post_data
         * @param type 
         */
        public function sendMail($post_data, $code, $created_id)
        {
            $store_name = Mage::getModel('core/website')->load(1)->getName();
            $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
            $store_phone = Mage::getStoreConfig('general/store_information/phone');
            //Array of variables to assign to template
            $emailTemplateVariables = array();
            $emailTemplateVariables['created_id'] = $created_id;
            $emailTemplateVariables['registration_code'] = $code;
            $emailTemplateVariables['name'] = $post_data['name'];
            $emailTemplateVariables['telephone'] = $post_data['telephone'];
            $emailTemplateVariables['email'] = $post_data['email'];
            $emailTemplateVariables['hearsource'] = $post_data['hearsource'];
            $emailTemplateVariables['query'] = $post_data['query'];
            $emailTemplateVariables['about_business'] = $post_data['about_business'];
            $emailTemplateVariables['adminlink'] = Mage::helper('adminhtml')->getUrl('admin_teddymountain/adminhtml_preregistration');

            $emailTemplateVariables['store_name'] = $store_name;
            $emailTemplateVariables['store_email'] = $store_email;
            $emailTemplateVariables['store_phone'] = $store_phone;

            $translate = Mage::getSingleton('core/translate');
            /* @var $translate Mage_Core_Model_Translate */
            $translate->setTranslateInline(false);
            $storeId = Mage::app()->getStore()->getId();
            $sender = array('name' => $post_data['name'],'email' => $post_data['email']);
            $emailTemplate=Mage::getStoreConfig('registration_code/email/template_admin', $storeId);

            Mage::getModel('core/email_template')
                    ->setDesignConfig(array('area' => 'frontend', 'store' => $storeId))
                    ->sendTransactional($emailTemplate, $sender, $store_email, $store_name, $emailTemplateVariables);

            $translate->setTranslateInline(true);
        }
    }
