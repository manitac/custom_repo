<?php
/**
 * Class Teddymountain_Teddymountain_Helper_Data
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function getSelectedPromotionalProducts($tm_id)
    {
        $products_row=Mage::getModel('teddymountain/promotions')->load($tm_id);       //get selected products in grid sereliser
        $json_products=$products_row->getPosition();
        $products=json_decode($json_products);
       
        $custIds = array();
 
        foreach ($products as $key=> $product) {
            $custIds[$key] = array('position'=>$product->position);
        }

        return $custIds;
    }
}
