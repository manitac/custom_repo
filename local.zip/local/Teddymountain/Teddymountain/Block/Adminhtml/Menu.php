<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Menu
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Menu extends Mage_Adminhtml_Block_Template
{
    public function getPatternHtml($saved_pattern)
    {
        //    print_r($saved_pattern); exit;
        $html = '';
        foreach ($saved_pattern as $pattern) {
            $pageTitle = Mage::getModel('cms/page')->load($pattern->id)->getTitle();
            $class = "";
            if ($pattern->id == '100') {
                $pageTitle = "Root(do not move)";
                $class = "red";
            }

            $html.='<li class="dd-item" data-id="' . $pattern->id . '">
                        <div class="dd-handle  ' . $class . '">' . $pageTitle . '</div>';

            $children = $pattern->children;
            if (is_object($children[0])) {
                $tmp_pattern = $pattern->children;

                $html.='<ol class="dd-list">';
                $html.=$this->getPatternHtml($tmp_pattern);
                $html.='</ol>';
            }

            $html.='</li>';
        }


        return $html;
    }
}
