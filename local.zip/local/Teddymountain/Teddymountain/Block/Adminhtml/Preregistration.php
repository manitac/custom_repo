<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = "adminhtml_preregistration";
        $this->_blockGroup = "teddymountain";
        $this->_headerText = Mage::helper("teddymountain")->__("Preregistration Manager");
        $this->_addButtonLabel = Mage::helper("teddymountain")->__("Add New Item");
        parent::__construct();
    }
}
