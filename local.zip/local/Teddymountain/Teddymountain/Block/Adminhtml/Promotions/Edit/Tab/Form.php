<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tab_Form
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("teddymountain_form", array("legend" => Mage::helper("teddymountain")->__("Item information")));

        $dateFormatIso = Mage::app()->getLocale()->getDateTimeFormat(
                            Mage_Core_Model_Locale::FORMAT_TYPE_SHORT
                        );

        $fieldset->addField("description", "text", array(
            "label" => Mage::helper("teddymountain")->__("Name"),
            "name" => "description",
            'required'  => true,
            'class'=>'requried-entry'

        ));


        $fieldset->addField("store", "select", array(
            "label" => Mage::helper("teddymountain")->__("Store"),
            'values' => Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getValueStore(),
            "name" => "store",

        ));

        $fieldset->addField("start_date", "date", array(
            "label" => Mage::helper("teddymountain")->__("Start date"),
            "name" => "start_date",
            'time' => true,
           'image'     => $this->getSkinUrl('images/grid-cal.gif'),
           'format'    => Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT),
           'readonly' => true,
           'after_element_html' => '<small><br/>Should be greater or equal curent date. Format: mm/dd/yyyy</small>',
           'class'=>'requried-entry',
           'required'  => true
            
        ));
        $fieldset->addField("end_date", "date", array(
            "label" => Mage::helper("teddymountain")->__("End date"),
            "name" => "end_date",
            'time' => true,
            'image'     => $this->getSkinUrl('images/grid-cal.gif'),
            'format'    => Mage::app()->getLocale()->getDateFormat(Mage_Core_Model_Locale::FORMAT_TYPE_SHORT),
            'readonly' => true,
            'after_element_html' => '<small><br/>Should be greater than start date. Format: mm/dd/yyyy</small>',
            'class'=>'requried-entry',
            'required'  => true
            
        ));

        

        $fieldset->addField('is_active', 'select', array(
            'label' => Mage::helper('teddymountain')->__('Is Active'),
            'values' => Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getValueArray3(),
            'name' => 'is_active',
            'class'=>'requried-entry',
            'required'  => true
        ));

        $fieldset->addField("details_description", "textarea", array(
            "label" => Mage::helper("teddymountain")->__("Description"),
            "name" => "details_description",
        ));




        if (Mage::getSingleton("adminhtml/session")->getPromotionsData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getPromotionsData());
            Mage::getSingleton("adminhtml/session")->setPromotionsData(null);
        } elseif (Mage::registry("promotions_data")) {
            $form->setValues(Mage::registry("promotions_data")->getData());
        }
        return parent::_prepareForm();
    }
}
