<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tabs
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    public function __construct()
    {
        parent::__construct();
        $this->setId("promotions_tabs");
        $this->setDestElementId("edit_form");
        $this->setTitle(Mage::helper("teddymountain")->__("Item Information"));
    }
    protected function _beforeToHtml()
    {
        $this->addTab("form_section", array(
                "label" => Mage::helper("teddymountain")->__("Promotion Details"),
                "title" => Mage::helper("teddymountain")->__("Promotion Details"),
                "content" => $this->getLayout()->createBlock("teddymountain/adminhtml_promotions_edit_tab_form")->toHtml(),
                ));
        $this->addTab('form_product', array(
                     'label'     => Mage::helper('teddymountain')->__('Promotion Items'),
                     'title'     => Mage::helper('teddymountain')->__('Promotion Items'),
                     'url'       => $this->getUrl('*/*/product', array('_current' => true)),
                     'class'     => 'ajax',
                  ));

        $this->addTab('form_salesresult', array(
                      'label'     => Mage::helper('teddymountain')->__('Sales Result'),
                      'title'     => Mage::helper('teddymountain')->__('Sales Result'),
                      'content'   => $this->getLayout()->createBlock('adminhtml/template')->setTemplate('teddymountain/promotions/sales-result.phtml')->toHtml(),
                ));

        $this->addTab('form_htmlcode', array(
                      'label'     => Mage::helper('teddymountain')->__('Html Code'),
                      'title'     => Mage::helper('teddymountain')->__('Html Code'),
                      'content'   => $this->getLayout()->createBlock('adminhtml/template')->setTemplate('teddymountain/promotions/html-code.phtml')->toHtml(),
                ));



        return parent::_beforeToHtml();
    }
}
