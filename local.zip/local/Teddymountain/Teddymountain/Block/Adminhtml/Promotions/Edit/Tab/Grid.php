<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tab_Form
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Edit_Tab_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('productGrid');
        $this->setUseAjax(true);
        $this->setDefaultSort('entity_id');
        $this->setDefaultFilter(array('in_products'=>1));
        $this->setSaveParametersInSession(false);
    }

   

    protected function _addColumnFilterToCollection($column)
    {
        // Set custom filter for in product flag
        if ($column->getId() == 'in_products') {
            $productIds = $this->_getSelectedProducts();
            if (empty($productIds)) {
                $productIds = 0;
            }
            if ($column->getFilter()->getValue()) {
                $this->getCollection()->addFieldToFilter('entity_id', array('in'=>$productIds));
            } else {
                if ($productIds) {
                    $this->getCollection()->addFieldToFilter('entity_id', array('nin'=>$productIds));
                }
            }
        } else {
            parent::_addColumnFilterToCollection($column);
        }
        return $this;
    }



    protected function _prepareCollection()
    {
        $collection = Mage::getModel('catalog/product')->getCollection()
            ->addAttributeToSelect('name')
            ->addAttributeToSelect('sku')
            ->addAttributeToSelect('price')
             ->addAttributeToSelect('special_price')
            ;

        $collection->joinTable(
                'cataloginventory/stock_status',
                'product_id=entity_id',
                array("stock_status" => "stock_status"),
                null,
                'left'
            )
            ->addAttributeToSelect('stock_status');

        $this->setCollection($collection);

        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn('in_products', array(
                'header_css_class'  => 'a-center',
                'type'              => 'checkbox',
                'name'              => 'product',
                'values'            => $this->_getSelectedProducts(),
                'align'             => 'center',
                'index'             => 'entity_id'
        ));

      
        $this->addColumn('entity_id', array(
            'header'    => Mage::helper('catalog')->__('ID'),
            'sortable'  => true,
            'width'     => '60px',
            'index'     => 'entity_id'
        ));


        $this->addColumn('product_image', array(
              'header'    => Mage::helper('catalog')->__('Image'),
              'align'     =>'left',
              'index'     => 'entity_id',
              'width'     => '40px',
              'renderer'  => 'Mage_Adminhtml_Block_Catalog_Product_Renderer_Image'
        ));


        $this->addColumn('name', array(
            'header'    => Mage::helper('catalog')->__('Name'),
            'index'     => 'name',
            'width'     => '200',
        ));



        $this->addColumn('sku', array(
            'header'    => Mage::helper('catalog')->__('Vendor'),
            'width'     => '10px',
            'index'     => 'sku'
        ));


       

        $this->addColumn('price', array(
            'header'    => Mage::helper('catalog')->__('Price'),
            'type'  => 'currency',
            'width'     => '1',
            'currency_code' => (string) Mage::getStoreConfig(Mage_Directory_Model_Currency::XML_PATH_CURRENCY_BASE),
            'index'     => 'price'
        ));

        $this->addColumn('special_price', array(
            'header'    => Mage::helper('catalog')->__('Special Price'),
            'type'  => 'currency',
            'width'     => '1',
            'currency_code' => (string) Mage::getStoreConfig(Mage_Directory_Model_Currency::XML_PATH_CURRENCY_BASE),
            'index'     => 'special_price',
           // 'renderer'  => 'teddymountain/adminhtml_promotions_edit_tab_grid_renderer_specialPriceInput'
            'renderer'  => 'Mage_Adminhtml_Block_Catalog_Product_Renderer_SpecialPriceInput'
        ));

        $this->addColumn('stock_status',
                 array(
                    'header'=> 'Stock Status',
                    'width' => '60px',
                    'index' => 'stock_status',
                    'type'  => 'options',
                    'options' => array('1'=>'IN STOCK','0'=>'OUT OF STOCK'),
            ));

        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn('websites',
                array(
                    'header'=> Mage::helper('catalog')->__('Websites'),
                    'width' => '100px',
                    'sortable'  => false,
                    'index'     => 'websites',
                    'type'      => 'options',
                    'options'   => Mage::getModel('core/website')->getCollection()->toOptionHash(),
            ));
        }

        $this->addColumn('position', array(
            'header'            => Mage::helper('catalog')->__('Position'),
            'name'              => 'position',
            'width'             => '10px',
            'type'              => 'number',
            'validate_class'    => 'validate-number',
            'index'             => 'position',
            'editable'          => true,
            'edit_only'         => true,
            'column_css_class'=>'no-display',
            'header_css_class'=>'no-display',
            ));
       

        return parent::_prepareColumns();
    }

    protected function _getSelectedProducts()
    {
        $products = array_keys($this->getSelectedProducts());
        return $products;
    }
 
    public function getSelectedProducts()
    {
        // Customer Data
        $tm_id = $this->getRequest()->getParam('id');


        if (!isset($tm_id)) {
            $tm_id = 0;
        }


        $custIds= Mage::helper('teddymountain')->getSelectedPromotionalProducts($tm_id);
       
        return $custIds;
    }


    public function getGridUrl()
    {
        return $this->_getData('grid_url') ? $this->_getData('grid_url') : $this->getUrl('*/*/productgrid', array('_current'=>true));
    }
}
