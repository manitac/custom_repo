<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId("PromotionsGrid");
        $this->setDefaultSort("Promotions_id");
        $this->setDefaultDir("DESC");
        $this->setUseAjax(true);
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel("teddymountain/Promotions")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn("promotions_id", array(
            "header" => Mage::helper("teddymountain")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "promotions_id",
        ));

        $this->addColumn("store", array(
            "header" => Mage::helper("teddymountain")->__("Store"),
            "index" => "store",
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getOptionArrayStore(),
        ));

        $this->addColumn("description", array(
            "header" => Mage::helper("teddymountain")->__("Name"),
            "index" => "description",
        ));

        $this->addColumn("details_description", array(
            "header" => Mage::helper("teddymountain")->__("Description"),
            "index" => "details_description",
        ));
        
        $this->addColumn("start_date", array(
            "header" => Mage::helper("teddymountain")->__("Start date"),
            "index" => "start_date",
            'type'      => 'date',
        ));
        
        
        $this->addColumn("end_date", array(
            "header" => Mage::helper("teddymountain")->__("End date"),
            "index" => "end_date",
            'type'      => 'date',
        ));
        
        $this->addColumn('is_active', array(
            'header' => Mage::helper('teddymountain')->__('Is Active?'),
            'index' => 'is_active',
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getOptionArray3(),
            'renderer'  => 'Mage_Adminhtml_Block_Catalog_Product_Renderer_PromotionIsActive'
        ));

        
        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('Promotions_id');
        $this->getMassactionBlock()->setFormFieldName('Promotions_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_Promotions', array(
            'label' => Mage::helper('teddymountain')->__('Remove Promotions'),
            'url' => $this->getUrl('*/adminhtml_Promotions/massRemove'),
            'confirm' => Mage::helper('teddymountain')->__('Are you sure?')
        ));
        return $this;
    }

    public static function getOptionArray3()
    {
        $data_array = array();
        $data_array[0] = 'Enabled';
        $data_array[1] = 'Disabled';
        return($data_array);
    }

    public static function getValueArray3()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getOptionArray3() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }
    
    
    public static function getOptionArrayStore()
    {
        $data_array = array();
        $data_array[0] = 'TeddyMountain';
        return($data_array);
    }

    public static function getValueStore()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Promotions_Grid::getOptionArrayStore() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }

    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', array('_current'=>true));
    }
}
