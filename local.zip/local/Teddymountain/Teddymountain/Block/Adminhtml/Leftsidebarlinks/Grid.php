<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId("leftsidebarlinksGrid");
        $this->setDefaultSort("leftsidebarlinks_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel("teddymountain/leftsidebarlinks")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn("leftsidebarlinks_id", array(
            "header" => Mage::helper("teddymountain")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "leftsidebarlinks_id",
        ));


        $this->addColumn('image', array(
            'header' => Mage::helper('catalog')->__('Thumbnail Image'),
            'width' => '50px',
            'index' => 'image',
            'frame_callback' => array($this, 'callback_image')
        ));

        $this->addColumn("title", array(
            "header" => Mage::helper("teddymountain")->__("Title"),
            "index" => "title",
        ));
        $this->addColumn('status', array(
            'header' => Mage::helper('teddymountain')->__('Status'),
            'index' => 'status',
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getOptionArray3(),
        ));

//        $this->addColumn("store", array(
//            "header" => Mage::helper("teddymountain")->__("Store"),
//            "index" => "store",
//        ));
        $this->addColumn("sort_order", array(
            "header" => Mage::helper("teddymountain")->__("Sort Order"),
            "index" => "sort_order",
        ));
        $this->addColumn("link", array(
            // "header" => Mage::helper("teddymountain")->__("Link"),
            // "index" => "link",

            'header' => Mage::helper('teddymountain')->__('Link to page'),
            'index' => 'link',
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getOptionArrayPageLink(),

        ));
        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('leftsidebarlinks_id');
        $this->getMassactionBlock()->setFormFieldName('leftsidebarlinks_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_leftsidebarlinks', array(
            'label' => Mage::helper('teddymountain')->__('Remove Services Item(s)'),
            'url' => $this->getUrl('*/adminhtml_leftsidebarlinks/massRemove'),
            'confirm' => Mage::helper('teddymountain')->__('Are you sure?')
        ));
        return $this;
    }

    public static function getOptionArray3()
    {
        $data_array = array();
        $data_array[0] = 'Enabled';
        $data_array[1] = 'Disabled';
        return($data_array);
    }

    public static function getValueArray3()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getOptionArray3() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }

    public static function getOptionArrayPageLink()
    {
        $data_array = array();

        $cms_arr = Mage::getModel('cms/page')->getCollection();

        foreach ($cms_arr as $page) {
            $page_id = $page->getpage_id();

            $page_links= str_replace("/index.php", '', Mage::helper('cms/page')->getPageUrl($page_id)) ;

            $title = $page->gettitle();
            $is_active = $page->getis_active();
            $active_status = ' (page disabled)' ? $is_active != 1 : '';

            $title=$title.$active_status;
            $data_array[$page_links]=$title;
        }

        //additional pages from modules
        $baseurl=str_replace("/index.php", '', Mage::getBaseUrl()) ;

        $data_array[$baseurl.'storelocator']='storelocator';



        return($data_array);
    }

    public static function getValueArrayPageLink()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getOptionArrayPageLink() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }



    public function callback_image($value)
    {
        $width = '';
        $height = '';
        return "<img src='" . Mage::getBaseUrl('media') . $value . "' width=" . $width . " height=" . $height . "/>";
    }
}
