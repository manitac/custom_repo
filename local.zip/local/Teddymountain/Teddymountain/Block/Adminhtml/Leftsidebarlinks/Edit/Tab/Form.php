<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Edit_Tab_Form
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("teddymountain_form", array("legend"=>Mage::helper("teddymountain")->__("Item information")));

                
        $fieldset->addField("title", "text", array(
                        "label" => Mage::helper("teddymountain")->__("Title"),
                        "class" => "required-entry",
                        "required" => true,
                        "name" => "title",
                        ));

                        
                                    
        $fieldset->addField('image', 'image', array(
                        'label' => Mage::helper('teddymountain')->__('Image'),
                        'name' => 'image',
                        'note' => '(*.jpg, *.png, *.gif)',
                        ));

        $fieldset->addField('link', 'select', array(
                        'label'     => Mage::helper('teddymountain')->__('Page link'),
                        'values'   => Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getValueArrayPageLink(),
                        'name' => 'link',
                        "class" => "required-entry",
                        "required" => true,
                        ));
                        
                                    
        $fieldset->addField('status', 'select', array(
                        'label'     => Mage::helper('teddymountain')->__('Status'),
                        'values'   => Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Grid::getValueArray3(),
                        'name' => 'status',
                        ));
//						$fieldset->addField("store", "text", array(
//						"label" => Mage::helper("teddymountain")->__("Store"),
//						"name" => "store",
//						));
                    
                        $fieldset->addField("sort_order", "text", array(
                        "label" => Mage::helper("teddymountain")->__("Sort Order"),
                        "name" => "sort_order",
                        ));
                    
                        
                        

        $fieldset->addField("description", "textarea", array(
                        "label" => Mage::helper("teddymountain")->__("Description"),
                        "name" => "description",
                        ));

        if (Mage::getSingleton("adminhtml/session")->getLeftsidebarlinksData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getLeftsidebarlinksData());
            Mage::getSingleton("adminhtml/session")->setLeftsidebarlinksData(null);
        } elseif (Mage::registry("leftsidebarlinks_data")) {
            $form->setValues(Mage::registry("leftsidebarlinks_data")->getData());
        }
        return parent::_prepareForm();
    }
}
