<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Edit_Tabs
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    public function __construct()
    {
        parent::__construct();
        $this->setId("leftsidebarlinks_tabs");
        $this->setDestElementId("edit_form");
        $this->setTitle(Mage::helper("teddymountain")->__("Item Information"));
    }
    protected function _beforeToHtml()
    {
        $this->addTab("form_section", array(
                "label" => Mage::helper("teddymountain")->__("Item Information"),
                "title" => Mage::helper("teddymountain")->__("Item Information"),
                "content" => $this->getLayout()->createBlock("teddymountain/adminhtml_leftsidebarlinks_edit_tab_form")->toHtml(),
                ));
        return parent::_beforeToHtml();
    }
}
