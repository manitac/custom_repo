<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId("preregistrationGrid");
        $this->setDefaultSort("preregistration_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel("teddymountain/preregistration")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn("preregistration_id", array(
            "header" => Mage::helper("teddymountain")->__("ID"),
            "align" => "right",
            "width" => "50px",
            "type" => "number",
            "index" => "preregistration_id",
        ));

        $this->addColumn("registration_code", array(
            "header" => Mage::helper("teddymountain")->__("Registration Code"),
            "index" => "registration_code",
        ));
        $this->addColumn("name", array(
            "header" => Mage::helper("teddymountain")->__("Your Name"),
            "index" => "name",
        ));
        $this->addColumn("telephone", array(
            "header" => Mage::helper("teddymountain")->__("Telephone "),
            "index" => "telephone",
        ));
        
        $this->addColumn("email", array(
            "header" => Mage::helper("teddymountain")->__("Email Address"),
            "index" => "email",
        ));
        $this->addColumn("approved", array(
            "header" => Mage::helper("teddymountain")->__("Is Approved"),
            "index" => "approved",
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::isApproved1Option(),
        ));
        
        $this->addColumn('hearsource', array(
            'header' => Mage::helper('teddymountain')->__('How did you hear about us? '),
            'index' => 'hearsource',
            'type' => 'options',
            'options' => Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::getOptionArray11(),
        ));
        $this->addColumn("about_business", array(
            "header" => Mage::helper("teddymountain")->__("About Business"),
            "index" => "about_business",
        ));

        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl("*/*/edit", array("id" => $row->getId()));
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('preregistration_id');
        $this->getMassactionBlock()->setFormFieldName('preregistration_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem('remove_preregistration', array(
            'label' => Mage::helper('teddymountain')->__('Remove pre-registration data'),
            'url' => $this->getUrl('*/adminhtml_preregistration/massRemove'),
            'confirm' => Mage::helper('teddymountain')->__('Are you sure?')
        ));
        return $this;
    }

    public static function getOptionArray11()
    {
        $data_array = array();
        $data_array[0] = '--- Please Choose ---';
        $data_array[1] = 'Internet search engine';
        $data_array[2] = 'Toy Directory';
        $data_array[3] = 'Email or direct mail';
        $data_array[4] = 'TV or radio';
        $data_array[5] = 'Other';
        return($data_array);
    }

    public static function getValueArray11()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::getOptionArray11() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }
    
    
    public static function isApproved1Option()
    {
        $data_array = array();
        $data_array[0] = 'No';
        $data_array[1] = 'Yes';
        return($data_array);
    }
    
    public static function isApproved()
    {
        $data_array = array();
        foreach (Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::isApproved1Option() as $k => $v) {
            $data_array[] = array('value' => $k, 'label' => $v);
        }
        return($data_array);
    }
}
