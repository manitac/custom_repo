<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Edit_Tab_Form
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form {

    protected function _prepareForm() {

        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset("teddymountain_form", array("legend" => Mage::helper("teddymountain")->__("Item information")));


        $fieldset->addField("registration_code", "text", array(
            "label" => Mage::helper("teddymountain")->__("Registration Code"),
            "class" => "required-entry",
            "required" => true,
            "name" => "registration_code",
        ));

        $fieldset->addField("name", "text", array(
            "label" => Mage::helper("teddymountain")->__("Your Name"),
            "class" => "required-entry",
            "required" => true,
            "name" => "name",
        ));

        $fieldset->addField("telephone", "text", array(
            "label" => Mage::helper("teddymountain")->__("Telephone "),
            //"class" => "required-entry",
           // "required" => true,
            "name" => "telephone",
        ));

        $fieldset->addField("email", "text", array(
            "label" => Mage::helper("teddymountain")->__("Email Address"),
            "class" => "required-entry",
            "required" => true,
            "name" => "email",
        ));

        $fieldset->addField('hearsource', 'select', array(
            'label' => Mage::helper('teddymountain')->__('How did you hear about us? '),
            'values' => Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::getValueArray11(),
            'name' => 'hearsource',
        ));
        
        
        
        
        $fieldset->addField("query", "textarea", array(
            "label" => Mage::helper("teddymountain")->__("questions or requests"),
            "name" => "query",
            'style'   => "height:70px",
        ));
$fieldset->addField("about_business", "textarea", array(
            "label" => Mage::helper("teddymountain")->__("About your business"),
            "name" => "about_business",
            'style'   => "height:70px",
        ));
        $fieldset->addField('approved', 'select', array(
            'label' => Mage::helper('teddymountain')->__('Is Approved? '),
            'values' => Teddymountain_Teddymountain_Block_Adminhtml_Preregistration_Grid::isApproved(),
            'name' => 'approved',
           
        ));
        $fieldset->addField('checkbox', 'checkbox', array(
          'label'     => Mage::helper('teddymountain')->__(''),
          'name'      => 'mail_send',
          'checked' => true,         
          'value'  => '1',
          'disabled' => false,         
          'tabindex' => 1, 
            'after_element_html' =>'<small>Mail will be sent with registration code, if checked.</small>'
            
        ));

        
        
        
        if (Mage::getSingleton("adminhtml/session")->getPreregistrationData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getPreregistrationData());
            Mage::getSingleton("adminhtml/session")->setPreregistrationData(null);
        } elseif (Mage::registry("preregistration_data")) {
            $form->setValues(Mage::registry("preregistration_data")->getData());
        }
        return parent::_prepareForm();
    }

}
