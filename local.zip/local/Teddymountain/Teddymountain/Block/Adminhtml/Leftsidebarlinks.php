<?php
/**
 * Class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Adminhtml_Leftsidebarlinks extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = "adminhtml_leftsidebarlinks";
        $this->_blockGroup = "teddymountain";
        $this->_headerText = Mage::helper("teddymountain")->__("Frontend Leftsidebar Service Menu Manager");
        $this->_addButtonLabel = Mage::helper("teddymountain")->__("Add New Service Link");
        parent::__construct();
    }
}
