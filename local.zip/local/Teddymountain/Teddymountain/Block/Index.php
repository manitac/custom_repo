<?php
/**
 * Class Teddymountain_Teddymountain_Block_Index
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Teddymountain_Block_Index extends Mage_Core_Block_Template
{
    public function getBanners()
    {
        $banners = Mage::getModel('teddymountain/sliderbanner')->getCollection()
                ->addFieldToFilter('status', array('eq' => 0))
                ->setOrder('sort_order', 'ASC')
        // ->addFiedToFilter('store',array('eq'=>0))    //todo store support
        ;
        return $banners;
    }
    
    /**
     * 
     * @param type $categories
     * @param string $class
     * @return string
     */
    public function get_categories($categories, $class='')
    {
        $array .= '';
        foreach ($categories as $category) {
            $cat = Mage::getModel('catalog/category')->load($category->getId());
            $count = $cat->getProductCount();
            $class = 'cat-level-' . $cat->getLevel();
            $class2 = '';
            $toggle_class = '';
            if ($category->hasChildren()) {
                $class2 = "have-child";
                $toggle_class = !empty($class) ? "icon-plus" : "icon-minus";
            }
            $array .= '<li>';
            $array .='<i class="fa fa-caret-right" aria-hidden="true"></i>';
            $array .= '<a id="cat-' . $category->getId() . '" class="' . $cat->getLevel() . '" href="' . Mage::getUrl($cat->getUrlPath()) . '">'
                    . $cat->getName() . '"</a>';

            if ($category->hasChildren()) {
                $children = Mage::getModel('catalog/category')->getCategories($category->getId());
                $array .= $this->get_categories($children, $class);
            }


            $array .= '</li>';
        }
        return $array;
    }

    public function getServices()
    {
        $services = Mage::getModel("teddymountain/leftsidebarlinks")
                            ->getCollection()
                            ->addFieldToFilter('status', array('eq'=>0))
                            ->setOrder('sort_order', 'DESC');
        return $services;
    }
}
