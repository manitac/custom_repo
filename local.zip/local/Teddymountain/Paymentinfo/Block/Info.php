<?php

/**
 * Class Teddymountain_Paymentinfo_Block_Info
 *
 * @category    Local
 * @package     Teddymountain_Paymentinfo
 */
class Teddymountain_Paymentinfo_Block_Info extends Mage_Payment_Block_Info
{

    /**
     * Payment rendered specific information
     * Overwrite the payment template to show transaction info in table.
     * @var Varien_Object
     */
    protected function _construct()
    {
        $controller = Mage::app()->getRequest()->getControllerName();
        parent::_construct();
        if ($controller == 'sales_order') {
            $this->setTemplate('teddymountain/info/default.phtml');
        }
    }

    /**
     * Load all credit card type infomation payment done by credut card type.
     * 
     * @return Array
     */
    public function getallpay()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        $collection = Mage::getModel('paymentinfo/payinfo')->getCollection();
        $collection->addFieldToFilter('order_id', $orderId);
        return $collection->getData();
    }
}
