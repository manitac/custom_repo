<?php

/**
 * Class Teddymountain_Paymentinfo_Model_Payinfo
 *
 * @category    Local
 * @package     Teddymountain_Paymentinfo
 */
class Teddymountain_Paymentinfo_Model_Payinfo extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init("paymentinfo/payinfo");
    }
}
