<?php
/**
 * Class Teddymountain_Payment_Model_Resource_Payinfo_Collection
 *
 * @category    Local
 * @package     Teddymountain_Payment
 * @author      Anoop Singh <anoops@chetu.com>
 */
class Teddymountain_Paymentinfo_Model_Resource_Payinfo_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    public function _construct()
    {
        $this->_init("paymentinfo/payinfo");
    }
}
