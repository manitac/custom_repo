<?php

class Teddymountain_Paymentinfo_Model_Observer
{
    public function save_paymentinfo(Varien_Event_Observer $observer)
    {
        $invoice = $observer->getEvent()->getInvoice();
        $order = $invoice->getOrder();
        $order_id = $order->getId();
        $invoiceData = $invoice->getData();
        $order = Mage::getModel("sales/order")->load($order_id);
        $payment = $order->getPayment();
        $payment_method_title = $payment->getMethodInstance()->getTitle();
        $cc_type = '';
        $cc_no = '';
        $cc_exp_month = '';
        $cc_exp_year = '';
        $add_data = $payment->getData();
        if (!empty($add_data) && $payment->getMethod() == 'authorizenet') {
            //foreach($add_data['authorize_cards'] as $cc)
            //{
            $cc_type = $add_data['cc_type'];
            $cc_no = $add_data['cc_last4'];
            $cc_exp_month = $add_data['cc_exp_month'];
            $cc_exp_year = $add_data['cc_exp_year'];
            //}
        }
        if (isset($invoiceData['requested_capture_case']) && $invoiceData['requested_capture_case'] == 'not_capture') {
            $manual_ship = 1;
        } else {
            $manual_ship = 0;
        }
        $payment_data = array(
            "order_id" => $order_id,
            "invoice_id" => $invoiceData['entity_id'],
            "amount" => $invoiceData['grand_total'],
            "manual_ship" => $manual_ship,
            "method" => $payment_method_title,
            "cc_type" => $cc_type,
            "cc_no" => $cc_no,
            "cc_exp_month" => $cc_exp_month,
            "cc_exp_year" => $cc_exp_year,
            "created_time" => Mage::getModel('core/date')->date('Y-m-d H:i:s')
        );
        $model = Mage::getModel('paymentinfo/payinfo');
        $model->setData($payment_data);
        $model->save();
    }

    public function autoInvoice(Varien_Event_Observer $observer)
    {
        $order = $observer->getEvent()->getOrder();
        if ($order->getPayment()->getMethodInstance()->getCode() == 'paypal_express') {
            try {
                if (!$order->canInvoice()) {
                    Mage::throwException(Mage::helper('core')->__('Cannot create an invoice.'));
                }

                $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();

                if (!$invoice->getTotalQty()) {
                    Mage::throwException(Mage::helper('core')->__('Cannot create an invoice without products.'));
                }

                $invoice->setRequestedCaptureCase(Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE);
                $invoice->register();
                $transactionSave = Mage::getModel('core/resource_transaction')
                        ->addObject($invoice)
                        ->addObject($invoice->getOrder());

                $transactionSave->save();
                $invoice->getOrder()->setIsInProcess(true);
                $invoice->sendEmail(true, '');
                $order->save();
            } catch (Mage_Core_Exception $e) {
                Mage::throwException(Mage::helper('core')->__('Cannot create an invoice.'));
            }
        }
    }
}
