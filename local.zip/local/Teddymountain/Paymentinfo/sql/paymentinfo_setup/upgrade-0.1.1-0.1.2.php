<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE {$this->getTable('custom_payment_info')} 
ADD COLUMN manual_ship ENUM('0','1') DEFAULT '0' AFTER amount;
");
$installer->endSetup();
