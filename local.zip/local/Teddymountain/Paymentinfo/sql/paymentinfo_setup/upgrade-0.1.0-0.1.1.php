<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE {$this->getTable('custom_payment_info')} 
ADD COLUMN cc_exp_month SMALLINT(6) NOT NULL AFTER cc_no, 
ADD COLUMN cc_exp_year INT(10) NOT NULL AFTER cc_exp_month;
");
$installer->endSetup();
