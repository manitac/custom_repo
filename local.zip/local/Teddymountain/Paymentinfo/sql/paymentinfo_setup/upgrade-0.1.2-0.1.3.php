<?php
$installer = $this;
$installer->startSetup();
$installer->run("
ALTER TABLE {$this->getTable('custom_payment_info')} 
ADD COLUMN invoice_id INT(11) NOT NULL AFTER order_id;
");
$installer->endSetup();
