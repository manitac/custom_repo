<?php

/**
 * Class Teddymountain_Customshipping_Model_Carrier_Customshipping
 *
 * @category    Local
 * @package     Teddymountain_Customshipping
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Customshipping_Model_Carrier_Customshipping extends Mage_Shipping_Model_Carrier_Abstract implements Mage_Shipping_Model_Carrier_Interface {

    protected $_code = 'customshipping';

    /**
     * Collect rates for this shipping method based on information in $request 
     * 
     * @param Mage_Shipping_Model_Rate_Request $data 
     * @return Mage_Shipping_Model_Rate_Result 
     */
    public function collectRates(Mage_Shipping_Model_Rate_Request $request) {

        $result = Mage::getModel('shipping/rate_result');

        $allowedmethods = $this->getConfigData('allowedmethods');
        $allowedmethods_arr = explode(',', $allowedmethods);
        // $allowedmethods_arr = array_reverse($allowedmethods_arr);
        $viewObj = new Teddymountain_Customshipping_Model_System_Config_Source_View();
        $optionsArray = $viewObj->toArray();
        $totals = $this->getCurrentQuote()->getTotals();

        $subtotal = round($totals["subtotal"]->getValue(), 3);
        $recipient_address = $this->getCurrentQuote()->getShippingAddress();
        $city = $recipient_address->getCity();
        $postcode = $recipient_address->getPostcode();
        $regioncode = Mage::getModel('directory/region')->load($recipient_address->getRegionId())->getCode();
        $countrycode = $recipient_address->getCountryId();
        foreach ($allowedmethods_arr as $key => $method) {
            $rate = Mage::getModel('shipping/rate_result_method');
            $rate->setCarrier($this->_code);
            $rate->setCarrierTitle($this->getConfigData('title'));
            //$ratedata = Mage::getModel('customshipping/fedexapi_fedexapidata')->getRates($method);
            // baserate_live = $ratedata['amount'];         

            $shippingEstimate = $this->getEstimatedShippingAmount($subtotal, $method, $regioncode, $countrycode);
            // $shippingEstimate=100;
            $rate->setMethod($method);
            $rate->setMethodTitle($optionsArray[$method]);

            $rate->setPrice($shippingEstimate);
            $rate->setCost($shippingEstimate);

            $result->append($rate);
        }

        return $result;
    }

    /**
     * Get allowed shipping methods
     *
     * @return array
     */
    public function getAllowedMethods() {

        $allowedmethods = $this->getConfigData('allowedmethods');
        $allowedmethods_arr = explode($allowedmethods);
        $allowedmethods_arr = array_reverse($allowedmethods_arr);
        $return_arr = array();
        foreach ($allowedmethods_arr as $value) {
            $return_arr[$value] = $allowedmethods_arr[$allowedmethods_arr];
        }

        return $return_arr;
    }

    /**
     * mannual calculation for estimated shipping amount
     *
     * @param type $subtotal
     * @param type $method
     * @param type $regioncode
     * @param type $countrycode
     * @return type $shippingEstimate
     */
    public function getEstimatedShippingAmount($subtotal, $method, $regioncode, $countrycode) {
        $shippingEstimate = 0;

        $baserate_FEDEX_GROUND = $this->getConfigData('increase_baserate_FEDEX_GROUND');
        $baserate_FEDEX_EXPRESS_SAVER = $this->getConfigData('increase_baserate_FEDEX_EXPRESS_SAVER');
        $baserate_FEDEX_2_DAY = $this->getConfigData('increase_baserate_FEDEX_2_DAY');
        $baserate_STANDARD_OVERNIGHT = $this->getConfigData('increase_baserate_STANDARD_OVERNIGHT');
        $rate_Hold_for_pick_up = $this->getConfigData('rate_Hold_for_pick_up');

        // step-1. get a base shipping rate based on the shipping type- $method
        switch ($method) {
            case "FEDEX_GROUND":
                $shippingEstimate = $subtotal * ($baserate_FEDEX_GROUND / 100);
                break;
            case "FEDEX_EXPRESS_SAVER":
                $shippingEstimate = $subtotal * ($baserate_FEDEX_EXPRESS_SAVER / 100);
                break;
            case "FEDEX_2_DAY":
                $shippingEstimate = $subtotal * ($baserate_FEDEX_2_DAY / 100);
                break;
            case "STANDARD_OVERNIGHT":
                $shippingEstimate = $subtotal * ($baserate_STANDARD_OVERNIGHT / 100);
                break;
            case "STANDARD_OVERNIGHT":
                $shippingEstimate = $subtotal * ($baserate_STANDARD_OVERNIGHT / 100);
                break;
            case "Hold_for_pick_up":
                $shippingEstimate = $rate_Hold_for_pick_up;
                return $shippingEstimate;   //for pickup is selected
            // break;
            default:$shippingEstimate = 100;
                break;
        }

        // step-2. non-continental usa: times 2.5 , australia and new zealand: times 3        
        $non_continetnal_regions = array('AK', 'HI', 'PR', 'VI');
        if (in_array($regioncode, $non_continetnal_regions) && $countrycode == 'US') {
            $shippingEstimate = $shippingEstimate * 2.5;
        } else if ($countrycode == "AU" || $countrycode == "NZ") {
            $shippingEstimate = $shippingEstimate * 3;
        }

        // step-3. increase shipping price for heavy items
        $extra = $this->getExtraShippingHeavierItems($subtotal, $method, $countrycode);
        $shippingEstimate +=$extra;

        return $shippingEstimate;
    }

    /**
     * 
     * @param type $subtotal
     * @param type $method
     * @param type $countrycode
     * @return type
     */
    public function getExtraShippingHeavierItems($subtotal, $method, $countrycode) {
        $ex = $this->GetExtraItemSubtotal($subtotal);
        $ex = $ex * 0.4; // add 40% extra for these items. 

        if ($method == "FEDEX_GROUND" && $countrycode == "US") { // ground shipping in US
            if ($subtotal > 1000) {
                $ex -= $subtotal * 0.15; // 10% instead of 25%
            } else if ($subtotal > 500) {
                $ex -= $subtotal * 0.12; // 13% instead of 25%
            } else if ($subtotal > 250) {
                $ex -= $subtotal * 0.09; // 16% instead of 25%
            }
        } else if ($countrycode == "CA") { // ground shipping CANADA
            //$ex += 25; // mandatory 25$ broker fee
            if ($subtotal <= 150)
                $ex += Mage::getStoreConfig('canada_shipping/canada_shipping_charges/fee_up_to_150', Mage::app()->getStore()->getId());  // added brokrage fee 18 for CA 
            else if ($subtotal > 150 && $subtotal <= 200)
                $ex += Mage::getStoreConfig('canada_shipping/canada_shipping_charges/fee_up_to_200', Mage::app()->getStore()->getId());  // added brokrage fee 23 for CA
            else if ($subtotal > 200 && $subtotal <= 1600)
                $ex += Mage::getStoreConfig('canada_shipping/canada_shipping_charges/fee_up_to_1600', Mage::app()->getStore()->getId()); // added brokrage fee 28 for CA
            else if ($subtotal > 1600 && $subtotal <= 5000)
                $ex += Mage::getStoreConfig('canada_shipping/canada_shipping_charges/fee_up_to_5000', Mage::app()->getStore()->getId());  // added brokrage fee 53 for CA
            else // >=5000
                $ex += Mage::getStoreConfig('canada_shipping/canada_shipping_charges/above_5000', Mage::app()->getStore()->getId());;  // // added brokrage fee 78 for CA
        }
        return $ex;
    }

    /**
     * 
     * @param type $subtotal
     * @return type
     */
    public function GetExtraItemSubtotal($subtotal) {
        $ex = 0;
        $extras = array(); // items that have extra shipping 
        $extras[] = "103";
        $extras[] = "Box";
        $extras[] = "Plush Bag";
        $extras[] = "PF100-01";
        $extras[] = "PF100-02";
        $extras[] = "PF25-1";
        $extras[] = "PF25-2";
        $extras[] = "PF50-1";
        $extras[] = "PF50-2";

        $cartItems = $this->getCurrentQuote()->getAllVisibleItems();
        foreach ($cartItems as $item) {
            if (in_array($item->getSku(), $extras)) {
                $ex +=$item->getPrice();
            }
        }

        return $ex;
    }

    /**
     * Get current session order quote
     *
     * @return array
     */
    public function getCurrentQuote() {
        $quote = null;
        $storeCode = Mage::app()->getStore()->getCode();
        if ($storeCode == "admin") {
            $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote();
        } else {
            $quote = Mage::getSingleton('checkout/session')->getQuote();
        }
        return $quote;
    }

}
