<?php
/**
 * Class Teddymountain_Customshipping_Model_System_Config_Source_View
 *
 * @category    Local
 * @package     Teddymountain_Customshipping
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Customshipping_Model_System_Config_Source_View {

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray() {
        return array(
            array('value' => 'FEDEX_GROUND', 'label' => Mage::helper('adminhtml')->__('Regular (3-7 days)')),
            array('value' => 'FEDEX_EXPRESS_SAVER', 'label' => Mage::helper('adminhtml')->__('Express Saver (3 days)')),
            array('value' => 'FEDEX_2_DAY', 'label' => Mage::helper('adminhtml')->__('Express (2 days)')),
            array('value' => 'STANDARD_OVERNIGHT', 'label' => Mage::helper('adminhtml')->__('Express (Overnight)')),
            array('value' => 'Hold_for_pick_up', 'label' => Mage::helper('adminhtml')->__('Hold for pick up'))
        );
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray() {
        return array(
            'FEDEX_GROUND' => Mage::helper('adminhtml')->__('Regular (3-7 days)'),
            'FEDEX_EXPRESS_SAVER' => Mage::helper('adminhtml')->__('Express Saver (3 days)'),
            'FEDEX_2_DAY' => Mage::helper('adminhtml')->__('Express (2 days)'),
            'STANDARD_OVERNIGHT' => Mage::helper('adminhtml')->__('Express (Overnight)'),
            'Hold_for_pick_up' => Mage::helper('adminhtml')->__('Hold for pick up'),
        );
    }

}

?>