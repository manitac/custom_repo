<?php

// Copyright 2009, FedEx Corporation. All rights reserved.
// Version 12.0.0

require_once __dir__ . '/fedex-common.php' ;

class Teddymountain_Customshipping_Model_Fedexapi_Fedexapidata extends Mage_Core_Model_Abstract {

   public function getRates($method) {
       
        $path_to_wsdl = __dir__ . "/RateService_v20.wsdl";

        ini_set("soap.wsdl_cache_enabled", "0");

        $client = new SoapClient($path_to_wsdl, array('trace' => 1));

        $request['WebAuthenticationDetail'] = array(
            'ParentCredential' => array(
                'Key' => getProperty('parentkey'),
                'Password' => getProperty('parentpassword')
            ),
            'UserCredential' => array(
                'Key' => getProperty('key'),
                'Password' => getProperty('password')
            )
        );
        $request['ClientDetail'] = array(
            'AccountNumber' => getProperty('shipaccount'),
            'MeterNumber' => getProperty('meter')
        );
        $request['TransactionDetail'] = array('CustomerTransactionId' => ' *** Rate Request using PHP ***');
        $request['Version'] = array(
            'ServiceId' => 'crs',
            'Major' => '20',
            'Intermediate' => '0',
            'Minor' => '0'
        );
        $request['ReturnTransitAndCommit'] = true;
        $request['RequestedShipment']['DropoffType'] = 'REGULAR_PICKUP'; // valid values REGULAR_PICKUP, REQUEST_COURIER, ...
        $request['RequestedShipment']['ShipTimestamp'] = date('c');
        $request['RequestedShipment']['ServiceType'] = $method; // valid values STANDARD_OVERNIGHT, PRIORITY_OVERNIGHT, FEDEX_GROUND, ...
        $request['RequestedShipment']['PackagingType'] = 'YOUR_PACKAGING'; // valid values FEDEX_BOX, FEDEX_PAK, FEDEX_TUBE, YOUR_PACKAGING, ...
        $request['RequestedShipment']['TotalInsuredValue'] = array(
            'Ammount' => 100,
            'Currency' => 'USD'
        );
        $request['RequestedShipment']['Shipper'] = $this->addShipper();
        $request['RequestedShipment']['Recipient'] = $this->addRecipient();
        $request['RequestedShipment']['ShippingChargesPayment'] = $this->addShippingChargesPayment();
        $request['RequestedShipment']['PackageCount'] = '1';
        $request['RequestedShipment']['RequestedPackageLineItems'] = $this->addPackageLineItem1();                          
        try {
            if (setEndpoint('changeEndpoint')) {
                $newLocation = $client->__setLocation(setEndpoint('endpoint'));
            }

            $response = $client->getRates($request);

            if ($response->HighestSeverity != 'FAILURE' && $response->HighestSeverity != 'ERROR') {
                $rateReply = $response->RateReplyDetails;
                
                //debug- 
                //Mage::log('rateReply details- ', null, 'fedex_api_data_error.log');
                //Mage::log($rateReply, null, 'fedex_api_data_error.log');
                
                $serviceType = $rateReply->ServiceType;
                if ($rateReply->RatedShipmentDetails && is_array($rateReply->RatedShipmentDetails)) {
                    $amount = number_format($rateReply->RatedShipmentDetails[0]->ShipmentRateDetail->TotalNetCharge->Amount, 2, ".", ",");
                } elseif ($rateReply->RatedShipmentDetails && !is_array($rateReply->RatedShipmentDetails)) {
                    $amount = number_format($rateReply->RatedShipmentDetails->ShipmentRateDetail->TotalNetCharge->Amount, 2, ".", ",");
                }
                if (array_key_exists('TransitTime', $rateReply->CommitDetails)) {
                    $transitTime = $rateReply->CommitDetails->TransitTime;
                } else {
                    $transitTime = $rateReply->DeliveryTimestamp;
                }
                if (array_key_exists('MaximumTransitTime', $rateReply->CommitDetails)) {
                    $maxTransitTime = $rateReply->CommitDetails->MaximumTransitTime;
                } else {
                    $maxTransitTime = 'not working';
                }

                $result['serviceType'] = $serviceType;
                $result['transitTime'] = $transitTime;
                $result['amount'] = $amount;
                $result['maxTransitTime'] = $maxTransitTime;

            } else {
                $result['error'] = 'error';           
                Mage::log($response, null, 'fedex_api_data_error.log');
            }
        } catch (SoapFault $exception) {
//            printFault($exception, $client);
             Mage::log($exception, null, 'fedex_api_data_error.log');
        }
        
        return $result;
    }

    public function addShipper() {
        $countrrycode = Mage::getStoreConfig('shipping/origin/country_id');
        $region_id = Mage::getStoreConfig('shipping/origin/region_id');
        $regioncode = Mage::getModel('directory/region')->load($region_id)->getCode();
        $postcode = Mage::getStoreConfig('shipping/origin/postcode');
        $city = Mage::getStoreConfig('shipping/origin/city');

        $shipper = array(           
            'Address' => array(
                'StreetLines' => array('Address Line 1'),
                'City' => $city,
                'StateOrProvinceCode' => $regioncode,
                'PostalCode' => $postcode,
                'CountryCode' => $countrrycode
            )
        );
        return $shipper;
    }

    public function addRecipient() {

        $recipient_address = Mage::getSingleton('checkout/session')->getQuote()->getShippingAddress();
        $city = $recipient_address->getCity();
        $postcode = $recipient_address->getPostcode();
        $regioncode = Mage::getModel('directory/region')->load($recipient_address->getRegionId())->getCode();
        $countrycode = $recipient_address->getCountryId();

        $recipient = array(           
            'Address' => array(
                'StreetLines' => array('Address Line 1'),
                'City' => $city,
                'StateOrProvinceCode' => $regioncode,
                'PostalCode' => $postcode,
                'CountryCode' => $countrycode,
                'Residential' => false
            )
        );
        return $recipient;
    }

    public function addShippingChargesPayment() {
        $shippingChargesPayment = array(
            'PaymentType' => 'SENDER', // valid values RECIPIENT, SENDER and THIRD_PARTY
            'Payor' => array(
                'ResponsibleParty' => array(
                    'AccountNumber' => getProperty('billaccount'),
                    'CountryCode' => 'US'
                )
            )
        );
        return $shippingChargesPayment;
    }

    public function addLabelSpecification() {
        $labelSpecification = array(
            'LabelFormatType' => 'COMMON2D', // valid values COMMON2D, LABEL_DATA_ONLY
            'ImageType' => 'PDF', // valid values DPL, EPL2, PDF, ZPLII and PNG
            'LabelStockType' => 'PAPER_7X4.75'
        );
        return $labelSpecification;
    }

    public function addSpecialServices() {
        $specialServices = array(
            'SpecialServiceTypes' => array('COD'),
            'CodDetail' => array(
                'CodCollectionAmount' => array(
                    'Currency' => 'USD',
                    'Amount' => 150
                ),
                'CollectionType' => 'ANY' // ANY, GUARANTEED_FUNDS
            )
        );
        return $specialServices;
    }

    public function addPackageLineItem1() {

        $weight = Mage::getSingleton('checkout/session')
                ->getQuote()
                ->getShippingAddress()
                ->getWeight();
        
        $weight=($weight<=0)?1:$weight;

        $packageLineItem = array(
            'SequenceNumber' => 1,
            'GroupPackageCount' => 1,
            'Weight' => array(
                'Value' => $weight,
                'Units' => 'LB'
            )
        );

        //Mage::log($packageLineItem);
        return $packageLineItem;
    }

}
