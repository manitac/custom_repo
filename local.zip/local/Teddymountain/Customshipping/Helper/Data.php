<?php
/**
 * Class Teddymountain_Customshipping_Helper_Data
 *
 * @category    Local
 * @package     Teddymountain_Customshipping
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Customshipping_Helper_Data extends Mage_Core_Helper_Abstract
{

	
}
	 