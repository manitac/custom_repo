<?php
/**
 * Product list
 *
 * @category   Mage
 * @package    Teddymountain_Newarrivals
 * @author     Magento Core Team <core@magentocommerce.com>
 */
class Teddymountain_Newarrivals_Block_Product_List extends Mage_Catalog_Block_Product_List
{
    public function getLoadedProductCollection()
    { 
        if(Mage::registry('current_category_id') == 33)
        { 
			$todayDate = Mage::app()->getLocale()->date()->toString(Varien_Date::DATETIME_INTERNAL_FORMAT);
            $_productCollection = Mage::getModel('catalog/product')
                                ->getCollection()
                                ->joinField('category_id', 'catalog/category_product', 'category_id', 'product_id = entity_id', null, 'left')
                                ->addAttributeToSelect('*')
                                ->addAttributeToFilter('category_id', array(
                                        array('finset' => '27'))
                                )
                                ->addAttributeToFilter('status',1)
                                ->addAttributeToFilter('visibility', 4)
                                ->addAttributeToFilter('news_from_date', array('date' => true, 'to' => $todayDate))
                                ->addAttributeToFilter('news_to_date', array('or'=> array(
                                                                                            0 => array( 
                                                                                                        'date' => true, 
                                                                                                        'from' => $todayDate
                                                                                                        ),
                                                                                            1 => array('is' => new Zend_Db_Expr('null'))
                                                                                        )
                                                                            ), 'left');
            $toolbar = $this->getToolbarBlock();
            $toolbar->setCollection($_productCollection);
            $layout = Mage::getSingleton('core/layout');
            $pager = $layout->createBlock('page/html_pager');
            $toolbar->setChild('product_list_toolbar_pager', $pager);
            Mage::unregister('current_category_id');
            return $_productCollection;
        }
        else
        {
            return $this->_getProductCollection();
        }
    }
}