<?php
/**
 * Class Teddymountain_Sendcad_Model_Mysql4_Cadfiles
 *
 * @category    Local
 * @package     Teddymountain_Sendcad
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Sendcad_Model_Resource_Cadfiles extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        $this->_init("sendcad/cadfiles", "id");
    }
}