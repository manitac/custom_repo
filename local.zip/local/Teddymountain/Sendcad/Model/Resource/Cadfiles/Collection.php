<?php
/**
 * Class Teddymountain_Sendcad_Model_Mysql4_Cadfiles_Collection
 *
 * @category    Local
 * @package     Teddymountain_Teddymountain
 * @author      Mukesh Pandit <mukeshp@chetu.com>
 */
class Teddymountain_Sendcad_Model_Resource_Cadfiles_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{

	public function _construct(){
		$this->_init("sendcad/cadfiles");
	}

	

}
	 