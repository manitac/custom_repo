<?php
/**
 * Class Teddymountain_Sendcad_Model_Cadfiles
 *
 * @category    Local
 * @package     Teddymountain_Sendcad
 * @author      Anoop Singh <anoops@chetu.com>
 */
class Teddymountain_Sendcad_Model_Cadfiles extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("sendcad/cadfiles");

    }

}
	 