<?php

class Teddymountain_Sendcad_Model_Observer {

    /**
     * function generates csv file with order information.
     * return csv file to download from server.
     */
    public function sendOrderNFI(Varien_Event_Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        $order_id = $order->getId();

        if ($this->_getPaymentMethod($order) == 'cashondelivery') {
            return $this;
        }
        Mage::log('order_id=' . $order_id, null, 'cshondeleiver.log');
        try {
            $order = Mage::getModel('sales/order')->load($order_id);
            $customer_order_id = $order->getIncrementId();
            $shippingAddress = $order->getShippingAddress();
            //echo "<pre>";print_r($shippingAddress); 
            $hdr = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $hdr_name = 'HDR_TZOrder_' . $customer_order_id;
            $hdr_file = $path . DS . $hdr_name . '.csv';
            $hdr->setAllowCreateFolders(true);
            $hdr->open(array('path' => $path));
            $hdr->streamOpen($hdr_file, 'w+');
            $hdr->streamLock(true);
            $get_method = $this->fetchShippingMethod($order->getShippingMethod());
            $hdrdata = array(
                $get_method, $customer_order_id, $shippingAddress->getCompany(), $shippingAddress->getName(), '', $shippingAddress->getStreetFull(), $shippingAddress->getCity(), $shippingAddress->getRegion(), $shippingAddress->getCountry(), $shippingAddress->getPostcode()
            );
            $hdr->streamWriteCsv($hdrdata);
            $hdr->streamClose();

            $io = new Varien_Io_File();
            $path = Mage::getBaseDir('var') . DS . 'NFI' . DS . date('d.m.Y');
            $name = 'DET_TZOrder_' . $customer_order_id;
            $file = $path . DS . $name . '.csv';
            $io->setAllowCreateFolders(true);
            $io->open(array('path' => $path));
            $io->streamOpen($file, 'w+');
            $io->streamLock(true);
            $serial = 1;
            $items = $order->getAllItems();

            foreach ($items as $item) {
                $rowdata = array(
                    $serial, $customer_order_id, $item->getSku(), intval($item->getQtyOrdered())
                );

                $io->streamWriteCsv($rowdata);
                $serial++;
            }

            $io->streamClose();
            $this->sendMail($customer_order_id);
        } catch (Exception $e) {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }
        return $this;
    }

    /**
     * email template path-  app\locale\en_US\template\email\send_order.html
     * @param type $order_id
     */
    public function sendMail($order_id) {

        $store_name = Mage::getModel('core/website')->load(1)->getName();
        $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
        $store_phone = Mage::getStoreConfig('general/store_information/phone');

        $emailTemplate = Mage::getModel('core/email_template')
                ->loadDefault('send_order_email_template');

        //Array of variables to assign to template
        $emailTemplateVariables = array();
        $emailTemplateVariables['order_no'] = $order_id;

        $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
        $to = 'shilak@mymails.chetu.com';

        $subject = 'Orders from Direct Wholasale';

        $headers = "From: " . strip_tags($store_email) . "\r\n";
        $headers .= "Reply-To: " . strip_tags($store_email) . "\r\n";
        //$headers .= "CC: $store_email\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($to, $subject, $processedTemplate, $headers);
    }

    function fetchShippingMethod($method) {

        if ($method == 'customshipping_Hold_for_pick_up') {
            return 'customshipping_Hold_for_pick_up';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_EXPRESS_SAVER') {
            return 'FEXP';
        } else if ($method == 'customshipping_FEDEX_2_DAY') {
            return 'F2D';
        } else if ($method == 'customshipping_STANDARD_OVERNIGHT') {
            return 'FSO';
        } else {
            return $method;
        }
    }

    private function _getPaymentMethod($order) {
        $code = $order->getPayment()->getMethodInstance()->getCode();
        return $code;
    }

}
