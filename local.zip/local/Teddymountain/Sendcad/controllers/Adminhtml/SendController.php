<?php
/**
 * This class
 * 
 * 
 */
class Teddymountain_Sendcad_Adminhtml_SendController extends Mage_Adminhtml_Controller_action 
{
    protected function _initAction() 
    {
        $this->loadLayout()->_setActiveMenu("teddymountain/sendcad")->_addBreadcrumb(Mage::helper("adminhtml")->__("Send CAD"), Mage::helper("adminhtml")->__("Send CAD"));
        return $this;
    }

    public function IndexAction() 
    {
        $this->loadLayout();
        $this->renderLayout();
    }

    public function SendfiAction() 
    {
        if ($data = $this->getRequest()->getPost()) 
        {
            $order_id = $data['order_id'];
            $order = Mage::getModel('sales/order')->load($order_id);
            $customer_order_id = $order->getIncrementId();
            $shippingAddress = $order->getShippingAddress();
            $country_id = $shippingAddress->getCountry_id();
            $customer_email = $shippingAddress->getEmail();
            if ($country_id == 'CA') {
                if (isset($_FILES['file_report']['name']) && $_FILES['file_report']['name'] != '') {
                    try {
                        $allowed_ext = array('CSV','csv','JPG','jpg','JPEG','jpeg','png','PNG','pdf','PDF','doc','DOC','docx','DOCX','xls','XLS','txt','TXT');
                        $path = Mage::getBaseDir('media').DS.'cad_files'.DS;  //desitnation directory
                        $fname = $_FILES['file_report']['name']; //file name
                        $fileExt = strtolower(pathinfo($fname, PATHINFO_EXTENSION));
                        $fileNamewoe = basename($fname, '.'.$fileExt);
                        $filtered_name = preg_replace('/\s+/', '_', $fileNamewoe);
                        $fileName = $filtered_name . '_' . time() . '.' . $fileExt;
                        $uploader = new Varien_File_Uploader('file_report'); //load class
                        $uploader->setAllowedExtensions($allowed_ext); //Allowed extension for file
                        $uploader->setAllowCreateFolders(true); //for creating the directory if not exists
                        $uploader->setAllowRenameFiles(false);
                        $uploader->setFilesDispersion(false);
                        $uploader->save($path, $fileName); //save the file
                        $files_data = array(
                                        'order_id' => $order_id,
                                        'file_name' => $fileName,
                                        'created_time' => date('Y-m-d H:i:s')
                                    );
                        $model = Mage::getModel('sendcad/cadfiles');
                        $model->setData($files_data);
                        $model->save();  
                        /****send email****/
                        $customer_order_id = $order->getIncrementId();
                        $file = $path.$fileName;
                        $this->sendmail($customer_order_id,$fileName,$file,$customer_email);
                        Mage::getSingleton('adminhtml/session')->addSuccess(Mage::helper('sales')->__("File has been sent successfully"));

                    }
                    catch (Exception $e)
                    {
                        $fileType = "Invalid file format";
                    }
                }
                else 
                {
                    $fileType = "Invalid file format";
                }
            } else {
                Mage::getSingleton('adminhtml/session')->addError(Mage::helper('sales')->__("File attachment can only be send in case of CAD shipping."));
                $this->_redirectReferer();
                exit();
            }
        }
        else 
        {
            $fileType = "Invalid file format";
        }
        
        if ($fileType == "Invalid file format") 
        {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('sales')->__($fname." Invalid file format"));
            $this->_redirectReferer();
            return;
        }
        $this->_redirectReferer();
        return true;
        // exit;
    }
    
    private function sendmail($customer_order_id,$filename,$file,$customer_email)
    {
        $emailTemplate = Mage::getModel('core/email_template')
                    ->loadDefault('send_cad_email_template');
        $emailTemplateVariables = array();
        $emailTemplateVariables['order_no'] = $customer_order_id;
        $emailTemplateVariables['file'] = $filename;
        $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
        $attachment1 = file_get_contents($file);
        $to = $customer_email;
        $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
        $subject = 'File Attachment for CAD shipping';
        try {
            $z_mail = new Zend_Mail('utf-8');
            $z_mail->setBodyHtml($processedTemplate)
                    ->setSubject($subject)
                    ->addTo($to)
                    ->setFrom($store_email, "From direct wholesale");
            $attach = new Zend_Mime_Part($attachment1);
            //$attach->type = 'application/csv';
            $attach->disposition = Zend_Mime::DISPOSITION_INLINE;
            $attach->encoding = Zend_Mime::ENCODING_BASE64;
            $attach->filename = $filename;
            $z_mail->addAttachment($attach);
            $z_mail->send();
        } catch (Exception $e) {
            return false;
        }
    }
    
    function DeletefiAction()
    {
        if ($data = $this->getRequest()->getPost())
        {
            $id = $data['id'];
            $items = Mage::getModel('sendcad/cadfiles');
            try 
            {
                $path = Mage::getBaseDir('media').DS.'cad_files'.DS;
                $files = $items->getCollection()->addFieldToFilter('id',$id);
                foreach($files->getData() as $file)
                    $target_file = $file['file_name'];
                $items->setId($id)->delete();
                unlink($path.$target_file);
                echo "File deleted successfully.";
            } 
            catch (Exception $e)
            {
                echo $e->getMessage(); 
            }
        }
    }

    function fetchShippingMethod($method) {

        if ($method == 'customshipping_Hold_for_pick_up') {
            return 'customshipping_Hold_for_pick_up';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_GROUND') {
            return 'FEIG';
        } else if ($method == 'customshipping_FEDEX_EXPRESS_SAVER') {
            return 'FEXP';
        } else if ($method == 'customshipping_FEDEX_2_DAY') {
            return 'F2D';
        } else if ($method == 'customshipping_STANDARD_OVERNIGHT') {
            return 'FSO';
        } else {
            return $method;
        }
    }

}
