<?php
 class Teddymountain_Sendcad_Helper_Data extends Mage_Core_Helper_Abstract {


}