<?php
class Teddymountain_Sendcad_Block_Sales_Order_View_Custom extends Mage_Core_Block_Template
{
     
}