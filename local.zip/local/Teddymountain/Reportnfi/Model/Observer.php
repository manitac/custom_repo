<?php

class Teddymountain_Reportnfi_Model_Observer {

    /**
     * function send nfi on order cancel and refund
     * email template path-  app\locale\en_US\template\email\order_cancel_nfi.html
     */
    public function Ordercancel(Varien_Event_Observer $observer) {

        $order = $observer->getEvent()->getOrder();
        $order_id = $order->getId();
        try {
            $order = Mage::getModel('sales/order')->load($order_id);
            $customer_order_id = $order->getIncrementId();
            /* send email to admin */
            $store_name = Mage::getModel('core/website')->load(1)->getName();
            $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
            $store_phone = Mage::getStoreConfig('general/store_information/phone');

            $emailTemplate = Mage::getModel('core/email_template')
                    ->loadDefault('cancel_order_nfi_email_template');
            //Array of variables to assign to template
            $emailTemplateVariables = array();
            $emailTemplateVariables['order_no'] = $customer_order_id;

            $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
            $nfi_email = Mage::getStoreConfig(
                            'general/nfi_emails/set_emails_for_nfi', Mage::app()->getStore()->getId()
            );
            $to = explode(",", $nfi_email);
            $subject = 'Cancel order from Teddy Mountain';
            try {
                $z_mail = new Zend_Mail('utf-8');

                $z_mail->setBodyHtml($processedTemplate)
                        ->setSubject($subject)
                        ->addTo($to)
                        ->setFrom($store_email, "From direct wholesale");


                $z_mail->send();
                Mage::getSingleton('adminhtml/session')->addSuccess('Email for order cancellation have been sent successfully to NFI.');
            } catch (Exception $e) {
                return false;
            }
            /* close code for send email */
            /* send order To nfi emails */
        } catch (Exception $e) {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }
        return $this;
    }

    public function Orderrefund(Varien_Event_Observer $observer) {
        /*         * ********* event triggered when the order refund is initiated *********** */


        $order_id = 0;
        $amount_refunded = 0;
        if ($observer->getEvent()->getCreditmemo()) {
            if ($observer->getEvent()->getCreditmemo()->getInvoice()) {
                $order_id = $observer->getEvent()->getCreditmemo()->getInvoice()->getOrderId();
                $amount_refunded = $observer->getEvent()->getCreditmemo()->getInvoice()->getBaseTotalRefunded();
            } else {
                $order_id = $observer->getEvent()->getCreditmemo()->getOrderId();
                $amount_refunded = $observer->getEvent()->getCreditmemo()->getGrandTotal();
            }
        }
        try {
            /*             * **** check for sending or not sending email to nfi ************ */
            if (!isset($_POST['creditmemo']['send_no_confirmation_nfi'])) {

                $order = Mage::getModel('sales/order')->load($order_id);
                $customer_order_id = $order->getIncrementId();
                /* send email to admin */
                $store_name = Mage::getModel('core/website')->load(1)->getName();
                $store_email = Mage::getStoreConfig('trans_email/ident_general/email');
                $store_phone = Mage::getStoreConfig('general/store_information/phone');

                $emailTemplate = Mage::getModel('core/email_template')
                        ->loadDefault('refund_order_nfi_email_template');
                //Array of variables to assign to template
                $emailTemplateVariables = array();
                $emailTemplateVariables['order_no'] = $customer_order_id;
                $emailTemplateVariables['amount_refunded'] = $amount_refunded;

                $processedTemplate = $emailTemplate->getProcessedTemplate($emailTemplateVariables);
                $nfi_email = Mage::getStoreConfig(
                                'general/nfi_emails/set_emails_for_nfi', Mage::app()->getStore()->getId()
                );
                $to = explode(",", $nfi_email);
                $subject = 'Refund from Teddy Mountain';
                try {
                    $z_mail = new Zend_Mail('utf-8');

                    $z_mail->setBodyHtml($processedTemplate)
                            ->setSubject($subject)
                            ->addTo($to)
                            ->setFrom($store_email, "From direct wholesale");
                    $z_mail->send();
                    Mage::getSingleton('adminhtml/session')->addSuccess('Email for order refund have been sent successfully to NFI.');
                } catch (Exception $e) {
                    return false;
                }
            }
            /* close code for send email */
            /* send order To nfi emails */
        } catch (Exception $e) {
            echo 'Caught exception: ', $e->getMessage(), "\n";
        }
        return $this;
    }

}
