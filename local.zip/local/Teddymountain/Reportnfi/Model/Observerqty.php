<?php
/**************class for event obserevr for related products quantity update*******************/

class Teddymountain_Reportnfi_Model_Observerqty {

    /**
     * function to update quantity of related product
     */
    public function updateQuantity(Varien_Event_Observer $observer) {
        
        if ($observer->getProduct()->getAttributeSetId() == 4) {
            $items = Mage::getSingleton('checkout/session')->getQuote()->getAllItems();
            foreach ($items as $item) {
                $observer->getBuyRequest()->setQty(6);

               /*if ($item->getProduct()->getAttributeSetId() == 9 && !($item->getItemId())){
                    $observer->getBuyRequest()->setQty($item->getQty());
                }*/
            }
        }
    }
}
