<?php
/**
 * Class Chetu_Custommessage_Helper_Data
 *
 * @category    Local
 * @package     Chetu_Custommessage
 * @author      Anoop Singh <anoops@chetu.com>
 */
class Chetu_Custommessage_Helper_Data extends Mage_Core_Helper_Abstract
{

	
}
	 