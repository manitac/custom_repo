<?php
/*
 * My Override on Customers Grid
 */
class Chetu_Customerstatus_Block_Customer_Grid extends Mage_Adminhtml_Block_Customer_Grid
{
    public function setCollection($collection)
    {
        $collection->addAttributeToSelect('customer_status');
        parent::setCollection($collection);
    }
 
    protected function _prepareColumns()
    {
        parent::_prepareColumns();
 
        $this->addColumn('Status', array(
                'header'=> Mage::helper('sales')->__('Status'),
                'index' => 'customer_status',
                'type'    => 'options',
                'options' => array('41' => 'Disabled','42' => 'Enabled'),
                'width' => '100px',
        ));


        return parent::_prepareColumns();
    }
}
