<?php
/**
 * Class Hwg_Attributemanager_Model_Mysql4_Options_Collection
 *
 * @category    Local
 * @package     Hwg_Attributemanager
 */
class Hwg_Attributemanager_Model_Mysql4_Options_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract {

    public function _construct() {
        $this->_init("attributemanager/options");
    }

}
