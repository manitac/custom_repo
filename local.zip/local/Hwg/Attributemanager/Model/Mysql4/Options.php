<?php
/**
 * Class Hwg_Attributemanager_Model_Mysql4_Options
 * @category    Local
 * @package     Hwg_Attributemanager
 */
class Hwg_Attributemanager_Model_Mysql4_Options extends Mage_Core_Model_Mysql4_Abstract {

    protected function _construct() {
        $this->_init("attributemanager/options", "id");
    }

}
