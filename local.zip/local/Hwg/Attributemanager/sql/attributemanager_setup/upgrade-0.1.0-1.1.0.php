<?php
$installer = $this;
$installer->startSetup();

$tablequote = $this->getTable('sales/quote_address');
$installer->run("ALTER TABLE  $tablequote ADD COLUMN (address_type_new varchar(255) NOT NULL, is_dropship_account varchar(100) NOT NULL, reciepient_name varchar(100) NOT NULL,carrier_type varchar(100) NOT NULL,shipping_business_account text NOT NULL)");
 
$tablequote = $this->getTable('sales/order_address');
$installer->run("ALTER TABLE  $tablequote ADD COLUMN (address_type_new varchar(255) NOT NULL, is_dropship_account varchar(100) NOT NULL, reciepient_name varchar(100) NOT NULL,carrier_type varchar(100) NOT NULL,shipping_business_account text NOT NULL)");

$installer->endSetup();

