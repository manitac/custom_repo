<?php

/*******installation script to be executed when the module is installed*****************/

$installer = $this;
$installer->startSetup();

$sql = <<<SQLTEXT
CREATE TABLE IF NOT EXISTS customer_bussiness_type_options(
id int not null auto_increment, 
option_id 	int(11),
is_visible 	text(200),
default_value 	int(10),
primary key(id)
);
SQLTEXT;

$installer->run($sql);
$installer->endSetup();
