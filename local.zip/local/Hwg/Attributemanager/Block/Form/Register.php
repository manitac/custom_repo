<?php

class Hwg_Attributemanager_Block_Form_Register extends Mage_Customer_Block_Form_Register 
{

    /**
     * Load all the options value of bussiness type attribute added in admin section  
     * 
     * @return Array
     */
    public function getalloptions() {

        $attribute_code = "business_type";
        $attribute_details = Mage::getSingleton("eav/config")->getAttribute('customer', $attribute_code);
        $attribute = $attribute_details->getData();
        $attributeId = $attribute['attribute_id'];
        $attribute = Mage::getModel('eav/entity_attribute')->load($attributeId);
        $options = Mage::getModel('eav/entity_attribute_source_table')
                ->setAttribute($attribute)
                ->getAllOptions(false);
        return $options;
    }
    
    /**
     * Load all the options that are set to be visible in front end 
     * 
     * @return Array
     */
    public function getvisibleoptions() 
    {
        $model = Mage::getModel('attributemanager/options')->getCollection()->getLastItem();
        $selectedValue = $model->getData('is_visible');
        $defaultValuesNew = $model->getOptionId();
        $arrayselectedValue = json_decode($selectedValue, true);
        return $arrayselectedValue;
    }

    /**
     * Load the only one value set as default in admin section
     * 
     * @return Array
     */
    public function getdefaultsetoption() 
    {
        $model = Mage::getModel('attributemanager/options')->getCollection()->getLastItem();
        $defaultValuesNew = $model->getOptionId();
        return $defaultValuesNew;
    }

}
