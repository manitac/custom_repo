module.exports = app => {
  app.use('/employee', require('../controllers/employeeController'));
  app.use('/employeeNew', require('../controllers/employeeController'));
};
