module.exports = {
  Employee: require('./employee.model')
};
