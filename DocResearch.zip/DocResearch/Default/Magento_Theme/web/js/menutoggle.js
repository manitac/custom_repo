define([
    'jquery'
], function () {
"use strict";
var myNav = {
        init: function () {
                this.cacheDOM();
                this.browserWidth();
                this.bindEvents();
        },
        cacheDOM: function () {
                this.navBars = jQuery(".navBars");
                this.toggle = jQuery("#toggle");
                this.navMenu = jQuery("#menu");
        },
        browserWidth: function () {
                jQuery(window).resize(this.bindEvents.bind(this));
        },
        bindEvents: function () {
                var width = window.innerWidth;

                if (width < 600) {
                        this.navBars.click(this.animate.bind(this));
                        this.navMenu.hide();
                        this.toggle[0].checked = false;
                } else {
                        this.resetNav();
                }
        },
        animate: function (e) {
                var checkbox = this.toggle[0];

                if (!checkbox.checked) {
                        this.navMenu.slideDown();
                } else {
                        this.navMenu.slideUp();
                }

        },
        resetNav: function () {
                this.navMenu.show();
        }
};
myNav.init();
});