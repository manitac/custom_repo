<?php
/**
 * Ps_Shoppingcart
 * overriding Ps_Shoppingcart php file
 */
use PrestaShop\PrestaShop\Adapter\Cart\CartPresenter;
class Ps_ShoppingcartOverride extends Ps_Shoppingcart
{
    /**
     * Author: Chetu Team
     * Func Name: hookHeader
     * Updated On: APr 26, 2018
     * Updated For: get review page id
     */
     public function hookHeader()
    {
        if (Configuration::isCatalogMode()) {
            return;
        }

        if (Configuration::get('PS_BLOCK_CART_AJAX')) {
            $this->context->controller->registerJavascript('modules-shoppingcart', 'modules/'.$this->name.'/ps_shoppingcart.js', ['position' => 'bottom', 'priority' => 150]);
        }
		// get review page id from database
		$query=Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow("SELECT id_cms FROM `"._DB_PREFIX_."cms_lang` where `link_rewrite`='reviews'"); 
		// assign id to an variable
		$this->context->smarty->assign('review_id',$query['id_cms']);
		// get order information-customer-service page id from database
		$queryorderinfolink=Db::getInstance(_PS_USE_SQL_SLAVE_)->getRow("SELECT id_cms FROM `"._DB_PREFIX_."cms_lang` where `link_rewrite`='order-information-customer-service'"); 
		// assign id to an variable
		$this->context->smarty->assign('order_info_id',$queryorderinfolink['id_cms']);
    }   

    /**
     * Author: Chetu Team
     * Func Name: renderModal
     * Created On: Feb 14, 2018
     * Created For: render Modal
     */
	public function renderModal(Cart $cart, $id_product, $id_product_attribute)
    {
		$data = (new CartPresenter)->present($cart);
		$product = null;
		$instore_pickup = 0;
		$ship = 0;
        foreach ($data['products'] as $p) {
			$carriers = Product::getCarriersId((int)$p['id_product'], $this->context->shop->id);
			foreach($carriers as $carrier){
				if($carrier['id_carrier'] == 30){
					$instore_pickup = $instore_pickup + 1;
				}
				if($carrier['id_carrier'] == 32){
					$ship  = $ship+1;
				}
			}

            if ($p['id_product'] == $id_product && $p['id_product_attribute'] == $id_product_attribute) {
                $product = $p;
                break;
            }
        }

        $this->smarty->assign(array(
            'product' => $product,
            'cart' => $data,
			'instore_pickup' => $instore_pickup,
			'ship' => $ship,
            'cart_url' => $this->getCartSummaryURLNew(),
        ));

        return $this->fetch('module:ps_shoppingcart/modal.tpl');
    }
	
	/**
     * Author: Chetu Team
     * Func Name: getWidgetVariables
     * Created On: Feb 14, 2018
     * Created For: getWidgetVariables
     */
	public function getWidgetVariables($hookName, array $params)
    {
        $cart_url = $this->getCartSummaryURLNew();
        $cart_data = (new CartPresenter)->present(isset($params['cart']) ? $params['cart'] : $this->context->cart);
		$instore_pickup = 0;
		$ship = 0;
		foreach ($cart_data['products'] as $p) {
			$carriers = Product::getCarriersId((int)$p['id_product'], $this->context->shop->id);
			foreach($carriers as $carrier){
				if($carrier['id_carrier'] == 30){
					$instore_pickup = $instore_pickup + 1;
				}
				if($carrier['id_carrier'] == 32){
					$ship  = $ship+1;
				}
			}
		}
        return array(
            'cart' => $cart_data,
            'refresh_url' => $this->context->link->getModuleLink('ps_shoppingcart', 'ajax'),
            'cart_url' => $cart_url,
             'instore_pickup' => $instore_pickup,
		    'ship' => $ship

        );
    }
	
	 /**
     * Author: Chetu Team
     * Func Name: getCartSummaryURLNew
     * Created On: Feb 14, 2018
     * Created For: get Cart Summary URL New
     */
	public function getCartSummaryURLNew()
    {
        return $this->context->link->getPageLink(
            'cart',
            null,
            $this->context->language->id,
            array(
                'action' => 'show'
            )
        );
    }

}
