<?php
/**
 * AmazzingFilter
 * overrining AmazzingFilter php file
 */

class AmazzingFilterOverride extends AmazzingFilter
{
    
    /**
     * Author: Chetu Team
     * Func Name: getProductsInfos
     * Created On: Dec 12, 2017
     * Created For: Returns all product info
     */
    public function getProductsInfos($ids, $id_lang, $id_shop)
    {
        if (!$ids) {
            return array();
        }
        $products_infos = array();
        $now = date('Y-m-d H:i:s');
        $nb_days_new = Configuration::get('PS_NB_DAYS_NEW_PRODUCT');
        $imploded_ids = implode(', ', $ids);
        $products_data = $this->db->executeS('
            SELECT p.*, product_shop.*, pl.*, image.id_image, il.legend, m.name AS manufacturer_name,
            DATEDIFF(\''.pSQL($now).'\', p.date_add) < '.(int)$nb_days_new.' AS new
            FROM '._DB_PREFIX_.'product p
            '.Shop::addSqlAssociation('product', 'p').'
            INNER JOIN '._DB_PREFIX_.'product_lang pl
                ON (pl.id_product = p.id_product'.Shop::addSqlRestrictionOnLang('pl').'
                AND pl.id_lang = '.(int)$id_lang.')
            LEFT JOIN '._DB_PREFIX_.'image image
                ON (image.id_product = p.id_product AND image.cover = 1)
            LEFT JOIN '._DB_PREFIX_.'image_lang il
                ON (il.id_image = image.id_image AND il.id_lang = '.(int)$id_lang.')
            LEFT JOIN '._DB_PREFIX_.'manufacturer m
                ON m.id_manufacturer = p.id_manufacturer
            WHERE p.id_product IN ('.pSQL($imploded_ids).')
        ');
        $positions = array_flip($ids);
        if ($this->is_17) {
            $factory = new ProductPresenterFactory($this->context, new TaxConfiguration());
            $factory_presenter = $factory->getPresenter();
            $factory_settings = $factory->getPresentationSettings();
            $lang_obj = new Language($id_lang);
        }
        
        //Sale price calculation
        $products_infos = array();
        foreach ($products_data as $pd) {
            // oos data is kept updated in stock_available table
            // joining this table in query significantly increases time if there are many $ids
            $pd['out_of_stock'] = StockAvailable::outOfStock($pd['id_product'], $id_shop);
            // cache_default_attribute is kept up to date in indexProduct()
            $pd['id_product_attribute'] = $pd['cache_default_attribute'];
            
            //Sale price calculation
            if (substr(number_format($pd['price'],2),-1) == 8) {
                $pd['discounted_sale_price'] = number_format(($pd['price']/0.9), 2);
            } elseif (substr(number_format($pd['price'],2),-1) == 7){
                $pd['discounted_sale_price'] = number_format(($pd['price']/0.8), 2);
            } elseif (substr(number_format($pd['price'],2),-1) == 6){
                $pd['discounted_sale_price'] = number_format(($pd['price']/0.7), 2);
            } elseif (substr(number_format($pd['price'],2),-1) == 5){
                $pd['discounted_sale_price'] = number_format(($pd['price']/0.6), 2);
            } elseif (substr(number_format($pd['price'],2),-1) == 4){
                $pd['discounted_sale_price'] = number_format(($pd['price']/0.5), 2);
            }            
            
            $pd = Product::getProductProperties($id_lang, $pd);
            if ($this->is_17 && Tools::getValue('controller') == 'ajax') {
                $pd = $factory_presenter->present($factory_settings, $pd, $lang_obj);
            }
            $products_infos[$positions[$pd['id_product']]] = $pd;
        }
        ksort($products_infos);
        return $products_infos;
    }
    public function getSpecialControllerIds($controller)
    {
        $ids = $items = array();

        switch ($controller) {
            case 'newproducts':
                $now = date('Y-m-d H:i:s');
                $nb_days_new = Configuration::get('PS_NB_DAYS_NEW_PRODUCT');
                $items = $this->db->executeS('
                    SELECT id_product
                    FROM '._DB_PREFIX_.'product_shop
                    WHERE id_shop = '.(int)$this->context->shop->id.'
                    AND active = 1
                    AND DATEDIFF(\''.pSQL($now).'\', date_add) < '.(int)$nb_days_new.'
                ');
                break;
            case 'bestsales':
                $items = $this->db->executeS('
                    SELECT ps.id_product
                    FROM '._DB_PREFIX_.'product_sale ps
                    '.Shop::addSqlAssociation('product', 'ps').'
                    WHERE product_shop.active = 1
                    ORDER BY ps.quantity DESC
                ');
                break;
            case 'pricesdrop':
                $groups = $this->context->customer->getGroups();
                $imploded_groups = implode(', ', $groups);
                $items = $this->db->executeS('
                    SELECT id_product
                    FROM '._DB_PREFIX_.'product_shop ps
                    WHERE id_shop = '.(int)$this->context->shop->id.'
                    AND active = 1
                    AND SUBSTR(ROUND(ps.price,2), -1) IN (4,5,6,7,8)
                    ORDER BY SUBSTR(ROUND(ps.price,2), -1) ASC
                ');
                break;
        }
        foreach ($items as $i) {
            $ids[$i['id_product']] = $i['id_product'];
        }
        return $ids;
    }

	
	/**
     * Author: Chetu Team
     * Func Name: getProductsInfos
     * Created On: Jan 23, 2018
     * Created For: Returns all filtered product info
     */
	public function getFilteredProducts($params)
    {
        $start_time = microtime(true);
        $id_lang = $this->context->language->id;
        $id_shop = $this->context->shop->id;
        $id_shop_group = $this->context->shop->id_shop_group;
        $id_currency = $this->context->currency->id;
        $trigger = Tools::getValue('trigger', 'af_page');
        $to_count_additionally = array();
        $filter_identifiers = array('c', 'a', 'f', 'm', 's', 't', 'q', 'p', 'w');

        // define "or" params basing on primary_filter
        if (!empty($params['primary_filter'])) {
            $primary_filter = $params['primary_filter'];
            $first_char = Tools::substr($primary_filter, 0, 1);
            $or_id = Tools::substr($params['primary_filter'], 1);
            if (in_array($first_char, $filter_identifiers)) {
                if (!empty($params[$first_char][$or_id])) {
                    $params['or-'.$first_char][$or_id] = $params[$first_char][$or_id];
                    unset($params[$first_char][$or_id]);
                } elseif (!empty($params[$primary_filter])) {
                    $params['or-'.$primary_filter] = $params[$primary_filter];
                    unset($params[$primary_filter]);
                }
                $key_for_additional_params = $first_char;
                if ((int)$or_id > 0) {
                    $key_for_additional_params .= (int)$or_id;
                }
                if (!empty($params['available_options'][$key_for_additional_params])) {
                    $to_count_additionally = $params['available_options'][$key_for_additional_params];
                    if (!is_array($to_count_additionally)) {
                        $to_count_additionally = explode(',', $to_count_additionally);
                    }
                    $to_count_additionally = array_flip($to_count_additionally);
                }
            }
        }

        // remove 0 options obtained from selects
        foreach (array('', 'or-') as $prefix) {
            foreach ($filter_identifiers as $i) {
                $i = $prefix.$i;
                if (!empty($params[$i])) {
                    if (isset($params[$i][0])) {
                        if (!$params[$i][0]) {
                            unset($params[$i]);
                        }
                    } else {
                        foreach (array_keys($params[$i]) as $id_group) {
                            if (!$params[$i][$id_group][0]) {
                                unset($params[$i][$id_group]);
                            }
                        }
                    }
                    if (empty($params[$i])) {
                        unset($params[$i]);
                    }
                }
            }
        }

        $selected_atts = isset($params['a']) ? $params['a'] : array();
        if (isset($params['or-a'])) {
            $selected_atts += $params['or-a'];
        }
        ksort($selected_atts);
        $check_stock = !empty($params['combinations_stock']);
        $check_existence = !empty($params['combinations_existence']) && $selected_atts;

        //sorting data
        $order_by = $params['orderBy'];
        $order_way = $params['orderWay'];
        if (!in_array($order_way, array('asc', 'desc'))) {
            $order_way = 'asc';
        }

        // Default sorting in 1.6 is displayed as '-' but submitted as order_by.order_way for all controllers
        // it has to be treated in a special way for some selected controllers
        if (!$this->is_17 && $this->isDefaultSorting($order_by, $order_way)) {
            if ($params['current_controller'] == 'search') {
                $order_by = 'position';
                $order_way = 'desc';
            } elseif ($params['current_controller'] == 'newproducts') {
                $order_by = 'date_add';
                $order_way = 'desc';
            }
        }

        if (!$params['controller_product_ids']) {
            $cpids = array();
        } else {
            $cpids = explode(',', $params['controller_product_ids']);
        }
		
        if ($order_by == 'position') {
            $all_positions = array();
            if (!empty($cpids)) {
                if ($order_way == 'desc') {
                    $cpids = array_reverse($cpids);
                }
                foreach ($cpids as $k => $id) {
                    $all_positions[$id] = $k + 1;
                }
            } else {
                $position_id_cat = $params['id_parent_cat'];
                // if only 1 category is checked, sort by positions in that category
                // TODO: add compatibility with top level category blocks (e.g. c31)
                foreach (array('or-c', 'c') as $k) {
                    if (!empty($params[$k])) {
                        foreach ($params[$k] as $categories) {
                            if (count($categories) == 1) {
                                $position_id_cat = current($categories);
                                break;
                            }
                        }
                    }
                }
                $raw_data = $this->db->executeS('
                    SELECT * FROM '._DB_PREFIX_.'category_product
                    WHERE id_category = '.(int)$position_id_cat.'
                ');
                foreach ($raw_data as $d) {
                    $all_positions[$d['id_product']] = $d['position'];
                }
            }
        } elseif ($order_by == 'manufacturer_name') {
            $raw_data = $this->db->executeS('
                SELECT id_manufacturer, name FROM '._DB_PREFIX_.'manufacturer WHERE active = 1
            ');
            $manufacturer_names = array();
            foreach ($raw_data as $d) {
                $manufacturer_names[$d['id_manufacturer']] = $d['name'];
            }
        }

        $params['controller_product_ids'] = array_combine($cpids, $cpids);

        // ranges
        $ranges = array('p' => array(), 'w' => array());
        foreach ($ranges as $identifier => $range) {
            if (isset($params[$identifier.'_slider_from']) && isset($params[$identifier.'_slider_to'])) {
                // sliders
                $ranges[$identifier] = array(
                    'values' => array(array($params[$identifier.'_slider_from'], $params[$identifier.'_slider_to'])),
                    'min' => 100000000,
                    'max' => 0,
                    'is_slider' => 1,
                );
            } elseif (isset($params['available_options'][$identifier])) {
                // range values
                $values = array();
                if (isset($params[$identifier])) {
                    $values = $params[$identifier];
                } elseif (isset($params['or-'.$identifier])) {
                    $values = $params['or-'.$identifier];
                }
                foreach ($values as &$val) {
                    $val = explode('-', $val);
                    $from = $val[0];
                    $to = isset($val[1]) ? $val[1] : $val[0];
                    $val = array($from, $to);
                }
                $ranges[$identifier] = array(
                    'values' => $values,
                    'min' => 10000000,
                    'max' => 0,
                );
            } else {
                unset($ranges[$identifier]);
            }
        }

        $index_path = $this->csv_dir.'index_'.$id_shop.'_'.$id_lang.'_'.$id_currency.'.csv';
        $products = file_exists($index_path) ? file($index_path): array();
        $filtered_ids = $move_to_the_end = $count_data = array();
        $sorted_products = $sorted_combinations_data = $sorted_qties = array();

        if ($check_stock || $check_existence) {
            $raw_data = $this->db->executeS('
                SELECT
                sa.id_product_attribute as id_comb,
                sa.quantity as qty,
                pac.id_attribute as id_att,
                sa.id_product,
                a.id_attribute_group as id_group
                FROM '._DB_PREFIX_.'stock_available sa
                INNER JOIN '._DB_PREFIX_.'product_shop ps
                    ON ps.id_product = sa.id_product AND ps.active = 1
                    AND ps.id_shop = '.(int)$id_shop.'
                LEFT JOIN '._DB_PREFIX_.'product_attribute_combination pac
                    ON pac.id_product_attribute = sa.id_product_attribute
                LEFT JOIN '._DB_PREFIX_.'attribute a
                    ON a.id_attribute = pac.id_attribute
                WHERE '.pSQL($this->addStockShopAssociaton($id_shop, $id_shop_group)).'
                ORDER BY pac.id_attribute ASC
            ');

            foreach ($raw_data as $d) {
                if (!$d['id_comb']) {
                    $sorted_qties[$d['id_product']] = $d['qty'];
                } elseif ($d['id_att']) {
                    $sorted_combinations_data[$d['id_product']][] = $d;
                }
            }
        }

        $special_ids = array();
        foreach (array_keys($this->getSpecialFilters()) as $s) {
            if ($s != 'in_stock' && !empty($params['available_options'][$s])) {
                $special_ids[$s] = $this->getSpecialControllerIds($s);
            }
        }

        $customer_groups = explode(',', $params['customer_groups']);
        $catalog_mode = Configuration::get('PS_CATALOG_MODE');
		//echo $index_path;die();

        foreach ($products as $k => $product_line) {
            $data = explode('|', trim($product_line));

            $visibility = $data[15];

            if ($visibility != 'both') {
                if (($visibility == 'catalog' && !$catalog_mode) ||
                    ($visibility == 'search' && $params['current_controller'] != 'search')) {
                        // visibility 'none' is excluded during indexation
                        continue;
                }
            }

            $price = Tools::jsonDecode($data[11], true);
            if (is_array($price)) {
                $price = isset($price[$this->context->customer->id_default_group]) ?
                $price[$this->context->customer->id_default_group] : current($price);
            }

            $id = $data[0];
            $cats = $data[3];
            if ($params['subcat_products'] && !empty($data[4])) {
                $cats .= ','.$data[4];
            }
            $p = array(
                'id' => $id,
                'name' => $data[1],
                'reference' => $data[2],
                'cats' => $cats,
                'atts' => $data[5],
                'id_manufacturer' => $data[6],
                'suppliers' => $data[7],
                'w' => $data[8],
                'image' => $data[9],
                'feats' => $data[10],
                'p' => (float)$price,
                'date_add' => $data[12],
                'date_upd' => $data[13],
                'tags' => $data[16],
                'condition' => $data[17],
            );

            $force_continue = 0;

            if (!empty($data[14])) {
                $groups_having_access = explode(',', $data[14]);
                if (!array_intersect($groups_having_access, $customer_groups)) {
                    continue;
                }
            }

            // select only products that belong to parent category
            $c = explode(',', $p['cats']);
            if (!in_array($params['id_parent_cat'], $c) || !$this->checkControllerCompliance($params, $p)) {
                continue;
            }

            foreach ($ranges as $identifier => &$range) {
                if ($p[$identifier] > $range['max']) {
                    $range['max'] = $p[$identifier];
                }
                if ($p[$identifier] < $range['min']) {
                    $range['min'] = $p[$identifier];
                }
                if ($range['values']) {
                    $within_range = false;
                    foreach ($range['values'] as $from_to) {
                        if ($p[$identifier] >= $from_to[0] && $p[$identifier] <= $from_to[1]) {
                            $within_range = true;
                            break;
                        }
                    }
                    if (!$within_range) {
                        if (isset($params['or-'.$identifier])) {
                            $force_continue = 1;
                        } else {
                            continue 2;
                        }
                    }
                }
            }

            if (!$check_stock) {
                if (!empty($params['available_options']['in_stock']) || $params['oos_behaviour']) {
                    $p['qty'] = $this->getProductQty($id, $id_shop, $id_shop_group);
                    if ($p['qty'] < 1) {
                        if ($params['oos_behaviour'] == 2 || !empty($params['in_stock'])) {
                            continue;
                        } elseif ($params['oos_behaviour'] == 1) {
                            $move_to_the_end[$id] = $id;
                        }
                    }
                }
            }

            // cats
            if (isset($params['c'])) {
                foreach ($params['c'] as $subcategories) {
                    if (!array_intersect($c, $subcategories)) {
                        continue 2;
                    }
                }
            }

            // special ids, for new product/bestsales etc
            foreach ($special_ids as $k => $ids) {
                if (!empty($params[$k]) && !isset($ids[$id])) {
                    continue 2;
                }
            }

            // atts
            $a = explode(',', $p['atts']);
            if (isset($params['a'])) {
                foreach ($params['a'] as $attributes_in_group) {
                    if (!array_intersect($a, $attributes_in_group)) {
                        continue 2;
                    }
                }
            }

            // feats
            $f = explode(',', $p['feats']);
            if (isset($params['f'])) {
                foreach ($params['f'] as $features_in_group) {
                    if (!array_intersect($f, $features_in_group)) {
                        continue 2;
                    }
                }
            }

            // manufacturers
            if (isset($params['m']) && !in_array($p['id_manufacturer'], $params['m'])) {
                continue;
            }

            // suppliers
            $s = explode(',', $p['suppliers']);
            if (isset($params['s']) && !array_intersect($s, $params['s'])) {
                continue;
            }

            // tags
            $t = explode(',', $p['tags']);
            if (isset($params['t']) && !array_intersect($t, $params['t'])) {
                continue;
            }

            // condition
            if (isset($params['q']) && !in_array($p['condition'], $params['q'])) {
                continue;
            }

            // additional matches for triggered criteria
            if (isset($params['or-c'])) {
                foreach ($c as $c_id) {
                    if (isset($to_count_additionally[$c_id])) {
                        $count_data['c-'.$c_id][$id] = $id;
                    }
                }
                foreach ($params['or-c'] as $subcategories) {
                    if (!array_intersect($c, $subcategories)) {
                        $force_continue = 1;
                    }
                }
            } elseif (isset($params['or-a'])) {
                if (!$check_stock && !$check_existence) {
                    foreach ($a as $a_id) {
                        if (isset($to_count_additionally[$a_id])) {
                            $count_data['a-'.$a_id][$id] = $id;
                        }
                    }
                }
                foreach ($params['or-a'] as $attributes_in_group) {
                    if (!array_intersect($a, $attributes_in_group)) {
                        $force_continue = 1;
                    }
                }
            } elseif (isset($params['or-f'])) {
                foreach ($f as $f_id) {
                    if (isset($to_count_additionally[$f_id])) {
                        $count_data['f-'.$f_id][$id] = $id;
                    }
                }
                foreach ($params['or-f'] as $features_in_group) {
                    if (!array_intersect($f, $features_in_group)) {
                        $force_continue = 1;
                    }
                }
            } elseif (isset($params['or-m'])) {
                $count_data['m-'.$p['id_manufacturer']][$id] = $id;
                if (!in_array($p['id_manufacturer'], $params['or-m'])) {
                    $force_continue = 1;
                }
            } elseif (isset($params['or-s'])) {
                foreach ($s as $s_id) {
                    if (isset($to_count_additionally[$s_id])) {
                        $count_data['s-'.$s_id][$id] = $id;
                    }
                }
                if (!array_intersect($s, $params['or-s'])) {
                    $force_continue = 1;
                }
            } elseif (isset($params['or-t'])) {
                foreach ($t as $t_id) {
                    if (isset($to_count_additionally[$t_id])) {
                        $count_data['t-'.$t_id][$id] = $id;
                    }
                }
                if (!array_intersect($t, $params['or-t'])) {
                    $force_continue = 1;
                }
            } elseif (isset($params['or-q'])) {
                $count_data['q-'.$p['condition']][$id] = $id;
                if (!in_array($p['condition'], $params['or-q'])) {
                    $force_continue = 1;
                }
            }
            foreach (array_keys($ranges) as $identifier) {
                if (isset($params['or-'.$identifier])) {
                    $count_data[$identifier][$p[$identifier]][$id] = $id;
                }
            }

            // ----- excluding non-existant/out-of-stock combinations
            if ($check_stock || $check_existence) {
                $combinations_data = $in_stock = $existing = $all_atts_grouped = $combination_qties = array();
                $to_include = array('exist' => array(), 'stock' => array());
                $keep_product = array('exist' => !$check_existence, 'stock' => !$check_stock);
                $p['qty'] = 0;

                if (!empty($sorted_combinations_data[$id])) {
                    $combinations_data = $sorted_combinations_data[$id];
                } elseif (!$selected_atts) {
                    // this product has no combinations and no attributes are selected
                    if ($check_stock && !empty($sorted_qties[$id])) {
                        $p['qty'] = $sorted_qties[$id];
                    }
                    $keep_product = array('exist' => 1, 'stock' => (!$check_stock || $p['qty']));
                }

                foreach ($combinations_data as $d) {
                    if (!$d['id_att'] || !$d['id_comb'] || !$d['id_group']) {
                        continue;
                    }
                    $all_atts_grouped[$d['id_group']][$d['id_att']] = $d['id_att'];
                    if ($check_existence) {
                        $existing[$d['id_comb']][$d['id_group']] = $d['id_att'];
                    }
                    if ($check_stock) {
                        if ($d['qty'] > 0) {
                            $in_stock[$d['id_comb']][$d['id_group']] = $d['id_att'];
                            $combination_qties[$d['id_comb']] = $d['qty'];
                        }
                    }
                }

                $atts = $selected_atts ? $selected_atts : $all_atts_grouped;
                $possible_combinations = $this->getPossibleCombinations($atts);

                // verify product availability basing on selected attributes
                foreach ($possible_combinations as $possible_comb) {
                    $possible_comb_atts_num = count($possible_comb);
                    if ($check_stock) {
                        foreach ($in_stock as $comb) {
                            $intersect = array_intersect($comb, $possible_comb);
                            if (count($intersect) == $possible_comb_atts_num) {
                                $keep_product['stock'] = 1;
                                $p['qty'] = isset($sorted_qties[$id]) ? $sorted_qties[$id] : 1;
                                // include count data here in order to skip some nested loops later
                                foreach ($comb as $id_att) {
                                    $to_include['stock'][$id_att] = $id_att;
                                }
                                break;
                                // if order_by == quantity, we can calculate stock only for selected attributes
                                // in this case we have to remove break,
                                // add key to foreach ($in_stock as $id_comb => $comb) ...
                                // and use  $p['qty'] += $combination_qties[$id_comb];
                                // but this approach significantly increases time,
                                // especially if you have more than 2000 combinations per product
                                // moreover, getProductProperties sets total qties later
                            }
                        }
                    }
                    if ($check_existence) {
                        foreach ($existing as $comb) {
                            $intersect = array_intersect($comb, $possible_comb);
                            if (count($intersect) == $possible_comb_atts_num) {
                                $keep_product['exist'] = 1;
                                foreach ($comb as $id_att) {
                                    $to_include['exist'][$id_att] = $id_att;
                                }
                                break;
                            }
                        }
                    }
                }

                // complex loop for count data
                foreach ($all_atts_grouped as $id_group => $atts) {
                    foreach ($atts as $id_att) {
                        foreach ($possible_combinations as $possible_comb) {
                            $possible_comb[$id_group] = $id_att;
                            if ($check_stock && empty($to_include['stock'][$id_att])) {
                                foreach ($in_stock as $comb) {
                                    if (!isset($comb[$id_group]) || $comb[$id_group] != $id_att) {
                                        continue;
                                    }
                                    $intersect = array_intersect($comb, $possible_comb);
                                    if (count($intersect) == count($possible_comb)) {
                                        $to_include['stock'][$id_att] = $id_att;
                                        break;
                                    }
                                }
                            }
                            if ($check_existence && empty($to_include['exist'][$id_att])) {
                                foreach ($existing as $comb) {
                                    if (!isset($comb[$id_group]) || $comb[$id_group] != $id_att) {
                                        continue;
                                    }
                                    $intersect = array_intersect($comb, $possible_comb);
                                    if (count($intersect) == count($possible_comb)) {
                                        $to_include['exist'][$id_att] = $id_att;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }

                if ($params['oos_behaviour'] < 2 && empty($params['in_stock'])) {
                    if (!$keep_product['stock']) {
                        $keep_product['stock'] = 1;
                        $move_to_the_end[$id] = $id;
                    }
                    foreach ($a as $id_att) {
                        $to_include['stock'][$id_att] = $id_att;
                    }
                }

                if ($check_stock && $check_existence) {
                    $to_include = array_intersect($to_include['stock'], $to_include['exist']);
                } elseif ($check_stock) {
                    $to_include = $to_include['stock'];
                } else {
                    $to_include = $to_include['exist'];
                }

                if ($selected_atts && !$force_continue) {
                    foreach ($to_include as $id_att) {
                        $count_data['a-'.$id_att][$id] = $id;
                    }
                }

                if (!$keep_product['stock'] || !$keep_product['exist']) {
                    $force_continue = 1;
                    // remove possible extra-matches for -or params
                    foreach ($c as $c_id) {
                        unset($count_data['c-'.$c_id][$id]);
                    }
                    foreach ($f as $f_id) {
                        unset($count_data['f-'.$f_id][$id]);
                    }
                    foreach ($t as $t_id) {
                        unset($count_data['t-'.$t_id][$id]);
                    }
                    foreach ($s as $s_id) {
                        unset($count_data['s-'.$s_id][$id]);
                    }
                    unset($count_data['m-'.$p['id_manufacturer']][$id]);
                    unset($count_data['q-'.$p['condition']][$id]);
                }
            }
            // ----- end excluding non-existant/out-of-stock combinations

            if ($force_continue) {
                continue;
            }

            if (!$check_stock && !$check_existence) {
                foreach ($a as $a_id) {
                    $count_data['a-'.$a_id][$id] = $id;
                }
            } elseif (!empty($to_include) && empty($selected_atts)) {
                foreach ($to_include as $id_att) {
                    $count_data['a-'.$id_att][$id] = $id;
                }
            }
            foreach ($c as $c_id) {
                $count_data['c-'.$c_id][$id] = $id;
            }
            foreach ($f as $f_id) {
                $count_data['f-'.$f_id][$id] = $id;
            }
            foreach ($t as $t_id) {
                $count_data['t-'.$t_id][$id] = $id;
            }
            $count_data['m-'.$p['id_manufacturer']][$id] = $id;
            foreach ($s as $s_id) {
                $count_data['s-'.$s_id][$id] = $id;
            }
            foreach ($special_ids as $k => $ids) {
                if (isset($ids[$id])) {
                    $count_data[$k][$id] = $id;
                }
            }
            if (!empty($params['available_options']['in_stock']) && $p['qty'] > 0) {
                $count_data['in_stock'][$id] = $id;
            }
            $count_data['q-'.$p['condition']][$id] = $id;

            foreach (array_keys($ranges) as $identifier) {
                $count_data[$identifier][$p[$identifier]][$id] = $id;
            }

            $sorted_products[$id] = $p;
            $filtered_ids[$id] = $id;

            switch ($order_by) {
                case 'name':
                case 'date_add':
                case 'date_upd':
                case 'reference':
                    $filtered_ids[$id] = $p[$order_by];
                    break;
                case 'price':
                    $filtered_ids[$id] = $p['p'];
                    break;
                case 'quantity':
                    $filtered_ids[$id] = isset($p['qty']) ? $p['qty'] :
                    $this->getProductQty($id, $id_shop, $id_shop_group);
                    break;
                case 'position':
                    $filtered_ids[$id] = isset($all_positions[$id]) ? $all_positions[$id] : 'n';
                    break;
                case 'manufacturer_name':
                    $filtered_ids[$id] = isset($manufacturer_names[$p['id_manufacturer']]) ?
                    $manufacturer_names[$p['id_manufacturer']] : '';
                    break;
            }
        }
		
        //sorting
		
        if ($order_way == 'asc') {
            asort($filtered_ids);
        } else {
            arsort($filtered_ids);
        }

        $filtered_ids = array_keys($filtered_ids);

        // instockfirst
        if ($params['oos_behaviour'] == 1 && $order_by != 'quantity') {
            $oos_ids = array();
            foreach ($filtered_ids as $pos => $id) {
                if (!empty($move_to_the_end[$id])) {
                    $oos_ids[] = $id;
                    unset($filtered_ids[$pos]);
                }
            }
            if (is_array($filtered_ids)) {
                $filtered_ids = array_merge($filtered_ids, $oos_ids);
            } else {
                $filtered_ids = $oos_ids;
            }
        }


        //pagination data
        $page_keepers = array('af_page', 'p_type');
        if (!empty($params['page']) && in_array($trigger, $page_keepers)) {
            $page = (int)$params['page'];
        } else {
            $page = 1;
        }

        $products_per_page = $params['nb_items'];
        $offset = ($page - 1) * $products_per_page;
        $length = $products_per_page;
		
		//code to filter product based on discount if we hit the browser
        if(Tools::getValue('controller') == 'pricesdrop' && $_GET['order'] == ''){
			$controller_product_ids = array_values($params['controller_product_ids']);
			$filteredProductsArray = array();
			
			foreach ($filtered_ids as $value) {
				$key = array_search($value, $controller_product_ids); 
				$filteredProductsArray[$key] = $value;
			}
			$filtered_ids = $filteredProductsArray;
			ksort($filtered_ids);

		} 
		
		//code to filter product based on discount if ajax request is been made and request contain order by parameter
        $process = 0;
		$current_url_param = '';
		$current_url_param = Tools::getValue('current_url_param');
		if((strpos($current_url_param, "prices-drop") !== false ) && (strpos($current_url_param, "order") === false )){
			$controller_product_ids = array_values($params['controller_product_ids']);
			$filteredProductsArray = array();
			die('helo');
			foreach ($filtered_ids as $value) {
				$key = array_search($value, $controller_product_ids); 
				$filteredProductsArray[$key] = $value;
			}
			$filtered_ids = $filteredProductsArray;
			ksort($filtered_ids);
			$process = 1;
		} 

		//code to filter product based on discount if ajax request is been made and request do not contain order by
        $current_url = Tools::getValue('current_url');
		if((strpos($current_url, "prices-drop") !== false ) && (strpos($current_url, "order") === false ) && $process == 0){
			$controller_product_ids = array_values($params['controller_product_ids']);
			$filteredProductsArray = array();
			
			foreach ($filtered_ids as $value) {
				$key = array_search($value, $controller_product_ids); 
				$filteredProductsArray[$key] = $value;
			}
			$filtered_ids = $filteredProductsArray;
			ksort($filtered_ids);
		} 
		
        $ids = array_slice($filtered_ids, $offset, $length);
        $products_infos = $this->getProductsInfos($ids, $id_lang, $id_shop);
        

        // prepare data for ranged filters (price/weight)
        foreach ($ranges as $identifier => $r) {
            $ranges[$identifier]['min'] = $min = floor($r['min']);
            $ranges[$identifier]['max'] = $max = ceil($r['max']);
            if (empty($range['is_slider'])) {
                // available_options may be empty on first page load, because min/max are not known yet
                // so we prepare range options here, basing on existing min/max values
                if (empty($params['available_options'][$identifier])) {
                    $step = isset($params[$identifier.'_range_step']) && (int)$params[$identifier.'_range_step'] ?
                    (int)$params[$identifier.'_range_step'] : 100;
                    $range_options = array();
                    for ($i = $min; $i < $max; $i += $step) {
                        $from = count($range_options) ? $i + 1 : $i;
                        $to = $i + $step;
                        if ($to > $max) {
                            $to = $max;
                        }
                        $range_options[] = $from.'-'.$to;
                    }
                    $params['available_options'][$identifier] = $range_options;
                    $ranges[$identifier]['available_options'] = $range_options; // include this in returned 'ranges'
                } else {
                    $range_options = $params['available_options'][$identifier];
                }
                $range_options = is_array($range_options) ? $range_options : explode(',', $range_options);
                $max_range_values = array();
                foreach ($range_options as $range_value) {
                    $max_range_values[$identifier.'-'.$range_value] = explode('-', $range_value)[1];
                }
                if (!empty($count_data[$identifier])) {
                    foreach ($count_data[$identifier] as $value => $ids) {
                        foreach ($max_range_values as $key => $max_value) {
                            if ($value <= $max_value) {
                                $count_data[$key] = isset($count_data[$key]) ? $count_data[$key] : array();
                                $count_data[$key] += $ids;
                                break;
                            }
                        }
                    }
                    unset($count_data[$identifier]);
                }
            }
        }

        // count
        $count_data_numbers = array();
        foreach ($count_data as $k => $cd) {
            if ($cd) {
                $count_data_numbers[$k] = count($cd);
            }
        }

        $filtered_ids_count = count($filtered_ids);
        $product_count_text = '';
        if ($params['p_type'] == 2) {
            // load more btn
            $product_count_text = $this->l('Showing 1 - %1$d of %2$d items');
            $shown_products = $page * $products_per_page;
            if ($filtered_ids_count < $shown_products) {
                $shown_products = $filtered_ids_count;
            }
            $product_count_text = sprintf($product_count_text, $shown_products, $filtered_ids_count);
        }

        $ret = array (
            'filtered_ids_count' => $filtered_ids_count,
            'page' => $page,
            'products_per_page' => $products_per_page,
            'count_data' => $count_data_numbers,
            'count_data_full' => $count_data, // this variable may be required in overrides
            'ranges' => $ranges,
            'trigger' => $trigger,
            'params' => $params,
            'time' => microtime(true) - $start_time,
            'products' => $products_infos,
            'hide_load_more_btn' => ($params['p_type'] == 2) && ($offset + $length >= $filtered_ids_count),
            'product_count_text' => $product_count_text,
        );
        // d(microtime(true) - $start_time);
        return $ret;
    }
   
}
