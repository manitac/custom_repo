<?php
/**
 * Wtmegamenu
 * overriding Wtmegamenu php file
 */
class WtmegamenuOverride extends Wtmegamenu
{
	/**
     * Author: Chetu Team
     * Func Name: getWidgetVariables
     * Created On: Feb 1, 2018
     * Created For: get Widget Variables
     */
	public function getWidgetVariables($hookName = null, array $configuration = [])
    {
		$id_lang = (int)$this->context->language->id;
		$id_shop = (int)Context::getContext()->shop->id;
		$group_cat_result = array();
		if (!$this->isCached('wtmegamenu.tpl', $this->getCacheId('wtmegamenu')))
		{
			$menu_obj = new WtMegamenuClass();
			$menus = $menu_obj->getMenus();
			$languages = Language::getLanguages();
			
			$new_menus = array();
			foreach ($menus as $menu)
			{
				if ($menu['type_link'] == 0 && $menu['dropdown'] == 1)
				{
					$type = Tools::substr($menu['link'], 0, 3);
					$id = (int)Tools::substr($menu['link'], 3, Tools::strlen($menu['link']) - 3);
					if ($menu['dropdown'] == 1 && $type == 'CAT')
					{
						$this->respMenu = '';
						$category = new Category((int)$id, $id_lang, $id_shop);
						$menu['sub_menu'] = $this->getRespCategories($id, false, false, $category->level_depth, $menu['subtitle'], $menu['type_icon'], $menu['icon'], $menu['align_sub'], $menu['class']);
					}
					else
						$menu['sub_menu'] = array();
					$menu['type'] = $type;
					$menu_info = $this->fomartLink($menu);
					$menu['link'] = $menu_info['link'];
					$menu['title'] = $menu_info['title'];
					$menu['selected_item'] = $menu_info['selected_item'];	
				}
				else
				{
					if ($menu['type_link'] == 0)
					{
						$type = Tools::substr($menu['link'], 0, 3);
						$menu['type'] = $type;
						$menu_info = $this->fomartLink($menu);
						$menu['link'] = $menu_info['link'];
						$menu['title'] = $menu_info['title'];
						$menu['selected_item'] = $menu_info['selected_item'];
					}
					$sub_menu = $this->getSubMenu($menu['id_wtmegamenu']);
					if (is_array($sub_menu) && count($sub_menu) > 0)
						$menu['sub_menu'] = $sub_menu;
					else
						$menu['sub_menu'] = array();
				}
				$new_menus[] = $menu;
			}
			//get all suppliers
			$suppliers = Supplier::getSuppliers();
			$link = new Link();
			$supplierArray = array();
			foreach($suppliers as $supplier){
				$supplier['url'] = $link->getSupplierLink($supplier['id_supplier']);
				$supplierArray[] = $supplier;
			}
			return [
				'menus' => $new_menus,
				'icon_path' => $this->_path.'views/img/icons/',
				'_path' => $this->_path,
				'suppliers' => $supplierArray
			];
		
		}
	}
}