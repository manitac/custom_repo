<?php

/**
 * Braintreejs
 * overrining Braintreejs php file
 */
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class BraintreejsOverride extends Braintreejs {

    /**
     * Author: Chetu Team
     * Func Name: processPayment
     * Created On: Apr 5, 2018
     * Created For: Process payment
     */
    public function processPayment() {
        $redirect_url = $this->context->link->getPageLink('order', true, null, 'step=3&bt_error=1#bt_error');
		//get user current case
		$querySqlcase = 'SELECT REPLACE(REPLACE(case_status, 1, "Fraud") , 2, "Good") as status FROM `' . _DB_PREFIX_ . 'emailage_status` Where id_user=' . $this->context->customer->id;
		$EAcaseResult = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($querySqlcase);
		//check fraud user and redirect on error page
		if($EAcaseResult[0]['status'] == 'Fraud' ) {
			$redirect_url = $this->context->link->getPageLink('order', true, null, 'errorf=fraud');
			Tools::redirect($redirect_url);
		}

        if (Tools::isSubmit('braintree_payment_advanced')) {
            $redirect_url = $this->context->link->getModuleLink($this->name, 'advancedpayment', array('token' => Tools::getToken(false), 'bt_error' => '1'), true);
        }

        $config = Configuration::getMultiple(array('BRAINTREE_MODE', 'BRAINTREE_SUBMIT_SETTLE', 'BRAINTREE_UI_MODE', 'BRAINTREE_3DS'));

        $is_enabled = Module::isEnabled('emailAge');
        if ($is_enabled) {
            //calculate the emailage score for a customer
            $querySql = 'SELECT `id_emailAge`,`EA_SCORE` FROM `' . _DB_PREFIX_ . 'emailage` Where id_customer=' . $this->context->customer->id . ' order by id_emailAge desc limit 1';
            $EAScoreResult = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($querySql);
        }

        //the environment is based on the global configuration since this is a new transaction
        $bt_env = $config['BRAINTREE_MODE'] ? Braintreejs::ENV_PRODUCTION : Braintreejs::ENV_SANDBOX;
        $this->setupBraintreeEnv($bt_env);
        $submit_settle = $config['BRAINTREE_SUBMIT_SETTLE'];
        if ($is_enabled) {
			if($EAcaseResult[0]['status'] == 'Good') {
				$submit_settle = $config['BRAINTREE_SUBMIT_SETTLE'];
			}
			else {
				if ($EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true)) {
					$submit_settle = 0;
				} else {
					$submit_settle = $config['BRAINTREE_SUBMIT_SETTLE'];
				}
			}
        }
        $merchant_account_id = $config['BRAINTREE_MODE'] ? Configuration::get('BRAINTREE_CURRENCY_LIVE_' . $this->context->currency->iso_code) : Configuration::get('BRAINTREE_CURRENCY_TEST_' . $this->context->currency->iso_code);
        $braintree_dropinui_enabled = $config['BRAINTREE_UI_MODE'] ? 1 : 0;
        $braintree_3ds = $config['BRAINTREE_3DS'] ? 1 : 0;

        //3DS only supported when dropin ui is disabled
        if ($braintree_dropinui_enabled)
            $braintree_3ds = false;

        try {
            $require3ds = array(
                'required' => ($braintree_3ds == '1' ? true : false),
            );

            //sale options used for any payment type
            $options = array(
                'amount' => $this->context->cart->getOrderTotal(),
                'orderId' => $this->context->cart->id,
                'merchantAccountId' => $merchant_account_id,
                'options' => array(
                    'submitForSettlement' => ($submit_settle == '1' ? true : false),
                    'threeDSecure' => $require3ds,
                ),
                'deviceData' => Tools::getValue('device_data'),
            );

            //always add the basic customer information for each sale
            $customerArray = array(
                'firstName' => $this->context->customer->firstname,
                'lastName' => $this->context->customer->lastname,
                'email' => $this->context->customer->email,
            );
            $options['customer'] = $customerArray;

            //customer is either paying with card or paypal
            $isPaypal = Tools::isSubmit('submitPaypalPayment');
            $isDropIn = Tools::isSubmit('submitDropInPayment');
            $isHosted = Tools::isSubmit('submitHostedPayment');

            if ($isPaypal) {
                $payment_method_nonce = Tools::getValue('payment_method_nonce'); //for new paypal account
                $payment_method_token = Tools::getValue('payment_method_token'); //for existing paypal account
                if ($payment_method_nonce) // new paypal account
                    $options['paymentMethodNonce'] = $payment_method_nonce;
                else if ($payment_method_token) // existing paypal token 
                    $options['paymentMethodToken'] = $payment_method_token;
                else {
                    Logger::addLog($this->l('Braintree - Exception occured') . ' Invalid payment method selected.  Please report issue to module developer ', 4, null, 'Cart', (int) $this->context->cart->id, true);

                    return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
//					Tools::redirectLink($redirect_url);
                }

                //if the delivery address is set and valid, then send it
                if (isset($this->context->cart->id_address_delivery)) {
                    //only send the address if not virtual
                    $isVirtual = $this->context->cart->isVirtualCart();

                    $delivery_address = new Address((int) $this->context->cart->id_address_delivery);
                    if (Validate::isLoadedObject($delivery_address) && !$isVirtual) {
                        $shipping = array(
                            'firstName' => $delivery_address->firstname,
                            'lastName' => $delivery_address->lastname,
                            'company' => $delivery_address->company,
                            'streetAddress' => $delivery_address->address1,
                            'extendedAddress' => $delivery_address->address2,
                            'locality' => $delivery_address->city,
                            'postalCode' => $delivery_address->postcode,
                        );

                        if ($delivery_address->id_country)
                            $shipping['countryCodeAlpha2'] = Country::getIsoById($delivery_address->id_country);

                        if ($delivery_address->id_state) {
                            $state = new State((int) $delivery_address->id_state);
                            if (Validate::isLoadedObject($state))
                                $shipping['region'] = $state->iso_code;
                        }

                        $options['shipping'] = $shipping;
                    }
                }
            }
            else if ($isDropIn) {
                $payment_method_nonce = Tools::getValue('payment_method_nonce');

                if ($payment_method_nonce)
                    $options['paymentMethodNonce'] = $payment_method_nonce;
                else {
                    Logger::addLog($this->l('Braintree - Exception occured') . ' Invalid payment method selected.  Please report issue to module developer ', 4, null, 'Cart', (int) $this->context->cart->id, true);

                    return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
                }

                //if the delivery address is set and valid, then send it
                //we do not send the billing address, as Braintree does not allow it when using Dropin UI.  The UI will collect any required AVS information.
                if (isset($this->context->cart->id_address_delivery)) {
                    //only send the address if not virtual
                    $isVirtual = $this->context->cart->isVirtualCart();

                    $delivery_address = new Address((int) $this->context->cart->id_address_delivery);
                    if (Validate::isLoadedObject($delivery_address) && !$isVirtual) {
                        $shipping = array(
                            'firstName' => $delivery_address->firstname,
                            'lastName' => $delivery_address->lastname,
                            'company' => $delivery_address->company,
                            'streetAddress' => $delivery_address->address1,
                            'extendedAddress' => $delivery_address->address2,
                            'locality' => $delivery_address->city,
                            'postalCode' => $delivery_address->postcode,
                        );

                        if ($delivery_address->id_country)
                            $shipping['countryCodeAlpha2'] = Country::getIsoById($delivery_address->id_country);

                        if ($delivery_address->id_state) {
                            $state = new State((int) $delivery_address->id_state);
                            if (Validate::isLoadedObject($state))
                                $shipping['region'] = $state->iso_code;
                        }

                        $options['shipping'] = $shipping;
                    }
                }
            }
            else if ($isHosted) {
                // a payment_method_nonce is required, if it does not exists, then there was an error
                $payment_method_nonce = Tools::getValue('payment_method_nonce');

                if ($payment_method_nonce)
                    $options['paymentMethodNonce'] = $payment_method_nonce;
                else {
                    Logger::addLog($this->l('Braintree - Exception occured') . ' Invalid payment method selected.  Please report issue to module developer ', 4, null, 'Cart', (int) $this->context->cart->id, true);

                    return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
//					Tools::redirectLink($redirect_url);
                }

                //if the billing address is set and valid, then send it
                if (isset($this->context->cart->id_address_invoice)) {
                    $billing_address = new Address((int) $this->context->cart->id_address_invoice);
                    if (Validate::isLoadedObject($billing_address)) {
                        $billing = array(
                            'firstName' => $billing_address->firstname,
                            'lastName' => $billing_address->lastname,
                            'company' => $billing_address->company,
                            'streetAddress' => $billing_address->address1,
                            'extendedAddress' => $billing_address->address2,
                            'locality' => $billing_address->city,
                            'postalCode' => $billing_address->postcode,
                        );

                        if ($billing_address->id_country)
                            $billing['countryCodeAlpha2'] = Country::getIsoById($billing_address->id_country);

                        if ($billing_address->id_state) {
                            $state = new State((int) $billing_address->id_state);
                            if (Validate::isLoadedObject($state))
                                $billing['region'] = $state->iso_code;
                        }

                        $options['billing'] = $billing;
                    }
                }
                //if the delivery address is set and valid, then send it
                if (isset($this->context->cart->id_address_delivery)) {
                    $delivery_address = new Address((int) $this->context->cart->id_address_delivery);
                    if (Validate::isLoadedObject($delivery_address)) {
                        $shipping = array(
                            'firstName' => $delivery_address->firstname,
                            'lastName' => $delivery_address->lastname,
                            'company' => $delivery_address->company,
                            'streetAddress' => $delivery_address->address1,
                            'extendedAddress' => $delivery_address->address2,
                            'locality' => $delivery_address->city,
                            'postalCode' => $delivery_address->postcode,
                        );

                        if ($delivery_address->id_country)
                            $shipping['countryCodeAlpha2'] = Country::getIsoById($delivery_address->id_country);

                        if ($delivery_address->id_state) {
                            $state = new State((int) $delivery_address->id_state);
                            if (Validate::isLoadedObject($state))
                                $shipping['region'] = $state->iso_code;
                        }

                        $options['shipping'] = $shipping;
                    }
                }
            }
            else {
                //invalid payment option was used, or nothing was sent
                die('no longer supported');
            }

            $this->recordTransaction($options, $this->context->cart->id, 'salerequest');
            $result = Braintree_Transaction::sale($options);
            $this->recordTransaction($result, $this->context->cart->id, 'saleresponse');

            if ($result->success) {
                $transaction = $result->transaction;
                $paymentInstrumentType = $transaction->paymentInstrumentType;
                $payment_instrument = $this->convertInstrumentType($paymentInstrumentType);
                $order_status = (int) Configuration::get('BRAINTREE_PAYMENT_ORDER_STATUS');
				//chnage emailage status if user case is good
				if($EAcaseResult[0]['status'] == 'Good') {
				    $order_status = (int) Configuration::get('EMAILAGE_ACCOUNT_CAPTURE_ORDER_STATUS');
				} else if($EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true)){
				    $order_status = (int) Configuration::get('EMAILAGE_ACCOUNT_VOID_ORDER_STATUS');
				}
                $message = $this->l('Braintree Transaction Details:') . "\n\n" .
                        $this->l('Braintree Transaction ID:') . ' ' . $transaction->id . "\n" .
                        $this->l('Status:') . ' ' . $transaction->status . "\n" .
                        $this->l('Instrument Type:') . ' ' . $paymentInstrumentType . "\n" .
                        $this->l('Processed on:') . ' ' . $transaction->createdAt->format('Y-m-d h:i:s a e') . "\n" .
                        $this->l('Currency:') . ' ' . Tools::strtoupper($transaction->currencyIsoCode) . "\n\n" .
                        $this->l('Initial Processor Response Details:') . "\n" .
                        $this->l('Authorization Code:') . ' ' . $transaction->processorAuthorizationCode . "\n" .
                        $this->l('Response Code:') . ' ' . $transaction->processorResponseCode . "\n" .
                        $this->l('Response Text:') . ' ' . $transaction->processorResponseText . "\n\n";

                if ($paymentInstrumentType == 'credit_card') {
                    $message .=
                            $this->l('Basic Fraud Details:') . "\n" .
                            $this->l('CVC Check:') . ' ' . $transaction->cvvResponseCode . "\n" .
                            $this->l('Address 1 Check:') . ' ' . $transaction->avsStreetAddressResponseCode . "\n" .
                            $this->l('Postal Code Check:') . ' ' . $transaction->avsPostalCodeResponseCode . "\n" .
                            $this->l('AVS Check:') . ' ' . $transaction->avsErrorResponseCode . "\n";
                }

                //customer paid using a credit card from the vault.
                if ($paymentInstrumentType == 'credit_card' && $transaction->creditCard['token'] != '')
                    $message .= "\n" . $this->l('Note: You are using the Dropin UI and the customer paid with a Credit Card from their Vault.  Due to PCI Compliance regulations, Braintree is not permitted to store the CVV code in the Vault.  Therefore we anticipate that the CVC Check value will be an I (Not Provided).');

                //customer paid using a credit card and the merchant is using the Dropin UI
                if ($paymentInstrumentType == 'credit_card' && $isDropIn)
                    $message .= "\n" . $this->l('Note: You are using the Dropin UI and we expect the Address 1 Check value to be an I (Not Provided).  This is because the Dropin UI does not collect the Address from the customer.  Since the value is not collected, Braintree bypasses the checks.');

                if ($paymentInstrumentType == 'credit_card') {
                    // In case of successful payment, the address / zip-code can however fail
                    if (isset($transaction->avsStreetAddressResponseCode) && $transaction->avsStreetAddressResponseCode == 'N')
                        $order_status = (int) Configuration::get('BRAINTREE_PENDING_ORDER_STATUS');
                    if (isset($transaction->avsPostalCodeResponseCode) && $transaction->avsPostalCodeResponseCode == 'N')
                        $order_status = (int) Configuration::get('BRAINTREE_PENDING_ORDER_STATUS');

                    //warn if cvc check fails, this should only apply if the merchant has not configured 'basic fraud protection' in braintree dashboard to decline
                    if (isset($transaction->cvvResponseCode) && $transaction->cvvResponseCode != 'M')
                        $order_status = (int) Configuration::get('BRAINTREE_PENDING_ORDER_STATUS');
                    //warn if avs check fails, this should only apply if the merchant has not configured 'basic fraud protection' in braintree dashboard to decline
                    if (isset($transaction->avsErrorResponseCode) && $transaction->avsErrorResponseCode == 'E')
                        $order_status = (int) Configuration::get('BRAINTREE_PENDING_ORDER_STATUS');
                }
				//check emailage score for new user
                if ($is_enabled && empty($EAcaseResult[0]['status'])) {
					if ($EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true)) {
						$order_status = Configuration::get('EMAILAGE_ACCOUNT_VOID_ORDER_STATUS');					
					}
				}

                $payment_method = $this->convertInstrumentType($paymentInstrumentType);

                try {
                    //capture the cart id incase we need to look it up later.  not sure when the context is cleared
                    $id_cart = $this->context->cart->id;
                    $this->validateOrder((int) $this->context->cart->id, (int) $order_status, ($transaction->amount), $payment_method, $message, array(), null, false, $this->context->customer->secure_key);
                } catch (Throwable $t) {
                    // Throwable Executed only in PHP 7, will not match in PHP 5.x
                    //we are catching an exception here in case an order was created, and we might still be able to continue.
                    //we do this because of the issue in PS v1.7.0.0, where the smarty function 'displayPrice' is not properly registered for the PDF invoice creation.
                    //so we will rethrow the exception only if an order does not exist
                    $message = $t->getMessage();
                    Logger::addLog($this->l('Braintree - Throwable caught while creating an order') . ' ' . $message, 4, null, 'Cart', (int) $id_cart, true);

                    $new_order = new Order((int) $this->currentOrder);
                    if (!Validate::isLoadedObject($new_order)) {
                        //currentOrder may not be defined yet, since the exception might be throw before that statement is reached, so we have to manually locate the id_order
                        $new_order = new Order((int) Order::getOrderByCartId($id_cart));
                        if (!Validate::isLoadedObject($new_order))
                            throw $t;
                        else
                            $this->currentOrder = (int) $new_order->id;
                    }
                } catch (Exception $e) {
                    // Executed only in PHP 5.x, will not be reached in PHP 7
                    //we are catching an exception here in case an order was created, and we might still be able to continue.
                    //we do this because of the issue in PS v1.7.0.0, where the smarty function 'displayPrice' is not properly registered for the PDF invoice creation.
                    //so we will rethrow the exception only if an order does not exist
                    $message = $e->getMessage();
                    Logger::addLog($this->l('Braintree - Exception caught while creating an order') . ' ' . $message, 4, null, 'Cart', (int) $id_cart, true);

                    $new_order = new Order((int) $this->currentOrder);
                    if (!Validate::isLoadedObject($new_order)) {
                        //currentOrder may not be defined yet, since the exception might be throw before that statement is reached, so we have to manually locate the id_order
                        $new_order = new Order((int) Order::getOrderByCartId($id_cart));
                        if (!Validate::isLoadedObject($new_order))
                            throw $e;
                        else
                            $this->currentOrder = (int) $new_order->id;
                    }
                }

                $new_order = new Order((int) $this->currentOrder);
                if (Validate::isLoadedObject($new_order)) {
                    $payment = $new_order->getOrderPaymentCollection();
                    if (isset($payment[0])) {
                        $payment[0]->payment_method = pSQL($payment_instrument);
                        $payment[0]->transaction_id = pSQL($transaction->id);
                        $payment[0]->save();
                    }
                }          
                 //calculate the emailage score for a customer
                 if($is_enabled) {
                         Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('UPDATE `' . _DB_PREFIX_ . 'emailage` SET order_id = '. (int) $this->currentOrder.' where id_emailAge=' . $EAScoreResult[0]['id_emailAge'] . '');
                 }
				 //chnage emailage status to cancel if emailage score greater than 700
				if(empty($EAcaseResult[0]['status']) && $EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true) ) {
					$braintree_order_status ='unpaid'; 
				} else {
					$braintree_order_status = ($transaction->status == Braintree_Transaction::AUTHORIZED || $transaction->status == Braintree_Transaction::SUBMITTED_FOR_SETTLEMENT || $transaction->status == Braintree_Transaction::AUTHORIZING || $transaction->status == Braintree_Transaction::SETTLED || $transaction->status == Braintree_Transaction::SETTLING ? 'paid' : 'unpaid');
                }
                // Store the transaction details
                if (isset($transaction->id))
                    Db::getInstance()->Execute('
					INSERT INTO ' . _DB_PREFIX_ . 'braintree_transaction (type, id_braintree_customer, id_cart, id_order,
					id_transaction, amount, status, currency, cvc_check, line1_check, zip_check, avs_check, mode, date_add, payment_instrument_type)
					VALUES (\'payment\', ' . (isset($transaction->customer['id']) ? (int) $transaction->customer['id'] : 0) . ', ' . (int) $this->context->cart->id . ', ' . (int) $this->currentOrder . ', \'' . pSQL($transaction->id) . '\',
					\'' . ($transaction->amount) . '\', \'' . $braintree_order_status . '\', \'' . pSQL($transaction->currencyIsoCode) . '\',
					' . ($transaction->cvvResponseCode == 'M' ? 1 : 0) . ',
					' . ($transaction->avsStreetAddressResponseCode == 'M' ? 1 : 0) . ',
					' . ($transaction->avsPostalCodeResponseCode == 'M' ? 1 : 0) . ',
					' . ($transaction->avsErrorResponseCode == '' ? 1 : 0) . ', \'' . (Configuration::get('BRAINTREE_MODE') ? 'live' : 'test') . '\', NOW(), \'' . pSQL($paymentInstrumentType) . '\')');

				//chnage emailage status to cancel if emailage score greater than 700
				if(empty($EAcaseResult[0]['status']) && $EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true) ) {
				        $result = Braintree_Transaction::void($transaction->id);
				     $this->recordTransaction($result, $this->currentOrder, 'void');
				}  
				//check emailage status to good  
			    if($EAcaseResult[0]['status'] == 'Good') {
					$result = Braintree_Transaction::submitForSettlement($transaction->id);
					$this->recordTransaction($result, $this->currentOrder, 'capture');
				 }
                $redirect = 'index.php?controller=order-confirmation&id_cart=' . (int) $this->context->cart->id . '&id_module=' . (int) $this->id . '&id_order=' . (int) $this->currentOrder . '&key=' . $this->context->customer->secure_key;
                Tools::redirect($redirect);
            }
            else if ($result->transaction) {

                $transaction = $result->transaction;

                //it is possible with Paypal to receive a status of "settlement_pending".  In this use case, we should create an order using a configured order status.
                if ($transaction->status == Braintree_Transaction::SETTLEMENT_PENDING) {
                    $order_status = (int) Configuration::get('BRAINTREE_SETTLEMENT_PENDING_OS');
                    $message = $this->l('Braintree Transaction Details:') . "\n\n" .
                            $this->l('Braintree Transaction ID:') . ' ' . $transaction->id . "\n" .
                            $this->l('Status:') . ' ' . $transaction->status . "\n" .
                            $this->l('Processed on:') . ' ' . $transaction->createdAt->format('Y-m-d h:i:s a e') . "\n" .
                            $this->l('Currency:') . ' ' . Tools::strtoupper($transaction->currencyIsoCode) . "\n" .
                            $this->l('Instrument Type:') . ' ' . ($transaction->paymentInstrumentType ) . "\n";

                    // Create the PrestaShop order in database
                    try {
                        $this->validateOrder((int) $this->context->cart->id, (int) $order_status, ($transaction->amount), $this->displayName, $message, array(), null, false, $this->context->customer->secure_key);
                    } catch (Throwable $t) {
                        // Throwable Executed only in PHP 7, will not match in PHP 5.x
                        //we are catching an exception here in case an order was created, and we might still be able to continue.
                        //we do this because of the issue in PS v1.7.0.0, where the smarty function 'displayPrice' is not properly registered for the PDF invoice creation.
                        //so we will rethrow the exception only if an order does not exist
                        $message = $t->getMessage();
                        Logger::addLog($this->l('Braintree - Throwable caught while creating an order') . ' ' . $message, 4, null, 'Cart', (int) $id_cart, true);

                        $new_order = new Order((int) $this->currentOrder);
                        if (!Validate::isLoadedObject($new_order)) {
                            //currentOrder may not be defined yet, since the exception might be throw before that statement is reached, so we have to manually locate the id_order
                            $new_order = new Order((int) Order::getOrderByCartId($id_cart));
                            if (!Validate::isLoadedObject($new_order))
                                throw $t;
                            else
                                $this->currentOrder = (int) $new_order->id;
                        }
                    } catch (Exception $e) {
                        // Executed only in PHP 5.x, will not be reached in PHP 7
                        //we are catching an exception here in case an order was created, and we might still be able to continue.
                        //we do this because of the issue in PS v1.7.0.0, where the smarty function 'displayPrice' is not properly registered for the PDF invoice creation.
                        //so we will rethrow the exception only if an order does not exist
                        $message = $e->getMessage();
                        Logger::addLog($this->l('Braintree - Exception caught while creating an order') . ' ' . $message, 4, null, 'Cart', (int) $id_cart, true);

                        $new_order = new Order((int) $this->currentOrder);
                        if (!Validate::isLoadedObject($new_order)) {
                            //currentOrder may not be defined yet, since the exception might be throw before that statement is reached, so we have to manually locate the id_order
                            $new_order = new Order((int) Order::getOrderByCartId($id_cart));
                            if (!Validate::isLoadedObject($new_order))
                                throw $e;
                            else
                                $this->currentOrder = (int) $new_order->id;
                        }
                    }

                    $new_order = new Order((int) $this->currentOrder);
                    if (Validate::isLoadedObject($new_order)) {
                        $payment = $new_order->getOrderPaymentCollection();
                        if (isset($payment[0])) {
                            $payment_instrument = $this->convertInstrumentType($transaction->paymentInstrumentType);
                            $payment[0]->payment_method = pSQL($payment_instrument);
                            $payment[0]->transaction_id = pSQL($transaction->id);
                            $payment[0]->save();
                        }
                    }
					//calculate the emailage score for a customer
                    if($is_enabled) {
                          Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('UPDATE `' . _DB_PREFIX_ . 'emailage` SET order_id = '. (int) $this->currentOrder.' where id_emailAge=' . $EAScoreResult[0]['id_emailAge'] . '');
                    }
                    // Store the transaction details
                    if (isset($transaction->id))
                        Db::getInstance()->Execute('
						INSERT INTO ' . _DB_PREFIX_ . 'braintree_transaction (type, id_braintree_customer, id_cart, id_order,
						id_transaction, amount, status, currency, cvc_check, line1_check, zip_check, avs_check, mode, date_add, payment_instrument_type)
						VALUES (\'payment\', ' . (isset($transaction->customer['id']) ? (int) $transaction->customer['id'] : 0) . ', ' . (int) $this->context->cart->id . ', ' . (int) $this->currentOrder . ', \'' . pSQL($transaction->id) . '\',
						\'' . ($transaction->amount) . '\', \'' . ($transaction->status == Braintree_Transaction::AUTHORIZED || $transaction->status == Braintree_Transaction::SUBMITTED_FOR_SETTLEMENT || $transaction->status == Braintree_Transaction::AUTHORIZING || $transaction->status == Braintree_Transaction::SETTLED || $transaction->status == Braintree_Transaction::SETTLING || $transaction->status == Braintree_Transaction::SETTLEMENT_PENDING ? 'paid' : 'unpaid') . '\', \'' . pSQL($transaction->currencyIsoCode) . '\',
						' . ($transaction->cvvResponseCode == 'M' ? 1 : 0) . ',
						' . ($transaction->avsStreetAddressResponseCode == 'M' ? 1 : 0) . ',
						' . ($transaction->avsPostalCodeResponseCode == 'M' ? 1 : 0) . ',
						' . ($transaction->avsErrorResponseCode == '' ? 1 : 0) . ', \'' . (Configuration::get('BRAINTREE_MODE') ? 'live' : 'test') . '\', NOW(), \'' . pSQL($transaction->paymentInstrumentType) . '\')');

                    $redirect = __PS_BASE_URI__ . 'index.php?controller=order-confirmation&id_cart=' . (int) $this->context->cart->id . '&id_module=' . (int) $this->id . '&id_order=' . (int) $this->currentOrder . '&key=' . $this->context->customer->secure_key;
                    Tools::redirect($redirect);
                }
                else {
                    $response = array(
                        'status' => $transaction->status,
                        'id' => $transaction->id,
                        'processorResponseCode' => $transaction->processorResponseCode,
                        'processorResponseText' => $transaction->processorResponseText,
                        'avsErrorResponseCode' => $transaction->avsErrorResponseCode,
                        'avsPostalCodeResponseCode' => $transaction->avsPostalCodeResponseCode,
                        'avsStreetAddressResponseCode' => $transaction->avsStreetAddressResponseCode,
                        'cvvResponseCode' => $transaction->cvvResponseCode,
                        'gatewayRejectionReason' => $transaction->gatewayRejectionReason,
                    );
                    $message = '';
                    foreach ($response as $key => $value)
                        $message .= "$key: $value, ";

                    Logger::addLog($this->l('Braintree - Payment transaction failed') . ' ' . $message, 2, null, 'Cart', (int) $this->context->cart->id, true);
                    return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
                }
            } else {
                //validation problems (like cvv or expiration).  We log the errors for the merchant and redirect back to payment page so they can try again.
                foreach ($result->errors->deepAll() as $error) {
                    $code = $error->code;
                    $message = $error->message;

                    Logger::addLog($this->l('Braintree - Validation Error occurred') . ' ' . $code . ': ' . $message, 3, $code, 'Cart', (int) $this->context->cart->id, true);
                }

                return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
            }
        } catch (Braintree_Exception_Authentication $e) {
            $message = $e->getMessage();
            Logger::addLog($this->l('Braintree - Braintree_Exception_Authentication occurred') . ' ' . $message, 4, null, 'Cart', (int) $this->context->cart->id, true);

            return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
        } catch (Braintree_Exception $e) {
            $message = $e->getMessage();
            Logger::addLog($this->l('Braintree - Braintree_Exception occurred') . ' ' . $message, 4, null, 'Cart', (int) $this->context->cart->id, true);

            return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
        } catch (Exception $e) {
            $message = $e->getMessage();
            Logger::addLog($this->l('Braintree - Exception occured') . ' ' . $message, 4, null, 'Cart', (int) $this->context->cart->id, true);

            return $this->redirectWithNotifications($redirect_url, $this->l('There was a problem processing your payment, please double check your data and try again.'));
        }
    }

    /*
     * This function sets up the Braintree SDK
     * environment can be either 'sandbox' or 'production'.  It defaults to 'sandbox'
     */

    private function setupBraintreeEnv($environment = Braintreejs::ENV_SANDBOX) {
        $config = Configuration::getMultiple(array('BRAINTREE_MODE', 'BRAINTREE_MERCHANTID_TEST', 'BRAINTREE_PUBLIC_KEY_TEST', 'BRAINTREE_PRIVATE_KEY_TEST', 'BRAINTREE_MERCHANTID_LIVE', 'BRAINTREE_PUBLIC_KEY_LIVE', 'BRAINTREE_PRIVATE_KEY_LIVE'));

        include_once(_PS_MODULE_DIR_ . 'braintreejs/lib/Braintree.php');

        //default to sandbox settings
        $merchant_id = $config['BRAINTREE_MERCHANTID_TEST'];
        $public_key = $config['BRAINTREE_PUBLIC_KEY_TEST'];
        $private_key = $config['BRAINTREE_PRIVATE_KEY_TEST'];
        if ($environment == Braintreejs::ENV_PRODUCTION) {
            $merchant_id = $config['BRAINTREE_MERCHANTID_LIVE'];
            $public_key = $config['BRAINTREE_PUBLIC_KEY_LIVE'];
            $private_key = $config['BRAINTREE_PRIVATE_KEY_LIVE'];
        }

        //verify the data is not empty
        if (empty($merchant_id) || empty($public_key) || empty($private_key))
            return false;

        Braintree_Configuration::environment($environment);
        Braintree_Configuration::merchantId($merchant_id);
        Braintree_Configuration::publicKey($public_key);
        Braintree_Configuration::privateKey($private_key);

        return true;
    }

    /**
     * Author: Chetu Team
     * Func Name: hookDisplayAdminOrderContentOrder
     * Created On: Apr 21, 2018
     * Created For: hook Display Admin Order Content
     */
    public function hookDisplayAdminOrderContentOrder($params) {
        $message = false;

        $order = $params['order'];
        $customer = $params['customer'];

        // Check if the order was paid with Braintree and display the transaction details
        if ($order->module != $this->name)
            return false;

        // Get the braintree mode.  If not found then we return since we did not use Braintree for this order, Or the database record is missing and we cannot do anything anyway
        $bt_mode = Db::getInstance()->getValue('SELECT mode FROM ' . _DB_PREFIX_ . 'braintree_transaction WHERE id_order = ' . (int) $order->id . ' AND type = \'payment\' ');
        if (!$bt_mode)
            return false;

        //continue only if Braintree settings are complete
        if (!$this->checkSettings())
            return false;

        //the environment is based on the transaction record since this is an existing transaction
        $bt_env = ($bt_mode == 'live') ? Braintreejs::ENV_PRODUCTION : Braintreejs::ENV_SANDBOX;
        $setup_ok = $this->setupBraintreeEnv($bt_env);

        if (!$setup_ok)
            return false;

        $can_refund = false;
        $can_void = false;
        $can_capture = false;
        $message_is_error = false;

        // Get the transaction details
        $braintree_transaction_details = Db::getInstance()->getRow('SELECT * FROM ' . _DB_PREFIX_ . 'braintree_transaction WHERE id_order = ' . (int) $order->id . ' AND type = \'payment\' ');

		//module is enabled or not
		$is_enabled = Module::isEnabled('emailAge');
		
        // If the "Void" button has been clicked, then attempt to void it with Braintree
        if (Tools::isSubmit('SubmitBraintreeVoid')) {
            try {
                //attempt to void
                $result = Braintree_Transaction::void($braintree_transaction_details['id_transaction']);
                $this->recordTransaction($result, $order->id, 'void');
                if($is_enabled){
					$this->changeOrderStatus($order->id, Configuration::get('EMAILAGE_ACCOUNT_VOID_ORDER_STATUS', true));
				}


                if ($result->success) {
                    //Transaction successfully voided, update original transaction to unpaid.
                    Db::getInstance()->Execute('UPDATE ' . _DB_PREFIX_ . 'braintree_transaction SET status =  \'unpaid\' WHERE id_braintree_transaction = ' . (int) $braintree_transaction_details['id_transaction']);

                    // add a negative entry to the payment table
                    $order->addOrderPayment(($order->total_paid * -1), null, $result->transaction->id);

                    //update status to error
                    $this->setCurrentOrderStateBraintree($order->id, Configuration::get('EMAILAGE_ACCOUNT_VOID_ORDER_STATUS', true), $this->context->employee->id);

                    $message = $this->l('The Void request was completed successfully');
					$this->context->cookie->__set('braintree_error', $message);
					$this->context->cookie->__set('braintree_error_mode', 0);
                } else {
                    $message = $this->l('The Capture request was NOT successful: ' . $result->message);
                    $message_is_error = true;
					$this->context->cookie->__set('braintree_error', $message);
					$this->context->cookie->__set('braintree_error_mode', 1);
                }
            } catch (Braintree_Exception $e) {
                $message = $e->getMessage();
                $message_is_error = true;
            }
			$currentPage =  (isset($_SERVER['HTTPS']) ? "https" : "http") ."://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
			Tools::redirectAdmin($currentPage);
        }

        // If the "Refund" button has been clicked, check if we can perform a partial or full refund on this order
        if (Tools::isSubmit('SubmitBraintreeRefund') && Tools::getIsset('braintree_amount_to_refund')) {
            $braintree_amount_to_refund = (float) Tools::getValue('braintree_amount_to_refund');

            try {
                if ($braintree_amount_to_refund > 0) {
                    //attempt the refund
                    $result = Braintree_Transaction::refund($braintree_transaction_details['id_transaction'], $braintree_amount_to_refund);
                    $this->recordTransaction($result, $order->id, 'refund');

                    if ($result->success) {
                        $transaction = $result->transaction;
                        $order->addOrderPayment(($braintree_amount_to_refund * -1), null, $transaction->id);

                        //update status to error
                        if ($order->total_paid_real == 0)
                            $order->setCurrentState((int) Configuration::get('PS_OS_ERROR'), $this->context->employee->id);

                        $message = $this->l('The Refund request was completed successfully');
                    }
                    else {
                        $message = $this->l('The Refund request was NOT successful: ' . $result->message);
                        $message_is_error = true;
                    }
                } else {
                    $message = $this->l('The refund amount has to exceed 0');
                    $message_is_error = true;
                }
            } catch (Braintree_Exception $e) {
                $message = $this->l('The Refund request was NOT successful: ' . $e->getMessage());
                $message_is_error = true;
            }
        }

        // If the "Capture" button has been clicked, then attempt to capture it with Braintree
        if (Tools::isSubmit('SubmitBraintreeCapture')) {
            try {
                //attempt to settle
                $result = Braintree_Transaction::submitForSettlement($braintree_transaction_details['id_transaction']);
                $this->recordTransaction($result, $order->id, 'capture');
                if($is_enabled){
					$this->changeOrderStatus($order->id, Configuration::get('EMAILAGE_ACCOUNT_CAPTURE_ORDER_STATUS', true));
				}

                if ($result->success){
                    $message = $this->l('The Capture request was completed successfully');
					$this->context->cookie->__set('braintree_error', $message);
					$this->context->cookie->__set('braintree_error_mode', 0);
                }else{
                    $message = $this->l('The Capture request was NOT successful: ' . $result->message);
					$this->context->cookie->__set('braintree_error', $message);
					$this->context->cookie->__set('braintree_error_mode', 1);
				}
            } catch (Braintree_Exception $e) {
                $message = $e->getMessage();
                $message_is_error = true;
            }
			$currentPage =  (isset($_SERVER['HTTPS']) ? "https" : "http") ."://". $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
			Tools::redirectAdmin($currentPage);
        }

        if (isset($braintree_transaction_details['id_transaction'])) {
            try {
                //check with Braintree if the transaction can be refunded
                $transaction = Braintree_Transaction::find($braintree_transaction_details['id_transaction']);
                $this->recordTransaction($transaction, $order->id, 'transaction');

                if ($transaction->status == Braintree_Transaction::SETTLED || $transaction->status == Braintree_Transaction::SETTLING) {
                    $can_refund = true;
                    $can_void = false;
                } else if ($transaction->status == Braintree_Transaction::AUTHORIZED || $transaction->status == Braintree_Transaction::SUBMITTED_FOR_SETTLEMENT) {
                    $can_refund = false;
                    $can_void = true;
                } else {
                    $can_refund = false;
                    $can_void = false;
                }

                if ($transaction->status == Braintree_Transaction::AUTHORIZED)
                    $can_capture = true;

                $refunds = array();
                $amount_refunded = 0;
                $bt_refund_amount = $transaction->amount; //this is the max amount that can be refunded
                foreach ($transaction->refundIds as $k => $id) {
                    $refund_result = Braintree_Transaction::find($id);
                    $this->recordTransaction($transaction, $order->id, 'refund_result');

                    $refund = array();
                    $refund['amount'] = $refund_result->amount;
                    $refund['currency'] = $refund_result->currencyIsoCode;
                    $refund['id_currency'] = (int) Currency::getIdByIsoCode(Tools::strtoupper($refund_result->currencyIsoCode));
                    $refund['created'] = $refund_result->createdAt;

                    $refunds[$k] = $refund;

                    $amount_refunded += $refund['amount'];
                }
                $bt_refund_amount -= $amount_refunded;
				//error mode
				if($this->context->cookie->braintree_error_mode != ''){
					$message_is_error = $this->context->cookie->braintree_error_mode;
					$message = $this->context->cookie->braintree_error;
				}
                //show the details
                $this->context->smarty->assign(array(
                    'customer' => $customer,
                    'bt_transaction' => $transaction,
                    'bt_status' => $this->convertTransactionStatus($transaction->status),
                    'bt_payment_instrument' => $this->convertInstrumentType($transaction->paymentInstrumentType),
                    'bt_amount' => Tools::displayPrice($transaction->amount),
                    'bt_mode' => $bt_mode,
                    'bt_env' => $bt_env,
                    'can_refund' => $can_refund,
                    'can_void' => $can_void,
                    'can_capture' => $can_capture,
                    'can_refund_yn' => ($can_refund ? $this->l('Yes') : $this->l('No')),
                    'can_void_yn' => ($can_void ? $this->l('Yes') : $this->l('No')),
                    'can_capture_yn' => ($can_capture ? $this->l('Yes') : $this->l('No')),
                    'bt_refund_amount' => $bt_refund_amount,
                    'refunds' => $refunds,
                    'bt_message_is_error' => $message_is_error,
                    'bt_message' => $message,
                ));
				$this->context->cookie->__set('braintree_error', '');
				$this->context->cookie->__set('braintree_error_mode', '');
                return $this->context->smarty->fetch($this->local_path . 'views/templates/admin/adminordertabcontent.tpl');
            } catch (Braintree_Exception $e) {
                $message = $e->getMessage();
                Logger::addLog($this->l('Braintree_Exception - Unable to retrieve Braintree transaction details: ') . ' ' . $message, 3, null, 'Order', (int) $order->id, true);
            }
        } 
    }

    /**
     * Author: Chetu Team
     * Func Name: processPayment
     * Created On: Apr 5, 2018
     * Created For: Process payment
     */
    public function changeOrderStatus($order_id, $order_status_admin) {
        $order = new Order($order_id);
        if (!Validate::isLoadedObject($order)) {
            $this->errors[] = $this->trans('The order cannot be found within your database.', array(), 'Admin.OrdersCustomers.Notification');
        }

        if (isset($order)) {
            $order_state = new OrderState($order_status_admin);
            if (!Validate::isLoadedObject($order_state)) {
                $this->errors[] = $this->trans('The new order status is invalid.', array(), 'Admin.OrdersCustomers.Notification');
            } else {
                $current_order_state = $order->getCurrentOrderState();

                if ($current_order_state->id != $order_state->id) {
                    // Create new OrderHistory
                    $history = new OrderHistory();
                    $history->id_order = $order->id;
                    $history->id_employee = (int) $this->context->employee->id;

                    $use_existings_payment = false;
                    if (!$order->hasInvoice()) {
                        $use_existings_payment = true;
                    }
                    $history->changeIdOrderState((int) $order_state->id, $order, $use_existings_payment);

                    $carrier = new Carrier($order->id_carrier, $order->id_lang);
                    $templateVars = array();
                    if ($history->id_order_state == Configuration::get('PS_OS_SHIPPING') && $order->shipping_number) {
                        $templateVars = array('{followup}' => str_replace('@', $order->shipping_number, $carrier->url));
                    }

                    // Save all changes
                    if ($history->addWithemail(true, $templateVars)) {
                        // synchronizes quantities if needed..
                        if (Configuration::get('PS_ADVANCED_STOCK_MANAGEMENT')) {
                            foreach ($order->getProducts() as $product) {
                                if (StockAvailable::dependsOnStock($product['product_id'])) {
                                    StockAvailable::synchronize($product['product_id'], (int) $product['id_shop']);
                                }
                            }
                        }
                    }
                    $this->errors[] = $this->trans('An error occurred while changing order status, or we were unable to send an email to the customer.', array(), 'Admin.OrdersCustomers.Notification');
                } else {
                    $this->errors[] = $this->trans('The order has already been assigned this status.', array(), 'Admin.OrdersCustomers.Notification');
                }
            }

        }
    }
	
	/**
     * Author: Chetu Team
     * Func Name: setCurrentOrderStateBraintree
     * Created On: May 17, 2018
     * Created For: set Current Order State from Braintree
     */
    public function setCurrentOrderStateBraintree($id_order, $id_order_state, $id_employee = 0)
    {
        if (empty($id_order_state)) {
           return false;
        }
        $order = new Order($id_order);
        $order->current_state = $id_order_state;
        $order->update();
    }

}
