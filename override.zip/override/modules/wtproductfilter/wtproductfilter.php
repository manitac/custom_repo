<?php

/**
 * WTProductFilter
 * overrining WTProductFilter php file
 */

class WTProductFilterOverride extends WTProductFilter {

    /**
     * Author: Chetu Team
     * Func Name: getViewAllLink
     * Created On: Feb 1, 2018
     * Created For: Returns View All Link
     */
    public function getViewAllLink($type_tab) {
        $nb = Configuration::get('NUM_PRO_DISPLAY');
        $id_lang = (int) Context::getContext()->language->id;
        if (strpos($type_tab, 'featured_products') !== false) {
            $link = new Link();
            $this->view_link = $link->getCategoryLink(2);
        } elseif (strpos($type_tab, 'special_products') !== false) {
			$link = new Link();
            $this->view_link = $link->getPageLink('prices-drop', true);
        } elseif (strpos($type_tab, 'topseller_products') !== false) {
            $link = new Link();
            $this->view_link = $link->getPageLink('best-sales', true);
        } elseif (strpos($type_tab, 'new_products') !== false) {
            $link = new Link();
            $this->view_link = $link->getPageLink('new-products', true);
        } elseif (strpos($type_tab, 'choose_the_category') !== false) {
            $id_cat = Tools::substr(strrchr($type_tab, "_"), 1);
            $link = new Link();
            $this->view_link = $link->getCategoryLink((int) $id_cat);
        }
        return $this->view_link;
    }
	
	/**
     * Author: Chetu Team
     * Func Name: getCacheDirectory
     * Created On: Mar 19, 2018
     * Created For: get cache directory
     */
	protected function getCacheDirectory()
	{
		return _PS_CACHE_DIR_ . '/smarty/cache'.str_replace('|','/',$this->getCacheId()).'/';
	}

	/**
     * Author: Chetu Team
     * Func Name: clearWTProductFilterCache
     * Created On: Mar 19, 2018
     * Created For: clear WTProduct Filter Cache
     */
	protected function clearWTProductFilterCache()
	{
		$dir = $this->getCacheDirectory();
		if (!is_dir($dir)) {
			return;
		}else{
			$this->removeDirectory($dir);
		}
	}

	/**
     * Author: Chetu Team
     * Func Name: removeDirectory
     * Created On: Mar 19, 2018
     * Created For: remove Directory
     */
	protected function removeDirectory($dirPath) {
		if (! is_dir($dirPath)) {
			return false;
		}

		if (substr($dirPath, strlen($dirPath) - 1, 1) != '/') {
			$dirPath .= '/';
		}
		if ($handle = opendir($dirPath)) {

			while (false !== ($sub = readdir($handle))) {
				if ($sub != "." && $sub != ".." && $sub != "Thumb.db") {
					$file = $dirPath . $sub;
					if (is_dir($file)) {
						$this->removeDirectory($file);
					} else {
						unlink($file);
					}
				}
			}
			closedir($handle);
		}
		rmdir($dirPath);
	}
	
	/**
     * Author: Chetu Team
     * Func Name: renderWidget
     * Created On: Mar 19, 2018
     * Created For: render Widget
     */
	public function renderWidget($hookName = null, array $configuration = [])
	{
		$this->clearWTProductFilterCache();    
		if ($this->context->controller->php_self == 'index')
		{
			$this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
			return $this->fetch('module:'.$this->name.'/views/templates/hook/'.$this->name.'.tpl', $this->getCacheId());
		}
			
	}
	
	/**
     * Author: Chetu Team
     * Func Name: getProductsAjax
     * Created On: Mar 19, 2018
     * Created For: Get Products Ajax
     */
	public function getProductsAjax($type_tab)
	{
		$nb = Configuration::get('NUM_PRO_DISPLAY');
		$id_lang = (int)Context::getContext()->language->id;
		if (strpos($type_tab, 'featured_products') !== false)
		{
			$category = new Category(Context::getContext()->shop->getCategory(), (int)Context::getContext()->language->id);
			$this->product_list = $category->getProducts($id_lang, 1, $nb);
		}
		elseif (strpos($type_tab, 'special_products') !== false)
		{
			$this->product_list = Product::getPricesDrop($id_lang, 0, $nb);	
		}
		elseif (strpos($type_tab, 'topseller_products') !== false)
		{
			$this->product_list = ProductSale::getBestSalesLight($id_lang, 0, $nb); 
		}
		elseif (strpos($type_tab, 'new_products') !== false)
		{
			$this->product_list = Product::getNewProducts($id_lang, 0, $nb);
			shuffle($this->product_list);
		}
		elseif (strpos($type_tab, 'choose_the_category') !== false)
		{
			$id_cat = Tools::substr(strrchr($type_tab, "_"), 1);
			$category = new Category((int)$id_cat, $id_lang);
			$this->product_list = $category->getProducts($id_lang, 1, $nb, 'date_upd', 'DESC');
			$this->cat_desc = $category->description;
		}
		return $this->product_list;
	}

}
?>
