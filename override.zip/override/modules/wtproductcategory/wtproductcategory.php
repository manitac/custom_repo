<?php
/**
 * WTProductCategory
 * overriding WTProductCategory php file
 */
class WtproductcategoryOverride extends Wtproductcategory
{
	 /**
     * Author: Chetu Team
     * Func Name: hookDisplayHome
     * Created On: Feb 1, 2018
     * Created For: set home template
     */
	public function clearCacheProdCat()
	{
		$this->_clearCache('wtproductcategory_bottomhome.tpl');
		$this->_clearCache('wtproductcategory_tophome.tpl');
		$this->_clearCache('wtproductcategory_topcolumn.tpl');
		$this->_clearCache('wtproductcategory_home.tpl');
	}
	
	/**
     * Author: Chetu Team
     * Func Name: getSubCategoriesWithProducts
     * Created On: Mar 1, 2018
     * Created For: Set sub categories with products
     */
	public function getSubCategoriesWithProducts($cat_prod_sub_cat, $number_prod)
	{
		$categoryArray = array();
		$id_lang = $this->context->language->id;
		$i = 0;
		foreach ($cat_prod_sub_cat as $cat_prod)
		{
			$id_cat = $cat_prod['id_category'];
			$category = new Category($id_cat, $id_lang);
			$product_list = $category->getProducts($id_lang, 1, $number_prod, 'date_upd', 'DESC');
			if(count($product_list) > 0){
				$categoryArray[$i] = $cat_prod;
			}
			$i++;
		}
		return $categoryArray;
	}
	
	/**
     * Author: Chetu Team
     * Func Name: prevHook
     * Created On: Mar 1, 2018
     * Created For: Execute Prev Hook
     */
	public function prevHook($hook_name)
	{
		$id_lang = $this->context->language->id;
		$group_cat_result = array();
		$group_cat = new WtGroupCategoryClass();
		$group_cat_hook = $group_cat->getGroupCatByHook($hook_name);
		foreach ($group_cat_hook as $group_cat)
		{
			$number_prod = $group_cat['num_show'];
			$cat_prod = new WtCategoryClass();
			$cat_prod_group = $cat_prod->getCatByGroupId($group_cat['id_wtgroupcategory']);
			$cat_prod_result = array();
			foreach ($cat_prod_group as $cat_prod)
			{
				
				$id_cat = $cat_prod['id_cat'];
				$category = new Category($id_cat, $id_lang);
				$product_list = $category->getProducts($id_lang, 1, $number_prod, 'date_upd', 'DESC');
				$cat_prod['product_list'] = $product_list;
				$cat_prod['cat_name'] = $category->name;
				$cat_prod['number_prod'] = $number_prod;
				$cat_prod['id_image'] = $category->id_image;
				$cat_prod['link_rewrite'] = $category->link_rewrite;
				$cat_prod_sub_cat = $category->getSubCategories($id_lang);
				$cat_prod['sub_cat'] = $this->getSubCategoriesWithProducts($cat_prod_sub_cat, $number_prod);
				$temp = $cat_prod['cat_desc'];
				$temp_url = '{wt_cat_url}';
				$cat_prod['cat_desc'] = str_replace($temp_url, _PS_BASE_URL_.__PS_BASE_URI__, $temp);
				$manu_ids = Tools::jsonDecode($cat_prod['manufacture']);
				$manu_arr = array();
				if (is_array($manu_ids) && count($manu_ids) > 0)
				{
					foreach ($manu_ids as $manu_item)
						$manu_arr[] = new Manufacturer($manu_item, $id_lang);
				}
				$cat_prod['manufacture'] = $manu_arr;
				
				$id_prod = (int)$cat_prod['special_prod'];
				if (isset($id_prod) && $id_prod > 0)
				{
					$product = new Product($id_prod);
					if ($product->active)
					{
						$product->id_image = $product->getCoverWs();
						$cat_prod['special_prod_obj'] = $product;
					}
				}
				
				if(count($product_list) > 0){
					$cat_prod_result[] = $cat_prod;
				}
			}
			$group_cat['cat_info'] = $cat_prod_result;
			$group_cat_result[] = $group_cat;
		}
		return $group_cat_result;
	}

}