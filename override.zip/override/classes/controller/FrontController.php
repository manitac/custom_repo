<?php
/**
 * FrontControllerCore
 * overriding FrontControllerCore php file
 */
class FrontController extends FrontControllerCore
{
	/**
     * Author: Chetu Team
     * Func Name: getLayout
     * Created On: May 3, 2018
     * Created For: getLayout
     */
    public function getLayout()
    {
        $entity = $this->php_self;
        if (empty($entity)) {
            $entity = $this->getPageName();
        }

        $layout = $this->context->shop->theme->getLayoutRelativePathForPage($entity);

		//code to show left sidebar for supplier and search page
		if($entity == 'search' || $entity == 'supplier') {
			$layout = 'layouts/layout-left-column.tpl';
		}
		
        if ($overridden_layout = Hook::exec(
            'overrideLayoutTemplate',
            array(
                'default_layout' => $layout,
                'entity' => $entity,
                'locale' => $this->context->language->locale,
                'controller' => $this,
            )
        )) {
            return $overridden_layout;
        }

        if ((int) Tools::getValue('content_only')) {
            $layout = 'layouts/layout-content-only.tpl';
        }

        return $layout;
    }
}
