<?php

/**
 * overriding Class Product
 */
class Product extends ProductCore {

    /**
     * Author: Chetu Development Team
     * Func Name: getPricesDrop
     * Created On: Jan 12, 2017
     * Created For: Overrided to show discounted product at home page.   
     */
    public static function getPricesDrop($id_lang, $page_number = 0, $nb_products = 10, $count = false, $order_by = null, $order_way = null, $beginning = false, $ending = false, Context $context = null) {
        if (!Validate::isBool($count)) {
            die(Tools::displayError());
        }

        if (!$context) {
            $context = Context::getContext();
        }
        if ($page_number < 1) {
            $page_number = 1;
        }
        if ($nb_products < 1) {
            $nb_products = 10;
        }
        if (empty($order_by) || $order_by == 'position') {
            $order_by = 'price';
        }
        if (empty($order_way)) {
            $order_way = 'DESC';
        }
        if ($order_by == 'id_product' || $order_by == 'price' || $order_by == 'date_add' || $order_by == 'date_upd') {
            $order_by_prefix = 'product_shop';
        } elseif ($order_by == 'name') {
            $order_by_prefix = 'pl';
        }
        if (!Validate::isOrderBy($order_by) || !Validate::isOrderWay($order_way)) {
            die(Tools::displayError());
        }
        $current_date = date('Y-m-d H:i:00');
        $ids_product = Product::_getProductIdByDate((!$beginning ? $current_date : $beginning), (!$ending ? $current_date : $ending), $context);

        $tab_id_product = array();
        foreach ($ids_product as $product) {
            if (is_array($product)) {
                $tab_id_product[] = (int) $product['id_product'];
            } else {
                $tab_id_product[] = (int) $product;
            }
        }

        $front = true;
        if (!in_array($context->controller->controller_type, array('front', 'modulefront'))) {
            $front = false;
        }

        $sql_groups = '';
        if (Group::isFeatureActive()) {
            $groups = FrontController::getCurrentCustomerGroups();
            $sql_groups = ' AND EXISTS(SELECT 1 FROM `' . _DB_PREFIX_ . 'category_product` cp
                JOIN `' . _DB_PREFIX_ . 'category_group` cg ON (cp.id_category = cg.id_category AND cg.`id_group` ' . (count($groups) ? 'IN (' . implode(',', $groups) . ')' : '= 1') . ')
                WHERE cp.`id_product` = p.`id_product`)';
        }

        if ($count) {
            return Db::getInstance(_PS_USE_SQL_SLAVE_)->getValue('
            SELECT COUNT(DISTINCT p.`id_product`)
            FROM `' . _DB_PREFIX_ . 'product` p
            ' . Shop::addSqlAssociation('product', 'p') . '
            WHERE product_shop.`active` = 1
            AND product_shop.`show_price` = 1
            ' . ($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '') . '
            ' . ((!$beginning && !$ending) ? 'AND p.`id_product` IN(' . ((is_array($tab_id_product) && count($tab_id_product)) ? implode(', ', $tab_id_product) : 0) . ')' : '') . '
            ' . $sql_groups);
        }

        if (strpos($order_by, '.') > 0) {
            $order_by = explode('.', $order_by);
            $order_by = pSQL($order_by[0]) . '.`' . pSQL($order_by[1]) . '`';
        }

        $sql = '
        SELECT
            p.*, product_shop.*, stock.out_of_stock, IFNULL(stock.quantity, 0) as quantity, pl.`description`, pl.`description_short`, pl.`available_now`, pl.`available_later`,
            IFNULL(product_attribute_shop.id_product_attribute, 0) id_product_attribute,
            pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`,
            pl.`name`, image_shop.`id_image` id_image, il.`legend`, m.`name` AS manufacturer_name,
            DATEDIFF(
                p.`date_add`,
                DATE_SUB(
                    "' . date('Y-m-d') . ' 00:00:00",
                    INTERVAL ' . (Validate::isUnsignedInt(Configuration::get('PS_NB_DAYS_NEW_PRODUCT')) ? Configuration::get('PS_NB_DAYS_NEW_PRODUCT') : 20) . ' DAY
                )
            ) > 0 AS new
        FROM `' . _DB_PREFIX_ . 'product` p
        ' . Shop::addSqlAssociation('product', 'p') . '
        LEFT JOIN `' . _DB_PREFIX_ . 'product_attribute_shop` product_attribute_shop
            ON (p.`id_product` = product_attribute_shop.`id_product` AND product_attribute_shop.`default_on` = 1 AND product_attribute_shop.id_shop=' . (int) $context->shop->id . ')
        ' . Product::sqlStock('p', 0, false, $context->shop) . '
        LEFT JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (
            p.`id_product` = pl.`id_product`
            AND pl.`id_lang` = ' . (int) $id_lang . Shop::addSqlRestrictionOnLang('pl') . '
        )
        LEFT JOIN `' . _DB_PREFIX_ . 'image_shop` image_shop
            ON (image_shop.`id_product` = p.`id_product` AND image_shop.cover=1 AND image_shop.id_shop=' . (int) $context->shop->id . ')
        LEFT JOIN `' . _DB_PREFIX_ . 'image_lang` il ON (image_shop.`id_image` = il.`id_image` AND il.`id_lang` = ' . (int) $id_lang . ')
        LEFT JOIN `' . _DB_PREFIX_ . 'manufacturer` m ON (m.`id_manufacturer` = p.`id_manufacturer`)
        WHERE product_shop.`active` = 1
        AND product_shop.`show_price` = 1
        ' . ($front ? ' AND product_shop.`visibility` IN ("both", "catalog")' : '') . ' AND SUBSTR(ROUND(p.price,2), -1) IN (4,5,6,7,8)
        ' . $sql_groups . '
        ORDER BY rand(), ' . (isset($order_by_prefix) ? pSQL($order_by_prefix) . '.' : '') . pSQL($order_by) . ' ' . pSQL($order_way) . '
        LIMIT ' . (int) (($page_number - 1) * $nb_products) . ', ' . (int) $nb_products;

        $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);

        if (!$result) {
            return false;
        }

        if ($order_by == 'price') {
            Tools::orderbyPrice($result, $order_way);
        }
        //Sale price calculation
        $products_infos = array();
        foreach ($result as $pd) {
            //Sale price calculation
            $pd['discounted_sale_price'] = '';
            if (substr(number_format($pd['price'], 2), -1) == 8) {
                $pd['discounted_sale_price'] = number_format(($pd['price'] / 0.9), 2);
            } elseif (substr(number_format($pd['price'], 2), -1) == 7) {
                $pd['discounted_sale_price'] = number_format(($pd['price'] / 0.8), 2);
            } elseif (substr(number_format($pd['price'], 2), -1) == 6) {
                $pd['discounted_sale_price'] = number_format(($pd['price'] / 0.7), 2);
            } elseif (substr(number_format($pd['price'], 2), -1) == 5) {
                $pd['discounted_sale_price'] = number_format(($pd['price'] / 0.6), 2);
            } elseif (substr(number_format($pd['price'], 2), -1) == 4) {
                $pd['discounted_sale_price'] = number_format(($pd['price'] / 0.5), 2);
            }
            $products_infos[] = $pd;
        }

        return Product::getProductsProperties($id_lang, $products_infos);
    }

    /*
     * module: amazzingfilter
     * date: 2017-03-03 10:12:22
     * version: 2.5.3
     */

    public static function getNewProducts(
    $id_lang, $page_number = 0, $nb_products = 10, $count = false, $order_by = null, $order_way = null, Context $context = null
    ) {
        if (!$context) {
            $context = Context::getContext();
        }
        if (isset($context->filtered_result) && $context->filtered_result['controller'] == 'newproducts') {
            if ($count) {
                return $context->filtered_result['total'];
            }
            return $context->filtered_result['products'];
        } else {
            return parent::getNewProducts(
                            $id_lang, $page_number, $nb_products, $count, $order_by, $order_way, $context
            );
        }
    }

    /**
     * Author: Chetu Development Team
     * Func Name: getProductProperties
     * Created On: Feb 14, 2018
     * Created For: Overrided to Supplier name and discounted sale price added.   
     */
    public static function getProductProperties($id_lang, $row, Context $context = null) {
        Hook::exec('actionGetProductPropertiesBefore', [
            'id_lang' => $id_lang,
            'product' => $row,
            'context' => $context
        ]);

        if (!$row['id_product']) {
            return false;
        }

        if ($context == null) {
            $context = Context::getContext();
        }


        $id_product_attribute = $row['id_product_attribute'] = (!empty($row['id_product_attribute']) ? (int) $row['id_product_attribute'] : null);

        // Product::getDefaultAttribute is only called if id_product_attribute is missing from the SQL query at the origin of it:
        // consider adding it in order to avoid unnecessary queries
        $row['allow_oosp'] = Product::isAvailableWhenOutOfStock($row['out_of_stock']);
        if (Combination::isFeatureActive() && $id_product_attribute === null && ((isset($row['cache_default_attribute']) && ($ipa_default = $row['cache_default_attribute']) !== null) || ($ipa_default = Product::getDefaultAttribute($row['id_product'], !$row['allow_oosp'])))) {
            $id_product_attribute = $row['id_product_attribute'] = $ipa_default;
        }
        if (!Combination::isFeatureActive() || !isset($row['id_product_attribute'])) {
            $id_product_attribute = $row['id_product_attribute'] = 0;
        }

        // Tax
        $usetax = !Tax::excludeTaxeOption();

        $cache_key = $row['id_product'] . '-' . $id_product_attribute . '-' . $id_lang . '-' . (int) $usetax;
        if (isset($row['id_product_pack'])) {
            $cache_key .= '-pack' . $row['id_product_pack'];
        }

        if (isset(self::$producPropertiesCache[$cache_key])) {
            return array_merge($row, self::$producPropertiesCache[$cache_key]);
        }

        // Datas
        $row['category'] = Category::getLinkRewrite((int) $row['id_category_default'], (int) $id_lang);
        $row['category_name'] = Db::getInstance()->getValue('SELECT name FROM ' . _DB_PREFIX_ . 'category_lang WHERE id_shop = ' . (int) $context->shop->id . ' AND id_lang = ' . (int) $id_lang . ' AND id_category = ' . (int) $row['id_category_default']);
        $row['link'] = $context->link->getProductLink((int) $row['id_product'], $row['link_rewrite'], $row['category'], $row['ean13']);

        $row['attribute_price'] = 0;
        if ($id_product_attribute) {
            $row['attribute_price'] = (float) Combination::getPrice($id_product_attribute);
        }

        if (isset($row['quantity_wanted'])) {
            // 'quantity_wanted' may very well be zero even if set
            $quantity = max((int) $row['minimal_quantity'], (int) $row['quantity_wanted']);
        } else {
            $quantity = (int) $row['minimal_quantity'];
        }

        $row['price_tax_exc'] = Product::getPriceStatic(
                        (int) $row['id_product'], false, $id_product_attribute, (self::$_taxCalculationMethod == PS_TAX_EXC ? 2 : 6), null, false, true, $quantity
        );

        if (self::$_taxCalculationMethod == PS_TAX_EXC) {
            $row['price_tax_exc'] = Tools::ps_round($row['price_tax_exc'], 2);
            /*$row['price'] = Product::getPriceStatic(
                            (int) $row['id_product'], true, $id_product_attribute, 6, null, false, true, $quantity
            );*/
            $row['price_without_reduction'] = Product::getPriceStatic(
                            (int) $row['id_product'], false, $id_product_attribute, 2, null, false, false, $quantity
            );
        } else {
           /* $row['price'] = Tools::ps_round(
                            Product::getPriceStatic(
                                    (int) $row['id_product'], true, $id_product_attribute, 6, null, false, true, $quantity
                            ), (int) Configuration::get('PS_PRICE_DISPLAY_PRECISION')
            );*/
            $row['price_without_reduction'] = Product::getPriceStatic(
                            (int) $row['id_product'], true, $id_product_attribute, 6, null, false, false, $quantity
            );
        }

        $row['reduction'] = Product::getPriceStatic(
                        (int) $row['id_product'], (bool) $usetax, $id_product_attribute, 6, null, true, true, $quantity, true, null, null, null, $specific_prices
        );

        $row['specific_prices'] = $specific_prices;

        $row['quantity'] = Product::getQuantity(
                        (int) $row['id_product'], 0, isset($row['cache_is_pack']) ? $row['cache_is_pack'] : null
        );

        $row['quantity_all_versions'] = $row['quantity'];

        if ($row['id_product_attribute']) {
            $row['quantity'] = Product::getQuantity(
                            (int) $row['id_product'], $id_product_attribute, isset($row['cache_is_pack']) ? $row['cache_is_pack'] : null
            );

            $row['available_date'] = Product::getAvailableDate(
                            (int) $row['id_product'], $id_product_attribute
            );
        }

        $row['id_image'] = Product::defineProductImage($row, $id_lang);
        $row['features'] = Product::getFrontFeaturesStatic((int) $id_lang, $row['id_product']);

        $row['attachments'] = array();
        if (!isset($row['cache_has_attachments']) || $row['cache_has_attachments']) {
            $row['attachments'] = Product::getAttachmentsStatic((int) $id_lang, $row['id_product']);
        }

        $row['virtual'] = ((!isset($row['is_virtual']) || $row['is_virtual']) ? 1 : 0);

        // Pack management
        $row['pack'] = (!isset($row['cache_is_pack']) ? Pack::isPack($row['id_product']) : (int) $row['cache_is_pack']);
        $row['packItems'] = $row['pack'] ? Pack::getItemTable($row['id_product'], $id_lang) : array();
        $row['nopackprice'] = $row['pack'] ? Pack::noPackPrice($row['id_product']) : 0;
        if ($row['pack'] && !Pack::isInStock($row['id_product'])) {
            $row['quantity'] = 0;
        }

        $row['customization_required'] = false;
        if (isset($row['customizable']) && $row['customizable'] && Customization::isFeatureActive()) {
            if (count(Product::getRequiredCustomizableFieldsStatic((int) $row['id_product']))) {
                $row['customization_required'] = true;
            }
        }

        $attributes = Product::getAttributesParams($row['id_product'], $row['id_product_attribute']);

        foreach ($attributes as $attribute) {
            $row['attributes'][$attribute['id_attribute_group']] = $attribute;
        }

        $row = Product::getTaxesInformations($row, $context);

        $row['ecotax_rate'] = (float) Tax::getProductEcotaxRate($context->cart->{Configuration::get('PS_TAX_ADDRESS_TYPE')});

        Hook::exec('actionGetProductPropertiesAfter', [
            'id_lang' => $id_lang,
            'product' => $row,
            'context' => $context
        ]);

        $combination = new Combination($id_product_attribute);

        if (0 != $combination->unit_price_impact && 0 != $row['unit_price_ratio']) {
            $unitPrice = ($row['price_tax_exc'] / $row['unit_price_ratio']) + $combination->unit_price_impact;
            $row['unit_price_ratio'] = $row['price_tax_exc'] / $unitPrice;
        }

        $row['unit_price'] = ($row['unit_price_ratio'] != 0 ? $row['price'] / $row['unit_price_ratio'] : 0);
        if (isset($row['discounted_sale_price'])) {
            unset($row['discounted_sale_price']);
        }
        if (isset($row['supplier_name'])) {
            unset($row['supplier_name']);
        }

        $row['discounted_sale_price'] = '';
        if (substr(number_format($row['price'], 2), -1) == 8) {
            $row['discounted_sale_price'] = number_format(($row['price'] / 0.9), 2);
        } else if (substr(number_format($row['price'], 2), -1) == 7) {
            $row['discounted_sale_price'] = number_format(($row['price'] / 0.8), 2);
        } else if (substr(number_format($row['price'], 2), -1) == 6) {
            $row['discounted_sale_price'] = number_format(($row['price'] / 0.7), 2);
        } else if (substr(number_format($row['price'], 2), -1) == 5) {
            $row['discounted_sale_price'] = number_format(($row['price'] / 0.6), 2);
        } else if (substr(number_format($row['price'], 2), -1) == 4) {
            $row['discounted_sale_price'] = number_format(($row['price'] / 0.5), 2);
        }
        $row['supplier_name'] = Db::getInstance()->getValue('SELECT name FROM ' . _DB_PREFIX_ . 'supplier WHERE id_supplier = ' . (int) $row['id_supplier']);

        /*         * ****************pickup and shipping ****************** */
        $carriers = array();
        $carriers = Product::getCarriersId((int) $row['id_product'], (int) $context->shop->id);

        $row['instore_pickup'] = "";
        $row['ship'] = "";

        foreach ($carriers as $carrier) {
            if ($carrier['id_carrier'] == Configuration::get('PS_BUYNOW_CARRIER')) {
                $row['instore_pickup'] = "yes";
            }
            if ($carrier['id_carrier'] == Configuration::get('PS_SHIP_CARRIER')) {
                $row['ship'] = "yes";
            }
        }


        /*         * ****************pickup and shipping ****************** */
        self::$producPropertiesCache[$cache_key] = $row;
        return self::$producPropertiesCache[$cache_key];
    }

    /**
     * Author: Chetu Development Team
     * Func Name: getCarriersId
     * Created On: Feb 14, 2018
     * Created For: Overrided to show discounted product at home page.   
     */
    public static function getCarriersId($product_id, $shop_id) {
        return Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS('
            SELECT c.`id_carrier`
            FROM `' . _DB_PREFIX_ . 'product_carrier` pc
            INNER JOIN `' . _DB_PREFIX_ . 'carrier` c
                ON (c.`id_reference` = pc.`id_carrier_reference` AND c.`deleted` = 0)
            WHERE pc.`id_product` = ' . $product_id . '
                AND pc.`id_shop` = ' . $shop_id);
    }

    /**
     * Author: Chetu Development Team
     * Func Name: updateWs
     * Created On: Apr 06, 2018
     * Created For: webserviceParameters   
     */
    public function updateWsqqqq($null_values = false) {
        if (is_null($this->price)) {
            $this->price = Product::getPriceStatic((int) $this->id, false, null, 6, null, false, true, 1, false, null, null, null, $this->specificPrice);
        }

        if (is_null($this->unit_price)) {
            $this->unit_price = ($this->unit_price_ratio != 0 ? $this->price / $this->unit_price_ratio : 0);
        }

        $success = parent::update($null_values);
        if ($success && Configuration::get('PS_SEARCH_INDEXATION')) {
            Search::indexation(false, $this->id);
        }
        Hook::exec('updateProduct', array('id_product' => (int) $this->id));
        Hook::exec('actionProductSave', array('id_product' => (int) $this->id, 'product' => $this));

        return $success;
    }

}
