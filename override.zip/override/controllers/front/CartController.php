<?php
/**
 * CartControllerCore
 * overriding CartControllerCore php file
 */
use PrestaShop\PrestaShop\Adapter\Cart\CartPresenter;

class CartController extends CartControllerCore
{
     /**
     * Author: Chetu Team
     * Func Name: initContent
     * Created On: Feb 14, 2018
     * Created For: initContent
     */
    public function initContent()
    {
        if (Configuration::isCatalogMode() && Tools::getValue('action') === 'show' ) {
            Tools::redirect('index.php');
        }

        parent::initContent();

        $presenter = new CartPresenter();
        $presented_cart = $presenter->present($this->context->cart, $shouldSeparateGifts = true);
        $instore_pickup = 0;
        $ship = 0;
        foreach ($presented_cart['products'] as $p) {
            $carriers = Product::getCarriersId((int)$p['id_product'], $this->context->shop->id);
            foreach($carriers as $carrier){
                if($carrier['id_carrier'] == 30){
                    $instore_pickup = $instore_pickup + 1;
                }
                if($carrier['id_carrier'] == 32){
                    $ship  = $ship+1;
                }
            }
        }
        $presented_cart['instore_pickup'] = $instore_pickup;
        $presented_cart['ship'] = $ship;

        $this->context->smarty->assign([
            'cart' => $presented_cart,
            'static_token' => Tools::getToken(false),
        ]);

        if (count($presented_cart['products']) > 0) {
            $this->setTemplate('checkout/cart');
        } else {
            $this->context->smarty->assign([
                'allProductsLink' => $this->context->link->getCategoryLink(Configuration::get('PS_HOME_CATEGORY')),
            ]);
            $this->setTemplate('checkout/cart-empty');
        }
    }
    /**
     * Author: Chetu Team
     * Func Name: postProcess
     * Created On: May 17, 2018
     * Created For: adding warranty function call
     */
    public function postProcess()
    {
        $this->updateCart();
        $is_enabled = Module::isEnabled('cps_warranty_orders');
        if($is_enabled && Tools::getValue('id_product') && Tools::getValue('warranty_product_id') && Tools::getValue('warranty_attr_id')) {
            $this->warrantyPro();
        }
    }
    /**
     * Author: Chetu Team
     * Func Name: updateCart
     * Created On: May 19, 2018
     * Created For: adding functionality for deleting warranty automatically when associated product is deleted.
     */
    protected function updateCart()
    {
        // Update the cart ONLY if $this->cookies are available, in order to avoid ghost carts created by bots
        if ($this->context->cookie->exists() && !$this->errors && !($this->context->customer->isLogged() && !$this->isTokenValid())) {
            if (Tools::getIsset('add') || Tools::getIsset('update')) {
                $this->processChangeProductInCart();
            } elseif (Tools::getIsset('delete')) {

                $this->processDeleteProductInCart();
                $is_enabled = Module::isEnabled('cps_warranty_orders');
                if ($is_enabled){
                     $this->warrantyProDelete();
                 }

            } elseif (CartRule::isFeatureActive()) {
                if (Tools::getIsset('addDiscount')) {
                    if (!($code = trim(Tools::getValue('discount_name')))) {
                        $this->errors[] = $this->trans('You must enter a voucher code.', array(), 'Shop.Notifications.Error');
                    } elseif (!Validate::isCleanHtml($code)) {
                        $this->errors[] = $this->trans('The voucher code is invalid.', array(), 'Shop.Notifications.Error');
                    } else {
                        if (($cartRule = new CartRule(CartRule::getIdByCode($code))) && Validate::isLoadedObject($cartRule)) {
                            if ($error = $cartRule->checkValidity($this->context, false, true)) {
                                $this->errors[] = $error;
                            } else {
                                $this->context->cart->addCartRule($cartRule->id);
                            }
                        } else {
                            $this->errors[] = Tools::displayError('This voucher does not exists.');
                        }
                    }
                } elseif (($id_cart_rule = (int)Tools::getValue('deleteDiscount')) && Validate::isUnsignedId($id_cart_rule)) {
                    $this->context->cart->removeCartRule($id_cart_rule);
                    CartRule::autoAddToCart($this->context);
                }
            }
        } elseif (!$this->isTokenValid() && Tools::getValue('action') !== 'show' && !Tools::getValue('ajax')) {
            Tools::redirect('index.php');
        }
    }
    /**
     * Author: Chetu Team
     * Func Name: postProcess
     * Created On: May 17, 2018
     * Created For: adding warranty function
     */

    public function warrantyPro(){

        $product_id = Tools::getValue('id_product');
        $warranty_product_id = Tools::getValue('warranty_product_id');
        $warranty_attr_id = Tools::getValue('warranty_attr_id');
        $cart_id = (int)$this->context->cart->id;
        $sql = 'INSERT INTO `'._DB_PREFIX_.'cps_warranty_sku_info` (`id_cart`, `id_product`,`id_warranty_product`, `id_warranty_sku`) VALUES ('.$cart_id.','.$product_id.', '.$warranty_product_id.','.$warranty_attr_id.')';
        Db::getInstance()->execute($sql);
        
    }
    /**
     * Author: Chetu Team
     * Func Name: warrantyProDelete
     * Created On: May 19, 2018
     * Created For: adding functionality for deleting warranty automatically when associated product is deleted.
     */
    
    public function warrantyProDelete()
    {
        $warranty_pro_ids = explode(",",Configuration::get('PS_WARRANTY_IDS'));
        $current_product[] =$this->id_product;
        $warranty_pro = array_intersect($warranty_pro_ids,$current_product);

        if( count($warranty_pro) > 0){
            //warranty product is deleted from cart and here deleting the entry of product in  cps_warranty_sku_info table

            $id_warranty_sku = Db::getInstance()->executeS('SELECT `id_attribute` FROM `'._DB_PREFIX_.'product_attribute_combination` WHERE `id_product_attribute` = '.$this->id_product_attribute);
            if (count($id_warranty_sku)) {
                $id_warranty_sku = $id_warranty_sku[0]['id_attribute'];
                Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'cps_warranty_sku_info`
                            WHERE `id_cart` = '.(int)$this->context->cart->id.'
                            AND `id_warranty_product` = '.(int)$this->id_product.'
                            AND `id_warranty_sku` = '.$id_warranty_sku) ;
            }

        }else{

            // deleting the associated warranty product from cart if product having this warranty is deleted.

            $warranty_associated = Db::getInstance()->executeS('SELECT * FROM `'._DB_PREFIX_.'cps_warranty_sku_info`
            WHERE `id_cart` = '.(int)$this->context->cart->id.' AND `id_product` = '.(int)$this->id_product);

            if (count($warranty_associated)) {
                
                foreach ($warranty_associated as $product) {
                    $id_cart = (int)$this->context->cart->id;
                    $id_product = $product['id_warranty_product'];

                    $result = Db::getInstance()->executeS('SELECT `id_product_attribute` FROM `'._DB_PREFIX_.'product_attribute_combination` WHERE `id_attribute` = '.$product['id_warranty_sku']);
                    if (count($result)) {
                       
                        $id_product_attribute = $result[0]['id_product_attribute'];
                        $result = Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'cart_product`
                                    WHERE `id_cart` = '.$id_cart.'
                                    AND `id_product` = '.$id_product.'
                                    AND `id_product_attribute` = '.$id_product_attribute) ;

                        if ($result) {
                               
                               // deleting the product record from  ps_cps_warranty_sku_info table when product is deleted form cart.
                                Db::getInstance()->execute('DELETE FROM `'._DB_PREFIX_.'cps_warranty_sku_info`
                                    WHERE `id_cart` = '.(int)$this->context->cart->id.'
                                    AND `id_product` = '.(int)$this->id_product ) ;
                        }
                    }
                }
            }
        }
    }
}
