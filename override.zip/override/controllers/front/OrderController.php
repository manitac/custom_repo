<?php

/**
 * OrderController
 * overriding OrderController php file
 */
use PrestaShop\PrestaShop\Core\Foundation\Templating\RenderableProxy;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;

class OrderController extends OrderControllerCore {

    public $ssl = true;
    public $php_self = 'order';
    public $page_name = 'checkout';
    protected $checkoutProcess;

	/**
     * Author: Chetu Team
     * Func Name: init
     * Created On: Feb 14, 2018
     * Created For: init
     */
    public function init() {
        parent::init();
        $this->cartChecksum = new CartChecksum(new AddressChecksum());
    }

	/**
     * Author: Chetu Team
     * Func Name: postProcess
     * Created On: Feb 14, 2018
     * Created For: postProcess
     */
    public function postProcess() {
        parent::postProcess();

        if (Tools::isSubmit('submitReorder') && $id_order = (int) Tools::getValue('id_order')) {
            $oldCart = new Cart(Order::getCartIdStatic($id_order, $this->context->customer->id));
            $duplication = $oldCart->duplicate();
            if (!$duplication || !Validate::isLoadedObject($duplication['cart'])) {
                $this->errors[] = $this->trans('Sorry. We cannot renew your order.', array(), 'Shop.Notifications.Error');
            } elseif (!$duplication['success']) {
                $this->errors[] = $this->trans(
                        'Some items are no longer available, and we are unable to renew your order.', array(), 'Shop.Notifications.Error'
                );
            } else {
                $this->context->cookie->id_cart = $duplication['cart']->id;
                $context = $this->context;
                $context->cart = $duplication['cart'];
                CartRule::autoAddToCart($context);
                $this->context->cookie->write();
                Tools::redirect('index.php?controller=order');
            }
        }

        $this->bootstrap();
    }

	/**
     * Author: Chetu Team
     * Func Name: getCheckoutSession
     * Created On: Feb 14, 2018
     * Created For: getCheckoutSession
     */
    protected function getCheckoutSession() {
        $deliveryOptionsFinder = new DeliveryOptionsFinder(
                $this->context, $this->getTranslator(), $this->objectPresenter, new PriceFormatter()
        );

        $session = new CheckoutSession(
                $this->context, $deliveryOptionsFinder
        );

        return $session;
    }

	/**
     * Author: Chetu Team
     * Func Name: bootstrap
     * Created On: Feb 14, 2018
     * Created For: bootstrap
     */
    protected function bootstrap() {
        $translator = $this->getTranslator();

        $session = $this->getCheckoutSession();

        $this->checkoutProcess = new CheckoutProcess(
                $this->context, $session
        );

        $this->checkoutProcess
                ->addStep(new CheckoutPersonalInformationStep(
                        $this->context, $translator, $this->makeLoginForm(), $this->makeCustomerForm()
                ))
                ->addStep(new CheckoutAddressesStep(
                        $this->context, $translator, $this->makeAddressForm()
        ));

        if (!$this->context->cart->isVirtualCart()) {
            $checkoutDeliveryStep = new CheckoutDeliveryStep(
                    $this->context, $translator
            );

            $checkoutDeliveryStep
                    ->setRecyclablePackAllowed((bool) Configuration::get('PS_RECYCLABLE_PACK'))
                    ->setGiftAllowed((bool) Configuration::get('PS_GIFT_WRAPPING'))
                    ->setIncludeTaxes(
                            !Product::getTaxCalculationMethod((int) $this->context->cart->id_customer) && (int) Configuration::get('PS_TAX')
                    )
                    ->setDisplayTaxesLabel((Configuration::get('PS_TAX') && !Configuration::get('AEUC_LABEL_TAX_INC_EXC')))
                    ->setGiftCost(
                            $this->context->cart->getGiftWrappingPrice(
                                    $checkoutDeliveryStep->getIncludeTaxes()
                            )
            );

            $this->checkoutProcess->addStep($checkoutDeliveryStep);
        }

        $this->checkoutProcess
                ->addStep(new CheckoutPaymentStep(
                        $this->context, $translator, new PaymentOptionsFinder(), new ConditionsToApproveFinder(
                        $this->context, $translator
                        )
                ))
        ;
    }

	/**
     * Author: Chetu Team
     * Func Name: saveDataToPersist
     * Created On: Feb 14, 2018
     * Created For: saveDataToPersist
     */
    protected function saveDataToPersist(CheckoutProcess $process) {
        $data = $process->getDataToPersist();
        $data['checksum'] = $this->cartChecksum->generateChecksum($this->context->cart);

        Db::getInstance()->execute(
                'UPDATE ' . _DB_PREFIX_ . 'cart SET checkout_session_data = "' . pSQL(json_encode($data)) . '"
                WHERE id_cart = ' . (int) $this->context->cart->id
        );
    }

	/**
     * Author: Chetu Team
     * Func Name: restorePersistedData
     * Created On: Feb 14, 2018
     * Created For: restorePersistedData
     */
    protected function restorePersistedData(CheckoutProcess $process) {
        $rawData = Db::getInstance()->getValue(
                'SELECT checkout_session_data FROM ' . _DB_PREFIX_ . 'cart WHERE id_cart = ' . (int) $this->context->cart->id
        );
        $data = json_decode($rawData, true);
        if (!is_array($data)) {
            $data = [];
        }

        $checksum = $this->cartChecksum->generateChecksum($this->context->cart);
        if (isset($data['checksum']) && $data['checksum'] === $checksum) {
            $process->restorePersistedData($data);
        }
    }

    /**
     * Author: Chetu Team
     * Func Name: displayAjaxselectDeliveryOption
     * Created On: Feb 14, 2018
     * Created For: displayAjaxselectDeliveryOption
     */
	public function displayAjaxselectDeliveryOption() {
        $cart = $this->cart_presenter->present(
                $this->context->cart
        );

        ob_end_clean();
        header('Content-Type: application/json');
        $this->ajaxDie(Tools::jsonEncode(array(
                    'preview' => $this->render('checkout/_partials/cart-summary', array(
                        'cart' => $cart,
                        'static_token' => Tools::getToken(false),
                    ))
        )));
    }

	/**
     * Author: Chetu Team
     * Func Name: initContent
     * Created On: Feb 14, 2018
     * Created For: initContent
     */
    public function initContent() {
        if (Configuration::isCatalogMode()) {
            Tools::redirect('index.php');
        }

        parent::initContent();

        $this->restorePersistedData($this->checkoutProcess);
        $this->checkoutProcess->handleRequest(
                Tools::getAllValues()
        );

        $presentedCart = $this->cart_presenter->present($this->context->cart);

        if (count($presentedCart['products']) <= 0 || $presentedCart['minimalPurchaseRequired']) {
            Tools::redirect('index.php?controller=cart');
        }

        $this->checkoutProcess
                ->setNextStepReachable()
                ->markCurrentStep()
                ->invalidateAllStepsAfterCurrent();

        $this->saveDataToPersist($this->checkoutProcess);

        if (!$this->checkoutProcess->hasErrors()) {
            if ($_SERVER['REQUEST_METHOD'] !== 'GET' && !$this->ajax) {
                return $this->redirectWithNotifications(
                                $this->checkoutProcess->getCheckoutSession()->getCheckoutURL()
                );
            }
        }
        $instore_pickup = 0;
        $ship = 0;
        foreach ($presentedCart['products'] as $p) {
            $carriers = Product::getCarriersId((int) $p['id_product'], $this->context->shop->id);
            foreach ($carriers as $carrier) {
                if ($carrier['id_carrier'] == 30) {
                    $instore_pickup = $instore_pickup + 1;
                }
                if ($carrier['id_carrier'] == 32) {
                    $ship = $ship + 1;
                }
            }
        }
        $presentedCart['instore_pickup'] = $instore_pickup;
        $presentedCart['ship'] = $ship;

        $this->context->smarty->assign([
            'checkout_process' => new RenderableProxy($this->checkoutProcess),
            'cart' => $presentedCart,
        ]);
        $this->setTemplate('checkout/checkout');
    }

}
