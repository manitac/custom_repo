<?php

/**
 * OrderConfirmationController
 * overriding OrderConfirmationController php file
 */
class OrderConfirmationController extends OrderConfirmationControllerCore {

    /**
     * Author: Chetu Team
     * Func Name: initContent
     * Created On: Feb 14, 2018
     * Created For: initContent
     */
    public function initContent() {
        if (Configuration::isCatalogMode()) {
            Tools::redirect('index.php');
        }

        $order = new Order(Order::getIdByCartId((int) ($this->id_cart)));
        $presentedOrder = $this->order_presenter->present($order);
        $register_form = $this
                ->makeCustomerForm()
                ->setGuestAllowed(false)
                ->fillWith(Tools::getAllValues());

        parent::initContent();

        //calculate the emailage score for a customer
		$is_enabled = Module::isEnabled('emailAge');
		$EAScore = 'good';
		if($is_enabled) {
			//Get user current status from database
		    $QueryResu = Db::getInstance()->getRow('select REPLACE(REPLACE(case_status, 1, "Fraud") , 2, "Good") as status from ' . _DB_PREFIX_ . 'emailage_status where id_user = "'.$this->context->customer->id.'"');
			// get emailage score from database
			$querySql = 'SELECT `id_emailAge`,`EA_SCORE` FROM `' . _DB_PREFIX_ . 'emailage` Where id_customer=' . $this->context->customer->id . ' order by id_emailAge desc limit 1';
			$EAScoreResult = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($querySql);
			if($QueryResu['status'] == 'Good') {
			    $EAScore = 'good';
			}
			else {
				if ($EAScoreResult[0]['EA_SCORE'] > Configuration::get('EMAILAGE_ACCOUNT_ORDER_CANCELLED_SCORE', true)) {
					 $EAScore = 'review';
					 $EAScase = 'cancel';
				 } else {
					 $EAScore = 'good';
				 }
			 }
			$this->context->cookie->__set('emailAgeExecution', 0);
		}

        $this->context->smarty->assign(array(
            'HOOK_ORDER_CONFIRMATION' => $this->displayOrderConfirmation($order),
            'HOOK_PAYMENT_RETURN' => $this->displayPaymentReturn($order),
            'order' => $presentedOrder,
            'register_form' => $register_form,
            'EAScore' => $EAScore,
			'case_type'=>$EAScase,
        ));

        if ($this->context->customer->is_guest) {
            /* If guest we clear the cookie for security reason */
            $this->context->customer->mylogout();
        }
        $this->setTemplate('checkout/order-confirmation');
    }

}
