<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Fastbay Cron - %s'] = '';

?>