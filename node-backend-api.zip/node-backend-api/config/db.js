module.exports = {
  // url : 'mongodb://manita:manita123@ds149404.mlab.com:49404/todo_app',
   url:'mongodb://127.0.0.1:27017/userauth',
   //tokenExpireSeconds :8000,
   secret : "secret-userauth",
   host: 'http://192.168.6.218:3001'
};