let mongoose = require ('mongoose'),
  Schema = mongoose.Schema,
  postimgSchema = new Schema ({
     imgUrl : {
      type:String
    },
    post: { type: Schema.Types.ObjectId, ref: 'post' },
    createdAt: {
      type: Date, 
      default: Date.now
    },
    updatedAt: {
      type: Date, 
      default: Date.now
    }
  })

  postimgSchema.methods.detail = function () {
    return {
      _id: this._id,
      imgUrl: this.imgUrl
    };
  }

  module.exports = mongoose.model('postimgs', postimgSchema);