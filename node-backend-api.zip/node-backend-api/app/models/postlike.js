let mongoose = require ('mongoose'),
  Schema = mongoose.Schema,
  postlikeSchema = new Schema ({
    userId : { type: Schema.Types.ObjectId, ref: 'user' },
    postId: { type: Schema.Types.ObjectId, ref: 'post' },
    createdAt: {
      type: Date, 
      default: Date.now
    }
  })


  module.exports = mongoose.model('postlikes', postlikeSchema);