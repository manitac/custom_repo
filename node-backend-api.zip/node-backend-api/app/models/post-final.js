let mongoose = require ('mongoose'),
  Schema = mongoose.Schema,
  postSchema = new Schema ({
    title: {
      required:[true, '{PATH} is required'],
      trim:true,
      type:String,
    },
    desc: {
      required:[true, '{PATH} is required'],
      trim:true,
      type:String,
    },
    videoUrl : {
      type:String
    },
    user: { type: Schema.Types.ObjectId, ref: 'user' },
    createdAt: {
      type: Date, 
      default: Date.now
    },
    updatedAt: {
      type: Date, 
      default: Date.now
    }
  })

  postSchema.methods.detail = function () {
    return {
      _id: this._id,
      title: this.title,
      desc: this.desc,
     // images:this.constructor().populate('postimgs'),
      videoUrl:this.videoUrl
    };
  }

  module.exports = mongoose.model('posts', postSchema);