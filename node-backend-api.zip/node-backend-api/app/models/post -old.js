let mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    postSchema = new Schema({
        title: {
            required: [true, '{PATH} is required'],
            type: String,
        },
        desc: {
            required: [true, '{PATH} is required'],
            type: String,
        },
        videoUrl: {
            type: String
        },
        images: { type: Object, default: [] },
        user: { type: Schema.Types.ObjectId, ref: 'user' },
        createdAt: {
            type: Date,
            default: Date.now
        },
        updatedAt: {
            type: Date,
            default: Date.now
        }
    })



module.exports = mongoose.model('posts', postSchema);