const models = require('../models'),
    multer = require('multer');
var ObjectId = require('mongodb').ObjectID;

var storage = multer.diskStorage({
    destination: function(req, file, callback) {
        console.log('type');
        console.log(file.type);
        callback(null, './uploads/posts');
    },
    filename: function(req, file, callback) {
        callback(null, file.fieldname + '-' + Date.now());
    }
});

var uploadFile = multer({ storage: storage }).any();
const fs = require('fs');



/**
 * Method to add post
 */
let uploadpost = (req, res) => {

    uploadFile(req, res, function(err) {
        if (err) res.status(500).send({ status: false, message: 'Error uploading file.', errors: err.code });
        if (req.files && req.files.length) {
            let files = req.files.map(file => ({ url: file.path, type: file.mimetype }))
            models.post.create(Object.assign(req.body, { images: files, user: req.user._id }))
                .then(post => res.status(200).send({ status: true, message: 'Post added successfully', data: post }))
                .catch(err => res.status(500).send({ status: false, message: 'Error uploading file.', errors: err.code }))
        }
    })
}



/**
 * Method to list post
 */

let listPosts = (req, res) => {
    // console.log(req.user._id);

    let query = { user: req.user._id };
    (models.post).find()
        .sort({
            id: 'desc'
        }).exec(function(err, posts) {
            if (err) return res.status(500).send({ status: false, message: 'unable to find list of posts', error: err });

            return res.status(200).send({ status: true, message: 'posts list successfully found', data: posts });

        })
}



/**
 * Get post data
 */

let getpostdata = (req, res) => {
    let { _id } = req.params;
    models.post.aggregate([
            { $match: { "_id": ObjectId(_id) } },
            {
                $lookup: {
                    from: "postlikes",
                    localField: "_id",
                    foreignField: "postId",
                    as: "likes"
                }
            }
        ]).then(result => {
            res.status(200).send({ status: true, message: 'post data successfully found', data: result })
        })
        .catch(err => res.status(500).send({ status: false, message: 'unable to find post data', error: err }))
}
/**
 * Delete post image
 */

let delpostimg = (req, res) => {
    let _id = ((req.params._id).trim());

    (models.postimg).findByIdAndDelete(req.params._id, (err, data) => {
        if (err) return res.status(500).send({ status: false, message: 'unable to delete image', error: err });

        return res.status(200).send({ status: true, message: 'post image successfully deleted', data: {} });
    });


}


/**
 * like post
 */

let likeunlikepost = (req, res) => {
    let userId = req.user._id;
    let { postId } = req.body;
    (models.postlike).findOne({ userId: ObjectId(userId), postId: ObjectId(postId) }, (err, posts) => {
        if (err) return res.status(422).send({ status: false, message: 'post like not found', errors: err.message });
        else if (posts) {
            (models.postlike).deleteOne({ userId: ObjectId(userId), postId: ObjectId(postId) }, (err, posts) => {
                if (err) return res.status(422).send({ status: false, message: 'post like not deleted', errors: err.message });
                else return res.status(200).send({ status: true, message: 'Post liked deleted successfully'});
            })
        }
        else {
            models.postlike.create({ userId, postId }, (err, data) => {
                if (err) return res.status(422).send({ status: false, message: 'post not liked', errors: err.message });
                else return res.status(200).send({ status: true, message: 'Post liked successfully', data });
            })
        }
    });

}


/**
 * Delete post like
 */

let delpostlike = (req, res) => {
    (models.postlike).findByIdAndDelete(req.params._id, (err, data) => {
        if (err) return res.status(500).send({ status: false, message: 'unable to delete post like', error: err });

        return res.status(200).send({ status: true, message: 'post like successfully deleted', data: {} });
    });


}

module.exports = {
    uploadpost: uploadpost,
    allposts: listPosts,
    getpostdata: getpostdata,
    delpostimg: delpostimg,
    likeunlikepost: likeunlikepost,
    delpostlike: delpostlike
}