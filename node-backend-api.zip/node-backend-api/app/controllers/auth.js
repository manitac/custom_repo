 const models = require ('../models'),
      jwt = require('jsonwebtoken'),
      config = require ('../../config/db');

/**
 * Method to login
*/
var login = (req, res) => {
  (models.user).findOne({email: req.body.email}, (err, user) => {
    if (err)
      return res.status(500).send({status: false, message: 'unable to login', errors: err});

    if (!user)
      return res.status(404).send({status: false, message: 'user not found', errors: 'Authentication failed. User not found.'});
      // check if password matches
      if (user.comparePassword(req.body.password)) {
        
        var token = jwt.sign({_id: user._id}, config.secret);

        return res.status(200).send ({status: true, message: 'user successfully login', data: {_id: user._id, type: 'JWT', token: token}});
      }

      return res.status(422).send({status: false, message: 'invalid password', errors: 'Authentication failed. Wrong password.'});
  });
}

module.exports = {
  login:login
}