const models = require('../models'),
    multer = require('multer');

var storage = multer.diskStorage({
    destination: function(req, file, callback) {
        console.log('type');
           console.log(file.type);
        callback(null, './uploads/posts');
    },
    filename: function(req, file, callback) {
        callback(null, file.fieldname + '-' + Date.now());
    }
});

var uploadFile = multer({ storage: storage }).any();
const fs = require('fs');

/**
 * Method uploadImg
 */

// image path for uploading image
// const STORAGE = (uploadPath = '') => {
//     return multer.diskStorage({
//         destination: function(req, file, callback) {
//             let dest = `uploads/${uploadPath}`;
//             mkdirp.sync(dest);
//             callback(null, dest);
//         },
//         filename: function(req, file, callback) {
//             var fileUniquename = Date.now();
//             callback(null, fileUniquename + path.extname(file.originalname));
//         }
//     });
// }

// multer({ storage: STORAGE('product') }).any('file'),
let uploadImg = (req, res) => {

    uploadFile(req, res, function(err) {
      console.log(req.file);
        if (err)
            return res.status(500).send({ status: false, message: 'Error uploading file.', errors: err.code });
        // send success
        return res.status(200).send({ status: true, message: 'Image successfully uploaded', data: { path: req.file.path } });
    });
}

/**
 * Method to add post
 */
let addPost = (req, res) => {

    let data = req.body;
    data['user'] = req.user._id;
    console.log(data);
    let post = new models.post(data);

    // save user data
    post.save((err, data) => {
        console.log(data);
        if (err)
            return res.status(422).send({ status: false, message: 'unable to add post', errors: err.message });

        return res.status(200).send({ status: true, message: 'Post added successfully', data: { Id: data._id } });

    })
}

/**
 * Method to add post
 */
let uploadpost = (req, res) => {

    uploadFile(req, res, function(err) {
        if (err) res.status(500).send({ status: false, message: 'Error uploading file.', errors: err.code });
        if (req.files && req.files.length) {
            let files = req.files.map(file => ({ url: file.path, type: file.mimetype }))
            models.post.create(Object.assign(req.body, { images: files, user: req.user._id }))
                .then(post => res.status(200).send({ status: true, message: 'Post added successfully', data: post }))
                .catch(err => res.status(500).send({ status: false, message: 'Error uploading file.', errors: err.code }))
        }
    })
}


let savepostimg = (req, res) => {

    let data = [];
    data['imgUrl'] = req.body['path'];
    data['post'] = req.body['post_id'];

    let postimg = new models.postimg(data);

    // save user data
    postimg.save((err, data) => {
        console.log(data);
        if (err)
            return res.status(422).send({ status: false, message: 'post images url not upadated', errors: err.message });

        return res.status(200).send({ status: true, message: 'Post add successfully', data: { Id: data._id } });

    })
}
/**
 * Method to list post
 */

let listPosts = (req, res) => {
  console.log(req.user._id);

    let query = { user: req.user._id };
    (models.post).find(query)
        .sort({
            id: 'desc'
        }).exec(function(err, posts) {
            if (err) return res.status(500).send({ status: false, message: 'unable to find list of posts', error: err });

            return res.status(200).send({ status: true, message: 'posts list successfully found', data: posts });

        })
}



/**
 * Get Image
 */

let getpostimg = (req, res) => {
    let _id = ((req.params._id).trim());
    (models.postimg).findById(_id, (err, postimg) => {
        if (postimg && postimg.imgUrl) {
            return fetchImg(res, postimg.imgUrl);
        } else fetchImg(res);
    });

}


/**
 * Read Image
 */

let fetchImg = (res, path) => {
    let image = fs.readFileSync(path);
    res.writeHead(200, { 'Content-Type': 'image/*' });
    return res.end(image, 'binary');
}



/**
 * Get post image data
 */

let getpostimgdata = (req, res) => {
    let _id = ((req.params._id).trim());

    let query = { post: _id };
    (models.postimg).find(query, (err, result) => {
        if (err) return res.status(500).send({ status: false, message: 'unable to find list of post images', error: err });
        return res.status(200).send({ status: true, message: 'post images list successfully found', data: result });
    });

}
/**
 * Get post image data
 */

let getpostdata = (req, res) => {
    let _id = ((req.params._id).trim());

    let query = { _id: _id };
    (models.post).find(query, (err, result) => {
        console.log(result);
        if (err) return res.status(500).send({ status: false, message: 'unable to find list of post images', error: err });
        return res.status(200).send({ status: true, message: 'post images list successfully found', data: result });
    });

}
/**
 * Delete post image
 */

let delpostimg = (req, res) => {
    let _id = ((req.params._id).trim());

    (models.postimg).findByIdAndDelete(req.params._id, (err, data) => {
        if (err) return res.status(500).send({ status: false, message: 'unable to delete image', error: err });

        return res.status(200).send({ status: true, message: 'post image successfully deleted', data: {} });
    });


}

module.exports = {
    uploadpostimg: uploadImg,
    addpost: addPost,
    uploadpost: uploadpost,
    allposts: listPosts,
    getpostimgdata: getpostimgdata,
    savepostimg: savepostimg,
    getpostimg: getpostimg,
    getpostdata: getpostdata,
    delpostimg: delpostimg,
   // getimg:getimg
}