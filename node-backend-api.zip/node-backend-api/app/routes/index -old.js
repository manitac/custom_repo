const controllers = require ('../controllers');

module.exports = function(app, passport) {
	
	/**
   * Routes
   */
	app.get ('/', (req, res) => {
			return res.status(200).send({status: true, message: 'application successfully working'})
	});
 	  app.post ('/signup', controllers.account.signup);
  	  app.post ('/login', controllers.auth.login);
	  app.get('/user/:_id', passport.authenticate('jwt', { session: false}), controllers.users.get);
 	  app.put ('/user/:_id', passport.authenticate('jwt', { session: false}), controllers.users.update);
	  app.post ('/image', controllers.users.uploadimage);
	  app.get ('/image/:type/:_id', controllers.users.getimage);
	/*  app.post ('/uploadpostimg', controllers.posts.uploadpostimg);
	  app.post ('/savepostimg', controllers.posts.savepostimg);
	  app.get ('/getpostimg/:_id', controllers.posts.getpostimg);
	  app.post ('/addpost', passport.authenticate('jwt', { session: false}),controllers.posts.addpost);*/
	  app.get('/posts', passport.authenticate('jwt', { session: false}), controllers.posts.allposts);
	 /* app.get('/getpostimgdata/:_id', controllers.posts.getpostimgdata);*/
	  app.get('/getindividualpost/:_id', controllers.posts.getpostdata);
	  app.delete('/deletepostimg/:_id', controllers.posts.delpostimg);

	  app.post ('/uploadpost', passport.authenticate('jwt', { session: false}),controllers.posts.uploadpost);

	  //app.get ('/getimg/:url', controllers.posts.getimg);

	
};