import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import axios from 'axios';
import '../App.css';
import { 
  TextField,
  AppBar,
  RaisedButton,
  } from 'material-ui';
import { Link , withRouter } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import Navbar from './Navbar';

class Login extends Component {
	constructor(props){
		  super(props);
		  this.state={
			  username:'',
			  password:'',
			  rememberMe: false,
			  fireRedirect: false,
			  remember:''
		  }
	 }

	 componentDidMount() {
	 	this.setState({
	          username: localStorage.getItem('username'),
	          password: localStorage.getItem('password'),
	          remember: localStorage.getItem('remember')
	    });
	 }

	 
	handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

	toggleRememberMe = (event) => {
		 if(event.target.checked == true){
		 	this.setState({
	          rememberMe: true
	      });
		}
    }

	handleSubmit = (event) =>{

		const self = this;
		event.preventDefault();

		if(this.state.rememberMe == true){
			localStorage.setItem('username',this.state.username);
			localStorage.setItem('password',this.state.password);
			localStorage.setItem('remember','checked');
		}else{
			localStorage.removeItem('username');
			localStorage.removeItem('password');
			localStorage.removeItem('remember');
		}
		
		var apiBaseUrl = "http://192.168.6.218:3001/login";
		
		var data ={
		 "email":this.state.username,
		 "password":this.state.password,
		 }

		 axios.post(apiBaseUrl, data)
		 .then(function (response) {
			 if(response.data.status == true){
			 	console.log("Login successful");
			 	localStorage.setItem('token',response.data.data.token);
			 	localStorage.setItem('_id',response.data.data._id);
			 	self.props.history.push('/profile');
			 }else{
			 	alert("Username does not exist "+response.data.code);
			 }
		 }).catch(function (error) {
		 	alert("Login failed");

		 });
	
		
 		
	}
	

render() {

    return (
    	<div>
    	<Navbar/>
	    <div className="login">
	        <MuiThemeProvider>
	          	<div>
	          		<AppBar title="Login" />
	          		<br/>
		             <br/>
		           <ValidatorForm
		            ref="form" onSubmit={this.handleSubmit} >
		           	
		               <TextValidator
		                 label = "Email"
		                 name="username"
		                 type="email"
		                  validators={['required']}
		                  errorMessages={[ 'email field is required']}
		                  onChange={this.handleChange}
		                  value={this.state.username}
		             />
		             <br/>
		             <br/>
		               <TextValidator
	                    label="Password"
	                    onChange={this.handleChange}
	                    name="password"
	                    type="password"
	                    validators={['required']}
	                    errorMessages={['this field is required']}
	                    value={this.state.password}
	                />
		             <br/>
				<input type="checkbox"  className="form-control" id="rememberMe" defaultChecked = {localStorage.getItem('remember')}  ref="rememberMe" placeholder="Remember Me" onChange={this.toggleRememberMe} />
			     <label htmlFor="rememberMe" className="remember-label">Remember me</label> <br />
		            <Button type="submit" style={style}>Submit</Button>
		            <Link to="/register" className="register-link">Register here</Link>
		        	</ValidatorForm>
	        	</div>
			</MuiThemeProvider>
	    </div>
	    </div>
    );
  }
}
const style = {
 margin: 15,
};
export default withRouter(Login)