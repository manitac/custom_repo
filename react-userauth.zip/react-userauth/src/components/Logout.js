import React, { Component } from 'react';
import Navbar from './Navbar';
import { Link , withRouter } from 'react-router-dom';
class Logout extends Component {

	componentDidMount() {
			localStorage.removeItem('token');
			localStorage.removeItem('_id');
			this.props.history.push('/')
	 }

	render() {
		    return (
			<div>
	    		<Navbar/>
		    	<div className="logout">
		  
		    	 	<header className="App-header">
		    			you are logged out now..
		    		</header>
		    	</div>
		    </div>
		    );
		}

}
export default  withRouter(Logout)