import React, { Component } from 'react';
import Navbar from '../Navbar';
import PostImages from './PostImages';
import { Link, withRouter } from 'react-router-dom';
export default class PostDetail extends Component {

    render() {
              const data = this.props.posts;
              
              const  posts = Object.keys(data).map(
                        (key) => (

                           <div className="post">
                                <h6> Title: {data[key].title}</h6>
                                <h6> Desc: {data[key].desc}</h6>
                                <h6>Video: </h6><iframe src={data[key].videoUrl} autoPlay></iframe><br/>
                                <PostImages post_id={data[key]._id} />
                                <Link to="/post/5c3c812842eec0041c2c6f1d" className="login-link">view</Link>
                            </div>
                      )
              );
        
        return (
                <div>
                          {posts}
                      
                </div>
        );
    }
}