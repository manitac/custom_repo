import React, { Component } from 'react';
import Navbar from '../Navbar';
import PostImages from './PostImages';
import axios from 'axios';

class SinglePost extends Component {

  constructor(props){
      super(props);
      this.state = {
        _id:'',
        title:'',
        desc:'',
        videoUrl:''
      }
    }

    componentDidMount() {
        const self = this;
         axios.get('http://192.168.6.218:3001/getindividualpost/'+this.props.match.params.id )
         .then(function (response) {
                self.setState({
                       _id : response.data.data[0]._id,
                        title : response.data.data[0].title,
                        desc : response.data.data[0].desc,
                        videoUrl : response.data.data[0].videoUrl
                });
        }).catch(function (error) {
            console.log("Not found");
         });
    }


    render() {      

           
                     
        return (
            <div>
                  <Navbar/>
                  <header className="App-header posts-header">

                            <h4>Post Details</h4>
                            <div className="post">
                                <h6> Title: {this.state.title}</h6>
                                <h6> Desc: {this.state.desc}</h6>
                                <h6>Video: </h6><iframe src={this.state.videoUrl} autoPlay></iframe><br/>
                              
                  
                            </div>
                             
                  </header>
                   
            </div>
        );
    }
}
export default SinglePost