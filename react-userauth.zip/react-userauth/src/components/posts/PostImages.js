import React, { Component } from 'react';
import axios from 'axios';
import Navbar from '../Navbar';
import { Link , withRouter } from 'react-router-dom';

class PostImages extends Component {
    constructor(props){
        super(props);
        this.state={
          imgs_data:'',
        }
    }
    componentDidMount() {
       //const self = this;
        const token = localStorage.getItem('token');
         axios.get('http://192.168.6.218:3001/getpostimgdata/'+this.props.post_id)
         .then( (response) => {

                this.setState({
                    imgs_data: response.data.data
                })
        })
     }

    handleClick = (e) => {
      const self = this;
      axios.delete('http://192.168.6.218:3001/deletepostimg/'+e.target.id)
         .then( (response) => {
            if(response.data.status == true){
              alert("image deleted successfully");
              self.props.history.push('/view-posts');
            }

        })
    }


    render() {
        var data = this.state.imgs_data ;
        var url = 'http://192.168.6.218:3001/getpostimg/';
        var image = '';
        if(data !=''){
            image = Object.keys(data).map(
                    (key) => (
                              <div> <img src={url+data[key]._id} />
                                <span onClick={this.handleClick} id={data[key]._id}>delete</span>
                               </div>
                            
                      )
                );
        }
           
        return (
                    <div className="image">
                        {image}
                    </div>
        );
    }
}
export default withRouter(PostImages);