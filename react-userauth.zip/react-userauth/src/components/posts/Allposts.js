import React, { Component } from 'react';
import axios from 'axios';
import Navbar from '../Navbar';
import PostDetail from './PostDetail';

export default class Allposts extends Component {

    constructor() {
        super();

        this.state = {
            posts: []
        };
    }

    componentDidMount() {

        const self = this;
        const token = localStorage.getItem('token');
         axios.get('http://192.168.6.218:3001/posts', { headers: {"Authorization" : `JWT ${token}`} } )
         .then(function (response) {
                self.setState({
                       posts: response.data.data
                });
        }).catch(function (error) {
            console.log("Not found");
         });
    }

    render() {
 
        
        return (
        		<div>
					<Navbar/>
					<header className="App-header posts-header">

						<h4>All Posts</h4>
					
			    		<div className="app-posts">
	                        <PostDetail posts={this.state.posts} />

	                    </div>
                    </header>
	                 
                </div>
        );
    }
}