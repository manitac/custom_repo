import React, { Component } from 'react';
import Navbar from '../Navbar';
import axios from 'axios';
import { Link , withRouter } from 'react-router-dom'; 

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Button from '@material-ui/core/Button';
import { 
  TextField,
  AppBar,
  RaisedButton,
  Dialog,
  Checkbox,

  } from 'material-ui';



const BASE_URL = 'http://192.168.6.218:3001';

class Addpost extends Component {

	constructor(props) {
		super(props);
		this.state = {
			title:'',
			desc:'',
			images: [],
			imageUrls: [],
			message: '',
			img_path:[],
			videoUrl:'',
			embeddedlink:''
		}
	}

	handleChange = (event) =>{

        this.setState({
        	[event.target.name] : event.target.value
        });

	}
	
	showVideo = (event) =>{
		this.setState({
							videoUrl : event.target.value
		});
		var url = event.target.value;
		 

	    if (url.indexOf('youtube.com') !== -1) {
	        var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
		    var match = url.match(regExp);
		   
		    if (match && match[2].length == 11) {
			    this.setState({ embeddedlink : "//www.youtube.com/embed/"+match[2] }); 
			} 
	    }else if (url.indexOf('vimeo.com') !== -1) {
		    	var afterSlashChars = url.match(/\/([^\/]+)\/?$/)[1];
				this.setState({ embeddedlink : "https://player.vimeo.com/video/"+afterSlashChars }); 

	    }else{
	    	this.setState({embeddedlink : ''}); 
	    }
		
	}

	selectImages = (event) => {

			let images = []
			for (var i = 0; i < event.target.files.length; i++) {
				images[i] = event.target.files.item(i);
			}
			images = images.filter(image => image.name.match(/\.(jpg|jpeg|png|gif)$/))
			let message = `${images.length} valid image(s) selected`
			this.setState({ images, message });
	}
	handleSubmit = (event) => {
		if(this.state.embeddedlink == ''){
			event.preventDefault();
			alert("please add url of youtbe or vimeo videos only")
		}else{
				const uploaders = this.state.images.map(image => {
				const data = new FormData();

				data.append("image", image, image.name);
				// Make an AJAX upload request using Axios

				return axios.post(BASE_URL + '/uploadpostimg', data)
					.then(response => {
						this.setState({
							img_path: [...this.state.img_path, response.data.data.path],
						});
					}).catch(function (error) {
						//alert(error);
					     alert("upload failed"); 
					 });
			});
			// Once all the files are uploaded 
			axios.all(uploaders).then(() => {

				
					const imgs_path = this.state.img_path;

					const self = this;

					var data = {
				   	 	"title": this.state.title,
	         			"desc":this.state.desc,
	         			"images": imgs_path,
	         			"videoUrl":this.state.embeddedlink,
	         			"Url":[{ 
	         					"url":"test.com"
							}
	         			]
				    }
				const token = localStorage.getItem('token');
				axios.post(BASE_URL + '/addpost', data, { headers: {"Authorization" : `JWT ${token}`} })
					.then(response => {
						const post_id = response.data.data.Id;

						this.state.img_path.forEach(function(element) {
				            var data = {
				            			"post_id": post_id,
				                      	"path": element
				                    }
				            const self = this;
				             axios.post('http://192.168.6.218:3001/savepostimg',data)
				                .then(function (response) {
				                        console.log(response.image);
				                }).catch(function (error) {
				                console.log("Not found");
				             });
				        });
				        alert('post added successfully');
					});
			});
		}
	}
	render() {
		var iframe = '';
		if(this.state.embeddedlink !=''){
			var iframe =  <iframe src={this.state.embeddedlink} autoPlay></iframe>
		}
		return (
			<div>
				<Navbar/>
				<div className="Uploadimg">
					<h2>Add Post</h2><hr/>

					 <ValidatorForm onSubmit={this.handleSubmit} >

					             <TextValidator
					                 label = "Post Title"
					                 name="title"
					                 type="text"
					                  validators={['required']}
					                  errorMessages={[ 'this field is required']}
					                  onChange={this.handleChange}
					                   value={this.state.title}
					             />
					              <br/>
					              <br/>
					              <TextValidator
					                 label = "Description"
					                 name="desc"
					                 type="text"
					                  validators={['required']}
					                  errorMessages={[ 'this field is required']}
					                  onChange={this.handleChange}
					                  value={this.state.desc}
					             />
					              <br/>
					              <br/>
					              <TextValidator
					                 label = "Video URL"
					                 name="videoUrl"
					                 type="text"
					                  onChange={this.showVideo}
					                  value={this.state.videoUrl}
					             />
					              <br/>
					               <br/>
					             		{iframe}
									<br/><br/><div className="image">
											<input className="form-control " type="file" 
											onChange={this.selectImages} multiple/>
										</div>
										<p className="text-info">{this.state.message}</p>
										<br/>
										<div className="col-sm-4">
											
											<Button type="submit">Submit</Button>
										</div>
					</ValidatorForm>
				</div>
			</div>
		);
	}
}
export default withRouter(Addpost);