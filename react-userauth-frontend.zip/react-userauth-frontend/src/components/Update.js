import React, { Component } from 'react';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import axios from 'axios';
import '../App.css';
import { 
  TextField,
  AppBar,
  RaisedButton,
  } from 'material-ui';
import { Link , withRouter } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import Navbar from './Navbar';

class Update extends Component {
  constructor(props){
      super(props);
      this.state={
        _id:'',
        first_name:'',
        last_name:'',
        email:'',
        avatar:'',
      }
    }
  componentDidMount() {
    if(!localStorage.getItem('token')){
      this.props.history.push('/')
    }
    const self = this;
    const token = localStorage.getItem('token');
    axios.get('http://192.168.6.218:3001/user/'+localStorage.getItem('_id'), { headers: {"Authorization" : `JWT ${token}`} })
     .then(function (response) {
        self.setState({
                _id : response.data.data.user._id,
                first_name : response.data.data.user.first_name,
                last_name : response.data.data.user.last_name,
                email : response.data.data.user.email,
                avatar : response.data.data.user.avatar,

          });
           localStorage.setItem('_id',response.data.data.user._id);
    }).catch(function (error) {
      console.log("user details not found");
     });
   }

   handleChange = (event) => {
        this.setState({ 
          [event.target.name] : event.target.value
        });
    }

handleSubmit = (event) =>{
       const self = this;
        event.preventDefault();
        var apiBaseUrl = "http://192.168.6.218:3001";
        var data={
          "first_name": this.state.first_name,
          "last_name":this.state.last_name
        };
        const token = localStorage.getItem('token');
        axios.put('http://192.168.6.218:3001/user/'+localStorage.getItem('_id'),data, { headers: {"Authorization" : `JWT ${token}`} } )
       .then(function (response) {
         if(response.data.status == true){
            alert("updated success");
            self.props.history.push('/profile');
         }else{
            alert("can't register "+response.data.code);
         }
       })
       .catch(function (error) {
         alert("can not update. failed"); 
       });
}



  render() {
        return (
          <div>
      <Navbar/>
      <div className="register">
        <MuiThemeProvider>
          <div>
          <AppBar
             title="Update Profile"
           /><br/>

           <ValidatorForm onSubmit={this.handleSubmit} >

             <TextValidator
                 label = "First Name"
                 name="first_name"
                 type="text"
                  validators={['required']}
                  errorMessages={[ 'this field is required']}
                  onChange={this.handleChange}
                    value={this.state.first_name}
             />
              <br/>
              <br/>
              <TextValidator
                 label = "last Name"
                 name="last_name"
                 type="text"
                  validators={['required']}
                  errorMessages={[ 'this field is required']}
                  onChange={this.handleChange}
                  value={this.state.last_name}
             />
              <br/>
              <br/>
              <Button type="submit">Submit</Button>
               </ValidatorForm>
           
          </div>
         </MuiThemeProvider>
      </div>
      </div>
        );
    }

}
export default withRouter(Update)