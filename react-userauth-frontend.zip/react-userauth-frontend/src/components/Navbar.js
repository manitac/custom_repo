import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import '../App.css';
export default class Navbar extends Component {

	render() {

		 	const isLoggedIn = localStorage.getItem('token');
		 	
	    	var button;

	    	if (isLoggedIn) {
	        	button = <div><Link to ="/logout">Logout</Link><Link to='/profile'>ViewProfile</Link>
				<Link to='/update-profile'>Update Profile</Link>
				<Link to='/addpost'>Add Post</Link>
				<Link to='/view-posts'>All Posts</Link></div>;
		    } else {
		        button = <div><Link to ="/login">login</Link>
		    			<Link to='/register'>Register</Link></div>;
		    }
		    return (

		    	<div className="Navbar">

		    			{button}
		    			
		    	</div>
		    );
		}
}