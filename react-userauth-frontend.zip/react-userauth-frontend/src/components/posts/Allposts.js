import React, { Component } from 'react';
import axios from 'axios';
import Navbar from '../Navbar';
import PostDetail from './PostDetail';
import { Link, withRouter } from 'react-router-dom';

export default class Allposts extends Component {

    constructor() {
        super();

        this.state = {
            posts: ''
        };
    }

    componentDidMount() {
        const self = this;
        const token = localStorage.getItem('token');
        axios.get('http://192.168.6.218:3001/posts', { headers: { "Authorization": `JWT ${token}` } })
            .then(function(response) {
                self.setState({
                    posts: response.data.data
                });
            }).catch(function(error) {
                console.log("Not found");
            });
    }

    render() {

        const data = this.state.posts;

        const posts = Object.keys(data).map(
            (key) => (

                <div className="post">
                                <h6> Title: {data[key].title}</h6>
                                <h6> Desc: {data[key].desc}</h6>
                                <iframe src={data[key].videoUrl} autoPlay></iframe>
                                <Link to={'/post/'+data[key]._id} className="login-link"><h6>View post</h6></Link>
                            </div>
            )
        );

        return (
            <div>
                    <Navbar/>
                    <header className="App-header posts-header">

                        <h4>All Posts</h4>
                    
                        <div className="app-posts">
                            {posts}
                        </div>
                    </header>
                     
                </div>
        );
    }
}