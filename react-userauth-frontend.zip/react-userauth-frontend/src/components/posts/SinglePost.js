import React, { Component } from 'react';
import Navbar from '../Navbar';
import PostImages from './PostImages';
import axios from 'axios';
const token = localStorage.getItem('token');
class SinglePost extends Component {

    constructor(props) {
        super(props);
        this.state = {
            _id: '',
            title: '',
            desc: '',
            videoUrl: '',
            images: '',
            liked: false,
            likes_data:'',
            likes_count:''
        }
    }

    componentDidMount() {
        const self = this;
        axios.get('http://192.168.6.218:3001/getindividualpost/' + this.props.match.params.id)
            .then(function(response) {
                self.setState({
                    _id: response.data.data[0]._id,
                    title: response.data.data[0].title,
                    desc: response.data.data[0].desc,
                    videoUrl: response.data.data[0].videoUrl,
                    images: response.data.data[0].images,
                    likes_data:response.data.data[0].likes,
                    likes_count : Object.keys(response.data.data[0].likes).length
                });
               console.log(self.state);
            }).catch(function(error) {
                console.log("Not found");
            });

    }
  
    
    likeUnlikePost = () => {
        this.setState({
            liked : !this.state.liked 
        })
        const self = this;
        var data = {
            "postId": this.state._id
        }
        axios.post('http://192.168.6.218:3001/likeunlikepost', data, { headers: { "Authorization": `JWT ${token}` } })
            .then(function(response) {
                //alert(JSON.stringify(response.data.data));
                if(response.data.data){
                    self.setState({
                       //likes_data : [...self.state.likes_data,response.data.data],
                       likes_count : self.state.likes_count + 1
                    })
                    //console.log(self.state);
                 }else{
                      self.setState({
                       likes_count : self.state.likes_count-1
                    })
                   //console.log(self.state);
                }
                
            }).catch(function(error) {
                console.log("Not found");
            });
    }

    render() {


        const data = this.state.images;
        var url = 'http://192.168.6.218:3001/';
        const imgs = [];
        const image = Object.keys(data).map(
            (key) => (
                <img src={url+(data[key].url).replace(/\\/g, '/')} />

            )
        );
        const text = this.state.liked ? 'unlike':'like';
        return (

            <div>
                  <Navbar/>
                  <header className="App-header posts-header">

                            <h4>Post Details</h4>
                            <div className="post-detail">
                                <h6> Title: {this.state.title}</h6>
                                <h6> Desc: {this.state.desc}</h6>
                                <h6>Video: </h6><iframe src={this.state.videoUrl} autoPlay></iframe><br/>
                                {image}<br/>
                                <h6>Total likes: {this.state.likes_count}</h6>
                             
                           <button className="btn btn-primary" onClick={this.likeUnlikePost}>
                                    {text}
                                </button>

                                <h6>Comment</h6>
                                <h6> Share</h6>
                            </div>
                             
                  </header>
            </div>
        );
    }
}
export default SinglePost