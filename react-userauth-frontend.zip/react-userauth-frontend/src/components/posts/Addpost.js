import React, { Component } from 'react';
import Navbar from '../Navbar';
import axios from 'axios';
import { Link , withRouter } from 'react-router-dom'; 

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import Button from '@material-ui/core/Button';
import { 
  TextField,
  AppBar,
  RaisedButton,
  Dialog,
  Checkbox,

  } from 'material-ui';



const BASE_URL = 'http://192.168.6.218:3001';

class Addpost extends Component {

	constructor(props) {
		super(props);
		this.state = {
			title:'',
			desc:'',
			images: '',
			message: '',
			videoUrl:'',
			embeddedlink:''
		}
	}

	handleChange = (event) =>{

        this.setState({
        	[event.target.name] : event.target.value
        });

	}
	
	showVideo = (event) =>{
		this.setState({
				videoUrl : event.target.value
		});
		var url = event.target.value;
		if (url.indexOf('youtube.com') !== -1) {
	        var regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
		    var match = url.match(regExp);
		   
		    if (match && match[2].length == 11) {
			    this.setState({ embeddedlink : "//www.youtube.com/embed/"+match[2] }); 
			} 
	    }else if (url.indexOf('vimeo.com') !== -1) {
		    	var afterSlashChars = url.match(/\/([^\/]+)\/?$/)[1];
				this.setState({ embeddedlink : "https://player.vimeo.com/video/"+afterSlashChars }); 

	    }else{
	    	this.setState({embeddedlink : ''}); 
	    }
		
	}

	selectImages = (event) => {

			let images = []
			for (var i = 0; i < event.target.files.length; i++) {
				images[i] = event.target.files.item(i);
			}
			images = images.filter(image => image.name.match(/\.(jpg|jpeg|png|gif)$/))
			let message = `${images.length} valid image(s) selected`
			this.setState({ images, message });
	}

	handleSubmit = (event) => {

		if(this.state.embeddedlink == ''){
			event.preventDefault();
			alert("please add url of youtube or vimeo videos only")
		}else{

			const data = new FormData();
			const token = localStorage.getItem('token');
			this.state.images.map(image => {
				data.append("image", image, image.name);
			});
			data.append("title", this.state.title);
			data.append("desc", this.state.desc);
			data.append("videoUrl", this.state.embeddedlink);
			axios.post(BASE_URL + '/uploadpost', data,{ headers: {"Authorization" : `JWT ${token}`} })
				.then(response => {
					alert("upload success");
				}).catch(function (error) {
				     alert("upload failed"); 
				});
		}
	}
	render() {
		
		var iframe = '';
		if(this.state.embeddedlink !=''){
			var iframe =  <iframe src={this.state.embeddedlink} autoPlay></iframe>
		}
		return (
			<div>
				<Navbar/>
				<div className="Uploadimg">
					<h2>Add Post</h2><hr/>

					 <ValidatorForm onSubmit={this.handleSubmit} >
					 <TextValidator
					                 label = "Post Title"
					                 name="title"
					                 type="text"
					                  validators={['required']}
					                  errorMessages={[ 'this field is required']}
					                  onChange={this.handleChange}
					                   value={this.state.title}
					             />
					              <br/>
					              <br/>
					              <TextValidator
					                 label = "Description"
					                 name="desc"
					                 type="text"
					                  validators={['required']}
					                  errorMessages={[ 'this field is required']}
					                  onChange={this.handleChange}
					                  value={this.state.desc}
					             />
					              <br/>
					              <br/>
					              <TextValidator
					                 label = "Video URL"
					                 name="videoUrl"
					                 type="text"
					                  onChange={this.showVideo}
					                  value={this.state.videoUrl}
					             />
					              <br/>
					               <br/>
	{iframe}
					         
									<br/><br/><div className="image">
											<input className="form-control " type="file" 
											onChange={this.selectImages} multiple/>
										</div>
										<p className="text-info">{this.state.message}</p>
										<br/>
										<div className="col-sm-4">
											
											<Button type="submit">Submit</Button>
										</div>
					</ValidatorForm>
				</div>
			</div>
		);
	}
}
export default withRouter(Addpost);