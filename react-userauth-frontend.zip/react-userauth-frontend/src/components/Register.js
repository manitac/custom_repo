import React, { Component } from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { ValidatorForm, TextValidator} from 'react-material-ui-form-validator';
import axios from 'axios';
import Navbar from './Navbar';
import Login from './Login';
import Button from '@material-ui/core/Button';
import { 
  TextField,
  AppBar,
  RaisedButton,
  Dialog,
  Checkbox,

  } from 'material-ui';

import { Link , withRouter } from 'react-router-dom';

class Register extends Component {

  constructor(props){
      super(props);
      this.state = {
          user:{
            first_name:'',
            last_name:'',
            email:'',
            password:'',
            repeatPassword: ''
          }
        }
    }
  
  componentDidMount() {
        // custom rule will have name 'isPasswordMatch'
        ValidatorForm.addValidationRule('isPasswordMatch', (value) => {
            if (value !== this.state.user.password) {
                return false;
            }
            return true;
        });
    }
 
    handleChange = (event) => {
        const { user } = this.state;
        user[event.target.name] = event.target.value;
        this.setState({ user });
    }
 
    handleSubmit = (event) => {
        const self = this;
        event.preventDefault();
        var apiBaseUrl = "http://192.168.6.218:3001";
        var data={
          "first_name": this.state.user.first_name,
          "last_name":this.state.user.last_name,
          "email":this.state.user.email,
          "password":this.state.user.password
        }

        axios.post(apiBaseUrl+'/signup', data)
       .then(function (response) {
         if(response.data.status == true){
            alert("register success");
            self.props.history.push('/login');
         }else{
            alert("can't register "+response.data.code);
         }
       })
       .catch(function (error) {
         alert("registration failed"); 
       });
    }

  render() {
    const { user } = this.state;
 
    return (
      <div>
      <Navbar/>
      <div className="register">
        <MuiThemeProvider>
          <div>
          <AppBar
             title="Register"
           /><br/>

           <ValidatorForm onSubmit={this.handleSubmit} >

             <TextValidator
                 label = "First Name"
                 name="first_name"
                 type="text"
                  validators={['required']}
                  errorMessages={[ 'this field is required']}
                  onChange={this.handleChange}
                    value={this.state.user.first_name}
             />
              <br/>
              <br/>
              <TextValidator
                 label = "last Name"
                 name="last_name"
                 type="text"
                  validators={['required']}
                  errorMessages={[ 'this field is required']}
                  onChange={this.handleChange}
                  value={this.state.user.last_name}
             />
              <br/>
              <br/>
               <TextValidator
                 label = "Email"
                 name="email"
                 type="email"
                  validators={['required']}
                  errorMessages={[ 'email field is required']}
                  onChange={this.handleChange}
                  value={this.state.user.email}
             />
             <br/>
             <br/>
                <TextValidator
                    label="Password"
                    onChange={this.handleChange}
                    name="password"
                    type="password"
                    validators={['required']}
                    errorMessages={['this field is required']}
                    value={this.state.user.password}
                />
                <br/>
                <br/>
                <TextValidator
                    label="Repeat password"
                    onChange={this.handleChange}
                    name="repeatPassword"
                    type="password"
                    validators={['isPasswordMatch', 'required']}
                    errorMessages={['password mismatch', 'this field is required']}
                    value={this.state.user.repeatPassword}
                />
                <br/>
                <br/>
                
                <Button type="submit">Submit</Button><Link to="/login" className="login-link">Login here</Link>
               </ValidatorForm>
           
          </div>
         </MuiThemeProvider>
      </div>
      </div>
    );
  }
}
const style = {
  margin: 15,
};
export default withRouter(Register);