import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import './App.css';
import Login from './components/Login';
import Logout from './components/Logout';
import Register from './components/Register';
import Navbar from './components/Navbar';
class App extends Component {
  render() {
    const isLoggedIn = localStorage.getItem('username');

    return (
      <div>
        <Navbar/>
        <header className="App-header">Welcome</header>
      </div>
    );
  }
}

export default App;
